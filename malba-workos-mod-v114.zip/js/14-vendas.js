/* ========== [10i] GESTÃO: Comissões + Avaliações (Lojas, admin) ========== */
var CRIT_MEMBRO = [
  {id:'pontualidade',label:'Pontualidade e assiduidade'},
  {id:'atendimento', label:'Qualidade do atendimento'},
  {id:'proatividade',label:'Proatividade'},
  {id:'tarefas',     label:'Cumprimento de tarefas'},
  {id:'postura',     label:'Postura e comportamento'}
];
var CRIT_LOJA = [
  {id:'organizacao', label:'Organização e limpeza'},
  {id:'atendimento', label:'Atendimento ao cliente'},
  {id:'metas',       label:'Cumprimento de metas'},
  {id:'tarefas',     label:'Execução das tarefas'},
  {id:'equipe',      label:'Trabalho em equipe'}
];
var SCALE_LABELS = ['', 'Insuficiente', 'Abaixo do esperado', 'Adequado', 'Bom', 'Excelente'];
// Diagnóstico automático a partir da nota média (referências: Lattice, Leapsome, 9-box)
function diagnostico(nota){
  var n=Number(nota)||0;
  if(n>=4.5) return {key:'exc',    label:'Desempenho excepcional', color:'#16A34A', soft:'rgba(22,163,74,.12)',  rec:'Reconhecer e reter. Ofereça novos desafios e um plano de crescimento.'};
  if(n>=3.5) return {key:'acima',  label:'Acima do esperado',      color:'#0EA5E9', soft:'rgba(14,165,233,.12)', rec:'Bom desempenho consistente. Mantenha e amplie os pontos fortes.'};
  if(n>=2.5) return {key:'ok',     label:'Dentro do esperado',     color:'#3B6FF7', soft:'rgba(59,111,247,.12)', rec:'Atende ao esperado. Combine 1–2 focos de evolução para o próximo ciclo.'};
  if(n>=1.5) return {key:'abaixo', label:'Abaixo do esperado',     color:'#F59E0B', soft:'rgba(245,158,11,.13)', rec:'Requer acompanhamento próximo e um plano de melhoria (PDI) com prazos.'};
  return               {key:'critico',label:'Crítico — ação imediata',color:'#EF4444', soft:'rgba(239,68,68,.12)',  rec:'Feedback formal e plano de recuperação com metas e prazo curto.'};
}
function diagBadge(nota){ var d=diagnostico(nota); return '<span class="diag-badge" style="color:'+d.color+';background:'+d.soft+'">'+d.label+'</span>'; }
function critBarsHTML(notas){
  var arr = Array.isArray(notas) ? notas : [];
  if(!arr.length) return '';
  return '<div class="crit-bars">'+arr.map(function(c){ var nota=Number(c.nota)||0; var pct=Math.round(nota/5*100); var col=nota>0?diagnostico(nota).color:'var(--u-border2)'; return '<div class="crit-bar"><div class="cb-top"><span>'+esc(c.label||'Critério')+'</span><b style="color:'+col+'">'+nota.toFixed(0)+'/5</b></div><div class="cb-track"><span style="width:'+pct+'%;background:'+col+'"></span></div></div>'; }).join('')+'</div>';
}
var MES_ABR = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
function periodoCurto(a){
  var src = a.periodo_inicio || a.data_avaliacao;
  if(src){ var p=String(src).slice(0,10).split('-'); var m=Number(p[1]); var y=String(p[0]).slice(2); if(m>=1&&m<=12) return MES_ABR[m-1]+'/'+y; }
  return a.periodo_label||'—';
}
function avalsDoMembro(memberId){
  return (ST.avaliacoes||[]).filter(function(a){ return a.tipo==='membro' && String(a.member_id)===String(memberId) && a.nota_final!=null; })
    .sort(function(a,b){ return String(a.periodo_inicio||a.data_avaliacao||'').localeCompare(String(b.periodo_inicio||b.data_avaliacao||'')); });
}
// Gráfico de evolução da nota mês a mês (barras no tempo + tendência + variação)
function avalEvolucaoRender(listRaw){
  var arr = (listRaw||[]).filter(function(a){ return a.nota_final!=null; }).slice()
    .sort(function(a,b){ return String(a.periodo_inicio||a.data_avaliacao||'').localeCompare(String(b.periodo_inicio||b.data_avaliacao||'')); });
  if(arr.length < 2) return '';
  var bars = arr.map(function(a, i){
    var nota=Number(a.nota_final)||0; var d=diagnostico(nota); var pct=Math.max(8,Math.round(nota/5*100));
    var prev = i>0 ? (Number(arr[i-1].nota_final)||0) : null;
    var delta = prev!=null ? (nota - prev) : null;
    var deltaHTML='';
    if(delta!=null){ var cls=delta>0.049?'up':(delta<-0.049?'down':'flat'); var ic=delta>0.049?'▲':(delta<-0.049?'▼':'▬'); deltaHTML='<span class="evo-delta '+cls+'">'+ic+' '+(delta>0?'+':'')+delta.toFixed(1)+'</span>'; }
    else deltaHTML='<span class="evo-delta flat">•</span>';
    return '<div class="evo-col" title="'+esc((a.periodo_label||fmtDate(a.data_avaliacao)))+' · '+nota.toFixed(1)+' de 5">'+
      '<div class="evo-bar-wrap"><span class="evo-bar-val">'+nota.toFixed(1)+'</span><div class="evo-bar" style="height:'+pct+'%;background:'+d.color+'"></div></div>'+
      deltaHTML+
      '<div class="evo-lbl">'+esc(periodoCurto(a))+'</div>'+
    '</div>';
  }).join('');
  var first=Number(arr[0].nota_final)||0, last=Number(arr[arr.length-1].nota_final)||0; var diff=last-first;
  var trend = diff>0.2?{t:'Melhorando', c:'#16A34A', ic:'▲'}:(diff<-0.2?{t:'Em queda', c:'#EF4444', ic:'▼'}:{t:'Estável', c:'var(--u-text2)', ic:'▬'});
  var head='<div class="evo-head"><span class="evo-trend" style="color:'+trend.c+'">'+trend.ic+' '+trend.t+'</span><span class="evo-sub">'+arr.length+' avaliações · '+first.toFixed(1)+' → '+last.toFixed(1)+'</span></div>';
  return '<div class="evo-wrap">'+head+'<div class="evo-chart">'+bars+'</div><div class="evo-scale"><span>5</span><span>0</span></div></div>';
}
function membrosDaLoja(lojaId) {
  return ST.members.filter(function(m){ return m.store_unit_id===lojaId && m.is_active!==false; });
}
function lojasGestao() {
  var ls = ST.storeUnits.slice().sort(function(a,b){ return (a.store_number||0)-(b.store_number||0); });
  if (ST.sector==='lojas' && ST.store && !isSuper(ST.session)) ls = ls.filter(function(s){ return s.id===ST.store.id; });
  return ls;
}

/* ========== [12] BOOT ========== */
function getTheme(){ try { return localStorage.getItem('malba_theme')||'light'; } catch(e){ return 'light'; } }
function applyTheme(t){ if(t==='dark') document.documentElement.classList.add('dark'); else document.documentElement.classList.remove('dark'); }
function toggleTheme(){ var t=getTheme()==='dark'?'light':'dark'; try{ localStorage.setItem('malba_theme', t); }catch(e){} applyTheme(t); var b=document.getElementById('themeToggle'); if(b){ b.innerHTML=icon(t==='dark'?'sun':'moon'); b.title=(t==='dark'?'Modo claro':'Modo escuro'); } }

function boot() {
  applyTheme(getTheme());
  try {
    var bp=new URLSearchParams(location.search).get('bling');
    if (bp) {
      window._blingMsg = (bp==='ok') ? ['Loja conectada ao Bling com sucesso!','success'] : ['Não foi possível conectar ao Bling. Tente de novo.','error'];
      history.replaceState(null,'', location.pathname + location.hash);
    }
  } catch(e){}
  if (!window._onlineHook) { window._onlineHook=true; window.addEventListener('online', setOnlineState); window.addEventListener('offline', setOnlineState); }
  if (!window._esctaHook) { window._esctaHook=true; document.addEventListener('click', function(e){ var b=e.target&&e.target.closest?e.target.closest('.es-cta'):null; if(b && ST.session){ e.preventDefault(); novoContextual(); } }); }
  if (!window._cmdkHook) { window._cmdkHook=true; window.addEventListener('keydown', function(e){ if ((e.metaKey||e.ctrlKey) && (e.key==='k'||e.key==='K')) { e.preventDefault(); if (ST.session) openCommandPalette(); } }); }
  if (!window._keysHook) { window._keysHook=true; window.addEventListener('keydown', function(e){
    if (!ST.session || e.metaKey || e.ctrlKey || e.altKey) return;
    var ae=document.activeElement;
    if (ae && (ae.tagName==='INPUT'||ae.tagName==='TEXTAREA'||ae.tagName==='SELECT'||ae.isContentEditable)) return;
    var modalOpen=document.querySelector('.modal-bg, .cmdk-bg');
    if (e.key==='/') { e.preventDefault(); var s=document.getElementById('topSearch'); if(s) s.focus(); }
    else if (e.key==='?') { e.preventDefault(); openShortcutsHelp(); }
    else if ((e.key==='n'||e.key==='N') && !modalOpen) { e.preventDefault(); openTaskModal(null); }
  }); }
  var session=getSession();
  if (!session || !session.user) {
    // v106: carrega departamentos antes de mostrar os cards (roda uma vez só)
    if (!ST.departamentos){
      render('<div class="screen"><div class="spinner"></div></div>');
      departamentosCarregar(function(){ renderSectorScreen(); });
    } else { renderSectorScreen(); }
    return;
  }
  ST.session=session; ST.sector=session.sector;
  var route=currentRoute();
  ST.page = (route.length>=2) ? route[1] : 'inicio';
  if (!ST.loaded) { render('<div class="screen"><div class="spinner"></div></div>'); loadData().then(function(){ renderPage(); flushBlingMsg(); }); }
  else { syncSessionPerms(); renderPage(); flushBlingMsg(); }
}
function flushBlingMsg(){ if (window._blingMsg) { var m=window._blingMsg; window._blingMsg=null; setTimeout(function(){ toast(m[0], m[1]); }, 300); } }
function init() {
  startSplash();
  render('<div class="screen"><div class="spinner"></div></div>');
  if (!sb) { render('<div class="screen"><div class="screen-inner"><div class="login-card"><h1 class="login-h">Erro</h1><p class="login-sub">Biblioteca do Supabase não carregou.</p></div></div></div>'); return; }
  pingBanco().then(function(ok){
    if (!ok) { render('<div class="screen"><div class="screen-inner"><div class="login-card"><h1 class="login-h">Sem conexão</h1><p class="login-sub">Não consegui falar com o banco. Confira URL e anon key na seção CONFIG.</p></div></div></div>'); return; }
    window.addEventListener('hashchange', boot);
    boot();
  });
}
init();

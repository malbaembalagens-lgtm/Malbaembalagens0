/* ========== [10d] CRM (clientes) ========== */
var CRM_STATUS = {
  ativo:     { label:'Ativo',     color:'#16A34A' },
  prospecto: { label:'Prospecto', color:'#3B6FF7' },
  inativo:   { label:'Inativo',   color:'#9aa1ad' }
};
// Segmentos calculados por recência (pesquisa de mercado: RFM com foco em recência)
var CRM_SEG = {
  ativo:     { label:'Ativo',     color:'#16A34A', dot:'#16A34A' },
  esfriando: { label:'Esfriando', color:'#F59E0B', dot:'#F59E0B' },
  inativo:   { label:'Inativo',   color:'#EF4444', dot:'#EF4444' },
  novo:      { label:'Novo',      color:'#0EA5E9', dot:'#0EA5E9' },
  prospecto: { label:'Prospecto', color:'#8B5CF6', dot:'#8B5CF6' }
};
function crmDaysSince(d){ if(!d) return null; var t=new Date((''+d).slice(0,10)+'T00:00:00'); var n=new Date(today()+'T00:00:00'); return Math.round((n-t)/86400000); }
function crmCycle(c){ var n=Number(c.purchase_cycle_days); return (n&&n>0)?n:30; }
// classifica o cliente: prospecto (lead) > novo (sem compra) > ativo/esfriando/inativo (por recência)
function crmSegment(c){
  if (c.status==='prospecto') return 'prospecto';
  var d=crmDaysSince(c.last_purchase);
  if (d===null) return 'novo';
  var cyc=crmCycle(c);
  if (d<=cyc) return 'ativo';
  if (d<=cyc*2) return 'esfriando';
  return 'inativo';
}
// nota de recência legível
function crmRecencia(c){
  var d=crmDaysSince(c.last_purchase);
  if (d===null) return 'sem compra registrada';
  if (d===0) return 'comprou hoje';
  if (d===1) return 'comprou ontem';
  return 'última compra há '+d+' dias';
}
var crmBusca = '';
var crmSeg = 'todos';

function crmPertenceSetor(c){
  if (deptoTemEquipe(ST.sector)) return (c.sector===ST.sector || !c.sector || !!c.store_unit_id); // v113
  return c.sector===ST.sector;
}
/* ========== [9] DASHBOARD ========== */
function dashboardHTML() {
  var u=ST.session.user; var ts=visibleTasks(); var hoje=today();
  var cTodo=0,cFaz=0,cFeito=0,cHoje=0,cAtras=0;
  ts.forEach(function(t){
    if(t.status==='todo')cTodo++; else if(t.status==='fazendo')cFaz++; else if(t.status==='feito')cFeito++;
    if(t.due_date===hoje)cHoje++;
    if(t.due_date && t.due_date<hoje && t.status!=='feito')cAtras++;
  });
  var hora=new Date().getHours(); var saud=hora<12?'Bom dia':(hora<18?'Boa tarde':'Boa noite');
  var setorLabel = SECTORS[ST.sector] ? SECTORS[ST.sector].label : 'Painel';
  var nome = u.name.split(' ')[0];
  var banner = sectorBanner();
  var hero;
  if (banner) {
    hero = bannerHeroHTML(banner);
  } else {
    var h = HERO[ST.sector] || { tag:'Painel', sa:saud+',', desc:'Seu centro de operação.' };
    hero = '<div class="dash-hero hero-pro">'+
      '<div class="hero-grid"></div>'+
      '<div class="hero-c">'+
        '<span class="hero-tag">'+esc(h.tag)+'</span>'+
        '<h2>'+esc(h.sa)+' <span class="hero-name">'+esc(nome)+'</span>! 👋</h2>'+
        '<p>'+esc(h.desc)+'</p>'+
      '</div>'+
    '</div>';
  }
  var counts={ todo:cTodo, faz:cFaz, feito:cFeito, hoje:cHoje, atras:cAtras };
  var cards = sectorStatCards(counts).map(statCardPro).join('');
  var dashStoreSel='';
  if (isAdmin(ST.session) && ST.sector==='lojas' && !ST.store && (ST.storeUnits||[]).length>0) {
    var dso='<option value="">Todas as lojas</option>'+ST.storeUnits.map(function(s){return '<option value="'+esc(s.id)+'"'+(String(ST.taskStore)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';}).join('');
    dashStoreSel='<select class="task-filter" id="dashStore" title="Ver loja">'+dso+'</select>';
  }
  return ''+
    hero+
    muralHTML()+
    '<div class="dash-sec-h"><h3>Resumo de hoje</h3><span>'+esc(dataExtenso())+' · Setor '+esc(setorLabel)+'</span>'+(dashStoreSel?'<span class="dash-sec-spacer"></span>'+dashStoreSel:'')+'</div>'+
    '<div class="dash-cards">'+cards+'</div>'+
    dashPanels();
}

/* ----- Painéis interativos do Início ----- */
function dashPanel(title, ic, body, action) {
  return '<div class="dash-panel"><div class="dash-panel-h">'+ic+'<h3>'+esc(title)+'</h3>'+(action||'')+'</div><div class="dash-panel-b">'+body+'</div></div>';
}
function dashTaskRow(t) {
  var pr=PRIO[t.priority]||PRIO.media;
  var late = t.due_date && t.due_date<today() && t.status!=='feito';
  return '<button class="dash-row" data-dtask="'+esc(t.id)+'"><span class="dr-prio" style="background:'+pr.color+'"></span><span class="dr-l">'+esc(t.title)+'</span>'+(t.due_date?'<span class="dr-date'+(late?' late':'')+'">'+fmtDate(t.due_date)+'</span>':'')+'</button>';
}
function panelTarefasHoje() {
  var ts=visibleTasks().filter(function(t){ return t.status!=='feito' && t.due_date && t.due_date.split('T')[0]<=today(); });
  ts.sort(function(a,b){ return (a.due_date||'').localeCompare(b.due_date||''); });
  var body = ts.length ? ts.slice(0,6).map(dashTaskRow).join('') : '<div class="dash-empty">Nada pendente para hoje. 🎉</div>';
  var act='<button class="dash-panel-act" id="dashGoTasks">ver todas</button>';
  return dashPanel('Tarefas de hoje', icon('tasks'), body, act);
}
function panelSetor() {
  var s=ST.sector;
  if (s==='marketing') {
    var cs=ST.campaigns.filter(function(c){ return campStatus(c).label==='Ativa'; }).slice(0,5);
    var body=cs.length ? cs.map(function(c){ return '<button class="dash-row" data-dcamp="'+esc(c.id)+'"><span class="dr-prio" style="background:'+(c.color||'#8B5CF6')+'"></span><span class="dr-l">'+esc(c.name)+'</span><span class="dr-s" style="color:#16A34A">Ativa</span></button>'; }).join('') : '<div class="dash-empty">Nenhuma campanha ativa agora.</div>';
    return dashPanel('Campanhas ativas', icon('megaphone'), body);
  }
  if (s==='vendas') {
    var y=new Date().getFullYear(), m=new Date().getMonth()+1;
    var gs=visibleGoals().filter(function(g){ return g.month===m && g.year===y; }).slice(0,5);
    var body=gs.length ? gs.map(function(g){ var u=g.user_id?userById(g.user_id):null; var nm=u?u.name:'Meta do setor'; var pct=g.goal_value>0?Math.min(100,Math.round(realizadoMeta(g)/g.goal_value*100)):0; return '<div class="dash-goal"><div class="dg-top"><span>'+esc(nm)+'</span><b>'+pct+'%</b></div><div class="dg-bar"><span style="width:'+pct+'%"></span></div></div>'; }).join('') : '<div class="dash-empty">Sem metas definidas neste mês.</div>';
    return dashPanel('Metas do mês', icon('target'), body);
  }
  if (s==='lojas') {
    var ms = ST.store ? ST.members.filter(function(x){ return x.store_unit_id===ST.store.id; }) : ST.members;
    ms=ms.slice(0,6);
    var body=ms.length ? ms.map(function(mm){ return '<div class="dash-row"><span class="dr-av" style="background:'+(mm.color||'#3B6FF7')+'">'+esc(iniciais(mm.name))+'</span><span class="dr-l">'+esc(mm.name)+'</span><span class="dr-s">'+esc(mm.role||'')+'</span></div>'; }).join('') : '<div class="dash-empty">Nenhum funcionário cadastrado.</div>';
    return dashPanel('Sua equipe', icon('users'), body);
  }
  var up=visibleTasks().filter(function(t){ return t.status!=='feito' && t.due_date && t.due_date.split('T')[0]>today(); });
  up.sort(function(a,b){ return (a.due_date||'').localeCompare(b.due_date||''); });
  var body2=up.length ? up.slice(0,6).map(dashTaskRow).join('') : '<div class="dash-empty">Sem tarefas futuras.</div>';
  return dashPanel('Próximas tarefas', icon('cal'), body2);
}
function panelProjetos() {
  var ps=(ST.projects||[]).filter(function(p){ return p.status!=='concluido'; }).slice(0,4);
  if (ps.length===0) return '';
  var body=ps.map(function(p){ var pct=projProgress(p.id); var cor=p.color||'#3B6FF7'; return '<button class="dash-proj" data-dproj="'+esc(p.id)+'"><div class="dp-top"><span class="dp-dot" style="background:'+cor+'"></span><span class="dp-n">'+esc(p.name)+'</span><b>'+pct+'%</b></div><div class="dg-bar"><span style="width:'+pct+'%;background:'+cor+'"></span></div></button>'; }).join('');
  return dashPanel('Projetos em andamento', icon('folder'), '<div class="dash-projs">'+body+'</div>');
}
// v78: faturamento — vinha de uma página de KPIs solta (fora do menu); agora é um bloco do Dashboard único
function panelFaturamento(){
  var rows=kpiFatRows();
  var fat=rows.reduce(function(s,f){ return s+(Number(f.total)||0); },0);
  var ped=rows.reduce(function(s,f){ return s+(Number(f.orders_count)||0); },0);
  var ticket=ped>0?fat/ped:0;
  var now=new Date(), y=now.getFullYear(), m=now.getMonth()+1, sid=kpiStoreId();
  var gs=visibleGoals().filter(function(g){ return g.month===m && g.year===y && (!sid || String(g.store_unit_id)===String(sid)); });
  var meta=gs.reduce(function(s,g){ return s+(Number(g.goal_value)||0); },0);
  var real=gs.reduce(function(s,g){ return s+realizadoMeta(g); },0);
  var pct=meta>0?Math.min(100,Math.round(real/meta*100)):0;
  var body='<div class="dash-fat">'+
      '<div class="df-kpi"><b style="color:var(--u-green)">'+brlShort(fat)+'</b><i>Faturamento (mês)</i></div>'+
      '<div class="df-kpi"><b>'+ped+'</b><i>Pedidos</i></div>'+
      '<div class="df-kpi"><b>'+brlShort(ticket)+'</b><i>Ticket médio</i></div>'+
    '</div>'+
    (meta>0
      ? '<div class="dash-goal"><div class="dg-top"><span>Meta do mês</span><b>'+pct+'%</b></div><div class="dg-bar"><span style="width:'+pct+'%"></span></div></div>'
      : '<div class="dash-empty">Defina a meta do mês em Gestão › Metas.</div>');
  return dashPanel('Faturamento', icon('dollar'), body);
}
function dashPanels() {
  var fat = deptoTemCRM(ST.sector) ? panelFaturamento() : ''; // v106
  return '<div class="dash-grid2">'+panelTarefasHoje()+panelSetor()+'</div>'+fat+panelProjetos();
}
/* ----- Painel da loja (posto de trabalho, dia a dia) ----- */
function vendasHojeLoja(storeId){ var t=today(); var s=0; (ST.blingFat||[]).forEach(function(f){ if(String(f.store_unit_id)===String(storeId) && String(f.ref_date).slice(0,10)===t) s+=Number(f.total)||0; }); return s; }
function lojaPainelHTML(){
  var loja=ST.store; var lojaNome=loja.name||('Loja '+loja.store_number);
  var hora=new Date().getHours(); var saud=hora<12?'Bom dia':(hora<18?'Boa tarde':'Boa noite');
  var mems=membrosDaLoja(loja.id).filter(function(m){return m.is_active!==false;});
  var presentes=mems.filter(function(m){ var c=checkinHojeDoMembro(m); return c&&c.entrada; });
  var hoje=today();
  var tarefasHoje=visibleTasks().filter(function(t){ return t.status!=='feito' && t.due_date && t.due_date.split('T')[0]<=hoje; }).sort(function(a,b){return (a.due_date||'').localeCompare(b.due_date||'');});
  var mm=lojaMetaMes(loja.id); var vHoje=vendasHojeLoja(loja.id);
  var hero='<div class="loja-hero"><div class="lh-badge"><span class="dot"></span> PAINEL DA LOJA</div><h1 class="lh-title">'+saud+', <span>'+esc(lojaNome)+'</span> 👋</h1><p class="lh-sub">'+esc(dataExtenso())+'</p></div>';
  function pk(v,l,c,s){ return '<div class="lp-kpi"><span class="lp-kpi-v" style="color:'+c+'">'+v+'</span><span class="lp-kpi-l">'+esc(l)+'</span>'+(s?'<span class="lp-kpi-s">'+esc(s)+'</span>':'')+'</div>'; }
  var kpis='<div class="lp-kpis">'+
    pk(presentes.length+'/'+mems.length, 'Presentes hoje', 'var(--u-accent)', 'ponto do dia')+
    pk(tarefasHoje.length, 'Tarefas de hoje', tarefasHoje.length?'#F59E0B':'#16A34A', tarefasHoje.length?'a fazer':'tudo em dia')+
    pk(mm.meta>0?(mm.pct+'%'):'—', 'Meta do mês', mm.pct>=100?'#16A34A':'var(--u-accent)', mm.meta>0?fmtBRL(mm.real):'sem meta')+
    pk(brlShort(vHoje), 'Vendas hoje', 'var(--u-green)', 'via Bling')+
  '</div>';
  var presAvatars = mems.length ? '<div class="lp-pres">'+mems.map(function(m){ var c=checkinHojeDoMembro(m); var on=c&&c.entrada; var out=c&&c.saida; return '<div class="lp-pres-av'+(on?' on':'')+(out?' out':'')+'" title="'+esc(m.name)+(on?(' · entrou '+hhmm(c.entrada)):' · não chegou')+'"><span style="background:'+(m.color||'#3B6FF7')+'">'+esc(iniciais(m.name))+'</span>'+(on?'<i class="lp-dot"></i>':'')+'</div>'; }).join('')+'</div>' : '<div class="dash-empty">Nenhum funcionário nesta loja.</div>';
  var presPanel='<div class="dash-panel"><div class="dash-panel-h">'+icon('users')+'<h3>Presença de hoje</h3><button class="dash-panel-act" id="lpGoPonto">bater ponto</button></div><div class="dash-panel-b">'+presAvatars+'</div></div>';
  var tBody=tarefasHoje.length ? tarefasHoje.slice(0,7).map(dashTaskRow).join('') : '<div class="dash-empty">Nada pendente para hoje. 🎉</div>';
  var tPanel='<div class="dash-panel"><div class="dash-panel-h">'+icon('tasks')+'<h3>Tarefas de hoje</h3><button class="dash-panel-act" id="lpGoTasks">ver todas</button></div><div class="dash-panel-b">'+tBody+'</div></div>';
  var metaPanel='<div class="dash-panel"><div class="dash-panel-h">'+icon('target')+'<h3>Meta do mês</h3><button class="dash-panel-act" id="lpGoMetas">detalhes</button></div><div class="dash-panel-b">'+(mm.meta>0?('<div class="lp-meta"><div class="lp-meta-bar"><span style="width:'+mm.pct+'%;background:'+(mm.pct>=100?'#16A34A':'var(--u-accent)')+'"></span></div><div class="lp-meta-sub">'+fmtBRL(mm.real)+' de '+fmtBRL(mm.meta)+' · <b style="color:'+(mm.pct>=100?'#16A34A':'var(--u-accent)')+'">'+mm.pct+'%</b></div></div>'):'<div class="dash-empty">Sem meta definida para este mês.</div>')+'</div></div>';
  return hero + muralHTML() + kpis + '<div class="dash-grid2">'+presPanel+tPanel+'</div>' + metaPanel;
}
function bindLojaPainel(){
  bindMural();
  var gp=document.getElementById('lpGoPonto'); if(gp) gp.addEventListener('click', function(){ ST.page='ponto'; navigate(ST.sector+'/ponto'); renderPage(); });
  var gt=document.getElementById('lpGoTasks'); if(gt) gt.addEventListener('click', function(){ ST.page='tarefas'; navigate(ST.sector+'/tarefas'); renderPage(); });
  var gm=document.getElementById('lpGoMetas'); if(gm) gm.addEventListener('click', function(){ ST.page='metas'; navigate(ST.sector+'/metas'); renderPage(); });
  var tr=app.querySelectorAll('[data-dtask]'); for(var i=0;i<tr.length;i++) tr[i].addEventListener('click', function(){ var t=taskById(this.getAttribute('data-dtask')); if(t) openTaskModal(t); });
}
function bindDashboard() {
  bindMural();
  var dst=document.getElementById('dashStore');
  if (dst) dst.addEventListener('change', function(){ ST.taskStore=this.value; renderPage(); });
  var g=document.getElementById('dashGoTasks');
  if (g) g.addEventListener('click', function(){ ST.page='tarefas'; navigate(ST.sector+'/tarefas'); renderPage(); });
  var tr=app.querySelectorAll('[data-dtask]');
  for (var i=0;i<tr.length;i++) tr[i].addEventListener('click', function(){ var id=this.getAttribute('data-dtask'); var t=null; for(var k=0;k<ST.tasks.length;k++) if(String(ST.tasks[k].id)===String(id)){t=ST.tasks[k];break;} if(t) openTaskModal(t); });
  var cr=app.querySelectorAll('[data-dcamp]');
  for (var j=0;j<cr.length;j++) cr[j].addEventListener('click', function(){ var id=this.getAttribute('data-dcamp'); var c=null; for(var k=0;k<ST.campaigns.length;k++) if(String(ST.campaigns[k].id)===String(id)){c=ST.campaigns[k];break;} if(c) openCampaignModal(c); });
  var pr=app.querySelectorAll('[data-dproj]');
  for (var z=0;z<pr.length;z++) pr[z].addEventListener('click', function(){ ST.openProject=this.getAttribute('data-dproj'); ST.page='projetos'; navigate(ST.sector+'/projetos'); renderPage(); });
}

// mensagens de hero por setor (iguais ao site no ar)
var DIAS_SEM = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
function dataExtenso() { var d=new Date(); return DIAS_SEM[d.getDay()]+', '+d.getDate()+' de '+MESES[d.getMonth()]; }
function brlShort(n) { return 'R$ '+Math.round(Number(n)||0).toLocaleString('pt-BR'); }
var HERO = {
  vendas:    { tag:'Painel de Vendas',    sa:'Bem-vindo de volta,', desc:'Acompanhe suas metas, clientes e resultados em um só lugar. Bora pra cima!' },
  lojas:     { tag:'Painel de Lojas',     sa:'Bom te ver,',         desc:'Operação das lojas, equipe e tarefas do dia — tudo sob controle.' },
  financeiro:{ tag:'Painel Financeiro',   sa:'Olá,',                desc:'Suas rotinas, contas e fluxo do mês organizados e no azul.' },
  marketing: { tag:'Painel de Marketing', sa:'E aí,',               desc:'Campanhas, conteúdos e resultados — transforme ideias em engajamento.' }
};
// cards de resumo específicos por setor — cada setor mostra o que importa
function sectorStatCards(c) {
  var hojeStr=today();
  var vt=visibleTasks();
  var hojeTasks=vt.filter(function(t){ return t.due_date && t.due_date.split('T')[0]===hojeStr; });
  var hojeDone=hojeTasks.filter(function(t){ return t.status==='feito'; }).length;
  var totalT=c.todo+c.faz+c.feito;
  var y=new Date().getFullYear(), m=new Date().getMonth()+1;
  var gs=(visibleGoals()||[]).filter(function(g){ return g.month===m && g.year===y; });
  var meta=gs.reduce(function(s,g){ return s+(Number(g.goal_value)||0); },0);
  var real=gs.reduce(function(s,g){ return s+realizadoMeta(g); },0);
  var metaPct=meta>0?Math.min(100,Math.round(real/meta*100)):0;
  var _ds=boardStore();
  var clientList=(ST.clients||[]).filter(function(x){ return !_ds || String(x.store_unit_id)===String(_ds); });
  var clientesAtivos=clientList.filter(function(x){ return !x.status || x.status==='ativo'; }).length;
  var campAtivas=(ST.campaigns||[]).filter(function(x){ var s=(x.start_date||'').split('T')[0], e=(x.end_date||'').split('T')[0]; return s && (!e ? s===hojeStr : (hojeStr>=s && hojeStr<=e)); }).length;
  var projAtivos=(ST.projects||[]).filter(function(p){ return p.status!=='concluido'; }).length;
  var pctHoje = hojeTasks.length?Math.round(hojeDone/hojeTasks.length*100):0;
  // Faturamento de hoje (Bling) — soma das lojas visíveis
  var fatRows=(ST.blingFat||[]).filter(function(f){ return (f.ref_date||'').slice(0,10)===hojeStr; });
  var _scp=boardStore(); if (_scp) fatRows=fatRows.filter(function(f){ return String(f.store_unit_id)===String(_scp); });
  var fatHoje=fatRows.reduce(function(s,f){ return s+(Number(f.total)||0); },0);
  var temFat=fatRows.length>0;
  var fatConn=(ST.bling||[]).some(function(b){ return b.connected; });

  if (ST.sector==='lojas') return [
    { label:'Faturamento hoje', val:(temFat?brlShort(fatHoje):'—'), sub:(temFat?'atualizado pelo Bling':(fatConn?'Aguardando 1ª sincronização':'Conecte o Bling')), subColor:(temFat?'var(--u-green)':'var(--u-text3)'), color:'#3B6FF7', icon:'dollar', viz:'spark' },
    { label:'Meta do mês',      val:metaPct+'%',    sub:(meta>0?brlShort(real)+' / '+brlShort(meta):'Defina as metas'), subColor:(meta>0?'var(--u-green)':'var(--u-text3)'), color:'#16A34A', icon:'target', viz:'bar', barPct:metaPct },
    { label:'Tarefas do dia',   val:hojeTasks.length, sub:hojeDone+' concluídas', subColor:'var(--u-green)', color:'#FB8C00', icon:'tasks', viz:'bar', barPct:pctHoje },
    { label:'Clientes ativos',  val:clientesAtivos.toLocaleString('pt-BR'), sub:clientList.length+' no CRM', subColor:'#8B5CF6', color:'#8B5CF6', icon:'users', viz:'spark' }
  ];
  if (deptoComoModelo('vendas')) return [
    { label:'Vendas do mês',  val:(real>0?brlShort(real):'—'), sub:(real>0?'meta '+brlShort(meta):'via Bling / metas'), subColor:(real>0?'var(--u-green)':'var(--u-text3)'), color:'#3B6FF7', icon:'dollar', viz:'spark' },
    { label:'Meta do mês',    val:metaPct+'%', sub:(meta>0?brlShort(real)+' / '+brlShort(meta):'Defina as metas'), subColor:(meta>0?'var(--u-green)':'var(--u-text3)'), color:'#16A34A', icon:'target', viz:'bar', barPct:metaPct },
    { label:'Tarefas do dia', val:hojeTasks.length, sub:hojeDone+' concluídas', subColor:'var(--u-green)', color:'#FB8C00', icon:'tasks', viz:'bar', barPct:pctHoje },
    { label:'Clientes',       val:clientList.length.toLocaleString('pt-BR'), sub:clientesAtivos+' ativos', subColor:'#8B5CF6', color:'#8B5CF6', icon:'users', viz:'spark' }
  ];
  if (deptoComoModelo('marketing')) {
    var mkArr=[
      { label:'Campanhas ativas', val:campAtivas, sub:(ST.campaigns||[]).length+' no total', subColor:'#8B5CF6', color:'#8B5CF6', icon:'megaphone', viz:'spark' },
      { label:'Tarefas do dia',   val:hojeTasks.length, sub:hojeDone+' concluídas', subColor:'var(--u-green)', color:'#3B6FF7', icon:'tasks', viz:'bar', barPct:pctHoje },
      { label:'Projetos ativos',  val:projAtivos, sub:(ST.projects||[]).length+' no total', subColor:'#FB8C00', color:'#FB8C00', icon:'folder', viz:'bar', barPct:((ST.projects||[]).length?Math.round(projAtivos/(ST.projects||[]).length*100):0) },
      { label:'Concluídas',       val:c.feito, sub:'tarefas feitas', subColor:'var(--u-green)', color:'#16A34A', icon:'dashboard', viz:'spark' }
    ];
    if (siteUnits().length) {
      mkArr.unshift({ label:'Faturamento do site (mês)', val:brlShort(siteFatMes()), sub:'site · via Bling', subColor:'var(--u-green)', color:'#16A34A', icon:'dollar', viz:'spark' });
    }
    return mkArr;
  }
  // financeiro
  return [
    { label:'Tarefas do dia', val:hojeTasks.length, sub:hojeDone+' concluídas', subColor:'var(--u-green)', color:'#3B6FF7', icon:'tasks', viz:'bar', barPct:pctHoje },
    { label:'Em andamento',   val:c.faz, sub:'em progresso', subColor:'var(--u-text3)', color:'#FB8C00', icon:'dashboard', viz:'bar', barPct:(totalT?Math.round(c.faz/totalT*100):0) },
    { label:'Concluídas',     val:c.feito, sub:'no total', subColor:'var(--u-green)', color:'#16A34A', icon:'target', viz:'spark' },
    { label:'Atrasadas',      val:c.atras, sub:(c.atras>0?'precisam de atenção':'tudo em dia'), subColor:(c.atras>0?'var(--u-red)':'var(--u-green)'), color:'#EF4444', icon:'bell', viz:'spark' }
  ];
}
function statCardPro(c, i) {
  var viz = (c.viz==='bar')
    ? '<div class="stat-pro-bar"><span style="width:'+(c.barPct||0)+'%;background:'+c.color+'"></span></div>'
    : miniSpark(c.color, (i||0)+2);
  var sub = c.sub ? '<div class="stat-pro-sub" style="color:'+(c.subColor||'var(--u-text3)')+'">'+esc(c.sub)+'</div>' : '';
  return '<div class="stat-pro">'+
    '<div class="stat-pro-top"><div class="stat-pro-meta"><div class="stat-pro-l">'+esc(c.label)+'</div><div class="stat-pro-v">'+c.val+'</div></div>'+
    '<span class="stat-pro-ico" style="background:'+c.color+'18;color:'+c.color+'">'+icon(c.icon)+'</span></div>'+
    sub + viz +
  '</div>';
}
// mini-gráfico decorativo (visual; ganha dados reais com histórico/Bling)
function miniSpark(color, seed) {
  var w=140,h=34,n=12,s=seed||1,pts=[];
  for (var i=0;i<n;i++) pts.push(Math.sin((i+s)*0.7)*0.5+0.5);
  var coords=pts.map(function(v,i){ return [(i/(n-1))*w, h-(v*(h-7))-3]; });
  var d=coords.map(function(p,i){ return (i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1); }).join(' ');
  var id='sp'+Math.random().toString(36).slice(2,6);
  return '<svg class="stat-spark" viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none">'+
    '<defs><linearGradient id="'+id+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+color+'" stop-opacity=".22"/><stop offset="1" stop-color="'+color+'" stop-opacity="0"/></linearGradient></defs>'+
    '<path d="'+d+' L '+w+' '+h+' L 0 '+h+' Z" fill="url(#'+id+')"/>'+
    '<path d="'+d+'" fill="none" stroke="'+color+'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity=".65"/></svg>';
}

// escolhe o banner ativo do setor (respeita sectors[] e loja)
function sectorBanner() {
  var bs = (ST.banners||[]).filter(function(b){
    if (b.is_active===false) return false;
    var secs = b.sectors||[];
    if (secs.length && secs.indexOf(ST.sector)===-1) return false;
    if (b.store_unit_id && ST.store && b.store_unit_id!==ST.store.id) return false;
    if (b.store_unit_id && !ST.store && !isSuper(ST.session)) return false;
    return true;
  }).sort(function(a,b){ return (a.position||0)-(b.position||0); });
  return bs[0] || null;
}
function bannerHeroHTML(b) {
  var bg = b.image_url_desktop ? ('center/cover no-repeat url("'+b.image_url_desktop+'")') : (b.bg_gradient || 'var(--u-grad-hero)');
  var overlay = b.image_url_desktop ? '<div class="banner-ov"></div>' : '';
  var inner = '<div class="banner-c"><h2>'+esc(b.title||'')+'</h2>'+(b.description?'<p>'+esc(b.description)+'</p>':'')+'</div>';
  if (b.link_url) {
    return '<a class="dash-hero banner" href="'+esc(b.link_url)+'" target="_blank" rel="noopener" style="background:'+bg+'">'+overlay+inner+'</a>';
  }
  return '<div class="dash-hero banner" style="background:'+bg+'">'+overlay+inner+'</div>';
}
/* ===== v89.1: RESTAURAÇÃO — funções engolidas pela limpeza da v87 =====
   A remoção de código morto cortou além da conta e levou junto estas
   auxiliares vivas. Reconstruídas a partir dos pontos de uso. */
function _ymNow(){ var d=new Date(); return { y:d.getFullYear(), m:d.getMonth()+1 }; }
function _inMonth(ds){ if(!ds) return false; var n=_ymNow(); return String(ds).slice(0,7) === (n.y+'-'+pad(n.m)); }
function _parseBRL(v){
  if (typeof v==='number') return v;
  v=String(v==null?'':v).replace(/[^\d,.\-]/g,'');
  if (v.indexOf(',')!==-1) v=v.replace(/\./g,'').replace(',','.');
  var n=parseFloat(v); return isNaN(n)?0:n;
}
function kpiIso(d){ return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); }
function kpiRange(){
  var fim=today();
  if (ST.kpiPeriod==='dia') return { ini:fim, fim:fim };
  if (ST.kpiPeriod==='semana') return { ini:addDays(fim,-6), fim:fim };
  return { ini:fim.slice(0,8)+'01', fim:fim }; // mês (padrão)
}
function pendingRequests(){ return (ST.requests||[]).filter(function(r){ return (r.status||'pendente')==='pendente'; }); }
function meuMemberId(){ var me=String(ST.session.user.id); for(var i=0;i<(ST.members||[]).length;i++){ if(String(ST.members[i].user_id||'')===me) return ST.members[i].id; } return null; }
function meuStoreId(){ var me=String(ST.session.user.id); for(var i=0;i<(ST.members||[]).length;i++){ if(String(ST.members[i].user_id||'')===me) return ST.members[i].store_unit_id||null; } return null; }
function minhaMetaMes(){
  var me=String(ST.session.user.id), n=_ymNow(), out=null;
  (ST.goals||[]).forEach(function(g){ if(String(g.user_id||'')===me && Number(g.month)===n.m && Number(g.year)===n.y) out=g; });
  return out;
}
function vendasUserMes(uid2){
  var s2=0, u=String(uid2);
  (ST.salesEntries||[]).forEach(function(e){ if(String(e.user_id||'')===u && _inMonth(e.sale_date)) s2+=Number(e.value)||0; });
  return s2;
}
function lojaMetaMes(storeId){
  var n=_ymNow(), meta=0;
  (ST.goals||[]).forEach(function(g){ if(String(g.store_unit_id||'')===String(storeId) && !g.user_id && Number(g.month)===n.m && Number(g.year)===n.y) meta+=Number(g.goal_value)||0; });
  var real=(typeof blingFatStoreMonth==='function') ? blingFatStoreMonth(storeId, n.m, n.y) : 0;
  var pct=meta>0 ? Math.min(999, Math.round(real/meta*100)) : 0;
  return { meta:meta, real:real, pct:pct };
}
// v89.1: também engolida na limpeza — o colaborador registra a própria venda
function openVendaModal(){
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal" style="max-width:380px">'+
    '<div class="wz-title">Registrar venda</div>'+
    '<div class="modal-row"><label class="modal-label">Valor da venda (R$)</label><input type="text" id="vdVal" inputmode="decimal" placeholder="ex: 350,00" autocomplete="off"></div>'+
    '<div class="modal-row"><label class="modal-label">Data</label><input type="date" id="vdData" value="'+today()+'"></div>'+
    '<div class="modal-note">Ela soma na sua meta do mês na hora.</div>'+
    modalFoot({ saveLabel:'Registrar', cancelId:'vdCancel', saveId:'vdOk' })+
  '</div>';
  document.body.appendChild(modal);
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#vdCancel').addEventListener('click', close);
  setTimeout(function(){ var el=modal.querySelector('#vdVal'); if(el) el.focus(); }, 30);
  modal.querySelector('#vdOk').addEventListener('click', function(){
    var val=_parseBRL(modal.querySelector('#vdVal').value);
    if(val<=0){ toast('Informe o valor da venda','error'); return; }
    var rec={ sector:ST.sector, user_id:ST.session.user.id, member_id:meuMemberId(), store_unit_id:meuStoreId(),
              value:val, sale_date:(modal.querySelector('#vdData').value||today()) };
    var b=this; setBusy(b,true);
    sb.from('malba_sales_entries').insert(rec).select().single().then(function(r){
      setBusy(b,false);
      if(r.error||!r.data){ toast('Não consegui registrar (peça ao gestor para conferir o SQL de vendas).','error'); console.error(r.error); return; }
      if(!ST.salesEntries) ST.salesEntries=[];
      ST.salesEntries.push(r.data);
      close(); toast('Venda registrada — '+fmtBRL(val),'success'); renderPage();
    });
  });
}
// usa o filtro de loja do admin (ou a loja da conta, se for conta de loja)
function kpiStoreId(){ return boardStore(); }
function kpiFatRows(){
  var r=kpiRange(); var sid=kpiStoreId();
  return (ST.blingFat||[]).filter(function(f){
    var d=(f.ref_date||'').slice(0,10);
    if (d<r.ini || d>r.fim) return false;
    if (sid && String(f.store_unit_id)!==String(sid)) return false;
    return true;
  });
}
function kpiSeries(){
  var sid=kpiStoreId(); var fim=today();
  var count = ST.kpiPeriod==='mes' ? Number(fim.slice(8,10)) : 7;
  if (count<1) count=1;
  var base=new Date(fim+'T00:00:00'); var out=[];
  for (var i=count-1;i>=0;i--){ var d=new Date(base); d.setDate(d.getDate()-i); var ds=kpiIso(d);
    var tot=(ST.blingFat||[]).filter(function(f){ return (f.ref_date||'').slice(0,10)===ds && (!sid||String(f.store_unit_id)===String(sid)); }).reduce(function(s,f){ return s+(Number(f.total)||0); },0);
    out.push({ date:ds, total:tot });
  }
  return out;
}
function blingFatStoreMonth(storeId, month, year){
  var s=0;
  (ST.blingFat||[]).forEach(function(f){
    if(String(f.store_unit_id)!==String(storeId)) return;
    var d=(f.ref_date||'').slice(0,10); if(!d) return;
    var p=d.split('-'); if(Number(p[0])===Number(year) && Number(p[1])===Number(month)) s+=Number(f.total)||0;
  });
  return s;
}
// "Realizado" de uma meta = o valor gravado (sincronizado pelo Bling ou digitado).
// Para meta de vendedor sem valor gravado, usa as vendas que ele registrou no mês.
function realizadoMeta(g){
  if(!g) return 0;
  var manual = Number(g.actual_value)||0;
  if (manual > 0) return manual;
  if (g.user_id){
    var sv=0; (ST.salesEntries||[]).forEach(function(e){ if(String(e.user_id)===String(g.user_id)){ var d=(e.sale_date||'').slice(0,10); var p=d.split('-'); if(Number(p[0])===Number(g.year) && Number(p[1])===Number(g.month)) sv+=Number(e.value)||0; } });
    return sv;
  }
  return 0;
}
function siteUnits(){ return (ST.storeUnits||[]).filter(function(u){ return u.is_site; }); }
function siteFatRange(ini, fim){ var ids={}; siteUnits().forEach(function(u){ ids[String(u.id)]=1; }); var s=0; (ST.blingFat||[]).forEach(function(f){ if(!ids[String(f.store_unit_id)]) return; var d=(f.ref_date||'').slice(0,10); if(d>=ini && d<=fim) s+=Number(f.total)||0; }); return s; }
function _firstDayMonth(){ var n=new Date(); var mm=n.getMonth()+1; return n.getFullYear()+'-'+(mm<10?'0':'')+mm+'-01'; }
function siteFatMes(){ return siteFatRange(_firstDayMonth(), today()); }
function kpisHTML(){
  var admin = isAdmin(ST.session);
  var sid = kpiStoreId();
  var r = kpiRange();
  var rows = kpiFatRows();
  var fat = rows.reduce(function(s,f){ return s+(Number(f.total)||0); },0);
  var ped = rows.reduce(function(s,f){ return s+(Number(f.orders_count)||0); },0);
  var ticket = ped>0 ? fat/ped : 0;
  // meta (sempre do mês corrente — metas são mensais)
  var now=new Date(), y=now.getFullYear(), m=now.getMonth()+1;
  var gs=visibleGoals().filter(function(g){ return g.month===m && g.year===y && (!sid || String(g.store_unit_id)===String(sid)); });
  var meta=gs.reduce(function(s,g){ return s+(Number(g.goal_value)||0); },0);
  var real=gs.reduce(function(s,g){ return s+realizadoMeta(g); },0);
  var metaPct = meta>0 ? Math.min(100, Math.round(real/meta*100)) : 0;
  // tarefas do período
  var ts=visibleTasks().filter(function(t){ var d=(t.due_date||'').slice(0,10); return d>=r.ini && d<=r.fim; });
  var tsFeito=ts.filter(function(t){ return t.status==='feito'; }).length;
  var tsPct = ts.length ? Math.round(tsFeito/ts.length*100) : 0;
  // comissões do período
  var com=(ST.comissoes||[]).filter(function(c){
    if (sid && String(c.store_unit_id)!==String(sid)) return false;
    var d=(c.periodo_inicio||c.created_at||'').slice(0,10); return d>=r.ini && d<=r.fim;
  }).reduce(function(s,c){ return s+(Number(c.total_comissao)||0); },0);

  var perLabel = ST.kpiPeriod==='dia'?'hoje':(ST.kpiPeriod==='semana'?'últimos 7 dias':'mês atual');

  var cards = [
    { label:'Faturamento ('+perLabel+')', val:brlShort(fat), sub:rows.length?'fonte: Bling':'sem dados ainda', subColor:rows.length?'var(--u-green)':'var(--u-text3)', color:'#3B6FF7', icon:'dollar', viz:'spark' },
    { label:'Pedidos ('+perLabel+')', val:ped.toLocaleString('pt-BR'), sub:rows.length?'via Bling':'—', subColor:'var(--u-text3)', color:'#0EA5E9', icon:'trend', viz:'spark' },
    { label:'Ticket médio', val:brlShort(ticket), sub:ped?(ped+' pedido(s)'):'—', subColor:'var(--u-text3)', color:'#8B5CF6', icon:'dollar', viz:'spark' },
    { label:'Meta do mês', val:metaPct+'%', sub:(meta>0?brlShort(real)+' / '+brlShort(meta):'defina as metas'), subColor:(meta>0?'var(--u-green)':'var(--u-text3)'), color:'#16A34A', icon:'target', viz:'bar', barPct:metaPct },
    { label:'Tarefas ('+perLabel+')', val:ts.length.toLocaleString('pt-BR'), sub:tsFeito+' concluídas', subColor:'var(--u-green)', color:'#FB8C00', icon:'tasks', viz:'bar', barPct:tsPct },
    { label:'Comissões ('+perLabel+')', val:brlShort(com), sub:com>0?'pagas no período':'sem lançamentos', subColor:com>0?'var(--u-green)':'var(--u-text3)', color:'#EC4899', icon:'dollar', viz:'spark' }
  ];
  var cardsHTML = cards.map(statCardPro).join('');

  // gráfico de barras por dia
  var serie=kpiSeries(); var maxV=Math.max.apply(null, serie.map(function(x){ return x.total; }).concat([1]));
  var bars = serie.map(function(x){
    var h = maxV>0 ? Math.max(2, Math.round(x.total/maxV*100)) : 2;
    var dd = x.date.slice(8,10)+'/'+x.date.slice(5,7);
    var hoje = x.date===today();
    return '<div class="kpi-bar" title="'+dd+': '+brlShort(x.total)+'">'+
      '<div class="kpi-bar-fill'+(hoje?' today':'')+'" style="height:'+h+'%"></div>'+
      '<span class="kpi-bar-x">'+dd+'</span></div>';
  }).join('');
  var chartBody = serie.some(function(x){ return x.total>0; })
    ? '<div class="kpi-bars">'+bars+'</div>'
    : '<div class="dash-empty">Sem faturamento registrado ainda. Os dados aparecem conforme o Bling sincroniza (a cada hora) e as vendas acontecem.</div>';
  var chart = dashPanel('Faturamento por dia', icon('trend'), chartBody);

  // RANKING de lojas (admin, visão consolidada)
  var breakdown='';
  if (admin && !sid){
    var byStore={};
    rows.forEach(function(f){ var k=String(f.store_unit_id); if(!byStore[k]) byStore[k]={fat:0,ped:0}; byStore[k].fat+=(Number(f.total)||0); byStore[k].ped+=(Number(f.orders_count)||0); });
    var ls=lojasGestao();
    var ranked=ls.map(function(s){ var d=byStore[String(s.id)]||{fat:0,ped:0}; var mt=lojaMetaMes(s.id); return { id:s.id, name:(s.name||('Loja '+s.store_number)), fat:d.fat, ped:d.ped, tk:(d.ped>0?d.fat/d.ped:0), metaPct:mt.pct, meta:mt.meta }; }).sort(function(a,b){ return b.fat-a.fat; });
    var medalC=['#F59E0B','#9CA3AF','#B45309'];
    var brows = ranked.length ? ranked.map(function(d,i){
      var badge = i<3 ? '<span class="kpi-medal" style="background:'+medalC[i]+'">'+(i+1)+'</span>' : '<span class="kpi-pos">'+(i+1)+'</span>';
      return '<button class="kpi-srow" data-rkstore="'+esc(d.id)+'">'+badge+
        '<span class="kpi-srow-n">'+esc(d.name)+'</span>'+
        '<span class="kpi-srow-mid"><span class="kpi-srow-v">'+brlShort(d.fat)+'</span><span class="kpi-srow-s">'+d.ped+' ped · ticket '+brlShort(d.tk)+'</span></span>'+
        (d.meta>0?'<span class="kpi-srow-meta"><span class="kpi-meta-bar"><span style="width:'+d.metaPct+'%"></span></span><span class="kpi-meta-pct">'+d.metaPct+'%</span></span>':'<span class="kpi-srow-meta"><span class="kpi-meta-none">sem meta</span></span>')+
      '</button>';
    }).join('') : '<div class="dash-empty">Sem lojas para ranquear.</div>';
    breakdown = dashPanel('Ranking de lojas ('+perLabel+')', icon('trend'), brows);
  }

  // controles: período + (admin) seletor de loja
  var seg = ['dia','semana','mes'].map(function(p){
    var lb = p==='dia'?'Dia':(p==='semana'?'Semana':'Mês');
    return '<button class="kpi-seg-b'+(ST.kpiPeriod===p?' on':'')+'" data-kpiper="'+p+'">'+lb+'</button>';
  }).join('');
  var storeSel='';
  if (admin && ST.sector==='lojas' && !ST.store && (ST.storeUnits||[]).length>0) {
    var so='<option value="">Todas as lojas</option>'+ST.storeUnits.map(function(s){return '<option value="'+esc(s.id)+'"'+(String(ST.taskStore)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';}).join('');
    storeSel='<select class="task-filter" id="kpiStore" title="Ver loja">'+so+'</select>';
  }
  var sub = sid ? ('Loja: '+esc(storeName(sid))) : 'Visão consolidada (todas as lojas)';

  return '<div class="tasks-head"><div><h2>KPIs</h2><div class="sub">'+sub+'</div></div>'+
    '<div class="kpi-controls">'+storeSel+'<div class="kpi-seg">'+seg+'</div></div></div>'+
    '<div class="dash-cards">'+cardsHTML+'</div>'+
    chart + breakdown;
}
function bindKPIs(){
  var segs=document.querySelectorAll('[data-kpiper]');
  for (var i=0;i<segs.length;i++) segs[i].addEventListener('click', function(){ ST.kpiPeriod=this.getAttribute('data-kpiper'); renderPage(); });
  var ks=document.getElementById('kpiStore');
  if (ks) ks.addEventListener('change', function(){ ST.taskStore=this.value; renderPage(); });
  var rk=document.querySelectorAll('.kpi-srow[data-rkstore]');
  for (var z=0;z<rk.length;z++) rk[z].addEventListener('click', function(){ ST.taskStore=this.getAttribute('data-rkstore'); renderPage(); });
}

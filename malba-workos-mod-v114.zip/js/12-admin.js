/* ========== [10f] CONFIGURAÇÕES / ADMIN (só admin) ========== */
/* ===== v89: HIERARQUIA DE USUÁRIOS =====
   Cinco níveis, cada um com permissões próprias declaradas numa tabela.
   Nada de comparação de "rank" espalhada pelo código: tudo passa por can(). */
var NIVEIS = {
  viewer:      { label:'Visualizador',        color:'#9aa1ad', rank:1, desc:'Apenas consulta informações.' },
  colaborador: { label:'Colaborador',         color:'#0EA5E9', rank:2, desc:'Executa tarefas, conclui checklists e envia evidências.' },
  supervisor:  { label:'Supervisor',          color:'#F59E0B', rank:3, desc:'Acompanha a execução, redistribui tarefas e acompanha indicadores.' },
  gestor:      { label:'Gestor',              color:'#3B6FF7', rank:4, desc:'Administra a equipe, cria projetos e rotinas (POPs) e administra as tarefas.' },
  admin:       { label:'Administrador Geral', color:'#8B5CF6', rank:5, desc:'Acesso total: estrutura, lojas, usuários e integrações.' }
};
var NIV_ORDER = ['viewer','colaborador','supervisor','gestor','admin'];
// nomes antigos continuam valendo (nada quebra pra quem já está cadastrado)
var NIVEL_ALIAS = { user:'colaborador', store_manager:'supervisor', sector_admin:'gestor', admin_geral:'admin', super:'admin' };
// O QUE CADA NÍVEL PODE — a fonte única de verdade
var CAPS = {
  admin:       { sistema:1, equipe:1, gerir:1, rotinas:1, redistribuir:1, indicadores:1, executar:1, estrategia:1, docs:1 },
  gestor:      {            equipe:1, gerir:1, rotinas:1, redistribuir:1, indicadores:1, executar:1, estrategia:1, docs:1 },
  supervisor:  {                                          redistribuir:1, indicadores:1, executar:1, estrategia:1, docs:1 },
  colaborador: {                                                                         executar:1,               docs:1 }, // v96: colaborador CRIA docs por padrão
  viewer:      {                                                                                                    docs:1 } // v96: viewer só LÊ (não cria/edita — controle no canEdit)
};
// lê o nível de um registro de usuário de forma resiliente
function nivelDe(u) {
  if (!u) return 'colaborador';
  var a = u.access_level;
  if (a && NIVEIS[a]) return a;
  if (a && NIVEL_ALIAS[a]) return NIVEL_ALIAS[a];
  if (u.role==='admin') return 'admin';
  if (u.role==='sector_admin' || u.sector_role==='admin') return 'gestor';
  if (u.role==='store_manager' || u.sector_role==='supervisor') return 'supervisor';
  return 'colaborador';
}
// can('gerir') — a única pergunta que o resto do sistema faz sobre permissão
function can(cap, s){
  s = s || ST.session;
  if (!s || !s.user) return false;
  // v110: se tiver perfil customizado, usa capsDoUsuario; senão, o CAPS por nível como antes
  if (typeof capsDoUsuario === 'function' && s.user.profile_id){
    return !!(capsDoUsuario(s.user)[cap]);
  }
  var nv = nivelDe(s.user);
  return !!((CAPS[nv]||{})[cap]);
}
function nivelInfo(s){ return NIVEIS[nivelDe((s||ST.session||{}).user)] || NIVEIS.colaborador; }

function configHTML() {
  if (!isAdmin(ST.session)) {
    return '<div class="empty-page"><div class="ep-ico">'+icon('gear')+'</div><h3>Acesso restrito</h3><p>Apenas administradores acessam as configurações.</p></div>';
  }
  var tab = ST.configTab || 'usuarios';
  var tabs = '<div class="cfg-tabs">'+
    '<button class="cfg-tab'+(tab==='usuarios'?' on':'')+'" data-tab="usuarios">'+icon('users')+'Usuários</button>'+
    '<button class="cfg-tab'+(tab==='lojas'?' on':'')+'" data-tab="lojas">'+icon('store')+'Lojas</button>'+
    '<button class="cfg-tab'+(tab==='banners'?' on':'')+'" data-tab="banners">'+icon('dashboard')+'Banners</button>'+
  '</div>';
  var body = tab==='lojas' ? lojasHTML() : (tab==='banners' ? bannersAdminHTML() : usuariosHTML());
  return '<div class="tasks-head"><div><h2>Configurações</h2><div class="sub">Administração do sistema</div></div></div>'+tabs+'<div id="cfgBody">'+body+'</div>';
}

/* ----- Usuários ----- */
function usuariosHTML() {
  // super vê todos; admin de setor vê só o próprio setor
  var list = isSuper(ST.session) ? ST.allUsers : ST.allUsers.filter(function(u){ return u.sector===ST.sector; });
  var rows = '';
  if (list.length===0) {
    rows = emptyState({ icon:'users', title:'Nenhum usuário', text:'Cada pessoa entra com o próprio login e vê só o que precisa.', cta:'Novo usuário' });
  } else {
    rows = '<div class="cfg-list">';
    list.forEach(function(u){
      var nv = NIVEIS[nivelDe(u)] || NIVEIS.colaborador;
      var setor = SECTORS[u.sector] ? SECTORS[u.sector].label : (u.sector||'—');
      rows += '<div class="cfg-row" data-uid="'+esc(u.id)+'">'+
        '<span class="crm-av" style="background:'+(u.color||'#3B6FF7')+'22;color:'+(u.color||'#3B6FF7')+'">'+esc(iniciais(u.name))+'</span>'+
        '<div class="crm-main"><b>'+esc(u.name||'—')+'</b><i>'+esc(u.email||'')+' · '+esc(setor)+'</i></div>'+
        '<span class="crm-status" style="color:'+nv.color+';background:'+nv.color+'18">'+nv.label+'</span>'+
      '</div>';
    });
    rows += '</div>';
  }
  return '<div class="cfg-sec-head"><span>'+list.length+' usuário(s)</span>'+(canEdit()?'<button class="btn-new" id="btnNovoUser">'+icon('plus')+'Novo usuário</button>':'')+'</div>'+rows;
}

function openUserModal(user) {
  if(!canEdit()){ blockManage(); return; }
  var isNew = !user;
  var u = user || { name:'', email:'', sector:ST.sector, color:'#3B6FF7' };
  var nivel = isNew ? 'colaborador' : nivelDe(u);
  var seedPerms = userPermMap({ user:u });
  var grantorRank = roleRank(ST.session); // só posso conceder níveis abaixo (ou igual) ao meu
  var nivelOpts = NIV_ORDER.filter(function(k){ return NIVEIS[k].rank <= grantorRank; }).map(function(k){
    return '<option value="'+k+'"'+(nivel===k?' selected':'')+'>'+NIVEIS[k].label+'</option>';
  }).join('');
  var canSuper = isSuper(ST.session);
  var sectorOpts = Object.keys(SECTORS).map(function(k){ return '<option value="'+k+'"'+(u.sector===k?' selected':'')+'>'+SECTORS[k].label+'</option>'; }).join('');

  var emailField = isNew
    ? '<div class="modal-row"><label class="modal-label">E-mail *</label><input type="text" id="uEmail" placeholder="voce@malba.com.br" value=""></div>'
    : '<div class="modal-row"><label class="modal-label">E-mail</label><input type="text" id="uEmail" value="'+esc(u.email||'')+'" disabled style="opacity:.6"></div>';
  var passField = '<div class="modal-row"><label class="modal-label">Senha '+(isNew?'*':'(deixe em branco para manter)')+'</label><input type="text" id="uPass" placeholder="'+(isNew?'senha de acesso':'•••••••• (inalterada)')+'" value=""></div>';

  var delBtn = (isNew || (u.id===ST.session.user.id)) ? '' : '<button class="btn btn-danger btn-del-wrap" id="userDel">Excluir</button>';

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<input class="modal-title-input" id="uName" placeholder="Nome do usuário..." value="'+esc(u.name||'')+'">'+
      emailField + passField +
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Setor</label><select id="uSector">'+sectorOpts+'</select></div><div class="modal-row"><label class="modal-label">Nível de acesso</label><select id="uLevel">'+nivelOpts+'</select></div></div>'+
      // v113: perfil customizado (só aparece se houver algum cadastrado)
      ((ST.perfis||[]).length ? (
        '<div class="modal-row"><label class="modal-label">Perfil de permissão <span class="cad-sub">(opcional — sobrepõe o nível)</span></label>'+
          '<select id="uPerfil">'+
            '<option value="">— usar apenas o nível de acesso —</option>'+
            (ST.perfis||[]).map(function(p){ return '<option value="'+esc(p.id)+'"'+(String(u.profile_id||'')===String(p.id)?' selected':'')+'>'+esc(p.label)+' (baseado em '+esc((NIVEIS[p.base_nivel]||{label:p.base_nivel}).label)+')</option>'; }).join('')+
          '</select>'+
        '</div>'
      ) : '')+
      '<div class="nivel-desc" id="uNivelDesc">'+esc((NIVEIS[nivel]||NIVEIS.colaborador).desc)+'</div>'+
      '<div id="permHolder"></div>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="userCancel">Cancelar</button><button class="btn btn-primary" id="userSave">'+(isNew?'Criar usuário':'Salvar')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);
  (function(){ var sel=modal.querySelector('#uLevel'), d=modal.querySelector('#uNivelDesc');
    if(sel&&d) sel.addEventListener('change', function(){ d.textContent=(NIVEIS[this.value]||{}).desc||''; }); })();

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#userCancel').addEventListener('click', close);
  modal.querySelector('#uName').focus();
  function updatePerms(preserve){
    var lvl=modal.querySelector('#uLevel').value; var sec=modal.querySelector('#uSector').value; var holder=modal.querySelector('#permHolder');
    if(lvl!=='user'){ holder.innerHTML='<div class="perm-note-hier">Este nível já tem acesso completo pela hierarquia. As permissões por função valem para o nível <b>Colaborador</b>.</div>'; return; }
    var cur = (preserve && holder.querySelector('.perm-seg')) ? readPerms(modal) : seedPerms;
    holder.innerHTML = permsPickerHTML(sec, cur); bindPermsPicker(modal);
  }
  modal.querySelector('#uLevel').addEventListener('change', function(){ updatePerms(true); });
  modal.querySelector('#uSector').addEventListener('change', function(){ updatePerms(true); });
  updatePerms(false);
  function aplicarPerms(id){ var lvl=modal.querySelector('#uLevel').value; var pr=(lvl==='user')?readPerms(modal):{}; savePerms(id, pr); }

  modal.querySelector('#userSave').addEventListener('click', function(){
    var name=(modal.querySelector('#uName').value||'').trim();
    var email=(modal.querySelector('#uEmail').value||'').trim().toLowerCase();
    var pass=(modal.querySelector('#uPass').value||'').trim();
    if (!name) { toast('Informe o nome','error'); return; }
    if (isNew && !email) { toast('Informe o e-mail','error'); return; }
    if (isNew && !pass) { toast('Defina uma senha','error'); return; }
    var lvl = modal.querySelector('#uLevel').value;
    // modelo resiliente: grava role + access_level + sector_role coerentes com a hierarquia
    var ehAdminSetor = (lvl==='sector_admin' || lvl==='admin_geral' || lvl==='super');
    var rec = {
      name:name,
      sector:modal.querySelector('#uSector').value,
      access_level:lvl,
      sector_role:(ehAdminSetor?'admin':'user'),
      role:(lvl==='super'?'admin':'user')
    };
    // v113: perfil customizado — se o dropdown existir e tiver valor, grava; se vazio, limpa
    var perfilSel = modal.querySelector('#uPerfil');
    if (perfilSel) rec.profile_id = perfilSel.value || null;
    if (isNew) { rec.email=email; rec.color=u.color||'#3B6FF7'; rec.initials=iniciais(name); }
    if (pass) rec.password_hash = pass; // a tabela guarda a senha em password_hash
    var saveBtn=modal.querySelector('#userSave'); setBusy(saveBtn,true);
    if (isNew) {
      sb.from('malba_users').insert(rec).select().single().then(function(r){
        if (r.error || !r.data) { toast('Erro ao criar (e-mail já existe?)','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Criar usuário'; return; }
        ST.allUsers.push(r.data); auditLog('Criou usuário', name+' · '+(NIVEIS[lvl]?NIVEIS[lvl].label:lvl)); aplicarPerms(r.data.id); close(); toast('Usuário criado','success'); renderPage();
      });
    } else {
      sb.from('malba_users').update(rec).eq('id', u.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar'; return; }
        for (var i=0;i<ST.allUsers.length;i++) if (ST.allUsers[i].id===u.id) { ST.allUsers[i]=Object.assign(ST.allUsers[i],rec); break; }
        aplicarPerms(u.id); close(); toast('Usuário atualizado','success'); renderPage();
      });
    }
  });

  if (!isNew && u.id!==ST.session.user.id) {
    modal.querySelector('#userDel').addEventListener('click', function(){
      confirmDelete('Excluir o usuário "'+(u.name||'')+'"?', function(){ sb.from('malba_users').delete().eq('id', u.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.allUsers = ST.allUsers.filter(function(x){ return x.id!==u.id; });
        close(); toast('Usuário excluído','success'); renderPage();
      }); });
    });
  }
}

/* ----- Lojas (com vínculo user_id) ----- */
function lojasHTML() {
  var list = ST.storeUnits.slice().sort(function(a,b){ return (a.store_number||0)-(b.store_number||0); });
  var rows = '';
  if (list.length===0) {
    rows = emptyState({ icon:'store', title:'Nenhuma loja', text:'Cadastre suas lojas para separar equipe, metas e vendas por unidade.', cta:'Nova loja' });
  } else {
    rows = '<div class="cfg-list">';
    list.forEach(function(s){
      var conta = s.user_id ? userByIdAll(s.user_id) : null;
      var vinc = conta ? ('Conta: '+esc(conta.name)) : 'Sem conta vinculada';
      var vincCor = conta ? 'var(--u-green)' : 'var(--u-amber)';
      var bl = blingDaLoja(s.id);
      var blConn = bl && bl.connected;
      var blLabel = blConn ? 'Bling conectado' : ((bl && bl.client_id) ? 'Conectar Bling' : 'Configurar Bling');
      var blBtn = '<button class="bling-btn'+(blConn?' on':'')+'" data-bling="'+esc(s.id)+'">'+icon(blConn?'trend':'plus')+blLabel+'</button>';
      var errLine = (bl && bl.last_error) ? '<div class="bling-err">⚠️ Último erro: '+esc(String(bl.last_error))+'</div>' : '';
      rows += '<div class="cfg-row bling-row" data-sid="'+esc(s.id)+'">'+
        '<span class="crm-av" style="background:var(--u-accent-soft);color:var(--u-accent)">'+icon('store')+'</span>'+
        '<div class="crm-main"><b>'+esc(s.name||('Loja '+s.store_number))+(s.is_site?' <span class="site-badge">🌐 Site</span>':'')+'</b><i>'+(s.district?esc(s.district)+' · ':'')+'<span style="color:'+vincCor+'">'+vinc+'</span></i>'+errLine+'</div>'+
        blBtn+
        '<span class="crm-status" style="color:var(--u-text2);background:var(--u-bg2)">#'+esc(s.store_number||'?')+'</span>'+
      '</div>';
    });
    rows += '</div>';
  }
  return '<div class="cfg-sec-head"><span>'+list.length+' loja(s)</span><div class="cfg-head-btns">'+(canEdit()?'<button class="btn-sync" id="btnSyncBling">'+icon('trend')+'Sincronizar Bling</button><button class="btn-new" id="btnNovaLoja">'+icon('plus')+'Nova loja</button>':'')+'</div></div>'+rows;
}
function userByIdAll(id){ for(var i=0;i<ST.allUsers.length;i++) if(ST.allUsers[i].id===id) return ST.allUsers[i]; return null; }
function blingDaLoja(id){ var b=ST.bling||[]; for(var i=0;i<b.length;i++) if(String(b[i].store_unit_id)===String(id)) return b[i]; return null; }
function openBlingModal(store) {
  var est = blingDaLoja(store.id);
  var connected = est && est.connected;
  var cid = (est && est.client_id) ? est.client_id : '';
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal">'+
    '<div class="modal-title-input" style="cursor:default">Bling · '+esc(store.name||('Loja '+store.store_number))+'</div>'+
    (connected?'<div class="bling-ok-note">'+icon('trend')+'Esta loja já está conectada ao Bling.</div>':'')+
    '<div class="bling-help">Cole o <b>Client ID</b> e o <b>Client Secret</b> do app criado na conta Bling <b>desta loja</b> (developer.bling.com.br → app Privado).</div>'+
    '<div class="modal-row"><label class="modal-label">Client ID</label><input type="text" id="blCid" placeholder="client_id da loja" value="'+esc(cid)+'"></div>'+
    '<div class="modal-row"><label class="modal-label">Client Secret</label><input type="password" id="blSecret" placeholder="client_secret da loja" autocomplete="new-password"></div>'+
    '<div class="bling-help" style="margin-top:2px">O Client Secret fica guardado em segurança e não é exibido de volta.'+(cid?' Já configurado antes? Deixe o Secret em branco para manter o atual.':'')+'</div>'+
    '<div class="modal-foot"><button class="btn btn-ghost" id="blCancel">Fechar</button><button class="btn btn-primary" id="blSave">Salvar e conectar</button></div>'+
  '</div>';
  document.body.appendChild(modal);
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click',function(e){ if(e.target===modal) close(); });
  modal.querySelector('#blCancel').addEventListener('click', close);
  modal.querySelector('#blSave').addEventListener('click', function(){
    var clientId=(modal.querySelector('#blCid').value||'').trim();
    var secret=(modal.querySelector('#blSecret').value||'').trim();
    if(!clientId){ toast('Informe o Client ID','error'); return; }
    if(!secret && !cid){ toast('Informe o Client Secret','error'); return; }
    var btn=modal.querySelector('#blSave'); setBusy(btn,true);
    var now=new Date().toISOString();
    var appRow={ store_unit_id:store.id, client_id:clientId, updated_at:now };
    if(secret) appRow.client_secret=secret;
    sb.from('malba_bling_apps').upsert(appRow, { onConflict:'store_unit_id' }).then(function(r1){
      if (r1.error) { console.error('[bling apps]', r1.error); toast('Erro (apps): '+(r1.error.message||r1.error.hint||'falha'),'error'); setBusy(btn,false); btn.textContent='Salvar e conectar'; return; }
      sb.from('malba_bling_estado').upsert({ store_unit_id:store.id, client_id:clientId, updated_at:now }, { onConflict:'store_unit_id' }).then(function(r2){
        if (r2.error) { console.error('[bling estado]', r2.error); toast('Erro (estado): '+(r2.error.message||r2.error.hint||'falha'),'error'); setBusy(btn,false); btn.textContent='Salvar e conectar'; return; }
        toast('Credenciais salvas. Indo ao Bling para autorizar...','success');
        setTimeout(function(){ window.location.href = blingAuthUrl(clientId, store.id); }, 700);
      });
    });
  });
}

function openStoreModal(store) {
  if(!canEdit()){ blockManage(); return; }
  var isNew = !store;
  var s = store || { name:'', store_number:(ST.storeUnits.length+1), district:'', address:'', phone:'', whatsapp:'', email:'', user_id:null };

  // usuários do setor lojas, candidatos a conta de acesso da loja
  var lojaUsers = ST.allUsers.filter(function(u){ return u.sector==='lojas'; });
  var userOpts = '<option value="">— Sem conta vinculada —</option>';
  lojaUsers.forEach(function(u){ userOpts += '<option value="'+esc(u.id)+'"'+(s.user_id===u.id?' selected':'')+'>'+esc(u.name)+' ('+esc(u.email)+')</option>'; });

  var delBtn = isNew ? '' : '<button class="btn btn-danger btn-del-wrap" id="storeDel">Excluir</button>';

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<input class="modal-title-input" id="sName" placeholder="Nome da loja..." value="'+esc(s.name||'')+'">'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Número</label><input type="text" id="sNum" value="'+esc(s.store_number||'')+'"></div><div class="modal-row"><label class="modal-label">Bairro</label><input type="text" id="sDistrict" value="'+esc(s.district||'')+'"></div></div>'+
      '<div class="modal-row"><label class="modal-label">Endereço</label><input type="text" id="sAddress" value="'+esc(s.address||'')+'"></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Telefone</label><input type="text" id="sPhone" value="'+esc(s.phone||'')+'"></div><div class="modal-row"><label class="modal-label">E-mail</label><input type="text" id="sEmail" value="'+esc(s.email||'')+'"></div></div>'+
      '<div class="modal-row"><label class="modal-label">Conta de acesso (login da loja)</label><select id="sUser">'+userOpts+'</select><div style="font-size:11px;color:var(--u-text3);margin-top:5px">Liga a loja ao usuário que faz login por ela. É o que faz tarefas, equipe e metas aparecerem certo para a loja.</div></div>'+
      '<label class="acc-toggle" style="border:1px solid var(--u-border);border-radius:12px;padding:12px 14px;background:var(--u-bg2);margin-top:2px"><input type="checkbox" id="sSite"'+(s.is_site?' checked':'')+'><span class="acc-txt"><b>Esta é a conta do site (e-commerce)</b><i>O faturamento dela também aparece no painel de Marketing.</i></span></label>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="storeCancel">Cancelar</button><button class="btn btn-primary" id="storeSave">'+(isNew?'Criar loja':'Salvar')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#storeCancel').addEventListener('click', close);
  modal.querySelector('#sName').focus();

  modal.querySelector('#storeSave').addEventListener('click', function(){
    var name=(modal.querySelector('#sName').value||'').trim();
    if (!name) { toast('Informe o nome da loja','error'); return; }
    var rec = {
      name:name,
      store_number: parseInt(modal.querySelector('#sNum').value,10) || null,
      district:(modal.querySelector('#sDistrict').value||'').trim(),
      address:(modal.querySelector('#sAddress').value||'').trim(),
      phone:(modal.querySelector('#sPhone').value||'').trim(),
      email:(modal.querySelector('#sEmail').value||'').trim(),
      user_id: modal.querySelector('#sUser').value || null
    };
    var saveBtn=modal.querySelector('#storeSave'); setBusy(saveBtn,true);
    var siteChecked = !!(modal.querySelector('#sSite') && modal.querySelector('#sSite').checked);
    function aplicarSite(id){
      // best-effort: ignora se a coluna is_site ainda não existir
      sb.from('malba_store_units').update({ is_site:siteChecked }).eq('id', id).then(function(rl){ if(!rl.error){ for(var i=0;i<ST.storeUnits.length;i++) if(String(ST.storeUnits[i].id)===String(id)) ST.storeUnits[i].is_site=siteChecked; } });
    }
    if (isNew) {
      sb.from('malba_store_units').insert(rec).select().single().then(function(r){
        if (r.error || !r.data) { toast('Erro ao criar loja','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Criar loja'; return; }
        ST.storeUnits.push(r.data); aplicarSite(r.data.id); close(); toast('Loja criada','success'); renderPage();
      });
    } else {
      sb.from('malba_store_units').update(rec).eq('id', s.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar'; return; }
        for (var i=0;i<ST.storeUnits.length;i++) if (ST.storeUnits[i].id===s.id) { ST.storeUnits[i]=Object.assign(ST.storeUnits[i],rec); break; }
        aplicarSite(s.id); close(); toast('Loja atualizada','success'); renderPage();
      });
    }
  });

  if (!isNew) {
    modal.querySelector('#storeDel').addEventListener('click', function(){
      confirmDelete('Excluir a loja "'+(s.name||'')+'"?', function(){ sb.from('malba_store_units').delete().eq('id', s.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.storeUnits = ST.storeUnits.filter(function(x){ return x.id!==s.id; });
        close(); toast('Loja excluída','success'); renderPage();
      }); });
    });
  }
}

/* ----- Banners (gestão) ----- */
var BANNER_GRADS = [
  'linear-gradient(120deg,#1a1040,#0d1b4d 45%,#0a2540)',
  'linear-gradient(135deg,#3B6FF7,#6366F1)',
  'linear-gradient(135deg,#16A34A,#0EA5E9)',
  'linear-gradient(135deg,#F59E0B,#EF4444)',
  'linear-gradient(135deg,#8B5CF6,#EC4899)',
  'linear-gradient(135deg,#0F172A,#334155)'
];
function bannersAdminHTML() {
  var list = (ST.banners||[]).slice().sort(function(a,b){ return (a.position||0)-(b.position||0); });
  var rows = '';
  if (list.length===0) {
    rows = emptyState({ icon:'dashboard', title:'Nenhum banner', text:'Banners aparecem no Início dos setores para avisos e destaques.', cta:'Novo banner' });
  } else {
    rows = '<div class="banner-list">';
    list.forEach(function(b){
      var secs = (b.sectors||[]).map(function(s){ return SECTORS[s]?SECTORS[s].label:s; }).join(', ') || 'Todos os setores';
      var bg = b.image_url_desktop ? ('center/cover url("'+b.image_url_desktop+'")') : (b.bg_gradient||'var(--u-grad-hero)');
      var off = b.is_active===false;
      rows += '<div class="banner-item'+(off?' off':'')+'" data-bid="'+esc(b.id)+'">'+
        '<span class="banner-thumb" style="background:'+bg+'"></span>'+
        '<div class="banner-meta"><b>'+esc(b.title||'(sem título)')+'</b><i>'+esc(secs)+'</i></div>'+
        '<span class="crm-status" style="color:'+(off?'#9aa1ad':'#16A34A')+';background:'+(off?'#9aa1ad':'#16A34A')+'18">'+(off?'Inativo':'Ativo')+'</span>'+
      '</div>';
    });
    rows += '</div>';
  }
  return '<div class="cfg-sec-head"><span>'+list.length+' banner(s)</span>'+(canEdit()?'<button class="btn-new" id="btnNovoBanner">'+icon('plus')+'Novo banner</button>':'')+'</div>'+rows;
}

function openBannerModal(banner) {
  if(!canEdit()){ blockManage(); return; }
  var isNew = !banner;
  var b = banner || { title:'', description:'', bg_gradient:BANNER_GRADS[0], image_url_desktop:null, link_url:'', sectors:[], is_active:true, store_unit_id:null };
  var imgData = b.image_url_desktop || null;

  var gradBtns = BANNER_GRADS.map(function(g){
    return '<button type="button" class="grad-dot'+(b.bg_gradient===g?' on':'')+'" data-grad="'+esc(g)+'" style="background:'+g+'"></button>';
  }).join('');
  var secChecks = Object.keys(SECTORS).map(function(k){
    var on=(b.sectors||[]).indexOf(k)!==-1;
    return '<label class="member-pick'+(on?' on':'')+'"><input type="checkbox" data-bsec="'+k+'"'+(on?' checked':'')+'>'+esc(SECTORS[k].label)+'</label>';
  }).join('');

  var delBtn = isNew ? '' : '<button class="btn btn-danger btn-del-wrap" id="bannerDel">Excluir</button>';

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<input class="modal-title-input" id="bTitle" placeholder="Título do banner..." value="'+esc(b.title||'')+'">'+
      '<div class="modal-row"><label class="modal-label">Subtítulo</label><input type="text" id="bSub" value="'+esc(b.description||'')+'"></div>'+
      '<div class="modal-row"><label class="modal-label">Cor de fundo</label><div class="color-row" id="bGrads">'+gradBtns+'</div></div>'+
      '<div class="modal-row"><label class="modal-label">Imagem (opcional — substitui a cor)</label><div class="banner-up" id="bUpBox"><span id="bUpTxt">'+(imgData?'Imagem carregada — clique para trocar':'Clique para enviar uma imagem')+'</span><input type="file" accept="image/*" id="bImg" style="display:none"></div><div id="bPrev" class="banner-prev" style="'+(imgData?('background:center/cover url(\''+imgData+'\');display:block'):'display:none')+'"></div></div>'+
      '<div class="modal-row"><label class="modal-label">Link ao clicar (opcional)</label><input type="text" id="bLink" placeholder="https://..." value="'+esc(b.link_url||'')+'"></div>'+
      '<div class="modal-row"><label class="modal-label">Aparece nos setores</label><div class="member-picks">'+secChecks+'</div></div>'+
      '<div class="modal-row"><label class="modal-label">Situação</label><div class="pills" id="bStatus"><button type="button" class="pill bs-pill'+(b.is_active!==false?' on':'')+'" data-act="1" style="color:#16A34A"><span class="pdot" style="background:#16A34A"></span>Ativo</button><button type="button" class="pill bs-pill'+(b.is_active===false?' on':'')+'" data-act="0" style="color:#9aa1ad"><span class="pdot" style="background:#9aa1ad"></span>Inativo</button></div></div>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="bannerCancel">Cancelar</button><button class="btn btn-primary" id="bannerSave">'+(isNew?'Criar banner':'Salvar')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);

  var gradPick = b.bg_gradient || BANNER_GRADS[0];
  var gdots = modal.querySelectorAll('.grad-dot');
  for (var i=0;i<gdots.length;i++) gdots[i].addEventListener('click', function(){ for(var k=0;k<gdots.length;k++) gdots[k].classList.remove('on'); this.classList.add('on'); gradPick=this.getAttribute('data-grad'); });

  var actPick = (b.is_active !== false);
  bindPills(modal, '#bStatus .bs-pill', 'act', function(v){ actPick=(v==='1'); });
  var secCbs = modal.querySelectorAll('[data-bsec]');
  for (var j=0;j<secCbs.length;j++) secCbs[j].addEventListener('change', function(){ this.closest('.member-pick').classList.toggle('on', this.checked); });

  // upload de imagem -> base64
  var upBox=modal.querySelector('#bUpBox'), fileEl=modal.querySelector('#bImg'), prev=modal.querySelector('#bPrev'), upTxt=modal.querySelector('#bUpTxt');
  upBox.addEventListener('click', function(){ fileEl.click(); });
  fileEl.addEventListener('change', function(){
    var f=this.files&&this.files[0]; if(!f) return;
    if (f.size > 1.5*1024*1024) { toast('Imagem muito grande (máx ~1,5MB)','error'); return; }
    var reader=new FileReader();
    reader.onload=function(ev){ imgData=ev.target.result; prev.style.background='center/cover url("'+imgData+'")'; prev.style.display='block'; upTxt.textContent='Imagem carregada — clique para trocar'; };
    reader.readAsDataURL(f);
  });

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#bannerCancel').addEventListener('click', close);
  modal.querySelector('#bTitle').focus();

  modal.querySelector('#bannerSave').addEventListener('click', function(){
    var title=(modal.querySelector('#bTitle').value||'').trim();
    if (!title) { toast('Informe o título','error'); return; }
    var secs=[]; modal.querySelectorAll('[data-bsec]:checked').forEach(function(cb){ secs.push(cb.getAttribute('data-bsec')); });
    var rec = {
      title:title,
      description:(modal.querySelector('#bSub').value||'').trim(),
      bg_gradient:gradPick,
      image_url_desktop:imgData||null,
      image_url_mobile:imgData||null,
      link_url:(modal.querySelector('#bLink').value||'').trim()||null,
      sectors:secs,
      is_active:actPick,
      store_unit_id:null
    };
    var saveBtn=modal.querySelector('#bannerSave'); setBusy(saveBtn,true);
    if (isNew) {
      rec.position=(ST.banners||[]).length;
      sb.from('malba_banners').insert(rec).select().single().then(function(r){
        if (r.error || !r.data) { toast('Erro ao criar banner','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Criar banner'; return; }
        ST.banners.push(r.data); close(); toast('Banner criado','success'); renderPage();
      });
    } else {
      sb.from('malba_banners').update(rec).eq('id', b.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar'; return; }
        for (var i=0;i<ST.banners.length;i++) if (ST.banners[i].id===b.id) { ST.banners[i]=Object.assign(ST.banners[i],rec); break; }
        close(); toast('Banner atualizado','success'); renderPage();
      });
    }
  });

  if (!isNew) {
    modal.querySelector('#bannerDel').addEventListener('click', function(){
      confirmDelete('Excluir este banner?', function(){ sb.from('malba_banners').delete().eq('id', b.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.banners = ST.banners.filter(function(x){ return x.id!==b.id; });
        close(); toast('Banner excluído','success'); renderPage();
      }); });
    });
  }
}

function bindConfig() {
  if (!isAdmin(ST.session)) return;
  var tabs = app.querySelectorAll('.cfg-tab');
  for (var i=0;i<tabs.length;i++) tabs[i].addEventListener('click', function(){ ST.configTab=this.getAttribute('data-tab'); renderPage(); });

  var nu = document.getElementById('btnNovoUser');
  if (nu) nu.addEventListener('click', function(){ openUserModal(null); });
  var uRows = app.querySelectorAll('.cfg-row[data-uid]');
  for (var j=0;j<uRows.length;j++) uRows[j].addEventListener('click', function(){
    var id=this.getAttribute('data-uid'); var u=userByIdAll(id);
    if (u) openUserModal(u);
  });

  var nl = document.getElementById('btnNovaLoja');
  if (nl) nl.addEventListener('click', function(){ openStoreModal(null); });
  var bs = document.getElementById('btnSyncBling');
  if (bs) bs.addEventListener('click', function(){
    var old=bs.innerHTML; bs.disabled=true; bs.textContent='Sincronizando...';
    toast('Buscando vendas no Bling...','success');
    fetch(SUPABASE_URL+'/functions/v1/bling-sync', {
      method:'POST',
      headers:{ 'Authorization':'Bearer '+SUPABASE_ANON_KEY, 'apikey':SUPABASE_ANON_KEY, 'Content-Type':'application/json' },
      body:'{}'
    }).then(function(res){ return res.json().catch(function(){ return { httpStatus:res.status }; }); }).then(function(d){
      bs.disabled=false; bs.innerHTML=old;
      console.log('[bling-sync]', d);
      if (!d || d.ok!==true) { toast('Sincronização: '+((d&&(d.message||d.error))||('falha HTTP '+(d&&d.httpStatus||'')) ),'error'); return; }
      var rs=d.results||[]; var erros=rs.filter(function(x){ return x.erro; });
      if (erros.length) { toast('Sincronizou, mas '+erros.length+' loja(s) com aviso (veja o console)','error'); }
      else { toast('Bling sincronizado! '+rs.length+' loja(s)','success'); }
      loadData().then(function(){ renderPage(); });
    }).catch(function(e){ bs.disabled=false; bs.innerHTML=old; console.error(e); toast('Erro ao sincronizar: '+e.message,'error'); });
  });
  var sRows = app.querySelectorAll('.cfg-row[data-sid]');
  for (var k=0;k<sRows.length;k++) sRows[k].addEventListener('click', function(){
    var id=this.getAttribute('data-sid'); var st=null;
    for (var x=0;x<ST.storeUnits.length;x++) if (String(ST.storeUnits[x].id)===String(id)) { st=ST.storeUnits[x]; break; }
    if (st) openStoreModal(st);
  });
  var blingBtns = app.querySelectorAll('.bling-btn[data-bling]');
  for (var bb2=0;bb2<blingBtns.length;bb2++) blingBtns[bb2].addEventListener('click', function(e){
    e.stopPropagation();
    var sid=this.getAttribute('data-bling'); var st=null;
    for (var x=0;x<ST.storeUnits.length;x++) if (String(ST.storeUnits[x].id)===String(sid)) { st=ST.storeUnits[x]; break; }
    if (st) openBlingModal(st);
  });

  var nb = document.getElementById('btnNovoBanner');
  if (nb) nb.addEventListener('click', function(){ openBannerModal(null); });
  var bRows = app.querySelectorAll('.banner-item[data-bid]');
  for (var z=0;z<bRows.length;z++) bRows[z].addEventListener('click', function(){
    var id=this.getAttribute('data-bid'); var bb=null;
    for (var x=0;x<ST.banners.length;x++) if (String(ST.banners[x].id)===String(id)) { bb=ST.banners[x]; break; }
    if (bb) openBannerModal(bb);
  });
}

/* ========== [10g] CAMPANHAS (Marketing) ========== */
var CAMP_COLORS = ['#3B6FF7','#E53935','#1E88E5','#43A047','#8E24AA','#FB8C00','#D81B60','#00ACC1'];
function uid(){ return (window.crypto&&crypto.randomUUID)?crypto.randomUUID():('c'+Date.now()+Math.random().toString(36).slice(2,8)); }

function campStatus(c) {
  var t=today();
  var ini=(c.start_date||'').split('T')[0], fim=(c.end_date||'').split('T')[0];
  if (fim && fim<t) return { label:'Encerrada', color:'#9aa1ad' };
  if (ini && ini>t) return { label:'Agendada', color:'#F59E0B' };
  return { label:'Ativa', color:'#16A34A' };
}

function campanhasHTML() {
  var admin = isAdmin(ST.session);
  var cs = ST.campaigns.slice().sort(function(a,b){ return (b.start_date||'').localeCompare(a.start_date||''); });
  var cards='';
  if (cs.length===0) {
    var msg = admin ? 'Crie a primeira campanha pelo botão acima.' : 'Nenhuma campanha cadastrada.';
    cards = emptyState({ span:true, icon:'megaphone', title:'Nenhuma campanha', text:msg, cta:(canEdit()?'Nova campanha':'') });
  } else {
    cs.forEach(function(c){ cards += campCardHTML(c); });
  }
  var btn = admin ? '<button class="btn-new" id="btnNovaCamp">'+icon('plus')+'Nova campanha</button>' : '';
  return '<div class="tasks-head"><div><h2>Campanhas</h2><div class="sub">'+cs.length+' campanha(s)</div></div>'+btn+'</div><div class="camp-grid">'+cards+'</div>';
}
function campCardHTML(c) {
  var cor=c.color||'#3B6FF7';
  var st=campStatus(c);
  var tks=c.tasks||[]; var nTasks=tks.length; var done=tks.filter(function(x){return x.done;}).length;
  var pct=nTasks?Math.round(done/nTasks*100):0;
  var nPart=(c.user_ids||[]).length;
  var periodo = (c.start_date?fmtDate(c.start_date):'') + (c.end_date?(' → '+fmtDate(c.end_date)):'');
  var prog = nTasks ? '<div class="proj-prog"><div class="proj-prog-bar"><span style="width:'+pct+'%;background:'+cor+'"></span></div><small>'+pct+'% · '+done+'/'+nTasks+' tarefas</small></div>' : '';
  return '<div class="camp-card" data-id="'+esc(c.id)+'">'+
    '<span class="camp-bar" style="background:'+cor+'"></span>'+
    '<div class="camp-body"><div class="camp-top"><b>'+esc(c.name)+'</b><span class="crm-status" style="color:'+st.color+';background:'+st.color+'18">'+st.label+'</span></div>'+
    (c.description?'<p>'+esc(c.description)+'</p>':'')+
    '<div class="camp-meta"><span class="tc-date">'+icon('cal')+(periodo||'sem datas')+'</span>'+(c.area?'<span class="tc-chip">'+esc(c.area)+'</span>':'')+'</div>'+
    prog+
    '<div class="camp-foot"><span>'+nTasks+' tarefa(s)</span><span>'+nPart+' participante(s)</span></div>'+
    '</div></div>';
}
function bindCampanhas() {
  var admin = isAdmin(ST.session);
  var nova=document.getElementById('btnNovaCamp');
  if (nova && admin) nova.addEventListener('click', function(){ openCampaignModal(null); });
  if (!admin) return;
  var cards=app.querySelectorAll('.camp-card');
  for (var i=0;i<cards.length;i++) cards[i].addEventListener('click', function(){
    var id=this.getAttribute('data-id'); var c=null;
    for (var k=0;k<ST.campaigns.length;k++) if (String(ST.campaigns[k].id)===String(id)) { c=ST.campaigns[k]; break; }
    if (c) openCampaignModal(c);
  });
}

function openCampaignModal(camp) {
  if(!canEdit()){ blockManage(); return; }
  var isNew=!camp;
  var t=today(); var wl=new Date(); wl.setDate(wl.getDate()+7);
  var c = camp || { name:'', description:'', start_date:t, end_date:wl.getFullYear()+'-'+pad(wl.getMonth()+1)+'-'+pad(wl.getDate()), color:'#3B6FF7', area:'', user_ids:[], tasks:[] };
  var taskList = (c.tasks||[]).slice();      // lista de tarefas da campanha (em memória)
  var partSel = (c.user_ids||[]).slice();

  var colorBtns=CAMP_COLORS.map(function(col){ return '<button type="button" class="color-dot'+(c.color===col?' on':'')+'" data-color="'+col+'" style="background:'+col+'"></button>'; }).join('');
  var partHTML=ST.users.map(function(u){
    var on=partSel.indexOf(u.id)!==-1;
    return '<label class="member-pick'+(on?' on':'')+'"><input type="checkbox" data-part="'+esc(u.id)+'"'+(on?' checked':'')+'><span class="member-pick-av" style="background:'+(u.color||'#3B6FF7')+'">'+esc(iniciais(u.name))+'</span>'+esc(u.name)+'</label>';
  }).join('');
  if (ST.users.length===0) partHTML='<div style="font-size:12px;color:var(--u-text3)">Nenhuma pessoa no setor</div>';

  var delBtn=isNew?'':'<button class="btn btn-danger btn-del-wrap" id="campDel">Excluir</button>';

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<input class="modal-title-input" id="cpName" placeholder="Nome da campanha..." value="'+esc(c.name)+'">'+
      '<div class="modal-row"><label class="modal-label">Descrição</label><textarea id="cpDesc" placeholder="Objetivo, observações...">'+esc(c.description||'')+'</textarea></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Início</label><input type="date" id="cpStart" value="'+esc((c.start_date||'').split('T')[0])+'"></div><div class="modal-row"><label class="modal-label">Término</label><input type="date" id="cpEnd" value="'+esc((c.end_date||'').split('T')[0])+'"></div></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Área</label><input type="text" id="cpArea" placeholder="ex: Redes sociais" value="'+esc(c.area||'')+'"></div><div class="modal-row"><label class="modal-label">Cor</label><div class="color-row" id="cpColors">'+colorBtns+'</div></div></div>'+
      '<div class="modal-row"><label class="modal-label">Tarefas da campanha</label><div id="cpTasks" class="camp-tasks"></div><div class="camp-task-add"><input type="text" id="cpNewTask" placeholder="Nova tarefa da campanha..."><select id="cpNewPrio"><option value="alta">Alta</option><option value="media" selected>Média</option><option value="baixa">Baixa</option></select><button type="button" class="btn btn-ghost" id="cpAddTask">+ Add</button></div></div>'+
      '<div class="modal-row"><label class="modal-label">Participantes</label><div class="member-picks">'+partHTML+'</div></div>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="campCancel">Cancelar</button><button class="btn btn-primary" id="campSave">'+(isNew?'Criar campanha':'Salvar')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);

  // render lista de tarefas da campanha
  function renderTaskList() {
    var box=modal.querySelector('#cpTasks');
    if (taskList.length===0) { box.innerHTML='<div style="font-size:12px;color:var(--u-text3);padding:4px 0">Nenhuma tarefa ainda.</div>'; return; }
    var respOpts=function(sel){ return '<option value="">Responsável</option>'+ST.users.map(function(u){ return '<option value="'+esc(u.id)+'"'+(String(sel)===String(u.id)?' selected':'')+'>'+esc(u.name)+'</option>'; }).join(''); };
    box.innerHTML = taskList.map(function(tk,idx){
      var pr=PRIO[tk.priority]||PRIO.media;
      return '<div class="camp-task-item'+(tk.done?' done':'')+'">'+
        '<button type="button" class="camp-task-check" data-idx="'+idx+'" style="border-color:'+(tk.done?'#16A34A':'var(--u-border)')+';background:'+(tk.done?'#16A34A':'transparent')+'">'+(tk.done?'✓':'')+'</button>'+
        '<span class="tc-prio" style="background:'+pr.color+'"></span>'+
        '<span class="camp-task-t">'+esc(tk.title)+'</span>'+
        '<input type="date" class="camp-task-date" data-dueidx="'+idx+'" value="'+esc((tk.due||'').slice(0,10))+'" title="Data">'+
        '<select class="camp-task-resp" data-respidx="'+idx+'" title="Responsável">'+respOpts(tk.assignee_id)+'</select>'+
        '<button type="button" class="camp-task-del" data-idx="'+idx+'">✕</button>'+
      '</div>';
    }).join('');
    box.querySelectorAll('.camp-task-check').forEach(function(b){ b.addEventListener('click', function(){ var i=+this.getAttribute('data-idx'); taskList[i].done=!taskList[i].done; renderTaskList(); }); });
    box.querySelectorAll('.camp-task-date').forEach(function(b){ b.addEventListener('change', function(){ taskList[+this.getAttribute('data-dueidx')].due=this.value||null; }); });
    box.querySelectorAll('.camp-task-resp').forEach(function(b){ b.addEventListener('change', function(){ taskList[+this.getAttribute('data-respidx')].assignee_id=this.value||null; }); });
    box.querySelectorAll('.camp-task-del').forEach(function(b){ b.addEventListener('click', function(){ taskList.splice(+this.getAttribute('data-idx'),1); renderTaskList(); }); });
  }
  renderTaskList();
  modal.querySelector('#cpAddTask').addEventListener('click', function(){
    var tt=(modal.querySelector('#cpNewTask').value||'').trim();
    if (!tt) return;
    taskList.push({ id:uid(), title:tt, priority:modal.querySelector('#cpNewPrio').value, done:false, due:null, assignee_id:null });
    modal.querySelector('#cpNewTask').value='';
    renderTaskList();
  });

  var colorPick=c.color||'#3B6FF7';
  var dots=modal.querySelectorAll('.color-dot');
  for (var i=0;i<dots.length;i++) dots[i].addEventListener('click', function(){ for(var k=0;k<dots.length;k++) dots[k].classList.remove('on'); this.classList.add('on'); colorPick=this.getAttribute('data-color'); });
  var partCbs=modal.querySelectorAll('[data-part]');
  for (var j=0;j<partCbs.length;j++) partCbs[j].addEventListener('change', function(){ this.closest('.member-pick').classList.toggle('on', this.checked); });

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#campCancel').addEventListener('click', close);
  modal.querySelector('#cpName').focus();

  modal.querySelector('#campSave').addEventListener('click', function(){
    var name=(modal.querySelector('#cpName').value||'').trim();
    if (!name) { toast('Informe o nome da campanha','error'); return; }
    var sel=[]; modal.querySelectorAll('[data-part]:checked').forEach(function(cb){ sel.push(cb.getAttribute('data-part')); });
    var rec = {
      id: isNew ? uid() : c.id,
      name:name,
      description:(modal.querySelector('#cpDesc').value||'').trim(),
      start_date:modal.querySelector('#cpStart').value||null,
      end_date:modal.querySelector('#cpEnd').value||null,
      color:colorPick,
      area:(modal.querySelector('#cpArea').value||'').trim(),
      user_ids:sel,
      tasks:taskList
    };
    var saveBtn=modal.querySelector('#campSave'); setBusy(saveBtn,true);
    sb.from('malba_campaigns').upsert(rec, { onConflict:'id' }).select().single().then(function(r){
      if (r.error || !r.data) { toast('Erro ao salvar campanha','error'); console.error(r.error); saveBtn.disabled=false; saveBtn.textContent=(isNew?'Criar campanha':'Salvar'); return; }
      if (isNew) ST.campaigns.push(r.data);
      else { for (var i=0;i<ST.campaigns.length;i++) if (ST.campaigns[i].id===c.id) { ST.campaigns[i]=r.data; break; } }
      auditLog(isNew?'Criou campanha':'Editou campanha', name); close(); toast(isNew?'Campanha criada':'Campanha atualizada','success'); renderPage();
    });
  });

  if (!isNew) {
    modal.querySelector('#campDel').addEventListener('click', function(){
      confirmDelete('Excluir a campanha "'+(c.name||'')+'"?', function(){ sb.from('malba_campaigns').delete().eq('id', c.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.campaigns = ST.campaigns.filter(function(x){ return x.id!==c.id; });
        // limpeza best-effort das instâncias diárias
        sb.from('malba_campaign_instances').delete().eq('campaign_id', c.id);
        close(); toast('Campanha excluída','success'); renderPage();
      }); });
    });
  }
}

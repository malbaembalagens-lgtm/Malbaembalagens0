
/* ============================================================
   MALBA Work OS — APLICAÇÃO (single-file)
   v1: Fundação · v2: módulo Tarefas (Lojas/Vendas/Financeiro/Marketing)
   Seções: [1]CONFIG [2]SUPABASE [3]ÍCONES [4]AUTH [5]ROTAS
           [6]ESTADO+DADOS [7]UTIL+ENTRADA [8]CASCA
           [9]DASHBOARD [10]TAREFAS [11]ROTEAMENTO [12]BOOT
   ============================================================ */
'use strict';

/* ========== [1] CONFIG ========== */
var APP_BUILD = 'v114 · 25/07 (Bloco 2: modularizacao — index.html carrega 22 arquivos JS de /js/, cada um focado num dominio; 12466 linhas divididas em modulos de 41 a 3429 linhas; deploy pelo Vercel sem alteracao)';
var SUPABASE_URL = 'https://tqnbpffqgnvjlxsigwpb.supabase.co';
function blingAuthUrl(clientId, storeId){ return 'https://www.bling.com.br/Api/v3/oauth/authorize?response_type=code&client_id='+encodeURIComponent(clientId)+'&state='+encodeURIComponent(storeId); }
var SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRxbmJwZmZxZ252amx4c2lnd3BiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAwNDY5NzksImV4cCI6MjA5NTYyMjk3OX0.FdjY8d39ncdYyNaFidO3-FAyXXgm_zIvU0GS5Gdon90';

var SECTORS = {
  marketing:  { label: 'Marketing',  sub: 'Campanhas & Conteúdo', icon: 'megaphone', color: '#8B5CF6' },
  vendas:     { label: 'Vendas',     sub: 'CRM & Metas',          icon: 'trend',     color: '#16A34A' },
  lojas:      { label: 'Lojas',      sub: 'Operação Diária',      icon: 'store',     color: '#3B6FF7' },
  financeiro: { label: 'Financeiro', sub: 'Rotinas & Controle',   icon: 'dollar',    color: '#F59E0B' }
};

function p(id,label,ic,enabled,group,hidden){ return { id:id, label:label, icon:ic, enabled:!!enabled, group:group||'PRINCIPAL', hidden:!!hidden }; }
// v74: navegação unificada — MESMO backbone em todos os setores, mesma ordem e mesmos grupos.
var GROUP_ORDER = ['PRINCIPAL','OPERAÇÃO','GESTÃO','SISTEMA'];
// Páginas de resultado (Metas/Relatório/Ranking/Orçamento) e Ponto ficam "hidden": seguem roteáveis (compat) mas
// não aparecem no menu — abrem como ABAS dentro da Gestão / Equipe. Assim o menu fica enxuto e o padrão é único.
var PAGE_PARENT   = { calendario:'tarefas', projetos:'tarefas', ponto:'equipe', metas:'gestao', relatorio:'gestao', ranking:'gestao', orcamento:'gestao', comissoes:'gestao', avaliacoes:'gestao', solicitacoes:'gestao', atividade:'gestao', kpis:'inicio' };
var GESTAO_CHILDREN = ['metas','relatorio','ranking','orcamento'];
var PAGES = {
  lojas: [
    p('inicio','Dashboard','dashboard',true,'PRINCIPAL'), p('tarefas','Trabalho','tasks',true,'PRINCIPAL'), p('calendario','Calendário','cal',true,'PRINCIPAL',true), p('projetos','Projetos','folder',true,'PRINCIPAL',true),
    p('equipe','Equipe','users',true,'OPERAÇÃO'), p('crm','CRM','users',true,'OPERAÇÃO'), p('estrategia','Estratégia','target',true,'OPERAÇÃO'), p('docs','Documentos','folder',true,'OPERAÇÃO'),
    p('gestao','Gestão','target',true,'GESTÃO'),
    p('chat','Comunicação','chat',true,'SISTEMA'), p('config','Cadastros','gear',true,'SISTEMA'),
    p('ponto','Ponto','clock',true,'OPERAÇÃO',true), p('metas','Metas','target',true,'GESTÃO',true), p('relatorio','Relatório','trend',true,'GESTÃO',true)
  ],
  vendas: [
    p('inicio','Dashboard','dashboard',true,'PRINCIPAL'), p('tarefas','Trabalho','tasks',true,'PRINCIPAL'), p('calendario','Calendário','cal',true,'PRINCIPAL',true), p('projetos','Projetos','folder',true,'PRINCIPAL',true),
    p('crm','CRM','users',true,'OPERAÇÃO'), p('estrategia','Estratégia','target',true,'OPERAÇÃO'), p('docs','Documentos','folder',true,'OPERAÇÃO'),
    p('gestao','Gestão','target',true,'GESTÃO'),
    p('chat','Comunicação','chat',true,'SISTEMA'), p('config','Cadastros','gear',true,'SISTEMA'),
    p('metas','Metas','target',true,'GESTÃO',true), p('ranking','Ranking','trend',true,'GESTÃO',true)
  ],
  financeiro: [
    p('inicio','Dashboard','dashboard',true,'PRINCIPAL'), p('tarefas','Trabalho','tasks',true,'PRINCIPAL'), p('calendario','Calendário','cal',true,'PRINCIPAL',true), p('projetos','Projetos','folder',true,'PRINCIPAL',true),
    p('estrategia','Estratégia','target',true,'OPERAÇÃO'), p('docs','Documentos','folder',true,'OPERAÇÃO'),
    p('chat','Comunicação','chat',true,'SISTEMA'), p('config','Cadastros','gear',true,'SISTEMA')
  ],
  marketing: [
    p('inicio','Dashboard','dashboard',true,'PRINCIPAL'), p('tarefas','Trabalho','tasks',true,'PRINCIPAL'), p('calendario','Calendário','cal',true,'PRINCIPAL',true), p('projetos','Projetos','folder',true,'PRINCIPAL',true),
    p('crm','CRM','users',true,'OPERAÇÃO'), p('campanhas','Campanhas','megaphone',true,'OPERAÇÃO'), p('conteudo','Conteúdo','image',true,'OPERAÇÃO'), p('biblioteca','Biblioteca','grid',true,'OPERAÇÃO'), p('estrategia','Estratégia','target',true,'OPERAÇÃO'), p('docs','Documentos','folder',true,'OPERAÇÃO'),
    p('gestao','Gestão','target',true,'GESTÃO'),
    p('chat','Comunicação','chat',true,'SISTEMA'), p('config','Cadastros','gear',true,'SISTEMA'),
    p('metas','Metas','target',true,'GESTÃO',true), p('relatorio','Relatório','trend',true,'GESTÃO',true), p('orcamento','Orçamento','dollar',true,'GESTÃO',true)
  ]
};

// Colaborador (nível "Funcionário") vê só o essencial do dia a dia.
var COLAB_PAGES = ['inicio','tarefas','calendario','chat'];
var STATUS = { todo:{label:'A fazer',color:'#9aa1ad'}, fazendo:{label:'Em andamento',color:'#3B6FF7'}, feito:{label:'Concluída',color:'#16A34A'} };
var STATUS_ORDER = ['todo','fazendo','feito'];
var PRIO = { alta:{label:'Alta',color:'#EF4444'}, media:{label:'Média',color:'#F59E0B'}, baixa:{label:'Baixa',color:'#9aa1ad'} };

/* ========== [2] SUPABASE ========== */
var sb = window.supabase ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth:{ persistSession:false } }) : null;
function pingBanco() {
  if (!sb) return Promise.resolve(false);
  return sb.from('malba_users').select('id').limit(1).then(function(r){ return !r.error; }).catch(function(){ return false; });
}

/* ========== [3] ÍCONES ========== */
var ICON_PATHS = {
  megaphone: '<path d="M3 11l14-6v14L3 13zM3 11v2a2 2 0 002 2h1"/><path d="M8 19v-3"/>',
  trend:     '<polyline points="3 17 9 11 13 15 21 7"/><polyline points="15 7 21 7 21 13"/>',
  store:     '<path d="M3 9l1.5-5h15L21 9"/><path d="M4 9v10a1 1 0 001 1h14a1 1 0 001-1V9"/><path d="M9 20v-6h6v6"/>',
  dollar:    '<line x1="12" y1="2" x2="12" y2="22"/><path d="M17 6.5A4 4 0 0012 5H10.5a3 3 0 000 6h3a3 3 0 010 6H11a4 4 0 01-4-2"/>',
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  tasks:     '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>',
  users:     '<path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>',
  target:    '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  folder:    '<path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>',
  gear:      '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>',
  search:    '<circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  bell:      '<path d="M18 8a6 6 0 00-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>',
  logout:    '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  plus:      '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  cal:       '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
  chat:      '<path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/>',
  moon:      '<path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>',
  sun:       '<circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="4"/><line x1="12" y1="20" x2="12" y2="22"/><line x1="4.2" y1="4.2" x2="5.6" y2="5.6"/><line x1="18.4" y1="18.4" x2="19.8" y2="19.8"/><line x1="2" y1="12" x2="4" y2="12"/><line x1="20" y1="12" x2="22" y2="12"/><line x1="4.2" y1="19.8" x2="5.6" y2="18.4"/><line x1="18.4" y1="5.6" x2="19.8" y2="4.2"/>',
  clock:     '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 14"/>',
  image:     '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.7"/><path d="M21 15l-5-5L5 21"/>',
  grid:      '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  // v75: ícones do vocabulário de ações
  trash:     '<polyline points="3 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>',
  edit:      '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
  copy:      '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>',
  move:      '<polyline points="5 9 2 12 5 15"/><polyline points="9 5 12 2 15 5"/><polyline points="15 19 12 22 9 19"/><polyline points="19 9 22 12 19 15"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="22"/>',
  archive:   '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a1 1 0 001 1h14a1 1 0 001-1V8"/><line x1="10" y1="12" x2="14" y2="12"/>',
  pause:     '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
  play:      '<polygon points="6 4 20 12 6 20 6 4"/>',
  check:     '<polyline points="20 6 9 17 4 12"/>'
};
function icon(name) {
  var body = ICON_PATHS[name] || ICON_PATHS.dashboard;
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+body+'</svg>';
}

/* ========== [4] AUTH & SESSÃO ÚNICA ========== */
var SESSION_KEY = 'malba_session';
function getSession() { try { var raw=sessionStorage.getItem(SESSION_KEY); return raw?JSON.parse(raw):null; } catch(e){ return null; } }
function saveSession(s) { try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(s)); } catch(e){ console.error(e); } }
function clearSession() {
  try { sessionStorage.removeItem(SESSION_KEY); } catch(e){}
  ['malba_vl_session','malba_sector','malba_v8_2_session'].forEach(function(k){ try{ sessionStorage.removeItem(k); }catch(e){} });
}
function iniciais(n){ return (n||'U').split(' ').map(function(w){return w.charAt(0);}).slice(0,2).join('').toUpperCase(); }

function login(email, password, sector) {
  var em=(email||'').toLowerCase().trim(), pw=password||'';
  if (!em||!pw) return Promise.resolve({ ok:false, msg:'Preencha e-mail e senha.' });
  if (!sb) return Promise.resolve({ ok:false, msg:'Sem conexão com o banco.' });
  return sb.from('malba_users').select('*').eq('email', em).maybeSingle().then(function(r){
    if (r.error) return { ok:false, msg:'Erro ao consultar usuário.' };
    var d=r.data;
    if (!d) return { ok:false, msg:'E-mail não encontrado.' };
    var guardada = (d.password!=null) ? d.password : d.password_hash;
    if (guardada !== pw) return { ok:false, msg:'Senha incorreta.' };
    var isSuperUser = d.role==='admin';
    if (!isSuperUser && d.sector && d.sector!==sector) return { ok:false, msg:'Este usuário não pertence ao setor selecionado.' };
    var session = { sector:sector, user:{ id:d.id, name:d.name||'Usuário', email:d.email, role:d.role||'user', access_level:d.access_level||null, sector_role:d.sector_role||null, sector:d.sector||sector, color:d.color||null, initials:d.initials||iniciais(d.name), avatar:d.avatar||null, phone:d.phone||'', position:d.position||'', bio:d.bio||'', perms:d.perms||{} } };
    saveSession(session);
    return { ok:true, session:session };
  }).catch(function(){ return { ok:false, msg:'Erro de conexão com o banco.' }; });
}
function logout() { clearSession(); location.hash=''; location.reload(); }
/* v89: tudo aqui responde pela tabela CAPS — um nível, um conjunto de permissões */
function isSuper(s){ return can('sistema', s); }                 // Administrador Geral
function isAdmin(s){ return can('equipe', s); }                  // Administrador Geral e Gestor
function isTopAdmin(s){ return can('sistema', s); }              // estrutura, usuários, integrações
function roleRank(s){ return (NIVEIS[nivelDe(s&&s.user)]||NIVEIS.colaborador).rank; }
function roleNivelLabel(s){ return (NIVEIS[nivelDe(s&&s.user)]||NIVEIS.colaborador).label; }
function canManage(){ return can('gerir'); }                     // cria/edita/exclui registros do setor
function blockManage(){ toast('Você não tem permissão para criar, editar ou excluir aqui.','error'); }
// "Colaborador pessoal" = acesso individual (Colaborador ou Visualizador) que NÃO é login de loja.
function isColaboradorPessoal(s){ s = s || ST.session; return roleRank(s) <= 2 && !ST.store; }
// permissões por função concedidas a uma pessoa: mapa { pageId: 'ver' | 'fazer' }
function userPermMap(s){ s = s || ST.session; var u=s&&s.user; if(!u) return {}; var p=u.perms;
  if(typeof p==='string'){ try{ p=JSON.parse(p); }catch(e){ p=p.split(',').map(function(x){return x.trim();}).filter(Boolean); } }
  if(Array.isArray(p)){ var m={}; p.forEach(function(id){ if(id) m[id]='fazer'; }); return m; } // compat: lista antiga = acesso total
  if(p && typeof p==='object'){ return p; }
  return {};
}
function permLevel(pgId, s){ var m=userPermMap(s); var v=m[pgId]; return (v==='ver'||v==='fazer')?v:'none'; }
function permsHas(pgId, s){ return permLevel(pgId, s) !== 'none'; }        // pode ao menos visualizar
function canEdit(){
  if(can('gerir')) return true;                                   // Administrador e Gestor
  if(!can('executar')) return false;                              // Visualizador nunca edita
  // Supervisor: pode mexer nas tarefas (redistribuir), não em projetos/cadastros
  if(can('redistribuir') && ST.page==='tarefas' && (ST.taskView||'')!=='projetos') return true;
  return permLevel(ST.page)==='fazer';                            // permissão concedida caso a caso
}
// páginas que o admin pode conceder a um colaborador (exclui início e as de administração)
function grantablePages(sector){ return (PAGES[sector]||PAGES.lojas).filter(function(p){ return !p.hidden && ['inicio','gestao','config'].indexOf(p.id)===-1; }); }
// mantém perms/nível do usuário logado atualizados a partir da lista de usuários já carregada
function syncSessionPerms(){ if(!ST.session||!ST.session.user||!ST.allUsers||!ST.allUsers.length) return; for(var i=0;i<ST.allUsers.length;i++){ if(String(ST.allUsers[i].id)===String(ST.session.user.id)){ ST.session.user.perms=ST.allUsers[i].perms||{}; ST.session.user.access_level=ST.allUsers[i].access_level||ST.session.user.access_level; try{ saveSession(ST.session); }catch(e){} break; } } }
// grava as permissões; avisa se a coluna 'perms' ainda não existir no banco
function savePerms(id, map){ return sb.from('malba_users').update({ perms: map||{} }).eq('id', id).then(function(rr){
  if(rr.error){ var m=(rr.error.message||'').toLowerCase(); console.error('savePerms:', rr.error);
    if(m.indexOf('perms')!==-1 || m.indexOf('column')!==-1 || m.indexOf('schema')!==-1 || m.indexOf('does not exist')!==-1){ toast('Para salvar permissões, rode o SQL "SQL-permissoes-colaborador.sql" no Supabase.','error'); }
    else { toast('Não consegui salvar as permissões: '+(rr.error.message||'erro'),'error'); }
    return false;
  }
  for(var i=0;i<(ST.allUsers||[]).length;i++) if(String(ST.allUsers[i].id)===String(id)) ST.allUsers[i].perms=(map||{});
  return true;
}); }
// que páginas cada pessoa pode acessar
function pageAllowed(pgId, s){
  s = s || ST.session;
  if (pgId==='config') return can('equipe', s); // v103: Admin e Gestor (Gestor restrito ao próprio setor)
  if (pgId==='gestao')  return can('indicadores', s);   // v89: Supervisor acompanha indicadores
  if (pgId==='estrategia') return can('estrategia', s) || permsHas(pgId, s); // v91
  if (pgId==='docs')       return can('docs', s) || permsHas(pgId, s);       // v96: docs abre pra todos por default
  if (pgId==='ponto')   return (deptoTemEquipe(ST.sector) && !isColaboradorPessoal(s)) || permsHas(pgId, s); // v105
  if (isColaboradorPessoal(s)) {
    // base do colaborador + funções concedidas no cadastro
    var base = deptoTemRotinas(ST.sector) ? ['inicio','chat'] : COLAB_PAGES; // v113: depto com rotinas → colab tem menu ainda mais enxuto
    return base.indexOf(pgId) !== -1 || permsHas(pgId, s);
  }
  return true;
}
// seletor reutilizável de permissões — nível por função (Sem acesso / Ver / Fazer)
function permsPickerHTML(sector, currentMap){
  currentMap = currentMap || {};
  var pages = grantablePages(sector);
  var rows = pages.map(function(p){
    var lvl = (currentMap[p.id]==='ver'||currentMap[p.id]==='fazer') ? currentMap[p.id] : 'none';
    return '<div class="perm-row"><span class="perm-row-l"><span class="perm-ic">'+icon(p.icon)+'</span>'+esc(p.label)+'</span>'+
      '<div class="perm-seg" data-perm="'+p.id+'">'+
        '<button type="button" class="'+(lvl==='none'?'on':'')+'" data-lvl="none">Sem acesso</button>'+
        '<button type="button" class="'+(lvl==='ver'?'on ver':'')+'" data-lvl="ver">Ver</button>'+
        '<button type="button" class="'+(lvl==='fazer'?'on fazer':'')+'" data-lvl="fazer">Fazer</button>'+
      '</div></div>';
  }).join('');
  return '<div class="perm-wrap" id="permWrap"><div class="perm-hd"><div><div class="perm-title">Permissões por função</div><div class="perm-sub">Em cada função: nada, só visualizar, ou visualizar e executar. "Fazer" já inclui ver.</div></div></div>'+
    '<div class="perm-shortcuts"><span>Atalhos:</span><button type="button" class="perm-sc" data-sc="ver">Só visualização</button><button type="button" class="perm-sc" data-sc="fazer">Acesso total</button><button type="button" class="perm-sc" data-sc="none">Limpar</button></div>'+
    '<div class="perm-rows">'+rows+'</div></div>';
}
function readPerms(modal){ var map={}; var segs=modal.querySelectorAll('.perm-seg'); for(var i=0;i<segs.length;i++){ var id=segs[i].getAttribute('data-perm'); var on=segs[i].querySelector('button.on'); var lvl=on?on.getAttribute('data-lvl'):'none'; if(lvl==='ver'||lvl==='fazer') map[id]=lvl; } return map; }
function bindPermsPicker(modal){
  var segBtns=modal.querySelectorAll('.perm-seg button'); for(var i=0;i<segBtns.length;i++) segBtns[i].addEventListener('click', function(){ var seg=this.parentNode; var bs=seg.querySelectorAll('button'); for(var j=0;j<bs.length;j++){ bs[j].classList.remove('on','ver','fazer'); } this.classList.add('on'); var lv=this.getAttribute('data-lvl'); if(lv==='ver') this.classList.add('ver'); if(lv==='fazer') this.classList.add('fazer'); });
  var scs=modal.querySelectorAll('.perm-sc'); for(var s=0;s<scs.length;s++) scs[s].addEventListener('click', function(){ var lvl=this.getAttribute('data-sc'); var segs=modal.querySelectorAll('.perm-seg'); for(var k=0;k<segs.length;k++){ var bs=segs[k].querySelectorAll('button'); for(var b=0;b<bs.length;b++){ var match=bs[b].getAttribute('data-lvl')===lvl; bs[b].classList.remove('on','ver','fazer'); if(match){ bs[b].classList.add('on'); if(lvl==='ver') bs[b].classList.add('ver'); if(lvl==='fazer') bs[b].classList.add('fazer'); } } } });
}
// permissões granulares por função
// registro de auditoria (quem fez o quê) — melhor esforço, nunca quebra a UX
function auditLog(action, detail){
  try{
    var u=ST.session && ST.session.user; if(!u) return;
    var txt = detail ? (action+': '+detail) : action;
    sb.from('malba_admin_audit').insert({ actor_id:u.id, actor_name:u.name, actor_sector:ST.sector, action:txt }).then(function(){}, function(){});
  }catch(e){}
}

/* ========== [5] ROTAS ========== */
function currentRoute() { var h=(location.hash||'').replace(/^#\/?/,''); return h?h.split('/').filter(Boolean):[]; }
function navigate(path) { location.hash = '#/' + String(path).replace(/^#?\/?/,''); }

/* ========== [6] ESTADO + DADOS ========== */
var ST = { session:null, sector:null, store:null, viewStore:null, page:'tarefas', taskView:'kanban', taskAssignee:'', taskStore:'', configTab:'usuarios', gestaoTab:'visao', gestaoStore:'', kpiPeriod:'mes', kpiStore:null, cal:{ y:null, m:null }, storeUnits:[], users:[], allUsers:[], tasks:[], members:[], goals:[], clients:[], projects:[], milestones:[], banners:[], events:[], campaigns:[], comissoes:[], avaliacoes:[], bling:[], blingFat:[], openProject:null, team:{ q:'', sit:'ativos', pend:'', loja:'' }, checkins:[], notes1on1:[], kudos:[], mktMetas:[], relM:null, relY:null, mktBudget:[], orcM:null, orcY:null, contentItems:[], contentView:'pipeline', conM:null, conY:null, creativos:[], bibKind:'todos', bibQ:'', checklistItems:[], checklistDone:[], caixas:[], lojaMetricas:[], lrM:null, lrY:null, lrStore:'', lojaProdutos:[], loaded:false };
// loja "em foco": conta vinculada a uma loja vê SÓ a dela (qualquer cargo);
// admin central (sem loja vinculada) vê unificado ou filtra pelo seletor do topo.
function scopeStore(){
  if (ST.sector!=='lojas') return null;
  if (ST.store) return ST.store.id;
  if (isSuper(ST.session)) return ST.viewStore || null;
  return null;
}

// v69: busca paginada — quebra o teto de 1000 linhas do Supabase (sem isso, recorrentes antigas somem)
function fetchAllTasks(sector){
  var PAGE=1000, all=[], from=0;
  function step(){
    return sb.from('malba_vl_tasks').select('*').eq('sector', sector).order('created_at',{ascending:false}).range(from, from+PAGE-1).then(function(r){
      if(r.error) return { data:all, error:r.error };
      var rows=(r.data||[]); all=all.concat(rows);
      if(rows.length<PAGE) return { data:all };
      from+=PAGE; return step();
    });
  }
  return step();
}
function loadData() {
  var sector = ST.sector;
  if (!sb) return Promise.resolve();
  return Promise.all([
    sb.from('malba_store_units').select('*').order('store_number'),
    fetchAllTasks(sector), // v69: paginado (antes cortava em 1000 e sumia recorrentes)
    sb.from('malba_users').select('*'),
    sb.from('malba_store_members').select('*').order('created_at'),
    sb.from('malba_sales_goals').select('*'),
    sb.from('malba_crm_clients').select('*').order('updated_at', { ascending:false }),
    sb.from('malba_vl_projects').select('*').eq('sector', sector).order('created_at', { ascending:false }),
    sb.from('malba_vl_milestones').select('*'),
    sb.from('malba_banners').select('*').order('position'),
    sb.from('malba_campaigns').select('*'),
    sb.from('malba_comissoes').select('*').order('created_at', { ascending:false }),
    sb.from('malba_avaliacoes').select('*').order('created_at', { ascending:false }),
    sb.from('malba_bling_estado').select('*'),
    sb.from('malba_bling_faturamento').select('*')
  ]).then(function(r){
    ST.storeUnits = (r[0]&&r[0].data) || [];
    ST.tasks      = (r[1]&&r[1].data) || [];
    var allUsers  = (r[2]&&r[2].data) || [];
    ST.allUsers = allUsers;
    syncSessionPerms(); // mantém o perms do usuário logado atualizado
    ST.users = allUsers.filter(function(u){ return u.sector===sector || u.role==='admin'; });
    ST.members    = (r[3]&&r[3].data) || [];
    ST.goals      = ((r[4]&&r[4].data) || []).filter(function(g){ return g.sector===sector; });
    ST.clients    = (r[5]&&r[5].data) || [];
    ST.projects   = (r[6]&&r[6].data) || [];
    ST.milestones = (r[7]&&r[7].data) || [];
    (function(){ var pmap={}; ST.projects.forEach(function(p){ pmap[String(p.id)]=1; }); ST.milestones = ST.milestones.filter(function(m){ return pmap[String(m.project_id)]; }); })();
    ST.banners    = (r[8]&&r[8].data) || [];
    ST.campaigns  = (r[9]&&r[9].data) || [];
    ST.comissoes  = (r[10]&&r[10].data) || [];
    ST.avaliacoes = (r[11]&&r[11].data) || [];
    ST.bling      = (r[12]&&r[12].data) || [];
    ST.blingFat   = (r[13]&&r[13].data) || [];
    ST.store = null;
    if (sector==='lojas' && ST.session.user) {
      for (var i=0;i<ST.storeUnits.length;i++) {
        if (ST.storeUnits[i].user_id === ST.session.user.id) { ST.store = ST.storeUnits[i]; break; }
      }
    }
    ST.loaded = true;
    // v70: gera automaticamente as ocorrências de hoje das rotinas (regra -> tarefas do dia). Fire-and-forget: re-renderiza se criar algo.
    try { materializarRecorrencias().then(function(created){ if(created) renderPage(); }); } catch(e){ console.error(e); }
    try { departamentosCarregar(function(){ if (ST.page==='config') renderPage(); }); } catch(e){ console.error(e); } // v105
    try { equipesCarregar(function(){ if (ST.page==='config') renderPage(); }); } catch(e){ console.error(e); } // v109
    try { perfisCarregar(function(){ if (ST.page==='config') renderPage(); }); } catch(e){ console.error(e); } // v110
    try { equipesCarregar(function(){ if (ST.page==='config') renderPage(); }); } catch(e){ console.error(e); } // v109
    try { cargosCarregar(function(){ if (ST.page==='config') renderPage(); }); } catch(e){ console.error(e); } // v104
    // eventos do calendário (carrega à parte; se a tabela não existir ainda, ignora sem quebrar)
    ST.events = [];
    try { sb.from('malba_events').select('*').eq('sector', sector).then(function(re){ if(!re.error && re.data){ ST.events=re.data; if(ST.page==='calendario') renderPage(); } }, function(){}); } catch(e){}
    // vendas registradas pelos colaboradores + solicitações (resiliente)
    ST.salesEntries = [];
    try { sb.from('malba_sales_entries').select('*').eq('sector', sector).then(function(re){ if(!re.error && re.data){ ST.salesEntries=re.data; if(ST.page==='inicio'||ST.page==='gestao'||ST.page==='metas'||ST.page==='kpis') renderPage(); } }, function(){}); } catch(e){}
    ST.requests = [];
    try { sb.from('malba_requests').select('*').eq('sector', sector).then(function(re){ if(!re.error && re.data){ ST.requests=re.data; if(ST.page==='inicio'||ST.page==='gestao') renderPage(); } }, function(){}); } catch(e){}
    try { loadEstrategia(sector); loadObjetivos(sector); loadEstrategiaAtividade(sector); loadDocs(sector); } catch(e){}
    ST.checkins = [];
    try { sb.from('malba_checkins').select('*').eq('sector', sector).then(function(re){ if(!re.error && re.data){ ST.checkins=re.data; if(ST.page==='inicio') renderPage(); } }, function(){}); } catch(e){}
    ST.notes1on1 = [];
    try { sb.from('malba_notes').select('*').eq('sector', sector).then(function(re){ if(!re.error && re.data){ ST.notes1on1=re.data; } }, function(){}); } catch(e){}
    ST.kudos = [];
    try { sb.from('malba_kudos').select('*').eq('sector', sector).then(function(re){ if(!re.error && re.data){ ST.kudos=re.data; if(ST.page==='inicio') renderPage(); } }, function(){}); } catch(e){}
    ST.mktMetas = [];
    try { sb.from('malba_mkt_metas').select('*').then(function(re){ if(!re.error && re.data){ ST.mktMetas=re.data; if(ST.page==='metas'||ST.page==='relatorio') renderPage(); } }, function(){}); } catch(e){}
    ST.mktBudget = [];
    try { sb.from('malba_mkt_budget').select('*').then(function(re){ if(!re.error && re.data){ ST.mktBudget=re.data; if(ST.page==='orcamento'||ST.page==='relatorio') renderPage(); } }, function(){}); } catch(e){}
    ST.contentItems = [];
    try { sb.from('malba_content').select('*').then(function(re){ if(!re.error && re.data){ ST.contentItems=re.data; if(ST.page==='conteudo') renderPage(); } }, function(){}); } catch(e){}
    ST.creativos = [];
    try { sb.from('malba_creativos').select('*').then(function(re){ if(!re.error && re.data){ ST.creativos=re.data; if(ST.page==='biblioteca') renderPage(); } }, function(){}); } catch(e){}
    ST.checklistItems = [];
    try { sb.from('malba_checklist_items').select('*').then(function(re){ if(!re.error && re.data){ ST.checklistItems=re.data; if(ST.page==='tarefas') renderPage(); } }, function(){}); } catch(e){}
    ST.checklistDone = [];
    try { sb.from('malba_checklist_done').select('*').gte('work_date', _firstDayMonth()).then(function(re){ if(!re.error && re.data){ ST.checklistDone=re.data; if(ST.page==='tarefas') renderPage(); } }, function(){}); } catch(e){}
    ST.caixas = [];
    try { sb.from('malba_caixa').select('*').order('work_date', { ascending:false }).then(function(re){ if(!re.error && re.data){ ST.caixas=re.data; if(ST.page==='tarefas') renderPage(); } }, function(){}); } catch(e){}
    ST.lojaMetricas = [];
    try { sb.from('malba_loja_metricas').select('*').then(function(re){ if(!re.error && re.data){ ST.lojaMetricas=re.data; if(ST.page==='relatorio') renderPage(); } }, function(){}); } catch(e){}
    ST.lojaProdutos = [];
    try { sb.from('malba_loja_produtos').select('*').then(function(re){ if(!re.error && re.data){ ST.lojaProdutos=re.data; if(ST.page==='relatorio') renderPage(); } }, function(){}); } catch(e){}
  }).catch(function(e){ console.error('[load]', e); ST.loaded = true; });
}

function visibleTasks(opts) {
  opts = opts || {};
  var list = ST.tasks.filter(function(t){ return !t.is_rule; }); // v70: esconde as regras de recorrência
  var sid = boardStore();
  if (sid) list = list.filter(function(t){ return String(t.store_unit_id) === String(sid); });
  if (!isAdmin(ST.session)) {
    var me = String(ST.session.user.id);
    list = list.filter(function(t){ return String(t.assignee_id)===me || String(t.created_by)===me; });
  } else if (opts.assignee) {
    list = list.filter(function(t){ return String(t.assignee_id)===String(opts.assignee); });
  }
  return list;
}
// escopo de loja do quadro/calendário: conta de loja vê só a sua; admin pode filtrar por loja
function boardStore(){ var sid=scopeStore(); if(sid) return sid; return ST.taskStore ? String(ST.taskStore) : null; }
function taskById(id){ for(var i=0;i<ST.tasks.length;i++) if(String(ST.tasks[i].id)===String(id)) return ST.tasks[i]; return null; }
function campById(id){ for(var i=0;i<ST.campaigns.length;i++) if(String(ST.campaigns[i].id)===String(id)) return ST.campaigns[i]; return null; }
function projName(id){ for(var i=0;i<ST.projects.length;i++) if(String(ST.projects[i].id)===String(id)) return ST.projects[i].name||'Projeto'; return 'Projeto'; }
function projStore(id){ for(var i=0;i<ST.projects.length;i++) if(String(ST.projects[i].id)===String(id)) return ST.projects[i].store_unit_id; return null; }
function addDays(ds,n){ var p=String(ds).split('-'); var d=new Date(+p[0],+p[1]-1,+p[2]); d.setDate(d.getDate()+n); return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); }
function navTaskCount(){
  var hoje=today();
  var list=visibleTasks({ assignee: isAdmin(ST.session)?(ST.taskAssignee||''):undefined });
  return list.filter(function(t){ var d=(t.due_date||'').slice(0,10); return t.status!=='feito' && d && d<=hoje; }).length;
}
function subProgress(arr){ if(!Array.isArray(arr)||!arr.length) return null; var d=0; for(var i=0;i<arr.length;i++) if(arr[i].done) d++; return { done:d, total:arr.length }; }

/* ========== [7] UTIL + TELAS DE ENTRADA ========== */
var app = document.getElementById('app');
function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function render(html){ app.innerHTML = html; }
function today(){ var d=new Date(); return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); }
function pad(n){ return n<10?'0'+n:''+n; }
function fmtDate(s){ if(!s)return''; var pp=String(s).split('T')[0].split('-'); return pp.length===3?pp[2]+'/'+pp[1]:s; }
function userById(id){ for(var i=0;i<ST.users.length;i++) if(ST.users[i].id===id) return ST.users[i]; return null; }
function toast(msg, type){
  var w=document.getElementById('toastWrap'); var el=document.createElement('div');
  el.className='toast '+(type||'info'); el.textContent=msg; w.appendChild(el);
  setTimeout(function(){ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(function(){ if(el.parentNode) el.parentNode.removeChild(el); },300); }, 2400);
}

/* ========== v75: BIBLIOTECA ÚNICA DE COMPONENTES DE AÇÃO ==========
   Fonte única de verdade pra todas as ações do sistema. Sempre que uma
   ação (Criar/Editar/Excluir/Duplicar/Mover/Arquivar/Pausar/Concluir)
   aparecer em qualquer módulo, use estes componentes — mesmo rótulo,
   mesmo ícone, mesmo visual, mesmo comportamento. */
var ACTIONS = {
  criar:    { label:'Criar',    icon:'plus',    cls:'btn-primary' },
  editar:   { label:'Editar',   icon:'edit',    cls:'btn-ghost' },
  excluir:  { label:'Excluir',  icon:'trash',   cls:'btn-danger', danger:true },
  duplicar: { label:'Duplicar', icon:'copy',    cls:'btn-ghost' },
  mover:    { label:'Mover',    icon:'move',    cls:'btn-ghost' },
  arquivar: { label:'Arquivar', icon:'archive', cls:'btn-ghost' },
  pausar:   { label:'Pausar',   icon:'pause',   cls:'btn-ghost' },
  retomar:  { label:'Retomar',  icon:'play',    cls:'btn-ghost' },
  concluir: { label:'Concluir', icon:'check',   cls:'btn-primary' }
};
// Diálogo de confirmação único (substitui o confirm() nativo do navegador).
function confirmDialog(opts){
  opts=opts||{};
  var kind = opts.danger?'danger':(opts.warn?'warn':'info');
  var confirmCls = opts.danger?'btn-danger':'btn-primary';
  var confirmLabel = opts.confirmLabel || (opts.danger?'Excluir':'Confirmar');
  var cancelLabel = opts.cancelLabel || 'Cancelar';
  var icKey = opts.icon || (opts.danger?'trash':(opts.warn?'bell':'bell'));
  var bg=document.createElement('div'); bg.className='confirm-bg';
  bg.innerHTML='<div class="confirm-card" role="alertdialog" aria-modal="true">'+
    '<div class="confirm-ic '+kind+'">'+icon(icKey)+'</div>'+
    '<h3>'+esc(opts.title||(opts.danger?'Tem certeza?':'Confirmar'))+'</h3>'+
    (opts.message?'<p>'+esc(opts.message)+'</p>':'')+
    '<div class="confirm-foot"><button class="btn btn-ghost" id="cfCancel">'+esc(cancelLabel)+'</button><button class="btn '+confirmCls+'" id="cfOk">'+esc(confirmLabel)+'</button></div>'+
  '</div>';
  document.body.appendChild(bg);
  function shut(){ if(bg.parentNode) bg.parentNode.removeChild(bg); document.removeEventListener('keydown', onKey, true); }
  function onKey(e){ if(e.key==='Escape'){ e.preventDefault(); shut(); if(opts.onCancel) opts.onCancel(); } else if(e.key==='Enter'){ e.preventDefault(); shut(); if(opts.onConfirm) opts.onConfirm(); } }
  document.addEventListener('keydown', onKey, true);
  bg.addEventListener('click', function(e){ if(e.target===bg){ shut(); if(opts.onCancel) opts.onCancel(); } });
  bg.querySelector('#cfCancel').addEventListener('click', function(){ shut(); if(opts.onCancel) opts.onCancel(); });
  bg.querySelector('#cfOk').addEventListener('click', function(){ shut(); if(opts.onConfirm) opts.onConfirm(); });
  setTimeout(function(){ var b=bg.querySelector('#cfOk'); if(b) b.focus(); }, 30);
}
// Atalho pra exclusões (o caso mais comum).
function confirmDelete(message, onConfirm, opts){
  opts=opts||{};
  confirmDialog({ danger:true, title:opts.title||'Tem certeza?', message:message, confirmLabel:opts.confirmLabel||'Excluir', onConfirm:onConfirm });
}
// Rodapé de modal padrão: [Excluir] Cancelar [Salvar].
/* v90: construtor único de modal — reduz cerimônia dos 27 modais existentes.
   Uso:
     var m = makeModal({ title:'Nova coisa', width:420, body:'<...>',
                        saveLabel:'Criar', onSave:function(close, root){ ... } });
   Já cuida de: overlay, foco no primeiro campo, fechar com Esc / clique fora,
   botões padrão (Cancelar/Salvar), acessibilidade. Os modais antigos continuam
   funcionando como estão — o construtor é para o novo código e para migrações. */
function makeModal(opts){
  opts=opts||{};
  var bg=document.createElement('div'); bg.className='modal-bg';
  var width = opts.width ? (' style="max-width:'+opts.width+'px"') : '';
  var head = opts.title ? ('<div class="wz-title">'+esc(opts.title)+'</div>') : '';
  var foot = opts.hideFoot ? '' : modalFoot({
    saveLabel: opts.saveLabel || 'Salvar',
    cancelLabel: opts.cancelLabel || 'Cancelar',
    cancelId: 'mkCancel', saveId: opts.onSave? 'mkSave' : null,
    del: !!opts.onDelete, delLabel: opts.deleteLabel || 'Excluir', delId: 'mkDel'
  });
  bg.innerHTML='<div class="modal"'+width+'>'+head+'<div class="modal-body">'+(opts.body||'')+'</div>'+foot+'</div>';
  document.body.appendChild(bg);
  var root = bg.querySelector('.modal');
  function close(){ if(bg.parentNode){ bg.parentNode.removeChild(bg); document.removeEventListener('keydown', onKey); } if(opts.onClose) opts.onClose(); }
  function onKey(e){ if(e.key==='Escape') close(); }
  document.addEventListener('keydown', onKey);
  bg.addEventListener('click', function(e){ if(e.target===bg) close(); });
  var c=bg.querySelector('#mkCancel'); if(c) c.addEventListener('click', close);
  var sv=bg.querySelector('#mkSave');   if(sv && opts.onSave) sv.addEventListener('click', function(){ opts.onSave(close, root); });
  var dl=bg.querySelector('#mkDel');    if(dl && opts.onDelete) dl.addEventListener('click', function(){ opts.onDelete(close, root); });
  // foco no primeiro campo
  setTimeout(function(){ var el=root.querySelector('input:not([type=hidden]),textarea,select'); if(el && !opts.noAutofocus) el.focus(); }, 30);
  return { close:close, root:root, bg:bg };
}
function modalFoot(o){
  o=o||{};
  var del = o.del ? '<button class="btn btn-danger btn-del-wrap" id="'+(o.delId||'mDel')+'">'+esc(o.delLabel||'Excluir')+'</button>' : '';
  var cancel = '<button class="btn btn-ghost" id="'+(o.cancelId||'mCancel')+'">'+esc(o.cancelLabel||'Cancelar')+'</button>';
  var save = (o.saveId===null) ? '' : '<button class="btn btn-primary" id="'+(o.saveId||'mSave')+'">'+esc(o.saveLabel||'Salvar')+'</button>';
  return '<div class="modal-foot">'+del+cancel+save+'</div>';
}
// Botão de ação padrão pra linhas/cartões (ícone + rótulo). type = chave de ACTIONS.
function actionBtn(type, attrs, iconOnly){
  var a=ACTIONS[type]||ACTIONS.editar; attrs=attrs||'';
  return '<button class="act-btn'+(a.danger?' danger':'')+(iconOnly?' icon-only':'')+'" '+attrs+' title="'+esc(a.label)+'">'+icon(a.icon)+'<span>'+esc(a.label)+'</span></button>';
}
// Assistente de cadastro em 4 passos — TODO cadastro usa o mesmo fluxo:
// 1) Informações principais  2) Configurações  3) Responsáveis  4) Revisão.
// O passo de Revisão é montado automaticamente lendo os campos marcados com data-review="Rótulo".
function formWizard(opts){
  opts=opts||{};
  var steps=opts.steps||[];
  var LABELS=['Informações principais','Configurações','Responsáveis','Revisão'];
  var cur=0;
  var bg=document.createElement('div'); bg.className='modal-bg';
  var stepper=LABELS.map(function(l,i){ return '<button class="wz-step" data-goto="'+i+'"><span class="wz-num">'+(i+1)+'</span><span class="wz-lb">'+esc(l)+'</span></button>'; }).join('<span class="wz-line"></span>');
  var panes='';
  for(var i=0;i<3;i++){ panes+='<div class="wz-pane" data-pane="'+i+'">'+((steps[i]&&steps[i].html)||'')+'</div>'; }
  panes+='<div class="wz-pane" data-pane="3"><div class="wz-review" id="wzReview"></div></div>';
  var del=(opts.del)?'<button class="btn btn-danger btn-del-wrap" id="wzDel">'+esc(opts.delLabel||'Excluir')+'</button>':'';
  bg.innerHTML='<div class="modal wz-modal">'+
    (opts.title?'<div class="wz-title">'+esc(opts.title)+'</div>':'')+
    '<div class="wz-steps">'+stepper+'</div>'+
    '<div class="wz-body">'+panes+'</div>'+
    '<div class="modal-foot wz-foot">'+del+'<div class="wz-foot-sp"></div><button class="btn btn-ghost" id="wzBack">Voltar</button><button class="btn btn-primary" id="wzNext">Avançar</button></div>'+
  '</div>';
  document.body.appendChild(bg);
  function close(){ if(bg.parentNode) bg.parentNode.removeChild(bg); }
  bg.addEventListener('click', function(e){ if(e.target===bg) close(); });
  var stepEls=bg.querySelectorAll('.wz-step');
  var paneEls=bg.querySelectorAll('.wz-pane');
  var backBtn=bg.querySelector('#wzBack');
  var nextBtn=bg.querySelector('#wzNext');
  function reviewVal(el){
    if(el.hasAttribute('data-review-value')) return el.getAttribute('data-review-value');
    var tag=el.tagName;
    if(tag==='SELECT'){ var o=el.options[el.selectedIndex]; return o?(o.textContent||'').trim():''; }
    if(tag==='INPUT'||tag==='TEXTAREA'){ if(el.type==='date'&&el.value) return fmtDate(el.value); return (el.value||'').trim(); }
    return (el.textContent||'').trim();
  }
  function buildReview(){
    var rows=''; var nodes=bg.querySelectorAll('[data-review]');
    for(var i=0;i<nodes.length;i++){ var lb=nodes[i].getAttribute('data-review'); var v=reviewVal(nodes[i]); rows+='<div class="wz-rev-row"><span class="wz-rev-l">'+esc(lb)+'</span><span class="wz-rev-v">'+(v?esc(v):'<i>—</i>')+'</span></div>'; }
    if(opts.reviewExtra){ var ex=opts.reviewExtra(bg); if(ex) rows+=ex; }
    bg.querySelector('#wzReview').innerHTML = rows || '<div class="wz-rev-empty">Sem dados para revisar.</div>';
  }
  function render(){
    for(var i=0;i<paneEls.length;i++) paneEls[i].style.display=(i===cur?'':'none');
    for(var s=0;s<stepEls.length;s++){ stepEls[s].className='wz-step'+(s===cur?' on':(s<cur?' done':'')); var num=stepEls[s].querySelector('.wz-num'); if(num) num.innerHTML=(s<cur?icon('check'):(s+1)); }
    backBtn.style.visibility=(cur===0?'hidden':'visible');
    nextBtn.textContent=(cur===3?(opts.saveLabel||(opts.editing?'Salvar':'Criar')):'Avançar');
    if(cur===3) buildReview();
    if(cur<3){ var f=paneEls[cur].querySelector('input,select,textarea'); if(f) setTimeout(function(){ try{f.focus();}catch(e){} },20); }
  }
  function valid(i){ var st=steps[i]; if(st&&st.validate) return st.validate(bg)!==false; return true; }
  function go(to){ if(to<0||to>3) return; if(to>cur){ for(var i=cur;i<to;i++){ if(!valid(i)){ cur=i; render(); return; } } } cur=to; render(); }
  backBtn.addEventListener('click', function(){ go(cur-1); });
  nextBtn.addEventListener('click', function(){ if(cur<3) go(cur+1); else if(opts.onSave) opts.onSave(bg, close, nextBtn); });
  for(var g=0; g<stepEls.length; g++) stepEls[g].addEventListener('click', function(){ go(parseInt(this.getAttribute('data-goto'),10)); });
  if(opts.del && opts.onDelete){ var dbtn=bg.querySelector('#wzDel'); if(dbtn) dbtn.addEventListener('click', function(){ opts.onDelete(close); }); }
  if(opts.onReady) opts.onReady(bg, close);
  render();
  return { bg:bg, close:close, go:go };
}
// Tela vazia padrão: ícone + o que é + o que fazer (CTA opcional). Some o "e agora?" de quem é novo.
// cta: rótulo do botão. O clique dispara a ação principal da tela (novoContextual), então é sempre previsível.
function emptyState(o){
  o=o||{};
  var cta = o.cta ? '<button class="btn btn-primary es-cta">'+icon('plus')+esc(o.cta)+'</button>' : '';
  return '<div class="empty-page"'+(o.span?' style="grid-column:1/-1"':'')+'><div class="ep-ico">'+icon(o.icon||'folder')+'</div><h3>'+esc(o.title||'Nada por aqui ainda')+'</h3>'+(o.text?'<p>'+esc(o.text)+'</p>':'')+cta+'</div>';
}
// Estado de carregamento de um botão (feedback imediato).
function setBusy(btn, on){ if(!btn) return; if(on){ btn.classList.add('busy'); btn.disabled=true; } else { btn.classList.remove('busy'); btn.disabled=false; } }
/* ================================================================= */

function startSplash(){
  if (document.getElementById('splash')) return;
  var ov=document.createElement('div'); ov.className='splash'; ov.id='splash';
  ov.innerHTML =
    '<div class="splash-grid"></div>'+
    '<div class="splash-c">'+
      '<div class="splash-tile"><span class="splash-ring"></span><span class="splash-ring r2"></span><b>M</b></div>'+
      '<div class="splash-word">'+brandMark('')+'</div>'+
      '<div class="splash-bar"><span></span></div>'+
      '<div class="splash-status" id="splashStatus">Inicializando o sistema…</div>'+
    '</div>';
  document.body.appendChild(ov);
  var steps=['Inicializando o sistema…','Conectando ao Bling…','Sincronizando dados…','Carregando seu painel…'];
  var i=0; var st=ov.querySelector('#splashStatus');
  var iv=setInterval(function(){ i++; if(i<steps.length && st) st.textContent=steps[i]; }, 470);
  setTimeout(function(){
    clearInterval(iv); if(st) st.textContent='Pronto ✓';
    ov.classList.add('out');
    setTimeout(function(){ if(ov.parentNode) ov.parentNode.removeChild(ov); }, 520);
  }, 2050);
}
function brandMark(size){
  var cls = size ? (' brand-mark-'+size) : '';
  return '<div class="brand-mark'+cls+'"><span class="brand-1">MALBA</span><span class="brand-2">Work OS</span></div>';
}
function renderSectorScreen() {
  var cards='';
  // v106: consome o cadastro real — ordenado e sem inativos
  var lista = (typeof departamentosParaLogin==='function') ? departamentosParaLogin() : Object.keys(SECTORS).map(function(k){ return { key:k }; });
  lista.forEach(function(d){
    var s = SECTORS[d.key]; if (!s) return;
    cards += '<button class="sector-card" data-sector="'+esc(d.key)+'"><span class="sector-ico" style="--c:'+s.color+'">'+icon(s.icon)+'</span><span class="sector-name">'+esc(s.label)+'</span><span class="sector-sub">'+esc(s.sub||'')+'</span></button>';
  });
  // v107: calcula o número de colunas pra cada linha ficar cheia (ou quase)
  var n = lista.length;
  var cols;
  if (n <= 4) cols = n;                                 // 1..4 → uma linha só
  else if (n === 5 || n === 6) cols = 3;                // 3+2 ou 3+3
  else if (n === 7 || n === 8) cols = 4;                // 4+3 ou 4+4
  else cols = 5;                                        // 9+ → 5 por linha
  render('<div class="screen"><div class="screen-inner">'+brandMark('lg')+'<p class="screen-title">Quem está acessando?</p><div class="sector-grid" style="--sector-cols:'+cols+'">'+cards+'</div></div></div>');
  var btns=app.querySelectorAll('.sector-card');
  for (var i=0;i<btns.length;i++) btns[i].addEventListener('click', function(){ renderLogin(this.getAttribute('data-sector')); });
}

function renderLogin(sector) {
  var s=SECTORS[sector];
  render('<div class="screen"><div class="screen-inner login-inner">'+brandMark('')+'<div class="login-card" style="margin-top:22px"><span class="login-ico" style="--c:'+s.color+'">'+icon(s.icon)+'</span><h1 class="login-h">'+esc(s.label)+'</h1><p class="login-sub">Entre com seu acesso</p><label class="field"><span>E-mail</span><input id="email" type="email" autocomplete="username" placeholder="voce@malba.com.br"></label><label class="field"><span>Senha</span><input id="senha" type="password" autocomplete="current-password" placeholder="••••••••"></label><p class="login-err" id="err"></p><button class="btn btn-primary" id="btnEntrar">Entrar</button><button class="btn-link" id="btnVoltar">← Trocar de setor</button></div><p class="version">MALBA Work OS · '+APP_BUILD+'</p></div></div>');
  var emailEl=document.getElementById('email'), senhaEl=document.getElementById('senha'), errEl=document.getElementById('err'), btn=document.getElementById('btnEntrar');
  function entrar(){
    errEl.textContent=''; btn.disabled=true; btn.textContent='Entrando...';
    login(emailEl.value, senhaEl.value, sector).then(function(r){
      setBusy(btn,false); btn.textContent='Entrar';
      if(!r.ok){ errEl.textContent=r.msg; return; }
      var landing = (roleRank(r.session) <= 2) ? 'inicio' : 'tarefas'; // v89: Colaborador e Visualizador entram pelo Início
      ST.loaded=false; startSplash(); navigate(sector+'/'+landing); boot();
    });
  }
  btn.addEventListener('click', entrar);
  senhaEl.addEventListener('keydown', function(e){ if(e.key==='Enter') entrar(); });
  document.getElementById('btnVoltar').addEventListener('click', renderSectorScreen);
  emailEl.focus();
}

/* ========== [10j] PERFIL ========== */
function perfilDesempenhoHTML(){
  var mids=meusMemberIds();
  var avals=ST.avaliacoes.filter(function(a){ return a.tipo==='membro' && mids.indexOf(String(a.member_id))!==-1; }).sort(function(a,b){return (b.data_avaliacao||'').localeCompare(a.data_avaliacao||'');});
  var avalHTML = avals.length ? avals.slice(0,8).map(function(a){ var nota=Number(a.nota_final)||0; var stars=''; for(var i=1;i<=5;i++) stars+= '<span style="color:'+(i<=Math.round(nota)?'#F59E0B':'var(--u-border2)')+'">★</span>'; return '<div class="me-aval"><div class="me-aval-h"><b>'+(a.periodo_label?esc(a.periodo_label):fmtDate(a.data_avaliacao))+'</b><span class="me-aval-nota">'+stars+' '+nota.toFixed(1)+'</span></div>'+(a.observacao?'<div class="me-aval-obs">'+esc(a.observacao)+'</div>':'')+'</div>'; }).join('') : '<div class="col-empty">Você ainda não tem avaliações.</div>';
  var coms=[];
  (ST.comissoes||[]).forEach(function(c){ (c.rateio||[]).forEach(function(r){ if(mids.indexOf(String(r.member_id))!==-1) coms.push({ label:(c.periodo_label||fmtDate(c.periodo_fim||c.periodo_inicio)), valor:r.valor, loja:storeName(c.store_unit_id) }); }); });
  var comHTML = coms.length ? coms.slice(0,8).map(function(c){ return '<div class="me-com"><span class="me-com-l">'+esc(c.label||'Período')+(c.loja?' · '+esc(c.loja):'')+'</span><span class="me-com-v">'+fmtBRL(c.valor)+'</span></div>'; }).join('') : '<div class="col-empty">Suas comissões aparecerão aqui.</div>';
  var latest = avals.length ? avals[0] : null;
  var diagCard='';
  if(latest){
    var lnota=Number(latest.nota_final)||0; var ld=diagnostico(lnota);
    var lArr = Array.isArray(latest.notas)?latest.notas:(latest.notas&&typeof latest.notas==='object'?Object.keys(latest.notas).filter(function(k){return k!=='_labels';}).map(function(k){var lb=(latest.notas._labels&&latest.notas._labels[k])||k;return {id:k,label:lb,nota:Number(latest.notas[k])||0};}):[]);
    var fb='';
    if(latest.pontos_fortes) fb+='<div class="asum-block fortes"><h5>Pontos fortes</h5><p>'+esc(latest.pontos_fortes)+'</p></div>';
    if(latest.pontos_desenvolver) fb+='<div class="asum-block desenv"><h5>A desenvolver</h5><p>'+esc(latest.pontos_desenvolver)+'</p></div>';
    if(latest.plano_acao) fb+='<div class="asum-block plano"><h5>Plano de ação</h5><p>'+esc(latest.plano_acao)+'</p></div>';
    diagCard='<div class="profile-card"><h3 class="profile-sec-h">Meu diagnóstico · '+(latest.periodo_label?esc(latest.periodo_label):fmtDate(latest.data_avaliacao))+'</h3>'+
      '<div class="aval-summary"><div class="asum-score" style="border-color:'+ld.color+'"><span class="asum-num" style="color:'+ld.color+'">'+lnota.toFixed(1)+'</span><span class="asum-of">de 5</span></div><div class="asum-diag">'+diagBadge(lnota)+'<p>'+ld.rec+'</p></div></div>'+
      critBarsHTML(lArr)+fb+'</div>';
  }
  var evoColab = avalEvolucaoRender(avals);
  var evoCard = evoColab ? ('<div class="profile-card"><h3 class="profile-sec-h">Minha evolução</h3>'+evoColab+'</div>') : '';
  return diagCard+evoCard+'<div class="profile-card"><h3 class="profile-sec-h">Minhas avaliações</h3><div class="me-avals">'+avalHTML+'</div></div>'+
         '<div class="profile-card"><h3 class="profile-sec-h">Minhas comissões</h3><div class="me-coms">'+comHTML+'</div></div>';
}
function perfilHTML() {
  var u=ST.session.user;
  var setor = SECTORS[u.sector] ? SECTORS[u.sector].label : (u.sector||'');
  var av = u.avatar ? 'style="background:center/cover url(\''+u.avatar+'\')"' : 'style="background:'+(u.color||'#3B6FF7')+'"';
  return ''+
    '<div class="profile-wrap">'+
      '<div class="profile-card">'+
        '<div class="profile-head">'+
          '<span class="profile-av" '+av+'>'+(u.avatar?'':esc(u.initials))+'</span>'+
          '<div class="profile-head-info"><h2>'+esc(u.name)+'</h2><p>'+esc(u.email)+' · '+esc(setor)+'</p>'+
            '<button class="btn btn-ghost" id="prfPhotoBtn">Trocar foto</button><input type="file" accept="image/*" id="prfPhotoFile" style="display:none"></div>'+
        '</div>'+
        '<div class="profile-grid"><div class="prf-field"><label>Nome</label><input type="text" id="prfName" value="'+esc(u.name)+'"></div><div class="prf-field"><label>Cargo</label><input type="text" id="prfPosition" value="'+esc(u.position||'')+'" placeholder="ex: Gerente"></div></div>'+
        '<div class="profile-grid"><div class="prf-field"><label>Telefone</label><input type="text" id="prfPhone" value="'+esc(u.phone||'')+'" placeholder="(11) 90000-0000"></div><div class="prf-field"><label>E-mail</label><input type="text" value="'+esc(u.email)+'" disabled></div></div>'+
        '<div class="prf-field"><label>Bio</label><textarea id="prfBio" placeholder="Sobre você...">'+esc(u.bio||'')+'</textarea></div>'+
        '<button class="btn btn-primary" id="prfSave">Salvar perfil</button>'+
      '</div>'+
      '<div class="profile-card">'+
        '<h3 class="profile-sec-h">Trocar senha</h3>'+
        '<div class="prf-field"><label>Nova senha</label><input type="password" id="prfPass" placeholder="mínimo 4 caracteres"></div>'+
        '<button class="btn btn-primary" id="prfPassSave">Alterar senha</button>'+
      '</div>'+
      perfilDesempenhoHTML()+
      '<div class="profile-card">'+
        '<h3 class="profile-sec-h">Conta</h3>'+
        '<p style="font-size:13px;color:var(--u-text2);margin-bottom:12px">Encerrar a sessão neste dispositivo.</p>'+
        '<button class="btn btn-danger" id="prfLogout">'+icon('logout')+' Sair da conta</button>'+
      '</div>'+
    '</div>';
}

function bindPerfil() {
  var u=ST.session.user;
  // trocar foto (base64, máx 200KB)
  var pb=document.getElementById('prfPhotoBtn'), pf=document.getElementById('prfPhotoFile');
  if (pb && pf) {
    pb.addEventListener('click', function(){ pf.click(); });
    pf.addEventListener('change', function(){
      var f=pf.files && pf.files[0]; if(!f) return;
      if (f.size > 200*1024) { toast('Imagem muito grande (máx 200KB)','error'); return; }
      var reader=new FileReader();
      reader.onload=function(ev){
        var data=ev.target.result;
        sb.from('malba_users').update({ avatar:data }).eq('id', u.id).then(function(r){
          if (r.error) { toast('Erro ao salvar foto','error'); console.error(r.error); return; }
          u.avatar=data; saveSession(ST.session); toast('Foto atualizada','success'); renderPage();
        });
      };
      reader.readAsDataURL(f);
    });
  }
  // salvar dados do perfil
  var save=document.getElementById('prfSave');
  if (save) save.addEventListener('click', function(){
    var name=(document.getElementById('prfName').value||'').trim();
    if (!name) { toast('Nome obrigatório','error'); return; }
    var payload={ name:name, phone:(document.getElementById('prfPhone').value||'').trim(), position:(document.getElementById('prfPosition').value||'').trim(), bio:(document.getElementById('prfBio').value||'').trim(), initials:iniciais(name) };
    setBusy(save,true);
    sb.from('malba_users').update(payload).eq('id', u.id).then(function(r){
      setBusy(save,false); save.textContent='Salvar perfil';
      if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); return; }
      Object.assign(u, payload); saveSession(ST.session); toast('Perfil atualizado','success'); renderPage();
    });
  });
  // trocar senha (grava na coluna `password`, que é a que o login lê)
  var ps=document.getElementById('prfPassSave');
  if (ps) ps.addEventListener('click', function(){
    var p=(document.getElementById('prfPass').value||'').trim();
    if (!p) { toast('Digite a nova senha','error'); return; }
    if (p.length<4) { toast('Senha muito curta (mín. 4)','error'); return; }
    setBusy(ps,true);
    sb.from('malba_users').update({ password_hash:p }).eq('id', u.id).then(function(r){
      setBusy(ps,false); ps.textContent='Alterar senha';
      if (r.error) { toast('Erro ao alterar senha','error'); console.error(r.error); return; }
      document.getElementById('prfPass').value=''; toast('Senha alterada','success');
    });
  });
  var out=document.getElementById('prfLogout');
  if (out) out.addEventListener('click', logout);
}

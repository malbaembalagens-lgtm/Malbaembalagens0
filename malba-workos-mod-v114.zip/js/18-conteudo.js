/* ========== [10k] CALENDÁRIO EDITORIAL (Marketing) ========== */
function calDayItems(ds) {
  var admin=isAdmin(ST.session), me=String(ST.session.user.id), sid=boardStore();
  var who = admin ? (ST.taskAssignee?String(ST.taskAssignee):null) : me;
  var projIds={}; (ST.projects||[]).forEach(function(p){ projIds[String(p.id)]=1; });
  var out=[];
  ST.tasks.forEach(function(t){
    if (t.is_rule) return; // v70
    if ((t.due_date||'').slice(0,10)!==ds) return;
    if (sid && String(t.store_unit_id)!==String(sid)) return;
    if (!admin) { if (String(t.assignee_id)!==me && String(t.created_by)!==me) return; }
    else if (who && String(t.assignee_id||'')!==who) return;
    out.push({ k:'task', id:t.id, label:t.title, status:t.status||'todo', priority:t.priority, assignee_id:t.assignee_id, drag:admin });
  });
  ST.milestones.forEach(function(m){
    if ((m.date||'').slice(0,10)!==ds) return;
    if (!projIds[String(m.project_id)]) return;                 // só marcos de projetos DESTE setor
    if (sid && String(projStore(m.project_id))!==String(sid)) return;
    if (who && String(m.assignee_id||'')!==who) return;
    out.push({ k:'ms', id:m.id, label:m.name, status:m.status||'todo', priority:'media', assignee_id:m.assignee_id, drag:admin, src:'Projeto' });
  });
  // campanhas só no Marketing (é onde elas existem)
  if (ST.sector==='marketing') {
    ST.campaigns.forEach(function(c){
      (c.tasks||[]).forEach(function(tk){
        if ((tk.due||'').slice(0,10)!==ds) return;
        var aid=tk.assignee_id?String(tk.assignee_id):null;
        if (who && aid!==who) return;
        out.push({ k:'camptask', id:String(c.id)+'__'+String(tk.id), label:tk.title, status:(tk.done?'feito':'todo'), priority:tk.priority||'media', assignee_id:aid, drag:admin, src:'Campanha' });
      });
    });
    ST.campaigns.forEach(function(c){
      var s=(c.start_date||'').slice(0,10), e=(c.end_date||'').slice(0,10)||s;
      if (!(s && ds>=s && ds<=e)) return;
      if (sid && c.store_unit_id && String(c.store_unit_id)!==String(sid)) return;
      out.push({ k:'camp', id:c.id, label:c.name, color:c.color||'#8B5CF6', drag:false, edge:(ds===s?'start':(ds===e?'end':'mid')) });
    });
  }
  // eventos do calendário: equipe (todos do setor) ou pessoal (só o criador)
  (ST.events||[]).forEach(function(ev){
    if (ev.kind==='aviso') return;
    if ((ev.date||'').slice(0,10)!==ds) return;
    if (String(ev.sector||'')!==String(ST.sector)) return;
    if (ev.scope==='me' && String(ev.created_by)!==me) return;
    if (ev.store_unit_id && sid && String(ev.store_unit_id)!==String(sid)) return;
    out.push({ k:'event', id:ev.id, label:ev.title, scope:ev.scope, kind:ev.kind, color:ev.color||'#8B5CF6', hora:ev.hora, drag:admin });
  });
  return out;
}
function calChipHTML(it) {
  if (it.k==='event') {
    return '<button class="cal-chip cal-chip-event'+(it.scope==='me'?' me':'')+'" data-ck="event" data-cid="'+esc(it.id)+'"'+(it.drag?' draggable="true"':'')+' title="'+(it.scope==='me'?'Só para você':'Toda a equipe')+'" style="background:'+it.color+'1f;color:'+it.color+'"><i style="background:'+it.color+'"></i><span>'+(it.hora?esc(it.hora)+' ':'')+esc(it.label)+'</span></button>';
  }
  if (it.k==='camp') {
    return '<button class="cal-chip cal-chip-camp" data-ck="camp" data-cid="'+esc(it.id)+'" style="background:'+it.color+'18;color:'+it.color+'"><i style="background:'+it.color+'"></i><span>'+esc(it.label)+'</span></button>';
  }
  var sc=(STATUS[it.status]||STATUS.todo).color;
  var pr=PRIO[it.priority]||PRIO.media;
  var done=it.status==='feito';
  var drag=it.drag?' draggable="true"':'';
  return '<button class="cal-chip'+(done?' done':'')+'" data-ck="'+it.k+'" data-cid="'+esc(it.id)+'"'+drag+' style="background:'+sc+'14;color:'+sc+'"><i style="background:'+pr.color+'"></i><span>'+esc(it.label)+'</span></button>';
}
function diaLabelCal(ds){ var p=ds.split('-'); var dt=new Date(Number(p[0]), Number(p[1])-1, Number(p[2]), 12,0,0); var dows=['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado']; return dows[dt.getDay()]+', '+Number(p[2])+' de '+MESES[Number(p[1])-1]; }
function calItemOpen(k, id){
  var admin=isAdmin(ST.session);
  if (k==='event'){ var ev=evById(id); if(ev){ if(admin||String(ev.created_by)===String(ST.session.user.id)) openEventModal(ev,null); else toast((ev.hora?ev.hora+' · ':'')+(ev.title||'Evento'),'info'); } }
  else if (k==='camp'){ var c=campById(id); if(c){ if(admin) openCampaignModal(c); else toast('Campanha "'+(c.name||'')+'"','info'); } }
  else if (k==='task'){ var t=taskById(id); if(t) openTaskModal(t); }
  else if (k==='ms'){ var mm=msById(id); if(mm){ ST.openProject=mm.project_id; ST.page='projetos'; navigate(ST.sector+'/projetos'); renderPage(); } }
  else if (k==='camptask'){ var cc=campById(String(id).split('__')[0]); if(cc){ if(admin) openCampaignModal(cc); else toast('Tarefa de campanha','info'); } }
}
function toggleTaskDoneCal(id, cb){ var t=taskById(id); if(!t) return; var nd=(t.status==='feito')?'todo':'feito'; t.status=nd; sb.from('malba_vl_tasks').update({ status:nd }).eq('id',id).then(function(r){ if(r.error) toast('Erro ao atualizar','error'); }); if(cb) cb(); renderPage(); }
function openDiaModal(ds){
  var admin=isAdmin(ST.session); var podeTarefa = admin || canEdit();
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  function row(it){
    var color, meta='';
    if(it.k==='event'){ color=it.color||'#0EA5E9'; meta=(it.hora?it.hora+' · ':'')+(it.scope==='me'?'Só você':'Equipe'); }
    else if(it.k==='camp'){ color=it.color||'#8B5CF6'; meta='Campanha'; }
    else { var sc=STATUS[it.status]||STATUS.todo; color=sc.color; var u=it.assignee_id?userByIdAll(it.assignee_id):null; meta=sc.label+(it.src?(' · '+it.src):'')+(u?(' · '+(u.name||'').split(' ')[0]):''); }
    var isTask=(it.k==='task'); var done=it.status==='feito';
    var lead = (isTask && podeTarefa) ? '<button class="dia-check'+(done?' on':'')+'" data-diatoggle="'+esc(it.id)+'">'+(done?icon('tasks'):'')+'</button>' : '<span class="dia-dot" style="background:'+color+'"></span>';
    return '<div class="dia-item'+(done?' done':'')+'" data-diak="'+esc(it.k)+'" data-diaid="'+esc(it.id)+'">'+lead+'<div class="dia-item-main"><b>'+esc(it.label)+'</b>'+(meta?'<span>'+esc(meta)+'</span>':'')+'</div><span class="dia-arrow">›</span></div>';
  }
  function draw(){
    var items=calDayItems(ds);
    var tarefas=items.filter(function(x){ return x.k==='task'||x.k==='ms'||x.k==='camptask'; });
    var eventos=items.filter(function(x){ return x.k==='event'; });
    var camps=items.filter(function(x){ return x.k==='camp'; });
    var body='';
    if(!items.length){ body='<div class="dia-empty">'+icon('cal')+'<p>Nada neste dia ainda.</p></div>'; }
    else {
      if(tarefas.length){ body+='<div class="dia-sec-h">'+icon('tasks')+'<span>Tarefas</span><i>'+tarefas.length+'</i></div>'+tarefas.map(row).join(''); }
      if(eventos.length){ body+='<div class="dia-sec-h">'+icon('cal')+'<span>Eventos</span><i>'+eventos.length+'</i></div>'+eventos.map(row).join(''); }
      if(camps.length){ body+='<div class="dia-sec-h">'+icon('megaphone')+'<span>Campanhas</span><i>'+camps.length+'</i></div>'+camps.map(row).join(''); }
    }
    var addBtns='<div class="dia-actions">'+(podeTarefa?'<button class="btn btn-primary" id="diaAddTask">'+icon('plus')+'Tarefa</button>':'')+'<button class="btn '+(podeTarefa?'btn-ghost':'btn-primary')+'" id="diaAddEvt">'+icon('plus')+'Evento</button></div>';
    modal.innerHTML='<div class="modal dia-modal"><div class="dia-head"><div><div class="dia-title">'+esc(diaLabelCal(ds))+'</div><div class="dia-sub">'+items.length+' item(ns) neste dia</div></div><button class="dia-close" id="diaClose">✕</button></div><div class="dia-body">'+body+'</div>'+addBtns+'</div>';
    bind();
  }
  function bind(){
    modal.querySelector('#diaClose').addEventListener('click', close);
    var at=modal.querySelector('#diaAddTask'); if(at) at.addEventListener('click', function(){ close(); openTaskModal(null, { due:ds }); });
    var ae=modal.querySelector('#diaAddEvt'); if(ae) ae.addEventListener('click', function(){ close(); openEventModal(null, ds); });
    var tgs=modal.querySelectorAll('[data-diatoggle]'); for(var i=0;i<tgs.length;i++) tgs[i].addEventListener('click', function(e){ e.stopPropagation(); toggleTaskDoneCal(this.getAttribute('data-diatoggle'), draw); });
    var rws=modal.querySelectorAll('.dia-item'); for(var j=0;j<rws.length;j++) rws[j].addEventListener('click', function(e){ if(e.target.closest('[data-diatoggle]')) return; var k=this.getAttribute('data-diak'), id=this.getAttribute('data-diaid'); close(); calItemOpen(k, id); });
  }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal); draw();
}
function calendarioHTML() {
  if (ST.cal.y==null) { var n=new Date(); ST.cal.y=n.getFullYear(); ST.cal.m=n.getMonth(); }
  var y=ST.cal.y, m=ST.cal.m;
  var first=new Date(y,m,1).getDay();
  var dim=new Date(y,m+1,0).getDate();
  var hoje=today();
  var admin=isAdmin(ST.session);
  var dow=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];

  var filter='';
  if (admin) {
    var meIdC = String(ST.session.user.id);
    var mineSelC = (String(ST.taskAssignee)===meIdC) ? ' selected' : '';
    var othersC = ST.users.filter(function(u){ return String(u.id)!==meIdC; }).map(function(u){ return '<option value="'+esc(u.id)+'"'+(String(ST.taskAssignee)===String(u.id)?' selected':'')+'>'+esc(u.name)+'</option>'; }).join('');
    var opts='<option value="'+esc(meIdC)+'"'+mineSelC+'>Minhas tarefas</option><option value="">Todos da equipe</option>'+othersC;
    filter='<select class="task-filter" id="calAssignee" title="Ver tarefas de">'+opts+'</select>';
  }
  var sub = admin ? 'Clique num dia para ver tudo e adicionar tarefas ou eventos' : 'Clique num dia para ver seus itens · você também pode criar lembretes';
  var addEvtBtn = '<button class="btn-new cal-evt-btn" id="btnNovoEvento">'+icon('plus')+'Evento</button>';
  var top='<div class="cal-top"><div><h2>Calendário</h2><div class="sub">'+sub+'</div></div>'+
    '<div class="cal-top-r">'+filter+addEvtBtn+'<div class="cal-nav-wrap"><button class="cal-nav" id="calPrev">‹</button><span class="cal-month">'+MESES[m]+' '+y+'</span><button class="cal-nav" id="calNext">›</button><button class="cal-today-btn" id="calToday">Hoje</button></div></div></div>';
  var legend='<div class="cal-legend"><span class="cal-lg"><i style="background:#9aa1ad"></i>A fazer</span><span class="cal-lg"><i style="background:#3B6FF7"></i>Em andamento</span><span class="cal-lg"><i style="background:#16A34A"></i>Concluída</span><span class="cal-lg"><i style="background:#8B5CF6"></i>Campanha</span><span class="cal-lg"><i style="background:#0EA5E9"></i>Evento/Reunião</span></div>';

  var grid='<div class="cal-grid">';
  dow.forEach(function(d){ grid+='<div class="cal-dow">'+d+'</div>'; });
  for (var b=0;b<first;b++) grid+='<div class="cal-cell empty"></div>';
  for (var d=1;d<=dim;d++) {
    var ds=y+'-'+pad(m+1)+'-'+pad(d);
    var items=calDayItems(ds);
    var chips='';
    items.slice(0,4).forEach(function(it){ chips+=calChipHTML(it); });
    if (items.length>4) chips+='<span class="cal-more">+'+(items.length-4)+' mais</span>';
    var addBtn = admin ? '<button class="cal-add" data-add="'+ds+'" title="Nova tarefa neste dia">+</button>' : '';
    grid+='<div class="cal-cell'+(ds===hoje?' today':'')+'" data-date="'+ds+'"><div class="cal-cell-h"><span class="cal-d">'+d+'</span>'+addBtn+'</div><div class="cal-chips">'+chips+'</div></div>';
  }
  grid+='</div>';
  return top+legend+grid;
}

function bindCalendario() {
  var prev=document.getElementById('calPrev'), next=document.getElementById('calNext'), tdy=document.getElementById('calToday');
  if (prev) prev.addEventListener('click', function(){ ST.cal.m--; if(ST.cal.m<0){ ST.cal.m=11; ST.cal.y--; } renderPage(); });
  if (next) next.addEventListener('click', function(){ ST.cal.m++; if(ST.cal.m>11){ ST.cal.m=0; ST.cal.y++; } renderPage(); });
  if (tdy) tdy.addEventListener('click', function(){ var n=new Date(); ST.cal.y=n.getFullYear(); ST.cal.m=n.getMonth(); renderPage(); });
  var af=document.getElementById('calAssignee');
  if (af) af.addEventListener('change', function(){ ST.taskAssignee=this.value; renderPage(); });
  var admin=isAdmin(ST.session);

  // botão "+ Evento" (todos podem; não-admin só cria pessoal)
  var evtBtn=document.getElementById('btnNovoEvento');
  if (evtBtn) evtBtn.addEventListener('click', function(){ openEventModal(null, null); });

  // abrir item ao clicar no chip
  var chips=app.querySelectorAll('.cal-chip');
  for (var i=0;i<chips.length;i++) chips[i].addEventListener('click', function(e){
    e.stopPropagation();
    if (this.classList.contains('dragging')) return;
    var k=this.getAttribute('data-ck'), id=this.getAttribute('data-cid');
    if (k==='event') { var ev=evById(id); if(ev){ if (admin || String(ev.created_by)===String(ST.session.user.id)) openEventModal(ev, null); else toast((ev.hora?ev.hora+' · ':'')+(ev.title||'Evento'),'info'); } }
    else if (k==='camp') { var c=campById(id); if (c) { if(admin) openCampaignModal(c); else toast('Campanha "'+(c.name||'')+'"','info'); } }
    else if (k==='task') { var t=taskById(id); if (t) openTaskModal(t); }
    else if (k==='ms') { var mm=msById(id); if (mm) { ST.openProject=mm.project_id; ST.page='projetos'; navigate(ST.sector+'/projetos'); renderPage(); } }
    else if (k==='camptask') { var cc=campById(String(id).split('__')[0]); if (cc) { if(admin) openCampaignModal(cc); else toast('Tarefa de campanha','info'); } }
  });

  // clique no dia abre a VISÃO DO DIA (todos podem ver; adicionar respeita a permissão)
  var cells=app.querySelectorAll('.cal-cell[data-date]');
  for (var z=0;z<cells.length;z++) cells[z].addEventListener('click', function(e){
    if (e.target.closest('.cal-chip') || e.target.closest('[data-add]')) return;
    openDiaModal(this.getAttribute('data-date'));
  });

  if (!admin) return; // criar direto no grid / arrastar: só admin

  // atalho "+" no canto do dia: nova tarefa direta
  var adds=app.querySelectorAll('[data-add]');
  for (var a=0;a<adds.length;a++) adds[a].addEventListener('click', function(e){ e.stopPropagation(); openTaskModal(null, { due:this.getAttribute('data-add') }); });

  // DRAG & DROP entre dias
  var dragData=null;
  var dgs=app.querySelectorAll('.cal-chip[draggable="true"]');
  for (var g=0;g<dgs.length;g++) {
    dgs[g].addEventListener('dragstart', function(e){ dragData={ k:this.getAttribute('data-ck'), id:this.getAttribute('data-cid') }; this.classList.add('dragging'); if(e.dataTransfer){ e.dataTransfer.effectAllowed='move'; try{e.dataTransfer.setData('text/plain',this.getAttribute('data-cid'));}catch(_){} } });
    dgs[g].addEventListener('dragend', function(){ this.classList.remove('dragging'); dragData=null; var ov=app.querySelectorAll('.cal-cell.drag-over'); for(var k=0;k<ov.length;k++) ov[k].classList.remove('drag-over'); });
  }
  for (var c2=0;c2<cells.length;c2++) {
    cells[c2].addEventListener('dragover', function(e){ if(!dragData) return; e.preventDefault(); if(e.dataTransfer) e.dataTransfer.dropEffect='move'; this.classList.add('drag-over'); });
    cells[c2].addEventListener('dragleave', function(e){ if(e.target===this) this.classList.remove('drag-over'); });
    cells[c2].addEventListener('drop', function(e){ e.preventDefault(); this.classList.remove('drag-over'); if(!dragData) return; calMove(dragData.k, dragData.id, this.getAttribute('data-date')); });
  }
}
function calMove(k, id, ds) {
  if (k==='task') { var t=taskById(id); if(!t||((t.due_date||'').slice(0,10)===ds)) return; t.due_date=ds; sb.from('malba_vl_tasks').update({ due_date:ds }).eq('id', id).then(function(r){ if(r.error) toast('Erro ao mover','error'); }); toast('Tarefa movida para '+fmtDate(ds),'success'); renderPage(); }
  else if (k==='ms') { var m=msById(id); if(!m||((m.date||'').slice(0,10)===ds)) return; m.date=ds; sb.from('malba_vl_milestones').update({ date:ds }).eq('id', id).then(function(r){ if(r.error) toast('Erro ao mover','error'); }); toast('Marco movido para '+fmtDate(ds),'success'); renderPage(); }
  else if (k==='camptask') { var parts=String(id).split('__'); var c=campById(parts[0]); if(!c) return; var tk=null; (c.tasks||[]).forEach(function(x){ if(String(x.id)===String(parts[1])) tk=x; }); if(!tk||((tk.due||'').slice(0,10)===ds)) return; tk.due=ds; sb.from('malba_campaigns').update({ tasks:c.tasks }).eq('id', c.id).then(function(r){ if(r.error) toast('Erro ao mover','error'); }); toast('Tarefa movida para '+fmtDate(ds),'success'); renderPage(); }
  else if (k==='event') { var ev=evById(id); if(!ev||((ev.date||'').slice(0,10)===ds)) return; ev.date=ds; sb.from('malba_events').update({ date:ds }).eq('id', id).then(function(r){ if(r.error) toast('Erro ao mover','error'); }); toast('Evento movido para '+fmtDate(ds),'success'); renderPage(); }
}
function evById(id){ for(var i=0;i<ST.events.length;i++) if(String(ST.events[i].id)===String(id)) return ST.events[i]; return null; }
function openEventModal(ev, presetDate){
  var admin=isAdmin(ST.session);
  var me=ST.session.user;
  var editing=!!ev;
  var canEdit = !editing || admin || String(ev.created_by)===String(me.id);
  if (editing && !canEdit){ toast('Você não pode editar este evento','error'); return; }
  var EK={ evento:{label:'Evento',color:'#0EA5E9'}, reuniao:{label:'Reunião',color:'#8B5CF6'}, lembrete:{label:'Lembrete',color:'#F59E0B'} };
  var kind = editing ? (ev.kind||'evento') : 'evento';
  var scope = admin ? (editing ? (ev.scope||'team') : 'team') : 'me';
  var lojas = (ST.sector==='lojas') ? lojasGestao() : [];
  var curStore = editing ? (ev.store_unit_id||'') : '';
  var dateVal = editing ? (ev.date||'').slice(0,10) : (presetDate || today());
  var kindPills = Object.keys(EK).map(function(k){ return '<button type="button" class="pill ev-kind'+(kind===k?' on':'')+'" data-k="'+k+'" style="color:'+EK[k].color+'"><span class="pdot" style="background:'+EK[k].color+'"></span>'+EK[k].label+'</button>'; }).join('');
  var scopeRow = admin ? ('<div class="modal-row"><label class="modal-label">Quem vê</label><div class="pills" id="evScope"><button type="button" class="pill ev-scope'+(scope==='team'?' on':'')+'" data-s="team" style="color:var(--u-accent)"><span class="pdot" style="background:var(--u-accent)"></span>Toda a equipe</button><button type="button" class="pill ev-scope'+(scope==='me'?' on':'')+'" data-s="me" style="color:var(--u-purple)"><span class="pdot" style="background:var(--u-purple)"></span>Só para mim</button></div></div>') : '<div class="modal-note">Este lembrete fica visível só para você.</div>';
  var storeRow = (admin && lojas.length) ? ('<div class="modal-row"><label class="modal-label">Loja (opcional)</label><select id="evStore"><option value="">Todas / nenhuma</option>'+lojas.map(function(s){return '<option value="'+esc(s.id)+'"'+(String(curStore)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';}).join('')+'</select></div>') : '';
  var delBtn = (editing && canEdit) ? '<button class="btn btn-danger btn-del-wrap" id="evDel">Excluir</button>' : '';
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal">'+
    '<div class="modal-title-input" style="cursor:default">'+(editing?'Editar evento':'Novo no calendário')+'</div>'+
    '<div class="modal-row"><label class="modal-label">Título</label><input type="text" id="evTitle" placeholder="ex: Reunião de equipe" value="'+esc(editing?(ev.title||''):'')+'" maxlength="120"></div>'+
    '<div class="modal-row"><label class="modal-label">Tipo</label><div class="pills" id="evKind">'+kindPills+'</div></div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Data</label><input type="date" id="evDate" value="'+esc(dateVal)+'"></div><div class="modal-row"><label class="modal-label">Hora (opcional)</label><input type="time" id="evHora" value="'+esc(editing?(ev.hora||''):'')+'"></div></div>'+
    scopeRow+ storeRow+
    '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="evCancel">Cancelar</button><button class="btn btn-primary" id="evSave">'+(editing?'Salvar':'Adicionar')+'</button></div>'+
  '</div>';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.querySelectorAll('.ev-kind').forEach(function(b){ b.addEventListener('click', function(){ kind=this.getAttribute('data-k'); modal.querySelectorAll('.ev-kind').forEach(function(x){x.classList.remove('on');}); this.classList.add('on'); }); });
  modal.querySelectorAll('.ev-scope').forEach(function(b){ b.addEventListener('click', function(){ scope=this.getAttribute('data-s'); modal.querySelectorAll('.ev-scope').forEach(function(x){x.classList.remove('on');}); this.classList.add('on'); }); });
  modal.querySelector('#evCancel').addEventListener('click', close);
  var del=modal.querySelector('#evDel');
  if (del) del.addEventListener('click', function(){
    confirmDelete('Excluir este evento?', function(){ sb.from('malba_events').delete().eq('id', ev.id).then(function(r){
      if(r.error){ toast('Erro ao excluir','error'); return; }
      ST.events=ST.events.filter(function(x){return x.id!==ev.id;});
      auditLog('Excluiu evento', ev.title||''); close(); toast('Evento excluído','success'); renderPage();
    }); });
  });
  modal.querySelector('#evSave').addEventListener('click', function(){
    var title=(modal.querySelector('#evTitle').value||'').trim();
    if(!title){ toast('Dê um título','error'); return; }
    var rec={ sector:ST.sector, title:title, date:modal.querySelector('#evDate').value||today(), hora:(modal.querySelector('#evHora').value||'')||null, kind:kind, scope:(admin?scope:'me'), color:EK[kind].color, store_unit_id:(modal.querySelector('#evStore')?(modal.querySelector('#evStore').value||null):null), created_by:(editing?(ev.created_by||me.id):me.id), created_by_name:(editing?(ev.created_by_name||me.name):me.name) };
    var btn=this; setBusy(btn,true);
    if (editing){
      sb.from('malba_events').update(rec).eq('id', ev.id).then(function(r){
        if(r.error){ toast('Erro ao salvar','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Salvar'; return; }
        for(var i=0;i<ST.events.length;i++) if(ST.events[i].id===ev.id){ ST.events[i]=Object.assign(ST.events[i],rec); break; }
        auditLog('Editou evento', title); close(); toast('Evento atualizado','success'); renderPage();
      });
    } else {
      sb.from('malba_events').insert(rec).select().single().then(function(r){
        if(r.error||!r.data){ toast('Erro ao adicionar (rodou o SQL de eventos?)','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Adicionar'; return; }
        ST.events.push(r.data); auditLog('Criou evento', title); close(); toast('Adicionado ao calendário','success'); renderPage();
      });
    }
  });
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal);
}

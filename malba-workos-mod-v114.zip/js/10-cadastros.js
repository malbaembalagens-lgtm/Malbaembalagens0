/* ============================================================
   v110: CADASTROS — Fase 5a (Perfis de Permissão customizáveis)

   Um perfil = nível base (um dos 5) + adições/remoções em cima.
   Quem tem um perfil atribuído usa-o. Quem não tem, usa o nível
   fixo como antes. Nada quebra.
   ============================================================ */

/* ---------- Capacidades disponíveis pra editar (rótulos amigáveis) ---------- */
var CAPS_INFO = {
  sistema:       { label:'Sistema completo',        desc:'Estrutura, usuários, integrações, configurações' },
  equipe:        { label:'Equipe',                  desc:'Gerenciar funcionários e ponto' },
  gerir:         { label:'Gerenciar tarefas',       desc:'Criar projetos, POPs e administrar todo o quadro' },
  rotinas:       { label:'Rotinas do Dia',          desc:'Criar e agendar POPs recorrentes' },
  redistribuir:  { label:'Redistribuir',            desc:'Mover tarefas entre pessoas' },
  indicadores:   { label:'Indicadores',             desc:'Ver KPIs, dashboards e relatórios' },
  executar:      { label:'Executar tarefas',        desc:'Marcar como feito, enviar evidências' },
  estrategia:    { label:'Estratégia',              desc:'Criar/ver ideias, objetivos, projetos' },
  docs:          { label:'Documentos',              desc:'Criar/ler documentos' }
};

/* ---------- Carregar perfis do banco ---------- */
function perfisCarregar(cb){
  if (!sb){ ST.perfis = []; if (cb) cb(); return; }
  sb.from('malba_perfis').select('*').order('label').then(function(r){
    if (r.error){
      var msg = (r.error.message||'').toLowerCase();
      if (msg.indexOf('does not exist')!==-1 || msg.indexOf('relation')!==-1){
        ST.perfis = [];
      } else {
        console.warn('perfis:', r.error.message);
        ST.perfis = [];
      }
    } else {
      ST.perfis = r.data || [];
    }
    if (cb) cb();
  });
}

/* ---------- Compõe capacidades: base + adiciona - remove ---------- */
function capsDoPerfil(perfil){
  if (!perfil) return null;
  var base = CAPS[perfil.base_nivel] || {};
  var out = Object.assign({}, base);
  (perfil.caps_adicionar||[]).forEach(function(k){ out[k] = 1; });
  (perfil.caps_remover||[]).forEach(function(k){ delete out[k]; });
  return out;
}

/* ---------- Substitui CAPS[user] no can() ---------- */
/* Se o usuário tem profile_id → usa capsDoPerfil. Senão → nivelDe(user) e CAPS[nível]. */
function capsDoUsuario(u){
  if (!u) return {};
  if (u.profile_id){
    var p = (ST.perfis||[]).find(function(x){ return String(x.id)===String(u.profile_id); });
    if (p) return capsDoPerfil(p);
  }
  var nv = nivelDe(u);
  return CAPS[nv] || {};
}

/* ---------- Rótulo do perfil (mostrar em lugar do "Gestor") ---------- */
function perfilLabelDe(u){
  if (u && u.profile_id){
    var p = (ST.perfis||[]).find(function(x){ return String(x.id)===String(u.profile_id); });
    if (p) return p.label;
  }
  var nv = nivelDe(u);
  return (NIVEIS[nv]||{label:nv}).label;
}

/* ============================================================
   TELA — Aba Perfis na Central
   ============================================================ */
function centralPerfisHTML(){
  var lista = (ST.perfis||[]).slice().sort(function(a,b){ return (a.label||'').localeCompare(b.label||''); });
  var podeMexer = isSuper(ST.session);
  var btn = podeMexer ? '<button class="btn-new" id="cadNovoPerfil">'+icon('plus')+'Novo perfil</button>' : '';

  // Bloco dos 5 níveis fixos (só leitura)
  var fixos = ['viewer','colaborador','supervisor','gestor','admin'].map(function(nv){
    var info = NIVEIS[nv];
    var cnt = (ST.allUsers||[]).filter(function(u){ return !u.profile_id && nivelDe(u)===nv; }).length;
    return '<div class="cad-linha">'+
      '<span class="cad-linha-ic" style="background:'+info.color+'18;color:'+info.color+'">'+icon('users')+'</span>'+
      '<span class="cad-linha-main">'+
        '<b>'+esc(info.label)+'</b> <span class="cad-eq-chip cinza">nível padrão</span>'+
        '<span class="cad-linha-sub">'+esc(info.desc)+' · '+cnt+' pessoa'+(cnt===1?'':'s')+'</span>'+
      '</span>'+
    '</div>';
  }).join('');

  // Perfis customizados
  var linhas = lista.length ? lista.map(function(p){
    var baseLb = (NIVEIS[p.base_nivel]||{label:p.base_nivel}).label;
    var cor = p.color || '#3B6FF7';
    var cnt = (ST.allUsers||[]).filter(function(u){ return String(u.profile_id||'')===String(p.id); }).length;
    var adds = (p.caps_adicionar||[]).length;
    var rems = (p.caps_remover||[]).length;
    var mods = [];
    if (adds) mods.push('+'+adds);
    if (rems) mods.push('−'+rems);
    var chip = mods.length ? '<span class="cad-eq-chip" style="color:'+cor+';background:'+cor+'18">'+mods.join(' · ')+' caps</span>' : '';
    var acao = podeMexer ? '<span class="cad-linha-acoes">'+
      '<button class="cad-linha-btn" data-perfil-edit="'+esc(p.id)+'" title="Editar">✎</button>'+
      '<button class="cad-linha-btn danger" data-perfil-del="'+esc(p.id)+'" title="Remover">×</button>'+
    '</span>' : '';
    return '<div class="cad-linha">'+
      '<span class="cad-linha-ic" style="background:'+cor+'18;color:'+cor+'">'+icon('gear')+'</span>'+
      '<span class="cad-linha-main">'+
        '<b>'+esc(p.label)+'</b> '+chip+
        '<span class="cad-linha-sub">Baseado em <b>'+esc(baseLb)+'</b> · '+cnt+' pessoa'+(cnt===1?'':'s')+'</span>'+
      '</span>'+
      acao+
    '</div>';
  }).join('') : '<div class="cad-vazio">Nenhum perfil customizado ainda. Os 5 níveis padrão continuam funcionando pra todo mundo.</div>';

  return '<div class="cad-titulo"><h3>🎭 Perfis de Permissão</h3><span class="cad-sub">'+(5+lista.length)+' perfis no total</span>'+btn+'</div>'+
    '<p class="cad-explica">Os 5 níveis padrão (Visualizador → Administrador) são a base. Perfis customizados <b>partem de um nível</b> e adicionam ou removem capacidades específicas.</p>'+
    '<div class="cad-bloco"><h4>Níveis padrão</h4>'+
      '<div class="cad-lista">'+fixos+'</div>'+
    '</div>'+
    '<div class="cad-bloco"><h4>Perfis customizados</h4>'+
      '<div class="cad-lista">'+linhas+'</div>'+
    '</div>';
}

function bindCentralPerfis(){
  var novo = document.getElementById('cadNovoPerfil');
  if (novo) novo.addEventListener('click', function(){ openPerfilModal({}); });
  document.querySelectorAll('[data-perfil-edit]').forEach(function(b){
    b.addEventListener('click', function(){
      var p = (ST.perfis||[]).find(function(x){ return String(x.id)===String(b.getAttribute('data-perfil-edit')); });
      if (p) openPerfilModal(p);
    });
  });
  document.querySelectorAll('[data-perfil-del]').forEach(function(b){
    b.addEventListener('click', function(){ perfilRemover(b.getAttribute('data-perfil-del')); });
  });
}

/* ---------- Modal criar/editar perfil ---------- */
function openPerfilModal(perfil){
  var isNew = !perfil || !perfil.id;
  var ed = Object.assign({
    label:'', base_nivel:'colaborador', color:'#3B6FF7',
    caps_adicionar:[], caps_remover:[]
  }, perfil || {});
  // clone os arrays pra não mutar o original
  ed.caps_adicionar = (ed.caps_adicionar||[]).slice();
  ed.caps_remover   = (ed.caps_remover||[]).slice();

  function refazBloco(){
    var baseCaps = CAPS[ed.base_nivel] || {};
    var itens = Object.keys(CAPS_INFO).map(function(k){
      var temNaBase = !!baseCaps[k];
      var isAdd = ed.caps_adicionar.indexOf(k)!==-1;
      var isRem = ed.caps_remover.indexOf(k)!==-1;
      // estado efetivo: base ? (rem ? off : on) : (add ? on : off)
      var ligado = temNaBase ? !isRem : isAdd;
      var estado = temNaBase ? (isRem ? 'removida' : 'base') : (isAdd ? 'adicionada' : 'off');
      var chip = { base:'do nível base', adicionada:'+ adicionada', removida:'− removida', off:'—' }[estado];
      var chipCor = { base:'#64748B', adicionada:'#16A34A', removida:'#EF4444', off:'#9CA3AF' }[estado];
      return '<label class="perfil-cap'+(ligado?' on':'')+'"><input type="checkbox" data-cap="'+esc(k)+'"'+(ligado?' checked':'')+'>'+
        '<span class="perfil-cap-main"><b>'+esc(CAPS_INFO[k].label)+'</b>'+
          '<span class="perfil-cap-desc">'+esc(CAPS_INFO[k].desc)+'</span>'+
        '</span>'+
        '<span class="perfil-cap-chip" style="color:'+chipCor+'">'+chip+'</span>'+
      '</label>';
    }).join('');
    var el = document.getElementById('perfilCapsList');
    if (el){
      el.innerHTML = itens;
      el.querySelectorAll('[data-cap]').forEach(function(chk){
        chk.addEventListener('change', function(){
          var k = this.getAttribute('data-cap');
          var temNaBase = !!(CAPS[ed.base_nivel]||{})[k];
          // limpa listas
          ed.caps_adicionar = ed.caps_adicionar.filter(function(x){ return x!==k; });
          ed.caps_remover   = ed.caps_remover.filter(function(x){ return x!==k; });
          if (this.checked){
            if (!temNaBase) ed.caps_adicionar.push(k); // marcado e não é da base → adicionar
          } else {
            if (temNaBase) ed.caps_remover.push(k);    // desmarcado e é da base → remover
          }
          refazBloco();
        });
      });
    }
  }

  var cores = ['#3B6FF7','#8B5CF6','#16A34A','#F59E0B','#EF4444','#0EA5E9','#EC4899','#14B8A6'];
  var coresHTML = cores.map(function(c){ return '<button type="button" class="dp-cor-opt'+(ed.color===c?' on':'')+'" data-perfil-cor="'+c+'" style="background:'+c+'"></button>'; }).join('');
  var niveisOpts = ['viewer','colaborador','supervisor','gestor','admin'].map(function(nv){
    return '<option value="'+nv+'"'+(ed.base_nivel===nv?' selected':'')+'>'+esc(NIVEIS[nv].label)+'</option>';
  }).join('');

  var contUso = ed.id ? (ST.allUsers||[]).filter(function(u){ return String(u.profile_id||'')===String(ed.id); }).length : 0;
  var infoUso = contUso ? '<div class="cad-explica">Este perfil está aplicado a <b>'+contUso+'</b> pessoa'+(contUso===1?'':'s')+'. Mudanças aqui refletem imediatamente para todas elas.</div>' : '';

  var m = makeModal({
    title: isNew ? 'Novo perfil' : 'Editar '+ed.label,
    width: 640,
    body:
      '<div class="dp-2col">'+
        '<div class="modal-row"><label class="modal-label">Nome do perfil</label>'+
          '<input type="text" id="perfilNome" value="'+esc(ed.label)+'" placeholder="Ex: Gerência Financeira" autofocus></div>'+
        '<div class="modal-row"><label class="modal-label">Baseado em</label>'+
          '<select id="perfilBase">'+niveisOpts+'</select>'+
        '</div>'+
      '</div>'+
      '<div class="modal-row"><label class="modal-label">Cor</label>'+
        '<div class="dp-cor-grid" id="perfilCorGrid">'+coresHTML+'</div>'+
      '</div>'+
      infoUso+
      '<div class="modal-row"><label class="modal-label">Capacidades</label>'+
        '<p class="cad-explica">Ative pra dar acesso, desative pra tirar. Cinza = do nível base, verde = adicionada, vermelho = removida.</p>'+
        '<div id="perfilCapsList" class="perfil-caps"></div>'+
      '</div>',
    saveLabel: isNew ? 'Criar perfil' : 'Salvar',
    onSave: function(close, root){
      var payload = {
        label: (root.querySelector('#perfilNome').value||'').trim(),
        base_nivel: root.querySelector('#perfilBase').value || 'colaborador',
        color: ed.color,
        caps_adicionar: ed.caps_adicionar,
        caps_remover: ed.caps_remover
      };
      if (!payload.label){ toast('Digite o nome','error'); return; }
      var dup = (ST.perfis||[]).find(function(x){
        return (!ed.id || String(x.id)!==String(ed.id)) &&
               (x.label||'').toLowerCase()===payload.label.toLowerCase();
      });
      if (dup){ toast('Já existe um perfil com esse nome','error'); return; }
      perfilSalvar(Object.assign({}, ed, payload), close);
    }
  });

  refazBloco();
  m.root.querySelector('#perfilBase').addEventListener('change', function(){
    ed.base_nivel = this.value;
    // NÃO limpa adds/rems — o usuário pode ter mexido de propósito
    refazBloco();
  });
  m.root.querySelectorAll('[data-perfil-cor]').forEach(function(b){
    b.addEventListener('click', function(){
      ed.color = this.getAttribute('data-perfil-cor');
      m.root.querySelectorAll('[data-perfil-cor]').forEach(function(x){ x.classList.toggle('on', x.getAttribute('data-perfil-cor')===ed.color); });
    });
  });
}

/* ---------- Salvar ---------- */
function perfilSalvar(perfil, cb){
  var isNew = !perfil.id;
  var payload = {
    label: perfil.label,
    base_nivel: perfil.base_nivel,
    color: perfil.color || '#3B6FF7',
    caps_adicionar: perfil.caps_adicionar || [],
    caps_remover: perfil.caps_remover || []
  };
  if (isNew){
    sb.from('malba_perfis').insert(payload).select().single().then(function(r){
      if (r.error){
        var m = (r.error.message||'').toLowerCase();
        if (m.indexOf('does not exist')!==-1) toast('Rode o SQL-cadastros-fase5a.sql no Supabase.','error');
        else toast('Não consegui criar: '+(r.error.message||''),'error');
        return;
      }
      ST.perfis = (ST.perfis||[]).concat([r.data]);
      if (cb) cb();
      toast('Perfil criado','success'); renderPage();
    });
  } else {
    sb.from('malba_perfis').update(payload).eq('id', perfil.id).then(function(r){
      if (r.error){ toast('Não consegui salvar: '+(r.error.message||''),'error'); return; }
      var i = (ST.perfis||[]).findIndex(function(x){ return String(x.id)===String(perfil.id); });
      if (i>=0) ST.perfis[i] = Object.assign(ST.perfis[i], payload);
      if (cb) cb();
      toast('Perfil salvo','success'); renderPage();
    });
  }
}

/* ---------- Remover ---------- */
function perfilRemover(id){
  var p = (ST.perfis||[]).find(function(x){ return String(x.id)===String(id); });
  if (!p) return;
  var cnt = (ST.allUsers||[]).filter(function(u){ return String(u.profile_id||'')===String(id); }).length;
  var msg = cnt
    ? 'Este perfil está aplicado a '+cnt+' pessoa'+(cnt===1?'':'s')+'. Ao remover, elas voltam para o nível padrão ('+((NIVEIS[p.base_nivel]||{label:p.base_nivel}).label)+'). Continuar?'
    : 'Remover o perfil "'+p.label+'"?';
  confirmDialog({
    title:'Remover perfil', message:msg, confirmLabel:'Remover',
    onConfirm: function(){
      sb.from('malba_perfis').delete().eq('id', id).then(function(r){
        if (r.error){ toast('Não consegui remover: '+(r.error.message||''),'error'); return; }
        // limpa profile_id de quem estava usando (mesma transação seria ideal via trigger, mas fazemos aqui)
        var afetados = (ST.allUsers||[]).filter(function(u){ return String(u.profile_id||'')===String(id); });
        afetados.forEach(function(u){ u.profile_id = null; });
        ST.perfis = (ST.perfis||[]).filter(function(x){ return String(x.id)!==String(id); });
        toast('Perfil removido','success'); renderPage();
      });
    }
  });
}

/* ============================================================
   v111: CADASTROS — Fase 5b (Dashboard da Estrutura)

   Tela "Organograma" dentro da Central. Mostra:
   - KPIs no topo
   - Árvore Empresa → Departamento → Equipes + Colaboradores
   - Contagens, filtro por departamento, expandir/colapsar
   ============================================================ */

/* ---------- Estado da tela ---------- */
function orgEstadoIni(){
  if (!ST.central.org) ST.central.org = { expandidos: {}, filtroDep: '', q: '' };
  return ST.central.org;
}

/* ---------- Lookups auxiliares ---------- */
function orgPessoasDoDepto(deptoKey){
  return (ST.allUsers||[]).filter(function(u){ return String(u.sector||'')===String(deptoKey); });
}
function orgEquipesDoDepto(deptoKey){
  return (ST.equipes||[]).filter(function(e){ return e.is_active!==false && String(e.sector||'')===String(deptoKey); });
}
function orgEquipesCruzadas(){
  return (ST.equipes||[]).filter(function(e){ return e.is_active!==false && !e.sector; });
}
function orgPessoasSemEquipe(deptoKey){
  var pessoas = orgPessoasDoDepto(deptoKey);
  var idsEmEquipe = new Set();
  (ST.equipes||[]).forEach(function(e){
    // membros que são deste depto
    (e.membros||[]).forEach(function(uid){
      var u = (ST.allUsers||[]).find(function(x){ return String(x.id)===String(uid); });
      if (u && String(u.sector||'')===String(deptoKey)) idsEmEquipe.add(String(u.id));
    });
  });
  return pessoas.filter(function(u){ return !idsEmEquipe.has(String(u.id)); });
}

/* ---------- Tela ---------- */
function centralOrganogramaHTML(){
  orgEstadoIni();
  var org = ST.central.org;
  var deps = (ST.departamentos||[]).slice().sort(function(a,b){ return (a.ordem||0)-(b.ordem||0); });
  // filtro por depto (Gestor cai automaticamente no seu setor)
  if (!isSuper(ST.session) && isAdmin(ST.session)) deps = deps.filter(function(d){ return d.key===ST.sector; });
  else if (org.filtroDep) deps = deps.filter(function(d){ return d.key===org.filtroDep; });

  // KPIs (calculados sobre a lista visível)
  var users = deps.reduce(function(acc,d){ return acc.concat(orgPessoasDoDepto(d.key)); }, []);
  var equipesAtivas = (ST.equipes||[]).filter(function(e){ return e.is_active!==false; });
  var equipesCruzadas = orgEquipesCruzadas().length;
  var comPerfilCustom = users.filter(function(u){ return !!u.profile_id; }).length;
  var lojas = (ST.storeUnits||[]).length;

  function kpi(v, l, cor){
    return '<div class="cad-kpi"><div class="cad-kpi-v" style="color:'+cor+'">'+v+'</div><div class="cad-kpi-l">'+esc(l)+'</div></div>';
  }
  var kpis = '<div class="cad-kpis">'+
    kpi(deps.length, 'Departamentos', '#3B6FF7')+
    kpi(users.length, 'Pessoas com acesso', '#16A34A')+
    kpi(equipesAtivas.length, 'Equipes ativas', '#8B5CF6')+
    kpi(equipesCruzadas, 'Equipes cruzadas', '#EC4899')+
    kpi(comPerfilCustom, 'Com perfil customizado', '#F59E0B')+
    kpi(lojas, 'Lojas', '#0EA5E9')+
  '</div>';

  // Filtro de departamento (só Admin geral)
  var filtroHTML = '';
  if (isSuper(ST.session)){
    var opts = '<option value="">Todos os departamentos</option>' +
      (ST.departamentos||[]).filter(function(d){ return d.is_active!==false; })
        .map(function(d){ return '<option value="'+esc(d.key)+'"'+(org.filtroDep===d.key?' selected':'')+'>'+esc(d.label)+'</option>'; }).join('');
    filtroHTML = '<div class="org-filtro"><select id="orgFiltro">'+opts+'</select>'+
      '<button class="btn btn-secondary" id="orgExpAll">'+icon('plus')+'Expandir tudo</button>'+
      '<button class="btn btn-secondary" id="orgColAll">×Colapsar tudo</button>'+
    '</div>';
  }

  // Árvore
  var arvore = deps.length ? deps.map(function(d){
    var pessoas = orgPessoasDoDepto(d.key);
    var equipes = orgEquipesDoDepto(d.key);
    var semEquipe = orgPessoasSemEquipe(d.key);
    var expandido = org.expandidos[d.key] !== false; // padrão: aberto
    var cor = d.color || '#3B6FF7';

    var equipesHTML = equipes.map(function(e){
      var membros = usuariosDaEquipe(e.id);
      var eqExp = org.expandidos['e:'+e.id] === true; // padrão: fechado
      var avs = membros.slice(0,5).map(function(u){
        return '<span class="cad-eq-mini" style="background:'+esc(u.color||'#64748B')+'" title="'+esc(u.name||'')+'">'+esc(iniciais(u.name||''))+'</span>';
      }).join('');
      var maisN = membros.length>5 ? '<span class="cad-eq-mini extra">+'+(membros.length-5)+'</span>' : '';
      var membrosLista = eqExp ? '<div class="org-membros">'+ membros.map(function(u){
        return '<button class="org-pessoa" data-org-pessoa="'+esc(u.id)+'">'+
          '<span class="cad-eq-av" style="background:'+esc(u.color||'#64748B')+'">'+esc(iniciais(u.name||''))+'</span>'+
          '<span class="org-pessoa-main"><b>'+esc(u.name||'')+'</b><span>'+esc(perfilLabelDe(u))+'</span></span>'+
        '</button>';
      }).join('') +'</div>' : '';
      return '<div class="org-equipe">'+
        '<button class="org-equipe-h" data-org-toggle="e:'+esc(e.id)+'">'+
          '<span class="org-caret">'+(eqExp?'▾':'▸')+'</span>'+
          '<span class="cad-linha-ic" style="background:'+esc(e.color||'#3B6FF7')+'18;color:'+esc(e.color||'#3B6FF7')+'">'+icon('users')+'</span>'+
          '<span class="org-equipe-main"><b>'+esc(e.name)+'</b><span>'+membros.length+' pessoa'+(membros.length===1?'':'s')+'</span></span>'+
          '<span class="cad-eq-avs">'+avs+maisN+'</span>'+
        '</button>'+
        membrosLista+
      '</div>';
    }).join('');

    var semEquipeHTML = semEquipe.length ? '<div class="org-sem-eq">'+
      '<div class="org-sem-eq-h">'+icon('users')+'Sem equipe · '+semEquipe.length+'</div>'+
      '<div class="org-membros">'+ semEquipe.map(function(u){
        return '<button class="org-pessoa" data-org-pessoa="'+esc(u.id)+'">'+
          '<span class="cad-eq-av" style="background:'+esc(u.color||'#64748B')+'">'+esc(iniciais(u.name||''))+'</span>'+
          '<span class="org-pessoa-main"><b>'+esc(u.name||'')+'</b><span>'+esc(perfilLabelDe(u))+'</span></span>'+
        '</button>';
      }).join('') +'</div>'+
    '</div>' : '';

    var corpo = expandido ? (
      '<div class="org-depto-body">'+
        (equipes.length ? '<div class="org-secao"><h5>Equipes ('+equipes.length+')</h5>'+equipesHTML+'</div>' : '')+
        (semEquipeHTML || (equipes.length ? '' : '<div class="cad-vazio" style="margin-top:8px">Nenhuma pessoa neste departamento ainda.</div>'))+
      '</div>'
    ) : '';

    return '<div class="org-depto">'+
      '<button class="org-depto-h" style="border-left-color:'+cor+'" data-org-toggle="'+esc(d.key)+'">'+
        '<span class="org-caret">'+(expandido?'▾':'▸')+'</span>'+
        '<span class="org-depto-ic" style="background:'+cor+'18;color:'+cor+'">'+icon(d.icon||'grid')+'</span>'+
        '<span class="org-depto-main"><b>'+esc(d.label)+'</b><span>'+pessoas.length+' pessoa'+(pessoas.length===1?'':'s')+' · '+equipes.length+' equipe'+(equipes.length===1?'':'s')+'</span></span>'+
      '</button>'+
      corpo+
    '</div>';
  }).join('') : '<div class="cad-vazio">Nenhum departamento visível.</div>';

  // Equipes cruzadas fora da árvore
  var cruzadasSecao = '';
  if (isSuper(ST.session)){
    var cruzadas = orgEquipesCruzadas();
    if (cruzadas.length){
      cruzadasSecao = '<div class="org-cruzadas"><h4>🔗 Equipes cruzadas ('+cruzadas.length+')</h4>'+
        '<p class="cad-explica">Não pertencem a um departamento — aceitam pessoas de qualquer setor.</p>'+
        cruzadas.map(function(e){
          var membros = usuariosDaEquipe(e.id);
          var avs = membros.slice(0,5).map(function(u){
            return '<span class="cad-eq-mini" style="background:'+esc(u.color||'#64748B')+'" title="'+esc(u.name||'')+'">'+esc(iniciais(u.name||''))+'</span>';
          }).join('');
          var maisN = membros.length>5 ? '<span class="cad-eq-mini extra">+'+(membros.length-5)+'</span>' : '';
          return '<button class="cad-linha" data-org-equipe="'+esc(e.id)+'">'+
            '<span class="cad-linha-ic" style="background:'+esc(e.color||'#8B5CF6')+'18;color:'+esc(e.color||'#8B5CF6')+'">'+icon('users')+'</span>'+
            '<span class="cad-linha-main"><b>'+esc(e.name)+'</b>'+
              '<span class="cad-linha-sub">'+membros.length+' pessoa'+(membros.length===1?'':'s')+' · de departamentos diversos</span>'+
            '</span>'+
            '<span class="cad-eq-avs">'+avs+maisN+'</span>'+
          '</button>';
        }).join('')+
      '</div>';
    }
  }

  return '<div class="cad-titulo"><h3>🗺️ Organograma</h3><span class="cad-sub">Como a empresa está organizada agora</span></div>'+
    kpis+
    filtroHTML+
    '<div class="org-arvore">'+arvore+'</div>'+
    cruzadasSecao;
}

function bindCentralOrganograma(){
  // toggle depto/equipe
  document.querySelectorAll('[data-org-toggle]').forEach(function(b){
    b.addEventListener('click', function(){
      var k = this.getAttribute('data-org-toggle');
      var org = ST.central.org;
      if (k.indexOf('e:')===0){
        org.expandidos[k] = !org.expandidos[k];
      } else {
        // deptos: default aberto, então guardar 'false' pra fechar
        org.expandidos[k] = org.expandidos[k] === false ? true : false;
      }
      renderPage();
    });
  });
  // clicar em pessoa: leva pro detalhe do colaborador (se existir vínculo em members) ou ao user modal
  document.querySelectorAll('[data-org-pessoa]').forEach(function(b){
    b.addEventListener('click', function(){
      var uid = this.getAttribute('data-org-pessoa');
      var u = (ST.allUsers||[]).find(function(x){ return String(x.id)===String(uid); });
      if (u) openUserModal(u);
    });
  });
  // clicar em equipe cruzada: abre detalhe da equipe
  document.querySelectorAll('[data-org-equipe]').forEach(function(b){
    b.addEventListener('click', function(){
      ST.central.nav = 'equipe';
      ST.central.equipeId = this.getAttribute('data-org-equipe');
      renderPage();
    });
  });
  // filtro
  var f = document.getElementById('orgFiltro');
  if (f) f.addEventListener('change', function(){
    ST.central.org.filtroDep = this.value;
    renderPage();
  });
  // expandir/colapsar tudo
  var ea = document.getElementById('orgExpAll');
  if (ea) ea.addEventListener('click', function(){
    var org = ST.central.org;
    (ST.departamentos||[]).forEach(function(d){ org.expandidos[d.key] = true; });
    (ST.equipes||[]).forEach(function(e){ org.expandidos['e:'+e.id] = true; });
    renderPage();
  });
  var ca = document.getElementById('orgColAll');
  if (ca) ca.addEventListener('click', function(){
    var org = ST.central.org;
    (ST.departamentos||[]).forEach(function(d){ org.expandidos[d.key] = false; });
    (ST.equipes||[]).forEach(function(e){ org.expandidos['e:'+e.id] = false; });
    renderPage();
  });
}

function crmHTML() {
  var q = crmBusca.toLowerCase();
  var sid = boardStore();
  var all = (ST.clients || []).filter(crmPertenceSetor);
  if (sid) all = all.filter(function(c){ return String(c.store_unit_id)===String(sid); });

  // contagem por segmento
  var counts={ todos:all.length, ativo:0, esfriando:0, inativo:0, novo:0, prospecto:0 };
  all.forEach(function(c){ var s=crmSegment(c); if(counts[s]!==undefined) counts[s]++; });

  // lista filtrada por busca + segmento
  var list = all.filter(function(c){
    if (crmSeg!=='todos' && crmSegment(c)!==crmSeg) return false;
    if (!q) return true;
    return (c.name||'').toLowerCase().indexOf(q)!==-1 ||
           (c.company||'').toLowerCase().indexOf(q)!==-1 ||
           (c.phone||'').toLowerCase().indexOf(q)!==-1 ||
           (c.email||'').toLowerCase().indexOf(q)!==-1;
  });

  // cards de resumo
  var summary = '<div class="crm-summary">'+
    crmStat('Total', counts.todos, '#3B6FF7', 'todos')+
    crmStat('Ativos', counts.ativo, CRM_SEG.ativo.color, 'ativo')+
    crmStat('Esfriando', counts.esfriando, CRM_SEG.esfriando.color, 'esfriando')+
    crmStat('Inativos', counts.inativo, CRM_SEG.inativo.color, 'inativo')+
    crmStat('Prospectos', counts.prospecto, CRM_SEG.prospecto.color, 'prospecto')+
  '</div>';

  // painel "para contatar": esfriando (mais dias = mais urgente) + inativo (recém-perdido converte melhor)
  var esf = all.filter(function(c){ return crmSegment(c)==='esfriando'; })
               .sort(function(a,b){ return (crmDaysSince(b.last_purchase)||0)-(crmDaysSince(a.last_purchase)||0); });
  var ina = all.filter(function(c){ return crmSegment(c)==='inativo'; })
               .sort(function(a,b){ return (crmDaysSince(a.last_purchase)||0)-(crmDaysSince(b.last_purchase)||0); });
  var contatar = esf.concat(ina).slice(0,8);
  var contatarPanel='';
  if (contatar.length) {
    var crows = contatar.map(crmContactRow).join('');
    contatarPanel = '<div class="crm-contact-panel"><div class="crm-cp-head">'+icon('megaphone')+'<b>Para contatar agora</b><span>'+esf.length+' esfriando · '+ina.length+' inativos</span></div>'+crows+'</div>';
  }

  // chips de filtro
  var chips = ['todos','ativo','esfriando','inativo','novo','prospecto'].map(function(s){
    var lb = s==='todos'?'Todos':CRM_SEG[s].label;
    var n = counts[s]!==undefined?counts[s]:0;
    return '<button class="crm-chip'+(crmSeg===s?' on':'')+'" data-seg="'+s+'">'+lb+' <i>'+n+'</i></button>';
  }).join('');

  // lista
  var rows = '';
  if (list.length === 0) {
    var vazioReal = all.length===0;
    rows = emptyState({ icon:'users', title: vazioReal?'Nenhum cliente ainda':'Nada encontrado', text: vazioReal?'Cada cliente guarda histórico de compra e recompra pra você acompanhar.':'Nenhum cliente nesse filtro ou busca.', cta:(vazioReal && canEdit())?'Novo cliente':'' });
  } else {
    rows = '<div class="crm-list">';
    list.forEach(function(c){ rows += crmRowHTML(c); });
    rows += '</div>';
  }

  var importBtn = isAdmin(ST.session) ? '<button class="btn-sync" id="btnImportBling">'+icon('trend')+'Importar do Bling</button>' : '';
  var foco = sid ? esc(storeName(sid)) : (deptoComoModelo('lojas') ? 'Todas as lojas' : esc((SECTORS[ST.sector]||{label:ST.sector}).label)); // v113
  var crmStoreFilter = '';
  if (isAdmin(ST.session) && ST.sector==='lojas' && !ST.store && (ST.storeUnits||[]).length>0) {
    var so='<option value="">Todas as lojas</option>'+ST.storeUnits.map(function(s){return '<option value="'+esc(s.id)+'"'+(String(ST.taskStore)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';}).join('');
    crmStoreFilter='<select class="task-filter" id="crmStore" title="Ver loja">'+so+'</select>';
  }
  return ''+
    '<div class="tasks-head"><div><h2>CRM</h2><div class="sub">'+all.length+' cliente(s) · '+foco+'</div></div><div class="cfg-head-btns">'+crmStoreFilter+importBtn+(canEdit()?'<button class="btn-new" id="btnNovoCliente">'+icon('plus')+'Novo cliente</button>':'')+'</div></div>'+
    summary+
    contatarPanel+
    '<div class="crm-chips">'+chips+'</div>'+
    '<div class="crm-search">'+icon('search')+'<input id="crmSearch" placeholder="Buscar por nome, empresa, telefone ou e-mail..." value="'+esc(crmBusca)+'"></div>'+
    rows;
}
function crmStat(label, n, color, seg){
  return '<button class="crm-stat'+(crmSeg===seg?' on':'')+'" data-seg="'+seg+'"><span class="crm-stat-dot" style="background:'+color+'"></span><span class="crm-stat-n">'+n+'</span><span class="crm-stat-l">'+esc(label)+'</span></button>';
}
function crmWhatsLink(c){
  var ph=(c.phone||'').replace(/\D/g,'');
  if (!ph) return null;
  if (ph.length<=11) ph='55'+ph; // assume Brasil se faltar DDI
  var msg=encodeURIComponent('Olá '+(c.name||'').split(' ')[0]+'! Tudo bem? Aqui é da MALBA Embalagens.');
  return 'https://wa.me/'+ph+'?text='+msg;
}
function crmContactRow(c){
  var seg=crmSegment(c); var sg=CRM_SEG[seg];
  var wa=crmWhatsLink(c);
  var waBtn = wa ? '<a class="crm-mini wa" href="'+wa+'" target="_blank" rel="noopener" data-stop="1">'+icon('chat')+'WhatsApp</a>' : '';
  var hist = (c.total_spent>0||c.orders_count>0) ? (' · '+brlShort(c.total_spent||0)+(c.orders_count?' em '+c.orders_count+' compra(s)':'')) : '';
  return '<div class="crm-cp-row">'+
    '<span class="crm-cp-dot" style="background:'+sg.dot+'"></span>'+
    '<div class="crm-cp-main"><b>'+esc(c.name)+'</b><i>'+esc(crmRecencia(c))+hist+(c.company?' · '+esc(c.company):'')+'</i></div>'+
    '<span class="crm-cp-seg" style="color:'+sg.color+';background:'+sg.color+'18">'+sg.label+'</span>'+
    waBtn+
    (canEdit()?'<button class="crm-mini buy" data-buy="'+esc(c.id)+'" data-stop="1">'+icon('dollar')+'Comprou</button>':'')+
  '</div>';
}
function crmRowHTML(c) {
  var seg=crmSegment(c); var sg=CRM_SEG[seg];
  var ini = iniciais(c.name);
  var sub = [c.company, c.phone].filter(Boolean).join(' · ');
  return '<div class="crm-row" data-id="'+esc(c.id)+'">'+
    '<span class="crm-av">'+esc(ini)+'</span>'+
    '<div class="crm-main"><b>'+esc(c.name)+'</b><i>'+esc(crmRecencia(c))+(sub?' · '+esc(sub):'')+'</i></div>'+
    '<span class="crm-status" style="color:'+sg.color+';background:'+sg.color+'18">'+sg.label+'</span>'+
  '</div>';
}

function bindCRM() {
  var novo = document.getElementById('btnNovoCliente');
  if (novo) novo.addEventListener('click', function(){ openClientModal(null); });
  var crmStore = document.getElementById('crmStore');
  if (crmStore) crmStore.addEventListener('change', function(){ ST.taskStore=this.value; renderPage(); });
  var imp = document.getElementById('btnImportBling');
  if (imp) imp.addEventListener('click', function(){
    var old=imp.innerHTML; imp.disabled=true; imp.textContent='Importando...';
    toast('Buscando clientes e compras no Bling... pode levar 1-2 min','success');
    fetch(SUPABASE_URL+'/functions/v1/bling-clientes', {
      method:'POST', headers:{ 'Authorization':'Bearer '+SUPABASE_ANON_KEY, 'apikey':SUPABASE_ANON_KEY, 'Content-Type':'application/json' }, body:'{}'
    }).then(function(res){ return res.json().catch(function(){ return { httpStatus:res.status }; }); }).then(function(d){
      imp.disabled=false; imp.innerHTML=old;
      console.log('[bling-clientes]', d);
      if (!d || d.ok!==true) { toast('Importação: '+((d&&(d.message||d.error))||('falha HTTP '+(d&&d.httpStatus||''))),'error'); return; }
      var tot=(d.results||[]).reduce(function(s,x){ return s+(x.clientes||0); },0);
      var erros=(d.results||[]).filter(function(x){ return x.erro; });
      if (erros.length) toast('Importou '+tot+' cliente(s), mas '+erros.length+' loja(s) com aviso (veja o console)','error');
      else toast('Importados/atualizados '+tot+' cliente(s) do Bling!','success');
      loadData().then(function(){ renderPage(); });
    }).catch(function(e){ imp.disabled=false; imp.innerHTML=old; console.error(e); toast('Erro ao importar: '+e.message,'error'); });
  });
  var search = document.getElementById('crmSearch');
  if (search) {
    search.addEventListener('input', function(){
      crmBusca = this.value;
      var pos = this.selectionStart;
      renderPage();
      var s2 = document.getElementById('crmSearch');
      if (s2) { s2.focus(); try { s2.setSelectionRange(pos,pos); } catch(e){} }
    });
  }
  // filtros por segmento (cards de resumo + chips)
  var segBtns = app.querySelectorAll('[data-seg]');
  for (var s=0;s<segBtns.length;s++) segBtns[s].addEventListener('click', function(){ crmSeg=this.getAttribute('data-seg'); renderPage(); });
  // botão "Comprou" (registrar compra hoje) no painel de contato
  var buyBtns = app.querySelectorAll('[data-buy]');
  for (var b=0;b<buyBtns.length;b++) buyBtns[b].addEventListener('click', function(e){ e.stopPropagation(); crmRegistrarCompra(this.getAttribute('data-buy')); });
  // links de WhatsApp não devem abrir o cliente
  var stops = app.querySelectorAll('[data-stop]');
  for (var z=0;z<stops.length;z++) stops[z].addEventListener('click', function(e){ e.stopPropagation(); });
  // abrir cliente
  var rows = app.querySelectorAll('.crm-row');
  for (var i=0;i<rows.length;i++) {
    rows[i].addEventListener('click', function(){
      var id=this.getAttribute('data-id'); var c=null;
      for (var k=0;k<ST.clients.length;k++) if (String(ST.clients[k].id)===String(id)) { c=ST.clients[k]; break; }
      if (c) openClienteFicha(c);
    });
  }
}
function crmRegistrarCompra(id){
  if(!canEdit()){ blockManage(); return; }
  var c=null; for (var k=0;k<ST.clients.length;k++) if (String(ST.clients[k].id)===String(id)) { c=ST.clients[k]; break; }
  if (!c) return;
  var rec={ last_purchase:today(), last_contact:today(), updated_at:new Date().toISOString() };
  sb.from('malba_crm_clients').update(rec).eq('id', c.id).then(function(r){
    if (r.error) { toast('Erro ao registrar compra','error'); console.error(r.error); return; }
    Object.assign(c, rec); toast('Compra registrada — '+c.name+' voltou a Ativo','success'); renderPage();
  });
}

function openClienteFicha(client){
  var c=client; if(!c) return;
  var modal=document.createElement('div'); modal.className='modal-bg';
  function refresh(){ for(var i=0;i<ST.clients.length;i++) if(String(ST.clients[i].id)===String(c.id)){ c=ST.clients[i]; break; } }
  function fichaHTML(){
    refresh();
    var seg=crmSegment(c); var sg=CRM_SEG[seg]; var ini=iniciais(c.name); var wa=crmWhatsLink(c);
    var phone=(c.phone||'').replace(/\s/g,'');
    var total=Number(c.total_spent)||0; var orders=Number(c.orders_count)||0; var ticket=orders>0?(total/orders):0;
    var actions='<div class="clf-actions">'+
      (wa?'<a class="clf-act wa" href="'+wa+'" target="_blank" rel="noopener">'+icon('chat')+'WhatsApp</a>':'')+
      (phone?'<a class="clf-act call" href="tel:'+esc(phone)+'">'+icon('bell')+'Ligar</a>':'')+
      (canEdit()?'<button class="clf-act buy" id="clfBuy">'+icon('dollar')+'Comprou hoje</button>':'')+
    '</div>';
    var resumo='<div class="clf-kpis">'+
      '<div class="clf-kpi"><span class="clf-kpi-v">'+brlShort(total)+'</span><span class="clf-kpi-l">Total gasto</span></div>'+
      '<div class="clf-kpi"><span class="clf-kpi-v">'+orders+'</span><span class="clf-kpi-l">Compras</span></div>'+
      '<div class="clf-kpi"><span class="clf-kpi-v">'+brlShort(ticket)+'</span><span class="clf-kpi-l">Ticket médio</span></div>'+
    '</div>';
    var infoRows='<div class="clf-info">'+
      '<div class="clf-ir"><span>Última compra</span><b>'+(c.last_purchase?(fmtDate(c.last_purchase)+' · '+esc(crmRecencia(c))):'—')+'</b></div>'+
      (c.email?('<div class="clf-ir"><span>E-mail</span><b>'+esc(c.email)+'</b></div>'):'')+
      (c.phone?('<div class="clf-ir"><span>Telefone</span><b>'+esc(c.phone)+'</b></div>'):'')+
      (c.store_unit_id?('<div class="clf-ir"><span>Loja</span><b>'+esc(storeName(c.store_unit_id))+'</b></div>'):'')+
      '<div class="clf-ir"><span>Ciclo de recompra</span><b>'+crmCycle(c)+' dias</b></div>'+
    '</div>';
    var notas = c.notes ? ('<div class="clf-notes"><h5>Observações</h5><p>'+esc(c.notes)+'</p></div>') : '';
    return '<div class="modal clf-modal">'+
      '<div class="clf-head"><span class="clf-av">'+esc(ini)+'</span><div class="clf-id"><b>'+esc(c.name)+'</b><i>'+(c.company?esc(c.company)+' · ':'')+esc(crmRecencia(c))+'</i></div><span class="crm-status" style="color:'+sg.color+';background:'+sg.color+'18">'+sg.label+'</span></div>'+
      actions + resumo + infoRows + notas +
      '<div class="modal-foot">'+(canEdit()?'<button class="btn btn-danger btn-del-wrap" id="clfDel">Excluir</button>':'')+'<button class="btn btn-ghost" id="clfClose">Fechar</button>'+(canEdit()?'<button class="btn btn-primary" id="clfEdit">Editar dados</button>':'')+'</div>'+
    '</div>';
  }
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  function draw(){ modal.innerHTML=fichaHTML(); bind(); }
  function bind(){
    modal.querySelector('#clfClose').addEventListener('click', close);
    var ed=modal.querySelector('#clfEdit'); if(ed) ed.addEventListener('click', function(){ close(); openClientModal(c); });
    var bt=modal.querySelector('#clfBuy'); if(bt) bt.addEventListener('click', function(){ crmRegistrarCompra(c.id); setTimeout(draw,80); });
    var dl=modal.querySelector('#clfDel'); if(dl) dl.addEventListener('click', function(){ confirmDelete('Excluir o cliente "'+c.name+'"?', function(){ sb.from('malba_crm_clients').delete().eq('id',c.id).then(function(r){ if(r.error){ toast('Erro ao excluir','error'); return; } ST.clients=ST.clients.filter(function(x){return String(x.id)!==String(c.id);}); close(); toast('Cliente excluído','success'); renderPage(); }); }); });
  }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal);
  draw();
}
function openClientModal(client) {
  if(!canEdit()){ blockManage(); return; }
  var isNew = !client;
  var c = client || { name:'', company:'', phone:'', email:'', notes:'', status:'ativo', last_purchase:'', purchase_cycle_days:'' };

  var tipoVal = (c.status==='prospecto') ? 'prospecto' : 'ativo';
  var stOpts = '<option value="ativo"'+(tipoVal==='ativo'?' selected':'')+'>Cliente</option>'+
               '<option value="prospecto"'+(tipoVal==='prospecto'?' selected':'')+'>Prospecto</option>';
  var superAdm = isSuper(ST.session) && ST.sector==='lojas';
  var curStore = (c.store_unit_id || scopeStore() || '');
  var lojaRow = superAdm ? ('<div class="modal-row"><label class="modal-label">Loja</label><select id="cStore"><option value="">— sem loja específica</option>'+(ST.storeUnits||[]).map(function(s){ return '<option value="'+esc(s.id)+'"'+(String(curStore)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>'; }).join('')+'</select></div>') : '';

  var delBtn = isNew ? '' : '<button class="btn btn-danger btn-del-wrap" id="cliDel">Excluir</button>';
  var taskBtn = isNew ? '' : '<button class="btn btn-ghost" id="cliTask">+ Tarefa</button>';

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<input class="modal-title-input" id="cName" placeholder="Nome do cliente..." value="'+esc(c.name)+'">'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Empresa</label><input type="text" id="cCompany" value="'+esc(c.company||'')+'"></div><div class="modal-row"><label class="modal-label">Telefone</label><input type="text" id="cPhone" value="'+esc(c.phone||'')+'"></div></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">E-mail</label><input type="text" id="cEmail" value="'+esc(c.email||'')+'"></div><div class="modal-row"><label class="modal-label">Tipo</label><select id="cStatus">'+stOpts+'</select></div></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Última compra</label><input type="date" id="cLastBuy" value="'+esc((c.last_purchase||'').slice(0,10))+'"></div><div class="modal-row"><label class="modal-label">Ciclo de recompra (dias)</label><input type="number" id="cCycle" min="1" placeholder="30" value="'+esc(c.purchase_cycle_days||'')+'"></div></div>'+
      lojaRow+
      '<div class="crm-seg-hint" id="cSegHint"></div>'+
      '<div class="modal-row"><label class="modal-label">Observações</label><textarea id="cNotes" placeholder="Anotações sobre o cliente...">'+esc(c.notes||'')+'</textarea></div>'+
      '<div class="modal-foot">'+delBtn+taskBtn+'<button class="btn btn-ghost" id="cliCancel">Cancelar</button><button class="btn btn-primary" id="cliSave">'+(isNew?'Criar':'Salvar')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#cliCancel').addEventListener('click', close);
  modal.querySelector('#cName').focus();

  function updSegHint(){
    var tipo=modal.querySelector('#cStatus').value;
    var lb=modal.querySelector('#cLastBuy').value;
    var cy=parseInt(modal.querySelector('#cCycle').value,10)||30;
    var seg=crmSegment({ status:tipo, last_purchase:lb||null, purchase_cycle_days:cy });
    var sg=CRM_SEG[seg];
    var extra=(seg==='esfriando')?' — boa hora de entrar em contato':((seg==='inativo')?' — candidato a reativação (win-back)':'');
    var info = lb ? (esc(crmRecencia({last_purchase:lb}))+extra) : ('defina a última compra para classificar automaticamente'+(tipo==='prospecto'?' (ou mantenha como Prospecto)':''));
    modal.querySelector('#cSegHint').innerHTML='<span class="crm-seg-badge" style="color:'+sg.color+';background:'+sg.color+'18">'+sg.label+'</span><span class="crm-seg-x">'+info+'</span>';
  }
  updSegHint();
  ['#cStatus','#cLastBuy','#cCycle'].forEach(function(sel){ var el=modal.querySelector(sel); if(el){ el.addEventListener('input', updSegHint); el.addEventListener('change', updSegHint); } });

  modal.querySelector('#cliSave').addEventListener('click', function(){
    var name=(modal.querySelector('#cName').value||'').trim();
    if (!name) { toast('Informe o nome','error'); return; }
    var cycleVal = parseInt(modal.querySelector('#cCycle').value,10);
    var storeEl = modal.querySelector('#cStore');
    var lojaId = storeEl ? (storeEl.value||null) : (ST.store ? ST.store.id : (scopeStore()||null));
    var rec = {
      name:name,
      company:(modal.querySelector('#cCompany').value||'').trim(),
      phone:(modal.querySelector('#cPhone').value||'').trim(),
      email:(modal.querySelector('#cEmail').value||'').trim(),
      status:modal.querySelector('#cStatus').value,
      notes:(modal.querySelector('#cNotes').value||'').trim(),
      last_purchase:(modal.querySelector('#cLastBuy').value||null),
      purchase_cycle_days:(cycleVal>0?cycleVal:30),
      sector:ST.sector, store_unit_id:lojaId,
      last_contact:today(), updated_at:new Date().toISOString()
    };
    var saveBtn=modal.querySelector('#cliSave'); setBusy(saveBtn,true);
    if (isNew) {
      sb.from('malba_crm_clients').insert(rec).select().single().then(function(r){
        if (r.error || !r.data) { toast('Erro ao salvar cliente','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Criar'; return; }
        ST.clients.unshift(r.data); auditLog('Criou cliente', name); close(); toast('Cliente criado','success'); renderPage();
      });
    } else {
      sb.from('malba_crm_clients').update(rec).eq('id', c.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar'; return; }
        for (var i=0;i<ST.clients.length;i++) if (ST.clients[i].id===c.id) { ST.clients[i]=Object.assign(ST.clients[i],rec); break; }
        close(); toast('Cliente atualizado','success'); renderPage();
      });
    }
  });

  if (!isNew) {
    // criar tarefa a partir do cliente (conecta com a espinha dorsal: tarefas)
    modal.querySelector('#cliTask').addEventListener('click', function(){
      close();
      var titulo = 'Contatar ' + c.name + (c.company ? ' ('+c.company+')' : '');
      openTaskModal({ title:titulo, description:'', priority:'media', status:'todo', due_date:today(), area:'CRM', assignee_id:'' });
    });
    modal.querySelector('#cliDel').addEventListener('click', function(){
      confirmDelete('Excluir o cliente "'+(c.name||'')+'"?', function(){ sb.from('malba_crm_clients').delete().eq('id', c.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.clients = ST.clients.filter(function(x){ return x.id!==c.id; });
        close(); toast('Cliente excluído','success'); renderPage();
      }); });
    });
  }
}

/* ========== [10] TAREFAS ========== */
function tarefasHTML() {
  var view = ST.taskView || 'kanban';
  var admin = isAdmin(ST.session);
  var sub = admin
    ? ((deptoComoModelo('lojas') && ST.store) ? ('Operação de '+esc(ST.store.name||('Loja '+ST.store.store_number))) : ('Setor '+esc((SECTORS[ST.sector]||{label:ST.sector}).label))) // v106b
    : 'Minhas tarefas';
  var rotinaBtn = deptoTemRotinas(ST.sector) ? '<button class="vt-btn'+(view==='rotina'?' on':'')+'" data-view="rotina">'+icon('clock')+'Rotina do dia</button>' : ''; // v105
  // v88: Calendário e Projetos viram VISÕES daqui — deixam de ser páginas do menu.
  // A permissão continua valendo: quem não tinha acesso à página não ganha a visão.
  var podeCal = pageAllowed('calendario', ST.session);
  var podeProj = pageAllowed('projetos', ST.session);
  if (view==='calendario' && !podeCal) view='kanban';
  if (view==='projetos' && !podeProj) view='kanban';
  var toggle = '<div class="view-toggle">'+rotinaBtn+
    '<button class="vt-btn'+(view==='kanban'?' on':'')+'" data-view="kanban">'+icon('dashboard')+'Quadro</button>'+
    '<button class="vt-btn'+(view==='matriz'?' on':'')+'" data-view="matriz">'+icon('target')+'Prioridades</button>'+
    (podeCal ? '<button class="vt-btn'+(view==='calendario'?' on':'')+'" data-view="calendario">'+icon('cal')+'Calendário</button>' : '')+
    (podeProj ? '<button class="vt-btn'+(view==='projetos'?' on':'')+'" data-view="projetos">'+icon('folder')+'Projetos</button>' : '')+
  '</div>';
  var filter = '';
  if (admin) {
    var meId = String(ST.session.user.id);
    var mineSel = (String(ST.taskAssignee)===meId) ? ' selected' : '';
    var others = ST.users.filter(function(u){ return String(u.id)!==meId; }).map(function(u){
      return '<option value="'+esc(u.id)+'"'+(String(ST.taskAssignee)===String(u.id)?' selected':'')+'>'+esc(u.name)+'</option>';
    }).join('');
    var opts = '<option value="'+esc(meId)+'"'+mineSel+'>Minhas tarefas</option><option value="">Todos da equipe</option>' + others;
    filter = '<select class="task-filter" id="taskAssignee" title="Ver tarefas de">'+opts+'</select>';
  }
  var storeFilter = '';
  if (admin && ST.sector==='lojas' && !ST.store && (ST.storeUnits||[]).length>0) {
    var sopts = '<option value="">Todas as lojas</option>' + ST.storeUnits.map(function(s){
      return '<option value="'+esc(s.id)+'"'+(String(ST.taskStore)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';
    }).join('');
    storeFilter = '<select class="task-filter" id="taskStore" title="Ver loja">'+sopts+'</select>';
  }
  var nova = admin ? '<button class="btn-new" id="btnNovaTarefa">'+icon('plus')+'Nova tarefa</button>' : '';
  if (view==='calendario' || view==='projetos') {
    // os filtros de tarefa não valem aqui; só a barra de visões, e a tela hospedada traz o próprio título
    return '<div class="view-bar">'+toggle+'</div>' + (view==='calendario' ? calendarioHTML() : projetosHTML());
  }
  var head = '<div class="tasks-head"><div><h2>Trabalho</h2><div class="sub">'+sub+'</div></div><div class="tasks-head-r">'+storeFilter+filter+toggle+nova+'</div></div>';
  return head + muralHTML() + (view==='kanban' ? rotinaHojeCardHTML() : '') + (view==='rotina' ? rotinaHTML() : (view==='matriz' ? matrizHTML() : kanbanHTML()));
}
// Junta TAREFAS + MARCOS de projeto + TAREFAS de campanha num só quadro
function taskSeriesKey(t){ if(t.recur_group) return 'g:'+t.recur_group; if((t.recurrence||'none')!=='none') return 'a:'+((t.title||'').toLowerCase().trim())+'|'+t.recurrence; return ''; }
// recorrentes aparecem só na ocorrência de HOJE (nas visões de gestão: quadro e prioridades)
function filtrarRecorrentesHoje(tks){
  tks = tks.filter(function(t){ return !t.is_rule; }); // v70: a regra nunca aparece como tarefa
  var hoje=today(); var cnt={};
  tks.forEach(function(t){ var k=taskSeriesKey(t); if(k) cnt[k]=(cnt[k]||0)+1; });
  return tks.filter(function(t){
    var k=taskSeriesKey(t); var isSer=k&&(k.charAt(0)==='g'||cnt[k]>=2);
    if(!isSer) return true;
    var due=(t.due_date||'').slice(0,10);
    if(due>hoje) return false;                          // v71: futura da série some do quadro (segue no calendário)
    if(due<hoje && t.status==='feito') return false;    // v71: passada já feita não precisa aparecer
    return true;                                        // hoje, ou ATRASADA não-feita: aparece
  });
}
function boardItems() {
  var admin = isAdmin(ST.session);
  var me = String(ST.session.user.id);
  var sid = boardStore();
  var items = [];
  // "who" = filtro de pessoa. Não-admin: só as minhas. Admin: a pessoa escolhida (ou null = toda a equipe).
  var who = admin ? (ST.taskAssignee?String(ST.taskAssignee):null) : me;
  // projetos do SETOR atual (ST.projects já vem filtrado por setor no loadData)
  var projIds = {}; (ST.projects||[]).forEach(function(p){ projIds[String(p.id)]=1; });
  // 1) Tarefas normais — RECORRENTES aparecem só na ocorrência de HOJE (para não lotar o quadro)
  filtrarRecorrentesHoje(visibleTasks({ assignee: admin?(ST.taskAssignee||''):undefined })).forEach(function(t){
    var src = t.project_id ? { type:'Projeto', name:projName(t.project_id), pid:t.project_id } : null;
    items.push({ kind:'task', id:t.id, title:t.title, status:t.status||'todo', due:(t.due_date||'').slice(0,10), assignee_id:t.assignee_id, priority:t.priority, rec:t.recurrence, area:t.area, source:src, sub:subProgress(t.subtasks), draggable:true });
  });
  // 2) Marcos de projeto — APENAS de projetos deste setor + respeita responsável
  (ST.milestones||[]).forEach(function(m){
    if (!projIds[String(m.project_id)]) return;                 // só marcos de projetos DESTE setor
    if (sid && String(projStore(m.project_id))!==String(sid)) return;
    if (who && String(m.assignee_id||'')!==who) return;         // filtro de pessoa (exclui sem responsável)
    items.push({ kind:'milestone', id:m.id, title:m.name, status:m.status||'todo', due:(m.date||'').slice(0,10), assignee_id:m.assignee_id, priority:'media', source:{type:'Projeto', name:projName(m.project_id), pid:m.project_id}, draggable:true });
  });
  // 3) Tarefas de campanha — campanhas existem só no Marketing, então só aparecem no quadro do Marketing
  if (ST.sector==='marketing') {
    (ST.campaigns||[]).forEach(function(c){
      if (sid && c.store_unit_id && String(c.store_unit_id)!==String(sid)) return;
      (c.tasks||[]).forEach(function(tk){
        var aid = tk.assignee_id?String(tk.assignee_id):null;
        if (who && aid!==who) return;                           // filtro de pessoa (exclui sem responsável)
        items.push({ kind:'camptask', id:String(c.id)+'__'+String(tk.id), title:tk.title, status:(tk.done?'feito':'todo'), due:(tk.due||c.end_date||'').slice(0,10), assignee_id:aid, priority:tk.priority||'media', source:{type:'Campanha', name:c.name, cid:c.id}, draggable:true });
      });
  });
  }
  return items;
}
function kanbanHTML() {
  var items = boardItems(); var cols=''; var hoje=today();
  STATUS_ORDER.forEach(function(key){
    var st=STATUS[key];
    var inCol=items.filter(function(it){ return (it.status||'todo')===key; });
    var body, count;
    if (key==='todo') {
      // QUADRO = foco do agora: só atrasadas + hoje (sem data também aparece)
      var focus=inCol.filter(function(it){ return !it.due || it.due<=hoje; });
      count=focus.length;
      var qa='<div class="quick-add"><input type="text" id="qaInput" placeholder="+ Tarefa rápida para hoje (Enter)" maxlength="140" autocomplete="off"></div>';
      body = qa + groupedTodoFocus(focus); // v73: Atrasadas -> Rotina de Hoje -> Demais
    } else if (key==='feito') {
      // só o que foi concluído para hoje (não acumula histórico antigo)
      var doneHoje=inCol.filter(function(it){ return it.due===hoje; });
      doneHoje.sort(function(a,b){ return (b.due||'').localeCompare(a.due||''); });
      count=doneHoje.length;
      body = doneHoje.length ? doneHoje.map(taskCardHTML).join('') : '<div class="col-empty">Nada concluído hoje ainda.</div>';
    } else {
      inCol.sort(function(a,b){ return (a.due||'9999').localeCompare(b.due||'9999'); });
      count=inCol.length;
      body = inCol.length ? inCol.map(taskCardHTML).join('') : '<div class="col-empty">Nenhuma tarefa</div>';
    }
    cols += '<div class="col" data-status="'+key+'"><div class="col-head"><span class="col-dot" style="background:'+st.color+'"></span><span class="col-title">'+st.label+'</span><span class="col-count">'+count+'</span></div><div class="col-body">'+body+'</div></div>';
  });
  return '<div class="board-hint">O quadro mostra o que precisa de atenção: <b>atrasadas</b> e de <b>hoje</b>. Para planejar e arrastar tarefas por data, use o <b>Calendário</b>.</div><div class="board">'+cols+'</div>';
}
// Agrupa por data: Atrasadas / Hoje / Amanhã / Esta semana / Mais pra frente / Sem data
// v73: agrupa a coluna "A Fazer" em Atrasadas -> Rotina de Hoje -> Demais (só divisores; cards intactos)
function groupedTodoFocus(items){
  var hoje=today();
  var atras=[], rot=[], demais=[];
  items.forEach(function(it){
    var d=it.due;
    if(d && d<hoje){ atras.push(it); return; }
    if(it.kind==='task' && it.rec && it.rec!=='none' && d===hoje){ rot.push(it); return; }
    demais.push(it);
  });
  var pr={alta:0,media:1,baixa:2};
  atras.sort(function(a,b){ return (a.due||'').localeCompare(b.due||''); });
  rot.sort(function(a,b){ return (pr[a.priority]||1)-(pr[b.priority]||1); });
  demais.sort(function(a,b){ return (a.due||'9999').localeCompare(b.due||'9999'); });
  var html='';
  if(atras.length) html+='<div class="grp grp-late"><span class="grp-l">🔴 Atrasadas</span><span class="grp-n">'+atras.length+'</span></div>'+atras.map(taskCardHTML).join('');
  if(rot.length)   html+='<div class="grp grp-rot" id="rotinaHojeAnchor"><span class="grp-l">🔵 Rotina de Hoje</span><span class="grp-n">'+rot.length+'</span></div>'+rot.map(taskCardHTML).join('');
  if(demais.length)html+='<div class="grp"><span class="grp-l">⚪ Demais</span><span class="grp-n">'+demais.length+'</span></div>'+demais.map(taskCardHTML).join('');
  return html || '<div class="col-empty">Nada atrasado ou para hoje. Planeje no Calendário.</div>';
}
// v73: estatística das recorrentes de HOJE (usa só dados em memória; não consulta o Supabase)
function estMinTarefa(t){ var v=[t.est_min,t.estimate_min,t.tempo_min,t.duracao_min]; for(var i=0;i<v.length;i++){ var n=Number(v[i]); if(!isNaN(n)&&n>0) return n; } return 0; }
function fmtDur(min){ min=Math.round(min); var h=Math.floor(min/60), m=min%60; if(h&&m) return h+'h '+m+'min'; if(h) return h+'h'; return m+'min'; }
function rotinaHojeStats(){
  var admin=isAdmin(ST.session);
  var list=visibleTasks({ assignee: admin?(ST.taskAssignee||''):undefined });
  var hoje=today();
  var rec=list.filter(function(t){ return isRecurring(t) && (t.due_date||'').slice(0,10)===hoje; });
  var total=rec.length, done=0, pendMin=0, hasEst=false;
  rec.forEach(function(t){ if(t.status==='feito') done++; else { var e=estMinTarefa(t); if(e>0){ hasEst=true; pendMin+=e; } } });
  return { total:total, done:done, pend:total-done, pct: total?Math.round(done/total*100):0, pendMin:pendMin, hasEst:hasEst };
}
function rotinaHojeCardHTML(){
  var s=rotinaHojeStats();
  if(s.total===0) return ''; // sem rotina hoje: não polui a tela
  var pct=s.pct, cor = pct>=100 ? 'var(--u-green)' : 'var(--u-accent)';
  var tempo = (s.hasEst && s.pend>0) ? ' · <span class="rh-time">⏱ ~'+fmtDur(s.pendMin)+' restantes</span>' : '';
  var doneMsg = pct>=100 ? '<div class="rh-done">Rotina de hoje concluída 🎉</div>' : '';
  return '<div class="rh-card">'+
    '<div class="rh-top"><div class="rh-title">🌅 Rotina de Hoje</div><button class="rh-btn" id="btnVerRotina">Ver rotina</button></div>'+
    '<div class="rh-stats"><b style="color:'+cor+'">'+s.done+'</b> de <b>'+s.total+'</b> feitas · <b style="color:#F59E0B">'+s.pend+'</b> pendentes · <b>'+pct+'%</b>'+tempo+'</div>'+
    '<div class="rh-bar"><span style="width:'+pct+'%;background:'+cor+'"></span></div>'+
    doneMsg+
  '</div>';
}
function scrollToRotinaHoje(){
  var el=document.getElementById('rotinaHojeAnchor') || document.querySelector('.board');
  if(el) el.scrollIntoView({ behavior:'smooth', block:'start' });
}
// Matriz de Eisenhower (importância = prioridade alta; urgência = vence hoje/atrasada)
function eisenQuadrant(t) {
  var imp = t.priority==='alta';
  var urg = t.due_date && t.due_date.split('T')[0] <= today();
  if (imp && urg) return 'fazer';
  if (imp && !urg) return 'planejar';
  if (!imp && urg) return 'delegar';
  return 'depois';
}
function matrizHTML() {
  var ts=filtrarRecorrentesHoje(visibleTasks()).filter(function(t){ return t.status!=='feito'; });
  var Q={ fazer:[], planejar:[], delegar:[], depois:[] };
  ts.forEach(function(t){ Q[eisenQuadrant(t)].push(t); });
  var meta={
    fazer:    { t:'Fazer agora',     d:'Importante e urgente',       c:'#EF4444' },
    planejar: { t:'Planejar',        d:'Importante, sem pressa',     c:'#3B6FF7' },
    delegar:  { t:'Resolver/Delegar', d:'Urgente, menos importante', c:'#F59E0B' },
    depois:   { t:'Quando der',      d:'Pode esperar',               c:'#9aa1ad' }
  };
  function quad(k){
    var m=meta[k], items=Q[k];
    var body = items.length ? items.map(function(t){
      var late=t.due_date && t.due_date.split('T')[0]<today();
      var pr=PRIO[t.priority]||PRIO.media;
      return '<button class="mz-task" data-id="'+esc(t.id)+'"><span class="mz-dot" style="background:'+pr.color+'"></span><span class="mz-l">'+esc(t.title)+'</span>'+(t.due_date?'<span class="mz-d'+(late?' late':'')+'">'+fmtDate(t.due_date)+'</span>':'')+'</button>';
    }).join('') : '<div class="mz-empty">Nada aqui</div>';
    return '<div class="mz-quad" style="--qc:'+m.c+'"><div class="mz-head"><span class="mz-bar"></span><div class="mz-ht"><b>'+m.t+'</b><i>'+m.d+'</i></div><span class="mz-count">'+items.length+'</span></div><div class="mz-list">'+body+'</div></div>';
  }
  return '<div class="matriz-hint">Prioridade <b>alta</b> = importante · prazo de <b>hoje ou atrasado</b> = urgente. Ajuste a prioridade e a data nas tarefas para reorganizar a matriz.</div><div class="matriz">'+quad('fazer')+quad('planejar')+quad('delegar')+quad('depois')+'</div>';
}
var REC = { none:{label:'Não repete'}, diaria:{label:'Diária'}, semanal:{label:'Semanal'}, mensal:{label:'Mensal'} };
var REC_ORDER = ['none','diaria','semanal','mensal'];
// próxima ocorrência a partir de hoje
function nextDate(rec) {
  var b=new Date();
  if (rec==='diaria') b.setDate(b.getDate()+1);
  else if (rec==='semanal') b.setDate(b.getDate()+7);
  else if (rec==='mensal') b.setMonth(b.getMonth()+1);
  return b.getFullYear()+'-'+pad(b.getMonth()+1)+'-'+pad(b.getDate());
}
function isRecurring(t){ return t.recurrence && t.recurrence!=='none'; }

function taskCardHTML(it) {
  var pr=PRIO[it.priority]||PRIO.media;
  var u=it.assignee_id?userById(it.assignee_id):null;
  var av=u?'<span class="tc-av" style="background:'+(u.color||'#3B6FF7')+'" title="'+esc(u.name)+'">'+esc(iniciais(u.name))+'</span>':'';
  var hoje=today(); var late=it.due && it.due<hoje && it.status!=='feito';
  var lateChip = late ? '<span class="tc-late">⚠ Atrasada</span>' : '';
  var dateChip=it.due?'<span class="tc-date'+(late?' late':'')+'">'+icon('cal')+fmtDate(it.due)+'</span>':'';
  var srcChip = it.source
    ? '<span class="tc-src tc-src-'+(it.source.type==='Projeto'?'proj':'camp')+'">'+esc(it.source.type)+' · '+esc(it.source.name)+'</span>'
    : (it.area?'<span class="tc-chip">'+esc(it.area)+'</span>':'');
  var recBadge = (it.kind==='task' && it.rec && it.rec!=='none') ? '<span class="tc-rec" title="Rotina · repete: '+(REC[it.rec]?REC[it.rec].label:'')+'">↻ Rotina</span>' : '';
  var subChip = it.sub ? '<span class="tc-sub'+(it.sub.done===it.sub.total?' done':'')+'">✓ '+it.sub.done+'/'+it.sub.total+'</span>' : '';
  // v90.1: só quando faz sentido — rotina que ainda não foi concluída hoje
  var quick = (it.kind==='task' && it.rec && it.rec!=='none' && it.status!=='feito') ? '<button class="tc-done" data-done="'+esc(it.id)+'">'+icon('check')+'<span>Concluir hoje</span></button>' : '';
  var drag = it.draggable ? ' draggable="true"' : '';
  return '<div class="task-card" data-kind="'+it.kind+'" data-id="'+esc(it.id)+'"'+drag+'><div class="tc-top"><span class="tc-prio" style="background:'+pr.color+'" title="Prioridade '+pr.label+'"></span><span class="tc-title">'+esc(it.title)+'</span></div><div class="tc-meta">'+lateChip+srcChip+recBadge+subChip+dateChip+av+'</div>'+quick+'</div>';
}
// move um item do quadro entre colunas (status) e persiste
/* v90.2: concluir a rotina de hoje — mantém a de hoje em "Concluída" e cria a próxima
   (mesmo comportamento pro botão "Concluir hoje" e pro arrastar pra "Concluída") */
function concluirRotinaHoje(t){
  if(!t) return;
  var prev=t.status; t.status='feito'; renderPage();
  sb.from('malba_vl_tasks').update({ status:'feito' }).eq('id', t.id).then(function(r){
    if(r.error){ t.status=prev; console.error(r.error); toast('Não consegui concluir: '+(r.error.message||r.error.code||'erro'),'error'); renderPage(); return; }
    // marcou como feita — agora cria a próxima ocorrência como nova tarefa
    if(!isRecurring(t)) { toast('Concluída!','success'); return; }
    var nd = nextDate(t.recurrence);
    var proxima = {
      sector: t.sector, title: t.title, description: t.description||null,
      status: 'todo', priority: t.priority||'media', due_date: nd,
      assignee_id: t.assignee_id||null, store_unit_id: t.store_unit_id||null,
      project_id: t.project_id||null, recurrence: t.recurrence,
      recur_group: t.recur_group||null, is_rule: false, rec_hora: t.rec_hora||null
    };
    sb.from('malba_vl_tasks').insert(proxima).select().single().then(function(r2){
      if(r2.error){ console.error(r2.error); toast('Concluída, mas não consegui criar a próxima: '+(r2.error.message||''),'error'); return; }
      if(r2.data) ST.tasks.push(r2.data);
      toast('Concluída! Próxima em '+fmtDate(nd),'success');
      renderPage();
    });
  });
}
function moveBoardItem(kind, id, ns) {
  if (kind==='task') {
    var t=taskById(id); if (!t || t.status===ns) return;
    // v90.2: arrastar rotina pra "Concluída" faz o mesmo que "Concluir hoje" —
    // cartão fica em Concluída E a próxima ocorrência aparece em "A fazer"
    if (ns==='feito' && isRecurring(t)) { concluirRotinaHoje(t); return; }
    var prev=t.status; t.status=ns; renderPage();
    sb.from('malba_vl_tasks').update({ status:ns }).eq('id', id).then(function(r){
      if(r.error){ t.status=prev; console.error('mover tarefa:', r.error); toast('Não consegui mover: '+(r.error.message||r.error.code||'erro'),'error'); renderPage(); }
    });
  } else if (kind==='milestone') {
    var m=msById(id); if (!m || m.status===ns) return;
    var pms=m.status; m.status=ns; renderPage();
    sb.from('malba_vl_milestones').update({ status:ns }).eq('id', id).then(function(r){
      if(r.error){ m.status=pms; console.error('mover marco:', r.error); toast('Não consegui mover: '+(r.error.message||r.error.code||'erro'),'error'); renderPage(); }
    });
  } else if (kind==='camptask') {
    var parts=String(id).split('__'); var c=campById(parts[0]); if(!c) return;
    var tk=null; (c.tasks||[]).forEach(function(x){ if(String(x.id)===String(parts[1])) tk=x; });
    if(!tk) return;
    var done = (ns==='feito');
    if (tk.done===done) return;
    var pdone=tk.done; tk.done=done; renderPage();
    sb.from('malba_campaigns').update({ tasks:c.tasks }).eq('id', c.id).then(function(r){
      if(r.error){ tk.done=pdone; console.error('mover tarefa de campanha:', r.error); toast('Não consegui mover: '+(r.error.message||r.error.code||'erro'),'error'); renderPage(); }
    });
  }
}
function bindTarefas() {
  var _vw=ST.taskView||'kanban';
  if (_vw==='calendario' || _vw==='projetos') {
    if(_vw==='calendario'){ if(typeof bindCalendario==='function') bindCalendario(); }
    else { if(typeof bindProjetos==='function') bindProjetos(); }
    var _vt2=app.querySelectorAll('.vt-btn');
    for(var _q=0;_q<_vt2.length;_q++) _vt2[_q].addEventListener('click', function(){ ST.taskView=this.getAttribute('data-view'); ST.openProject=null; renderPage(); });
    return;
  }
  if (_vw==='rotina') { bindRotina(); bindMural(); var _af=document.getElementById('taskStore'); if(_af) _af.addEventListener('change', function(){ ST.taskStore=this.value; renderPage(); }); var _vts=app.querySelectorAll('[data-view]'); for(var _v=0;_v<_vts.length;_v++) _vts[_v].addEventListener('click', function(){ ST.taskView=this.getAttribute('data-view'); renderPage(); }); return; }
  var nova=document.getElementById('btnNovaTarefa');
  if (nova) nova.addEventListener('click', function(){ openTaskModal(null); });
  var verRot=document.getElementById('btnVerRotina');
  if (verRot) verRot.addEventListener('click', scrollToRotinaHoje); // v73
  bindMural();
  // captura rápida (quick-add) — cria tarefa de hoje atribuída a mim
  var qa=document.getElementById('qaInput');
  if (qa) qa.addEventListener('keydown', function(e){
    if (e.key!=='Enter') return;
    var title=(this.value||'').trim(); if(!title) return;
    var me=ST.session.user;
    var payload={ title:title, description:'', priority:'media', status:'todo', due_date:today(), recurrence:'none', area:'', assignee_id:me.id, project_id:null, sector:ST.sector, created_by:me.id, store_unit_id:(ST.store?ST.store.id:scopeStore()) };
    this.value=''; this.disabled=true;
    var self=this;
    sb.from('malba_vl_tasks').insert(payload).select().single().then(function(r){
      self.disabled=false;
      if (r.error||!r.data){ toast('Erro ao criar','error'); return; }
      ST.tasks.unshift(r.data); auditLog('Criou tarefa', title); toast('Tarefa adicionada','success'); renderPage();
      setTimeout(function(){ var q=document.getElementById('qaInput'); if(q) q.focus(); },30);
    });
  });
  // filtro de responsável (admin)
  var af=document.getElementById('taskAssignee');
  if (af) af.addEventListener('change', function(){ ST.taskAssignee=this.value; renderPage(); });
  // filtro de loja (admin de setor de Lojas)
  var sf=document.getElementById('taskStore');
  if (sf) sf.addEventListener('change', function(){ ST.taskStore=this.value; renderPage(); });
  // botão "feito hoje" das recorrentes — reagenda para a próxima ocorrência
  var dones=app.querySelectorAll('[data-done]');
  for (var d=0;d<dones.length;d++) {
    dones[d].addEventListener('click', function(e){
      e.stopPropagation();
      var id=this.getAttribute('data-done'); var t=taskById(id);
      if (!t) return;
      concluirRotinaHoje(t); // v90.2: reusa a mesma lógica do arrastar
    });
  }
  // clique nos cards (depende do tipo)
  var admin=isAdmin(ST.session);
  var cards=app.querySelectorAll('.task-card');
  for (var i=0;i<cards.length;i++) {
    cards[i].addEventListener('click', function(){
      if (this.classList.contains('dragging')) return;
      var kind=this.getAttribute('data-kind'), id=this.getAttribute('data-id');
      if (kind==='task') { var t=taskById(id); if(t) openTaskModal(t); }
      else if (kind==='milestone') { var m=msById(id); if(m){ ST.openProject=m.project_id; ST.page='projetos'; navigate(ST.sector+'/projetos'); renderPage(); } }
      else if (kind==='camptask') { var c=campById(String(id).split('__')[0]); if(c){ if(admin) openCampaignModal(c); else toast('Tarefa da campanha "'+(c.name||'')+'"','info'); } }
    });
  }
  // DRAG & DROP entre colunas
  var dragData=null;
  var dgs=app.querySelectorAll('.task-card[draggable="true"]');
  for (var g=0;g<dgs.length;g++) {
    dgs[g].addEventListener('dragstart', function(e){
      dragData={ kind:this.getAttribute('data-kind'), id:this.getAttribute('data-id') };
      this.classList.add('dragging');
      if (e.dataTransfer){ e.dataTransfer.effectAllowed='move'; try{ e.dataTransfer.setData('text/plain', this.getAttribute('data-id')); }catch(_){} }
    });
    dgs[g].addEventListener('dragend', function(){
      this.classList.remove('dragging'); dragData=null;
      var ov=app.querySelectorAll('.col.drag-over'); for(var k=0;k<ov.length;k++) ov[k].classList.remove('drag-over');
    });
  }
  var colsEl=app.querySelectorAll('.col');
  for (var c2=0;c2<colsEl.length;c2++) {
    colsEl[c2].addEventListener('dragover', function(e){ if(!dragData) return; e.preventDefault(); if(e.dataTransfer) e.dataTransfer.dropEffect='move'; this.classList.add('drag-over'); });
    colsEl[c2].addEventListener('dragleave', function(e){ if(e.target===this) this.classList.remove('drag-over'); });
    colsEl[c2].addEventListener('drop', function(e){
      e.preventDefault(); this.classList.remove('drag-over');
      if(!dragData) return;
      var ns=this.getAttribute('data-status');
      moveBoardItem(dragData.kind, dragData.id, ns);
    });
  }
  // alternar Quadro / Prioridades
  var vts=app.querySelectorAll('.vt-btn');
  for (var v=0;v<vts.length;v++) vts[v].addEventListener('click', function(){ ST.taskView=this.getAttribute('data-view'); renderPage(); });
  // clique nas tarefas da matriz
  var mzs=app.querySelectorAll('.mz-task');
  for (var z=0;z<mzs.length;z++) mzs[z].addEventListener('click', function(){
    var id=this.getAttribute('data-id'); var t=taskById(id);
    if (t) openTaskModal(t);
  });
}
function _dParse(s){ var p=String(s||'').split('-'); return new Date(Number(p[0]), Number(p[1])-1, Number(p[2]), 12,0,0); }
function _dFmt(d){ return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); }
function fimDoMesDe(s){ var d=_dParse(s); var last=new Date(d.getFullYear(), d.getMonth()+1, 0).getDate(); return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(last); }
function fimDoAnoDe(s){ var d=_dParse(s); return d.getFullYear()+'-12-31'; }
function gerarDatasRec(startStr, rec, opts){
  opts=opts||{}; var out=[]; if(!startStr) return out;
  var start=_dParse(startStr), end=_dParse(opts.until||startStr); if(end<start) return out;
  var MAX=400, cur=new Date(start);
  if(rec==='diaria'){ while(cur<=end && out.length<MAX){ var wd=cur.getDay(); if(!(opts.diasUteis && (wd===0||wd===6))) out.push(_dFmt(cur)); cur.setDate(cur.getDate()+1); } }
  else if(rec==='semanal'){ var wds=(opts.weekdays&&opts.weekdays.length)?opts.weekdays:[start.getDay()]; while(cur<=end && out.length<MAX){ if(wds.indexOf(cur.getDay())!==-1) out.push(_dFmt(cur)); cur.setDate(cur.getDate()+1); } }
  else if(rec==='mensal'){ var dom=start.getDate(), d=new Date(start); while(d<=end && out.length<MAX){ out.push(_dFmt(d)); var mo=d.getMonth()+1, yr=d.getFullYear(); if(mo>11){mo=0;yr++;} var last=new Date(yr,mo+1,0).getDate(); d=new Date(yr,mo,Math.min(dom,last),12,0,0); } }
  return out;
}
function insertRecorrencia(rows, cb){
  sb.from('malba_vl_tasks').insert(rows).select().then(function(r){
    if(r.error){ var m=(r.error.message||'').toLowerCase();
      if(m.indexOf('recur_group')!==-1 || m.indexOf('column')!==-1 || m.indexOf('schema')!==-1){
        var rows2=rows.map(function(x){ var y=Object.assign({},x); delete y.recur_group; return y; });
        sb.from('malba_vl_tasks').insert(rows2).select().then(function(r2){ if(r2.error){ toast('Erro ao criar tarefas','error'); console.error(r2.error); cb(false); return; } if(r2.data) ST.tasks=r2.data.concat(ST.tasks); cb(true, (r2.data||rows).length); });
        return;
      }
      toast('Erro ao criar tarefas','error'); console.error(r.error); cb(false); return;
    }
    if(r.data) ST.tasks=r.data.concat(ST.tasks); cb(true, (r.data||rows).length);
  });
}
// ===== v70: RECORRÊNCIA POR REGRA (a tarefa recorrente vira uma "regra"; o sistema gera a ocorrência de cada dia sozinho) =====
var REC_HORIZON = 45; // quantos dias à frente o sistema já deixa prontos (cobre o mês atual + o próximo no calendário)
var REC_CATCHUP = 3;  // v71: dias pra trás que o sistema recupera (rotina que ninguém abriu ontem não some — aparece como Atrasada)
function parseWeekdaysStr(s){
  if(Array.isArray(s)) return s.map(Number);
  if(!s) return [];
  try{ var a=JSON.parse(s); return Array.isArray(a)?a.map(Number):[]; }catch(e){ return []; }
}
// datas de uma regra dentro de uma janela [winStart..winEnd] (strings YYYY-MM-DD)
function occDatesForRule(rule, winStart, winEnd){
  var rec=rule.recurrence, anchor=(rule.rec_start||(rule.due_date||'').slice(0,10)||winStart);
  if(rec==='mensal'){
    var dom=_dParse(anchor).getDate(), out=[], d=_dParse(winStart), guard=0;
    d=new Date(d.getFullYear(), d.getMonth(), 1, 12,0,0);
    while(_dFmt(d)<=winEnd && guard<80){
      guard++;
      var last=new Date(d.getFullYear(), d.getMonth()+1, 0).getDate();
      var occ=_dFmt(new Date(d.getFullYear(), d.getMonth(), Math.min(dom,last), 12,0,0));
      if(occ>=winStart && occ<=winEnd && occ>=anchor) out.push(occ);
      d=new Date(d.getFullYear(), d.getMonth()+1, 1, 12,0,0);
    }
    return out;
  }
  return gerarDatasRec(winStart, rec, { until:winEnd, diasUteis:!!rule.rec_dias_uteis, weekdays:parseWeekdaysStr(rule.rec_weekdays) })
         .filter(function(s){ return s>=anchor; });
}
// gera as ocorrências que faltam de HOJE até HOJE+REC_HORIZON para todas as regras ativas
function materializarRecorrencias(){
  if(!sb) return Promise.resolve(false);
  var rules=(ST.tasks||[]).filter(function(t){ return t.is_rule; });
  if(!rules.length) return Promise.resolve(false);
  var hoje=today(), winEnd=addDays(hoje, REC_HORIZON), winStartBase=addDays(hoje, -REC_CATCHUP); // v71: começa alguns dias atrás
  var existing={};
  (ST.tasks||[]).forEach(function(t){ if(!t.is_rule && t.recur_group){ existing[t.recur_group+'|'+(t.due_date||'').slice(0,10)]=1; } });
  var novos=[];
  rules.forEach(function(rule){
    if(!rule.recur_group) return;
    if(rule.rec_paused) return; // v72: rotina pausada não gera novos dias
    var winStart=winStartBase;
    if(rule.rec_start && rule.rec_start>winStart) winStart=rule.rec_start; // regra que ainda vai começar / não recupera antes do início
    var end=winEnd;
    if(rule.rec_until && rule.rec_until<end) end=rule.rec_until;        // regra com data de término
    if(end<winStart) return;
    var skips=parseSkips(rule.rec_skips); // v72: dias pulados nunca voltam
    occDatesForRule(rule, winStart, end).forEach(function(ds){
      if(skips.indexOf(ds)!==-1) return;
      var key=rule.recur_group+'|'+ds;
      if(existing[key]) return;
      existing[key]=1;
      novos.push({
        title:rule.title, description:rule.description||'', priority:rule.priority||'media',
        status:'todo', due_date:ds, recurrence:rule.recurrence, area:rule.area||'',
        assignee_id:rule.assignee_id||null, project_id:rule.project_id||null,
        sector:rule.sector, created_by:rule.created_by||null, store_unit_id:(rule.store_unit_id||null),
        recur_group:rule.recur_group, is_rule:false,
        subtasks:(Array.isArray(rule.subtasks)&&rule.subtasks.length?rule.subtasks.map(function(s){ return { id:uid(), text:s.text, done:false }; }):null)
      });
    });
  });
  if(!novos.length) return Promise.resolve(false);
  return sb.from('malba_vl_tasks').insert(novos).select().then(function(r){
    if(r.error){ console.error('materializarRecorrencias', r.error); return false; }
    if(r.data && r.data.length){ ST.tasks=r.data.concat(ST.tasks); return true; }
    return false;
  }, function(e){ console.error(e); return false; });
}
function openTaskModal(task, preset) {
  var isEdit=!!task;
  preset = preset || {};
  var t=task||{ title:'', description:'', priority:'media', status:'todo', due_date:(preset.due||today()), area:'', assignee_id:(preset.assignee||'') };
  var canMng=canEdit();
  var occRule=(isEdit && task && task.recur_group && !task.is_rule && canMng) ? ruleForOccurrence(task) : null; // v72
  var recManageRow = occRule ? ('<div class="rec-manage"><span class="rec-manage-l">↻ Faz parte de uma rotina'+(occRule.rec_paused?' · pausada':'')+'</span><div class="rec-manage-btns"><button type="button" class="btn btn-ghost rec-mini" id="recEdit">Editar rotina</button><button type="button" class="btn btn-ghost rec-mini" id="recSkip">Pular este dia</button></div></div>') : '';
  var ro = isEdit && !canMng; // usuário comum editando tarefa existente: só status (mas pode marcar checklist)
  var dis = ro?' disabled':'';
  var subList = (task && Array.isArray(task.subtasks)) ? task.subtasks.map(function(s){ return { id:s.id||uid(), text:s.text||'', done:!!s.done }; }) : [];
  var stPills=STATUS_ORDER.map(function(k){ return '<button type="button" class="pill st-pill'+(t.status===k?' on':'')+'" data-st="'+k+'" style="color:'+STATUS[k].color+'"><span class="pdot" style="background:'+STATUS[k].color+'"></span>'+STATUS[k].label+'</button>'; }).join('');
  // v79: tipo da tarefa (Normal / POP) — alimenta o filtro da Central de Tarefas
  var kindPills=[['normal','Normal'],['pop','POP']].map(function(k){ return '<button type="button" class="pill kd-pill'+(((t.task_kind||'normal')===k[0])?' on':'')+'" data-kd="'+k[0]+'">'+k[1]+'</button>'; }).join('');
  var prPills=['alta','media','baixa'].map(function(k){ return '<button type="button" class="pill pr-pill'+(t.priority===k?' on':'')+'" data-pr="'+k+'" style="color:'+PRIO[k].color+'"><span class="pdot" style="background:'+PRIO[k].color+'"></span>'+PRIO[k].label+'</button>'; }).join('');
  var recPills=REC_ORDER.map(function(k){ return '<button type="button" class="pill rec-pill'+((t.recurrence||'none')===k?' on':'')+'" data-rec="'+k+'">'+REC[k].label+'</button>'; }).join('');
  var userOpts='<option value="">— Ninguém —</option>';
  ST.users.forEach(function(u){ userOpts += '<option value="'+esc(u.id)+'"'+(t.assignee_id===u.id?' selected':'')+'>'+esc(u.name)+'</option>'; });
  var projOpts='<option value="">— Nenhum —</option>';
  (ST.projects||[]).forEach(function(pr){ projOpts += '<option value="'+esc(pr.id)+'"'+(String(t.project_id||'')===String(pr.id)?' selected':'')+'>'+esc(pr.name||'Projeto')+'</option>'; });
  var delBtn=(isEdit && canMng)?('<button class="btn btn-danger btn-del-wrap" id="taskDel">Excluir</button>'+((task&&task.recur_group)?'<button class="btn btn-ghost" id="taskDelSerie" style="color:var(--u-red)">Excluir série</button>':'')):'';

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal" id="taskModal">'+
      '<input class="modal-title-input" id="tTitle" placeholder="Título da tarefa..." value="'+esc(t.title)+'"'+dis+'>'+
      (ro?'<div class="crm-seg-hint"><span class="crm-seg-x">Você pode alterar o status desta tarefa. A edição completa é só para administradores.</span></div>':'')+
      '<div class="modal-row"><label class="modal-label">Status</label><div class="pills" id="tStatus">'+stPills+'</div></div>'+
      '<div class="modal-row"><label class="modal-label">Prioridade</label><div class="pills'+(ro?' pills-ro':'')+'" id="tPrio">'+prPills+'</div></div>'+
      '<div class="modal-row"><label class="modal-label">Tipo</label><div class="pills'+(ro?' pills-ro':'')+'" id="tKind">'+kindPills+'</div></div>'+
      '<div class="modal-row"><label class="modal-label">Repetição</label><div class="pills'+(ro?' pills-ro':'')+'" id="tRec">'+recPills+'</div></div>'+
      '<div id="tRecOpts" class="rec-opts" style="display:none"></div>'+
      recManageRow+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Data</label><input type="date" id="tDate" value="'+esc((t.due_date||'').split('T')[0])+'"'+dis+'></div><div class="modal-row"><label class="modal-label">Área / etiqueta</label><input type="text" id="tArea" placeholder="ex: Estoque" value="'+esc(t.area||'')+'"'+dis+'></div></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Responsável</label><select id="tAssignee"'+dis+'>'+userOpts+'</select></div><div class="modal-row"><label class="modal-label">Projeto (opcional)</label><select id="tProj"'+dis+'>'+projOpts+'</select></div></div>'+
      '<div class="modal-row"><label class="modal-label">Checklist / Subtarefas <span id="tSubCount" class="sub-count"></span></label><div id="tSubs" class="sub-list"></div><div class="sub-add"><input type="text" id="tSubInput" placeholder="+ adicionar item (Enter)" maxlength="140" autocomplete="off"></div></div>'+
      '<div class="modal-row"><label class="modal-label">Descrição</label><textarea id="tDesc" placeholder="Detalhes da tarefa..."'+dis+'>'+esc(t.description||'')+'</textarea></div>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="taskCancel">Cancelar</button><button class="btn btn-primary" id="taskSave">'+(isEdit?(ro?'Salvar status':'Salvar'):'Criar tarefa')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);

  var stPick=t.status, prPick=t.priority, recPick=t.recurrence||'none', kdPick=(t.task_kind||'normal');
  var recUntil='', recDiasUteis=false, recWeekdays=[], recSemFim=true; // v70: por padrão a rotina roda pra sempre
  bindPills(modal, '#tStatus .st-pill', 'st', function(v){ stPick=v; });
  if (!ro) {
    bindPills(modal, '#tPrio .pr-pill', 'pr', function(v){ prPick=v; });
    bindPills(modal, '#tKind .kd-pill', 'kd', function(v){ kdPick=v; });
    bindPills(modal, '#tRec .rec-pill', 'rec', function(v){ recPick=v; renderRecOpts(); });
  }
  function renderRecOpts(){
    var box=modal.querySelector('#tRecOpts'); if(!box) return;
    if(recPick==='none' || ro || isEdit){ box.style.display='none'; box.innerHTML=''; return; }
    box.style.display='block';
    var start=modal.querySelector('#tDate').value||today();
    if(!recUntil || _dParse(recUntil)<_dParse(start)) recUntil=fimDoAnoDe(start); // v69: padrão fim do ANO (antes fim do mês, a série "acabava")
    var extra='';
    if(recPick==='diaria'){
      extra='<label class="rec-check"><input type="checkbox" id="recUteis"'+(recDiasUteis?' checked':'')+'><span>Somente dias úteis (seg a sex)</span></label>';
    } else if(recPick==='semanal'){
      var wdN=['D','S','T','Q','Q','S','S'], wdF=['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
      if(!recWeekdays.length) recWeekdays=[_dParse(start).getDay()];
      extra='<div class="rec-wd-label">Repete nestes dias:</div><div class="rec-wd">'+wdN.map(function(n,i){ return '<button type="button" class="rec-wd-btn'+(recWeekdays.indexOf(i)!==-1?' on':'')+'" data-wd="'+i+'" title="'+wdF[i]+'">'+n+'</button>'; }).join('')+'</div>';
    } else if(recPick==='mensal'){
      extra='<div class="rec-note-inline">Repete todo dia '+_dParse(start).getDate()+' de cada mês.</div>';
    }
    // v70: "sem data fim" = a rotina roda pra sempre (o sistema gera a tarefa de cada dia sozinho)
    var semFimRow='<label class="rec-check"><input type="checkbox" id="recSemFim"'+(recSemFim?' checked':'')+'><span>Sem data fim (roda pra sempre)</span></label>';
    var untilRow= recSemFim ? '' : '<div class="rec-until"><label class="modal-label">Repetir até</label><div class="rec-until-row"><input type="date" id="recUntil" value="'+esc(recUntil)+'"><button type="button" class="rec-quick" data-until="mes">Fim do mês</button><button type="button" class="rec-quick" data-until="ano">Fim do ano</button></div></div>';
    var padrao='';
    if(recPick==='diaria') padrao = recDiasUteis ? 'todo dia útil (seg a sex)' : 'todos os dias';
    else if(recPick==='semanal'){ var nm=['dom','seg','ter','qua','qui','sex','sáb']; var sel=recWeekdays.slice().sort(function(a,b){return a-b;}).map(function(i){return nm[i];}); padrao='toda semana ('+(sel.join(', ')||'—')+')'; }
    else if(recPick==='mensal') padrao='todo dia '+_dParse(start).getDate()+' do mês';
    var ateTxt = recSemFim ? 'sem data fim — roda pra sempre' : ('até '+fmtDate(recUntil));
    var preview='<div class="rec-preview">Repete <b>'+padrao+'</b>, a partir de '+fmtDate(start)+', '+ateTxt+'.<br><span style="opacity:.7">O sistema cria a tarefa de cada dia automaticamente — ninguém precisa recriar.</span></div>';
    box.innerHTML=extra+semFimRow+untilRow+preview;
    var sf=box.querySelector('#recSemFim'); if(sf) sf.addEventListener('change', function(){ recSemFim=this.checked; if(!recSemFim && (!recUntil||_dParse(recUntil)<_dParse(start))) recUntil=fimDoAnoDe(start); renderRecOpts(); });
    var u=box.querySelector('#recUteis'); if(u) u.addEventListener('change', function(){ recDiasUteis=this.checked; renderRecOpts(); });
    var wbs=box.querySelectorAll('.rec-wd-btn'); for(var i=0;i<wbs.length;i++) wbs[i].addEventListener('click', function(){ var d=+this.getAttribute('data-wd'); var ix=recWeekdays.indexOf(d); if(ix===-1) recWeekdays.push(d); else if(recWeekdays.length>1) recWeekdays.splice(ix,1); renderRecOpts(); });
    var ru=box.querySelector('#recUntil'); if(ru) ru.addEventListener('change', function(){ recUntil=this.value; renderRecOpts(); });
    var qks=box.querySelectorAll('.rec-quick'); for(var q=0;q<qks.length;q++) qks[q].addEventListener('click', function(){ var st=modal.querySelector('#tDate').value||today(); recUntil=(this.getAttribute('data-until')==='ano')?fimDoAnoDe(st):fimDoMesDe(st); renderRecOpts(); });
  }
  var tDateEl=modal.querySelector('#tDate'); if(tDateEl) tDateEl.addEventListener('change', function(){ recUntil=''; renderRecOpts(); });
  renderRecOpts();
  // ----- checklist / subtarefas -----
  function renderSubs(){
    var box=modal.querySelector('#tSubs'); if(!box) return;
    var cnt=modal.querySelector('#tSubCount');
    if (subList.length===0){ box.innerHTML='<div class="sub-empty">Sem itens. Quebre a tarefa em passos.</div>'; if(cnt) cnt.textContent=''; }
    else {
      var done=0; subList.forEach(function(s){ if(s.done) done++; });
      if(cnt) cnt.textContent=done+'/'+subList.length;
      box.innerHTML=subList.map(function(s,i){
        return '<div class="sub-item'+(s.done?' done':'')+'">'+
          '<button type="button" class="sub-check" data-i="'+i+'" style="border-color:'+(s.done?'#16A34A':'var(--u-border2)')+';background:'+(s.done?'#16A34A':'transparent')+'">'+(s.done?'✓':'')+'</button>'+
          '<span class="sub-text">'+esc(s.text)+'</span>'+
          '<button type="button" class="sub-del" data-i="'+i+'" title="Remover">✕</button>'+
        '</div>';
      }).join('');
      box.querySelectorAll('.sub-check').forEach(function(b){ b.addEventListener('click', function(){ var i=+this.getAttribute('data-i'); subList[i].done=!subList[i].done; renderSubs(); }); });
      box.querySelectorAll('.sub-del').forEach(function(b){ b.addEventListener('click', function(){ subList.splice(+this.getAttribute('data-i'),1); renderSubs(); }); });
    }
  }
  renderSubs();
  var subInput=modal.querySelector('#tSubInput');
  if (subInput) subInput.addEventListener('keydown', function(e){
    if (e.key!=='Enter') return; e.preventDefault();
    var v=(this.value||'').trim(); if(!v) return;
    subList.push({ id:uid(), text:v, done:false }); this.value=''; renderSubs(); this.focus();
  });

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#taskCancel').addEventListener('click', close);
  modal.querySelector('#tTitle').focus();

  modal.querySelector('#taskSave').addEventListener('click', function(){
    var saveBtn=modal.querySelector('#taskSave');
    if (ro) {
      // colaborador: salva o status e o checklist (pode marcar os próprios passos)
      setBusy(saveBtn,true);
      var roPayload={ status:stPick };
      if (subList.length>0 || (task && task.subtasks && task.subtasks.length)) roPayload.subtasks=subList;
      sb.from('malba_vl_tasks').update(roPayload).eq('id', t.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar status'; return; }
        for (var i=0;i<ST.tasks.length;i++) if (ST.tasks[i].id===t.id) { ST.tasks[i].status=stPick; ST.tasks[i].subtasks=subList; break; }
        close(); toast('Atualizado','success'); renderPage();
      });
      return;
    }
    var title=(modal.querySelector('#tTitle').value||'').trim();
    if (!title) { toast('Informe o título da tarefa','error'); return; }
    var payload={ title:title, description:(modal.querySelector('#tDesc').value||'').trim(), priority:prPick, status:stPick, due_date:modal.querySelector('#tDate').value||today(), recurrence:recPick, area:(modal.querySelector('#tArea').value||'').trim(), task_kind:kdPick, assignee_id:modal.querySelector('#tAssignee').value||null, project_id:(modal.querySelector('#tProj')?(modal.querySelector('#tProj').value||null):null), sector:ST.sector, created_by:ST.session.user.id, store_unit_id:ST.store?ST.store.id:scopeStore() };
    if (subList.length>0 || (task && task.subtasks && task.subtasks.length)) payload.subtasks=subList;
    setBusy(saveBtn,true);
    if (isEdit) {
      sb.from('malba_vl_tasks').update(payload).eq('id', t.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar'; return; }
        for (var i=0;i<ST.tasks.length;i++) if (ST.tasks[i].id===t.id) { ST.tasks[i]=Object.assign(ST.tasks[i],payload); break; }
        auditLog('Editou tarefa', title); close(); toast('Tarefa atualizada','success'); renderPage();
      });
    } else {
      if (recPick!=='none') {
        // v70: cria uma REGRA (uma linha) e deixa o sistema gerar as tarefas de cada dia sozinho
        var grupo=uid();
        var rulePayload=Object.assign({}, payload);
        rulePayload.is_rule=true;
        rulePayload.recur_group=grupo;
        rulePayload.rec_start=payload.due_date;
        rulePayload.rec_dias_uteis=(recPick==='diaria')?!!recDiasUteis:false;
        rulePayload.rec_weekdays=(recPick==='semanal')?JSON.stringify(recWeekdays.slice().sort(function(a,b){return a-b;})):null;
        rulePayload.rec_until=recSemFim?null:(recUntil||null);
        sb.from('malba_vl_tasks').insert(rulePayload).select().single().then(function(r){
          if (r.error){
            var m=(r.error.message||'').toLowerCase();
            if (m.indexOf('is_rule')!==-1 || m.indexOf('rec_')!==-1 || m.indexOf('column')!==-1 || m.indexOf('schema')!==-1){
              // FALLBACK: colunas da regra ainda não existem -> volta ao modo antigo (pré-geração até o fim do ano)
              var until2=recSemFim?fimDoAnoDe(payload.due_date):(recUntil||fimDoAnoDe(payload.due_date));
              var datas=gerarDatasRec(payload.due_date, recPick, { until:until2, diasUteis:recDiasUteis, weekdays:recWeekdays });
              if (datas.length>1){
                var rows=datas.map(function(ds){ var p=Object.assign({}, payload); p.due_date=ds; p.recur_group=grupo; return p; });
                insertRecorrencia(rows, function(ok, n){ if(!ok){ setBusy(saveBtn,false); saveBtn.textContent='Criar tarefa'; return; } auditLog('Criou tarefas recorrentes (compat)', title+' ('+n+')'); close(); toast(n+' tarefas criadas ✓','success'); toast('Dica: rode o SQL da Parte 2 p/ o modo automático','info'); renderPage(); });
                return;
              }
            }
            toast('Erro ao criar rotina','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Criar tarefa'; return;
          }
          if (r.data) ST.tasks.unshift(r.data); // a regra em si (fica invisível nas telas)
          materializarRecorrencias().then(function(){
            auditLog('Criou rotina recorrente', title); close(); toast('Rotina criada — aparece todo dia ✓','success'); renderPage();
          });
        }, function(e){ toast('Erro ao criar rotina','error'); console.error(e); setBusy(saveBtn,false); saveBtn.textContent='Criar tarefa'; });
        return;
      }
      sb.from('malba_vl_tasks').insert(payload).select().single().then(function(r){
        if (r.error || !r.data) { toast('Erro ao criar tarefa','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Criar tarefa'; return; }
        ST.tasks.unshift(r.data);
        auditLog('Criou tarefa', title); close(); toast('Tarefa criada','success'); renderPage();
      });
    }
  });

  if (isEdit && canMng) {
    var recEditBtn=modal.querySelector('#recEdit');
    if(recEditBtn) recEditBtn.addEventListener('click', function(){ close(); openRotinaModal(occRule); });
    var recSkipBtn=modal.querySelector('#recSkip');
    if(recSkipBtn) recSkipBtn.addEventListener('click', function(){
      confirmDelete('Pular só o dia '+fmtDate(t.due_date)+' desta rotina?\nA rotina continua nos outros dias, e este dia não volta.', function(){ pularDiaRotina(occRule, t, function(ok){ if(ok){ close(); renderPage(); } }); });
    });
    modal.querySelector('#taskDel').addEventListener('click', function(){
      confirmDelete('Excluir a tarefa "'+(t.title||'sem título')+'"?', function(){ sb.from('malba_vl_tasks').delete().eq('id', t.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.tasks=ST.tasks.filter(function(x){ return x.id!==t.id; });
        auditLog('Excluiu tarefa', t.title||''); close(); toast('Tarefa excluída','success'); renderPage();
      }); });
    });
    var delSerie=modal.querySelector('#taskDelSerie');
    if (delSerie) delSerie.addEventListener('click', function(){
      var g=task.recur_group; if(!g) return;
      var n=(ST.tasks||[]).filter(function(x){ return String(x.recur_group)===String(g); }).length;
      confirmDelete('Excluir a SÉRIE inteira ('+n+' tarefas repetidas)?', function(){ sb.from('malba_vl_tasks').delete().eq('recur_group', g).then(function(r){
        if (r.error) { toast('Erro ao excluir série','error'); return; }
        ST.tasks=ST.tasks.filter(function(x){ return String(x.recur_group)!==String(g); });
        auditLog('Excluiu série de tarefas', t.title||''); close(); toast('Série excluída','success'); renderPage();
      }); });
    });
  }
}
// ===== v72: GESTÃO DA ROTINA (editar / pausar / pular um dia) =====
function parseSkips(s){ if(Array.isArray(s)) return s.slice(); if(!s) return []; try{ var a=JSON.parse(s); return Array.isArray(a)?a:[]; }catch(e){ return []; } }
function ruleForOccurrence(t){ if(!t||!t.recur_group) return null; for(var i=0;i<ST.tasks.length;i++){ var x=ST.tasks[i]; if(x.is_rule && String(x.recur_group)===String(t.recur_group)) return x; } return null; }
function descrevePadraoRegra(rule){
  var rec=rule.recurrence;
  if(rec==='diaria') return rule.rec_dias_uteis?'todo dia útil (seg a sex)':'todos os dias';
  if(rec==='semanal'){ var nm=['dom','seg','ter','qua','qui','sex','sáb']; var w=parseWeekdaysStr(rule.rec_weekdays); return 'toda semana ('+(w.map(function(i){return nm[i];}).join(', ')||'—')+')'; }
  if(rec==='mensal'){ var d=rule.rec_start?_dParse(rule.rec_start).getDate():''; return 'todo dia '+d+' do mês'; }
  return 'recorrente';
}
function pularDiaRotina(rule, occ, cb){
  if(!rule||!occ){ if(cb)cb(false); return; }
  var ds=(occ.due_date||'').slice(0,10);
  var skips=parseSkips(rule.rec_skips); if(skips.indexOf(ds)===-1) skips.push(ds);
  sb.from('malba_vl_tasks').update({ rec_skips: JSON.stringify(skips) }).eq('id', rule.id).then(function(r1){
    if(r1.error){ toast('Erro ao pular o dia','error'); console.error(r1.error); if(cb)cb(false); return; }
    rule.rec_skips=JSON.stringify(skips);
    sb.from('malba_vl_tasks').delete().eq('id', occ.id).then(function(r2){
      if(r2.error){ toast('Erro ao remover o dia','error'); console.error(r2.error); if(cb)cb(false); return; }
      ST.tasks=ST.tasks.filter(function(x){ return x.id!==occ.id; });
      auditLog('Pulou dia da rotina', (rule.title||'')+' · '+ds); toast('Dia pulado ✓','success'); if(cb)cb(true);
    });
  }, function(e){ toast('Erro ao pular o dia','error'); console.error(e); if(cb)cb(false); });
}
function openRotinaModal(rule){
  if(!rule) return;
  var prPick=rule.priority||'media';
  var prPills=['alta','media','baixa'].map(function(k){ return '<button type="button" class="pill pr-pill'+(prPick===k?' on':'')+'" data-pr="'+k+'" style="color:'+PRIO[k].color+'"><span class="pdot" style="background:'+PRIO[k].color+'"></span>'+PRIO[k].label+'</button>'; }).join('');
  var userOpts='<option value="">— Ninguém —</option>';
  ST.users.forEach(function(u){ userOpts += '<option value="'+esc(u.id)+'"'+(String(rule.assignee_id||'')===String(u.id)?' selected':'')+'>'+esc(u.name)+'</option>'; });
  var pausado=!!rule.rec_paused;
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal">'+
    '<div class="modal-title-input" style="cursor:default">Editar rotina</div>'+
    '<div class="modal-note">Repete <b>'+esc(descrevePadraoRegra(rule))+'</b>'+(pausado?' · <b style="color:var(--u-red)">pausada</b>':'')+'. As mudanças valem para <b>hoje e os próximos dias</b> (dias já feitos não mudam).</div>'+
    '<input class="modal-title-input" id="roTitle" placeholder="Título da rotina..." value="'+esc(rule.title||'')+'">'+
    '<div class="modal-row"><label class="modal-label">Prioridade</label><div class="pills" id="roPrio">'+prPills+'</div></div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Responsável</label><select id="roAssignee">'+userOpts+'</select></div><div class="modal-row"><label class="modal-label">Área / etiqueta</label><input type="text" id="roArea" value="'+esc(rule.area||'')+'" placeholder="ex: Abertura"></div></div>'+
    '<div class="modal-row"><label class="modal-label">Descrição</label><textarea id="roDesc" placeholder="Detalhes...">'+esc(rule.description||'')+'</textarea></div>'+
    '<div class="modal-foot"><button class="btn btn-danger btn-del-wrap" id="roDelSerie">Excluir rotina</button><button class="btn btn-ghost" id="roPause" style="color:'+(pausado?'var(--u-green)':'#F59E0B')+'">'+(pausado?'Retomar rotina':'Pausar rotina')+'</button><button class="btn btn-ghost" id="roCancel">Cancelar</button><button class="btn btn-primary" id="roSave">Salvar</button></div>'+
  '</div>';
  document.body.appendChild(modal);
  bindPills(modal, '#roPrio .pr-pill', 'pr', function(v){ prPick=v; });
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#roCancel').addEventListener('click', close);
  modal.querySelector('#roSave').addEventListener('click', function(){
    var title=(modal.querySelector('#roTitle').value||'').trim(); if(!title){ toast('Informe o título','error'); return; }
    var patch={ title:title, description:(modal.querySelector('#roDesc').value||'').trim(), priority:prPick, area:(modal.querySelector('#roArea').value||'').trim(), assignee_id:(modal.querySelector('#roAssignee').value||null) };
    var btn=modal.querySelector('#roSave'); setBusy(btn,true);
    sb.from('malba_vl_tasks').update(patch).eq('id', rule.id).then(function(r){
      if(r.error){ toast('Erro ao salvar rotina','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Salvar'; return; }
      Object.assign(rule, patch);
      // propaga para as próximas ocorrências ainda não feitas (de hoje pra frente)
      sb.from('malba_vl_tasks').update(patch).eq('recur_group', rule.recur_group).eq('is_rule', false).gte('due_date', today()).neq('status','feito').then(function(){
        ST.tasks.forEach(function(x){ if(!x.is_rule && String(x.recur_group)===String(rule.recur_group) && (x.due_date||'').slice(0,10)>=today() && x.status!=='feito'){ Object.assign(x, patch); } });
        auditLog('Editou rotina', title); close(); toast('Rotina atualizada ✓','success'); renderPage();
      }, function(){ close(); toast('Rotina atualizada ✓','success'); renderPage(); });
    });
  });
  modal.querySelector('#roPause').addEventListener('click', function(){
    var novo=!rule.rec_paused; var btn=this;
     var _go=function(){
    btn.disabled=true;
    sb.from('malba_vl_tasks').update({ rec_paused: novo }).eq('id', rule.id).then(function(r){
      if(r.error){ toast('Erro','error'); console.error(r.error); btn.disabled=false; return; }
      rule.rec_paused=novo;
      if(novo){
        // ao pausar, limpa os dias FUTUROS ainda não feitos
        sb.from('malba_vl_tasks').delete().eq('recur_group', rule.recur_group).eq('is_rule', false).gt('due_date', today()).neq('status','feito').then(function(){
          ST.tasks=ST.tasks.filter(function(x){ return !(!x.is_rule && String(x.recur_group)===String(rule.recur_group) && (x.due_date||'').slice(0,10)>today() && x.status!=='feito'); });
          auditLog('Pausou rotina', rule.title||''); close(); toast('Rotina pausada','success'); renderPage();
        }, function(){ close(); toast('Rotina pausada','success'); renderPage(); });
      } else {
        auditLog('Retomou rotina', rule.title||'');
        materializarRecorrencias().then(function(){ close(); toast('Rotina retomada ✓','success'); renderPage(); });
      }
    });
   }; if(novo){ confirmDialog({ warn:true, title:'Pausar rotina?', message:'Pausar a rotina "'+(rule.title||'')+'"?\nEla para de gerar novos dias (os já criados continuam). Você pode retomar quando quiser.', confirmLabel:'Pausar', onConfirm:_go }); } else { _go(); }});
  modal.querySelector('#roDelSerie').addEventListener('click', function(){
    var g=rule.recur_group;
    var n=(ST.tasks||[]).filter(function(x){ return String(x.recur_group)===String(g) && !x.is_rule; }).length;
    confirmDelete('Excluir a rotina INTEIRA e suas '+n+' tarefas já criadas? Não dá para desfazer.', function(){ sb.from('malba_vl_tasks').delete().eq('recur_group', g).then(function(r){
      if(r.error){ toast('Erro ao excluir','error'); return; }
      ST.tasks=ST.tasks.filter(function(x){ return String(x.recur_group)!==String(g); });
      auditLog('Excluiu rotina', rule.title||''); close(); toast('Rotina excluída','success'); renderPage();
    }); });
  });
}
function bindPills(root, selector, attr, cb) {
  var pills=root.querySelectorAll(selector);
  for (var i=0;i<pills.length;i++) {
    pills[i].addEventListener('click', function(){
      for (var k=0;k<pills.length;k++) pills[k].classList.remove('on');
      this.classList.add('on');
      cb(this.getAttribute('data-'+attr));
    });
  }
}

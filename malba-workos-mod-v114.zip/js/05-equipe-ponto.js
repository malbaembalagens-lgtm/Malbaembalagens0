/* ========== [10b] EQUIPE (funcionários da loja) ========== */
var FUNCOES = ['Vendedor','Caixa','Estoquista','Gerente','Atendente','Repositor','Auxiliar'];

// membros visíveis: loja vê os da própria loja; super admin vê todos.
function visibleMembers() {
  if (ST.sector==='lojas' && ST.store && !isSuper(ST.session)) {
    return ST.members.filter(function(m){ return m.store_unit_id === ST.store.id; });
  }
  // super admin / outros: mostra todos (poderá filtrar por loja no futuro)
  return ST.members;
}

function equipeHTML() {
  var admin = isAdmin(ST.session);
  var all = visibleMembers();
  var t = ST.team || (ST.team = { q:'', sit:'ativos', pend:'', loja:'' });
  var q = (t.q||'').trim().toLowerCase();
  var list = all.filter(function(m){
    if (t.sit==='ativos' && m.is_active===false) return false;
    if (t.sit==='inativos' && m.is_active!==false) return false;
    if (t.loja && String(m.store_unit_id)!==String(t.loja)) return false;
    if (q && (m.name||'').toLowerCase().indexOf(q)===-1) return false;
    if (t.pend==='acesso' && userDoMembro(m)) return false;
    if (t.pend==='meta' && metaMembroMes(m)) return false;
    if (t.pend==='solic' && !reqsDoMembro(m).some(function(r){return (r.status||'pendente')==='pendente';})) return false;
    if (t.pend==='atraso' && tarefasMembroStats(m).atrasadas===0) return false;
    return true;
  });
  list.sort(function(a,b){ return (a.is_active===false)-(b.is_active===false); });
  var ativos = all.filter(function(m){ return m.is_active!==false; });
  // pendências (só admin)
  var pend='';
  if (admin) {
    var pAcc=0,pMeta=0,pSol=0,pAtr=0;
    ativos.forEach(function(m){ if(!userDoMembro(m)) pAcc++; if(!metaMembroMes(m)) pMeta++; if(reqsDoMembro(m).some(function(r){return (r.status||'pendente')==='pendente';})) pSol++; if(tarefasMembroStats(m).atrasadas>0) pAtr++; });
    function pchip(key,label,count,color){ if(!count) return ''; return '<button class="team-pchip'+(t.pend===key?' on':'')+'" data-pend="'+key+'" style="--pc:'+color+'"><span class="tpc-dot"></span>'+label+' <b>'+count+'</b></button>'; }
    var chips = pchip('acesso','Sem acesso',pAcc,'#EF4444')+pchip('meta','Sem meta',pMeta,'#F59E0B')+pchip('solic','Solicitações',pSol,'#3B6FF7')+pchip('atraso','Com atraso',pAtr,'#8B5CF6');
    if (chips) pend = '<div class="team-pend"><span class="team-pend-l">Precisa de atenção</span>'+chips+(t.pend?'<button class="team-pchip clear" data-pend="">limpar</button>':'')+'</div>';
  }
  // barra: busca + situação + loja
  var searchBox='<div class="team-search">'+icon('search')+'<input id="teamQ" placeholder="Buscar por nome..." value="'+esc(t.q||'')+'"></div>';
  var sitSeg='<div class="team-seg"><button class="'+(t.sit==='ativos'?'on':'')+'" data-sit="ativos">Ativos</button><button class="'+(t.sit==='todos'?'on':'')+'" data-sit="todos">Todos</button></div>';
  var lojaSel='';
  if (admin && !ST.store && (ST.storeUnits||[]).length>1) { var op='<option value="">Todas as lojas</option>'+(ST.storeUnits||[]).map(function(s){return '<option value="'+esc(s.id)+'"'+(String(t.loja)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';}).join(''); lojaSel='<select class="task-filter" id="teamLoja">'+op+'</select>'; }
  var btn = admin ? '<button class="btn-new" id="btnNovoMembro">'+icon('plus')+'Novo funcionário</button>' : '';
  var cards = list.length ? list.map(function(m){ return memberCardHTML(m, admin); }).join('') : '<div class="empty-page" style="grid-column:1/-1"><div class="ep-ico">'+icon('users')+'</div><h3>Nada por aqui</h3><p>Ajuste a busca ou os filtros acima.</p></div>';
  var sub = (deptoComoModelo('lojas') && ST.store) ? ('Equipe de '+esc(ST.store.name||('Loja '+ST.store.store_number))) : 'Equipe do setor'; // v106b
  // v74: Ponto vira aba da Equipe (some do menu, mesma navegação do hub Gestão)
  var showPonto = deptoTemEquipe(ST.sector); // v106
  var etab = showPonto ? (ST.equipeTab||'equipe') : 'equipe';
  var tabBar = showPonto ? ('<div class="cfg-tabs"><button class="cfg-tab'+(etab==='equipe'?' on':'')+'" data-etab="equipe">'+icon('users')+'Equipe</button><button class="cfg-tab'+(etab==='ponto'?' on':'')+'" data-etab="ponto">'+icon('clock')+'Ponto</button></div>') : '';
  if (etab==='ponto') {
    return '<div class="tasks-head"><div><h2>Equipe</h2><div class="sub">Presença e ponto do dia</div></div></div>'+tabBar+pontoHTML();
  }
  return '<div class="tasks-head"><div><h2>Equipe</h2><div class="sub">'+sub+' · '+ativos.length+' ativo(s)</div></div>'+btn+'</div>'+tabBar+
    '<div class="team-bar">'+searchBox+sitSeg+lojaSel+'</div>'+ pend +
    '<div class="team-grid">'+cards+'</div>';
}

function storeName(id) {
  for (var i=0;i<ST.storeUnits.length;i++) if (ST.storeUnits[i].id===id) return ST.storeUnits[i].name || ('Loja '+ST.storeUnits[i].store_number);
  return '';
}
function memberCardHTML(m, showStore) {
  var inativo = m.is_active === false;
  var ini = iniciais(m.name);
  var hasAcc = !!userDoMembro(m);
  var g = metaMembroMes(m); var metaVal=g?Number(g.goal_value)||0:0; var real=g?realizadoMeta(g):0; var pct=metaVal>0?Math.min(100,Math.round(real/metaVal*100)):0;
  var ts = tarefasMembroStats(m);
  var temSolic = reqsDoMembro(m).some(function(r){ return (r.status||'pendente')==='pendente'; });
  var alerta = (ts.atrasadas>0) || temSolic;
  var status = '<div class="mc-status">'+
    '<span class="mc-acc '+(hasAcc?'on':'off')+'">'+icon('users')+(hasAcc?'com acesso':'sem acesso')+'</span>'+
    (metaVal>0?'<span class="mc-meta" style="color:'+(pct>=100?'#16A34A':'var(--u-accent)')+'">meta '+pct+'%</span>':'')+
    (ts.atrasadas>0?'<span class="mc-alert">'+ts.atrasadas+' atras.</span>':'')+
    (temSolic?'<span class="mc-req">pedido</span>':'')+
  '</div>';
  var subline = esc(m.role||'Sem função')+(showStore&&m.store_unit_id?(' · '+esc(storeName(m.store_unit_id))):'')+(inativo?' · inativo':'');
  return '<div class="member-card'+(inativo?' off':'')+(alerta?' has-alert':'')+'" data-id="'+esc(m.id)+'" data-name="'+esc((m.name||'').toLowerCase())+'">'+
    '<span class="member-av" style="background:'+(m.color||'#3B6FF7')+'">'+esc(ini)+'</span>'+
    '<div class="member-info"><b>'+esc(m.name)+'</b><i>'+subline+'</i>'+status+'</div></div>';
}

function bindEquipe() {
  var admin = isAdmin(ST.session);
  // v74: abas Equipe/Ponto
  var etabs=app.querySelectorAll('.cfg-tab[data-etab]');
  for (var e=0;e<etabs.length;e++) etabs[e].addEventListener('click', function(){ ST.equipeTab=this.getAttribute('data-etab'); renderPage(); });
  if ((ST.equipeTab||'')==='ponto' && deptoTemEquipe(ST.sector)){ if(typeof bindPonto==='function') bindPonto(); return; } // v106
  var novo = document.getElementById('btnNovoMembro');
  if (novo && admin) novo.addEventListener('click', function(){ openMemberModal(null); });
  var qEl = document.getElementById('teamQ');
  if (qEl) qEl.addEventListener('input', function(){ var v=this.value.trim().toLowerCase(); ST.team.q=this.value; var cs=app.querySelectorAll('.member-card'); for(var i=0;i<cs.length;i++){ var nm=cs[i].getAttribute('data-name')||''; cs[i].style.display=(!v||nm.indexOf(v)!==-1)?'':'none'; } });
  var segs = app.querySelectorAll('.team-seg [data-sit]');
  for (var s=0;s<segs.length;s++) segs[s].addEventListener('click', function(){ ST.team.sit=this.getAttribute('data-sit'); renderPage(); });
  var pl = document.getElementById('teamLoja');
  if (pl) pl.addEventListener('change', function(){ ST.team.loja=this.value; renderPage(); });
  var pch = app.querySelectorAll('[data-pend]');
  for (var p=0;p<pch.length;p++) pch[p].addEventListener('click', function(){ var k=this.getAttribute('data-pend'); ST.team.pend=(ST.team.pend===k)?'':k; renderPage(); });
  if (!admin) return;
  var cards = app.querySelectorAll('.member-card');
  for (var i=0;i<cards.length;i++) {
    cards[i].addEventListener('click', function(){
      var id=this.getAttribute('data-id'); var m=null;
      for (var k=0;k<ST.members.length;k++) if (String(ST.members[k].id)===String(id)) { m=ST.members[k]; break; }
      if (m) openFichaColaborador(m);
    });
  }
}

function openMemberModal(member) {
  if(!canEdit()){ blockManage(); return; }
  var isNew = !member;
  var m = member || { name:'', role:'', phone:'', color:'#3B6FF7', is_active:true };
  var admin = isAdmin(ST.session);

  // Loja-alvo: se há loja logada (login de loja), usa ela. Se é admin, ele escolhe no seletor.
  var lojaFixa = ST.store ? ST.store.id : null;

  // v104: consome cargos cadastrados; se o cargo atual do funcionário não estiver na lista, adiciona-o
  var roleOpts = '<option value="">Selecione a função</option>';
  var listaC = cargosVisiveis(ST.sector);
  var nomesLista = listaC.map(function(c){ return c.name; });
  if (m.role && nomesLista.indexOf(m.role)===-1) roleOpts += '<option value="'+esc(m.role)+'" selected>'+esc(m.role)+' (personalizado)</option>';
  listaC.forEach(function(c){ roleOpts += '<option value="'+esc(c.name)+'"'+(m.role===c.name?' selected':'')+'>'+esc(c.name)+'</option>'; });

  // Seletor de loja: aparece quando NÃO há loja fixa (admin gerenciando várias lojas).
  var lojaSelectHTML = '';
  if (!lojaFixa) {
    var opts = '<option value="">Selecione a loja</option>';
    ST.storeUnits.forEach(function(s){
      var nm = s.name || ('Loja '+s.store_number);
      opts += '<option value="'+esc(s.id)+'"'+(m.store_unit_id===s.id?' selected':'')+'>'+esc(nm)+'</option>';
    });
    lojaSelectHTML = '<div class="modal-row"><label class="modal-label">Loja *</label><select id="mStore">'+opts+'</select></div>';
  }

  var colors = ['#3B6FF7','#16A34A','#F59E0B','#8B5CF6','#EF4444','#0EA5E9'];
  var colorBtns = colors.map(function(c){
    return '<button type="button" class="color-dot'+(m.color===c?' on':'')+'" data-color="'+c+'" style="background:'+c+'"></button>';
  }).join('');

  var statusToggle = isNew ? '' :
    '<div class="modal-row"><label class="modal-label">Situação</label><div class="pills" id="mStatus">'+
      '<button type="button" class="pill ms-pill'+(m.is_active!==false?' on':'')+'" data-act="1" style="color:#16A34A"><span class="pdot" style="background:#16A34A"></span>Ativo</button>'+
      '<button type="button" class="pill ms-pill'+(m.is_active===false?' on':'')+'" data-act="0" style="color:#9aa1ad"><span class="pdot" style="background:#9aa1ad"></span>Inativo</button>'+
    '</div></div>';

  var delBtn = isNew ? '' : '<button class="btn btn-danger btn-del-wrap" id="memberDel">Excluir</button>';

  // ----- bloco de acesso (login do funcionário) -----
  var grantorRank = roleRank(ST.session);
  var nivelOpts = NIV_ORDER.filter(function(k){ return NIVEIS[k].rank <= grantorRank; }).map(function(k){ return '<option value="'+k+'"'+(k==='colaborador'?' selected':'')+'>'+NIVEIS[k].label+'</option>'; }).join('');
  function userVinculado(){
    if (!member) return null;
    var byId=null; (ST.allUsers||[]).forEach(function(u){ if(member.user_id && String(u.id)===String(member.user_id)) byId=u; });
    if (byId) return byId;
    var nm=(member.name||'').trim().toLowerCase(); if(!nm) return null; var found=null;
    (ST.allUsers||[]).forEach(function(u){ if((u.name||'').trim().toLowerCase()===nm && u.sector==='lojas') found=u; });
    return found;
  }
  var linked = userVinculado();
  var accessBlock;
  if (linked) {
    var nvL = NIVEIS[nivelDe(linked)]||NIVEIS.colaborador;
    accessBlock = '<div class="acc-linked">'+icon('users')+'<span>Acesso já vinculado: <b>'+esc(linked.email||linked.name)+'</b> · '+esc(nvL.label)+'</span></div>';
  } else {
    accessBlock = '<div class="acc-box">'+
      '<label class="acc-toggle"><input type="checkbox" id="mMakeUser"><span class="acc-txt"><b>Criar acesso ao sistema</b><i>A pessoa entra com e-mail e senha e vê as próprias comissões e avaliações.</i></span></label>'+
      '<div class="acc-fields" id="mAccessFields" style="display:none">'+
        '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">E-mail de acesso *</label><input type="text" id="mEmail" placeholder="pessoa@malba.com.br"></div><div class="modal-row"><label class="modal-label">Senha *</label><input type="text" id="mPass" placeholder="senha de acesso"></div></div>'+
        '<div class="modal-row"><label class="modal-label">Nível de acesso</label><select id="mLevel">'+nivelOpts+'</select><div class="nivel-desc" id="mNivelDesc">'+esc(NIVEIS.colaborador.desc)+'</div></div>'+
        '<div id="mPermHolder"></div>'+
      '</div>'+
    '</div>';
  }

  var modal = document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<input class="modal-title-input" id="mName" placeholder="Nome do funcionário..." value="'+esc(m.name)+'">'+
      lojaSelectHTML+
      '<div class="modal-row"><label class="modal-label">Função</label><select id="mRole">'+roleOpts+'</select></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Telefone</label><input type="text" id="mPhone" placeholder="(11) 90000-0000" value="'+esc(m.phone||'')+'"></div><div class="modal-row"><label class="modal-label">Cor</label><div class="color-row" id="mColors">'+colorBtns+'</div></div></div>'+
      statusToggle+
      accessBlock+
      '<div class="acc-err" id="accErr" style="display:none"></div>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="memberCancel">Cancelar</button><button class="btn btn-primary" id="memberSave">'+(isNew?'Adicionar':'Salvar')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);
  (function(){ var sel=modal.querySelector('#mLevel'), d=modal.querySelector('#mNivelDesc');
    if(sel&&d) sel.addEventListener('change', function(){ d.textContent=(NIVEIS[this.value]||{}).desc||''; }); })();

  var colorPick = m.color || '#3B6FF7';
  var dots = modal.querySelectorAll('.color-dot');
  for (var i=0;i<dots.length;i++) {
    dots[i].addEventListener('click', function(){
      for (var k=0;k<dots.length;k++) dots[k].classList.remove('on');
      this.classList.add('on'); colorPick=this.getAttribute('data-color');
    });
  }
  var actPick = (m.is_active !== false);
  if (!isNew) bindPills(modal, '#mStatus .ms-pill', 'act', function(v){ actPick = (v==='1'); });

  var mk=modal.querySelector('#mMakeUser');
  var mPermDraw=function(){ var h=modal.querySelector('#mPermHolder'); if(!h) return; var lvEl=modal.querySelector('#mLevel'); var on=mk&&mk.checked; if(on && lvEl && lvEl.value==='user'){ h.innerHTML=permsPickerHTML('lojas', {}); bindPermsPicker(modal); } else if(on){ h.innerHTML='<div class="perm-note-hier">Este nível já tem acesso completo pela hierarquia.</div>'; } else { h.innerHTML=''; } };
  if (mk) mk.addEventListener('change', function(){
    var f=modal.querySelector('#mAccessFields'); if(f) f.style.display=this.checked?'block':'none';
    if(this.checked){ var em=modal.querySelector('#mEmail'); if(em) em.focus(); }
    mPermDraw();
  });
  var mLvEl=modal.querySelector('#mLevel'); if(mLvEl) mLvEl.addEventListener('change', mPermDraw);

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#memberCancel').addEventListener('click', close);
  modal.querySelector('#mName').focus();

  modal.querySelector('#memberSave').addEventListener('click', function(){
    var _eb=modal.querySelector('#accErr'); if(_eb){ _eb.style.display='none'; _eb.innerHTML=''; }
    if (!admin) { toast('Apenas o administrador pode gerenciar a equipe','error'); return; }
    var name=(modal.querySelector('#mName').value||'').trim();
    if (!name) { toast('Informe o nome','error'); return; }
    // loja-alvo: loja fixa (login de loja) OU a escolhida no seletor (admin)
    var storeAlvo = lojaFixa;
    if (!storeAlvo) {
      var sel = modal.querySelector('#mStore');
      storeAlvo = sel ? sel.value : (m.store_unit_id || null);
    }
    if (!storeAlvo) { toast('Selecione a loja do funcionário','error'); return; }
    var rec = { store_unit_id:storeAlvo, name:name, role:modal.querySelector('#mRole').value||null, phone:(modal.querySelector('#mPhone').value||'').trim(), color:colorPick, is_active:actPick };

    // acesso (login) opcional
    var makeUser = !!(mk && mk.checked);
    var accEmail = makeUser ? (modal.querySelector('#mEmail').value||'').trim().toLowerCase() : '';
    var accPass  = makeUser ? (modal.querySelector('#mPass').value||'').trim() : '';
    var accLvl   = makeUser ? (modal.querySelector('#mLevel').value||'user') : 'user';
    var accPerms = (makeUser && accLvl==='user') ? readPerms(modal) : {};
    if (makeUser) {
      if (!accEmail) { toast('Informe o e-mail de acesso (ou desmarque "Criar acesso")','error'); return; }
      if (!accPass)  { toast('Defina a senha de acesso','error'); return; }
    }

    var saveBtn=modal.querySelector('#memberSave'); setBusy(saveBtn,true);
    function finalize(msg, kind){ close(); toast(msg || ('Funcionário '+(isNew?'adicionado':'atualizado')), kind||'success'); renderPage(); }
    function showAccErr(err){
      var raw=(err&&err.message)?err.message:(typeof err==='string'?err:'erro desconhecido');
      var low=raw.toLowerCase(); var friendly='';
      if (low.indexOf('row-level security')!==-1 || low.indexOf('violates row-level')!==-1 || (low.indexOf('policy')!==-1)) {
        friendly='O banco está <b>bloqueando a criação de usuários</b> (regra de permissão / RLS). Rode o arquivo <b>SQL-corrigir-criar-acesso.sql</b> no Supabase → SQL Editor e tente de novo.';
      } else if (low.indexOf('not-null')!==-1 || low.indexOf('null value')!==-1) {
        friendly='Falta preencher uma coluna obrigatória na tabela de usuários (veja o detalhe do banco abaixo).';
      } else if (low.indexOf('duplicate')!==-1 || low.indexOf('unique')!==-1) {
        friendly='Já existe um usuário com esse e-mail. Use outro e-mail.';
      } else if (low.indexOf('column')!==-1 && low.indexOf('does not exist')!==-1) {
        friendly='A tabela de usuários não tem uma coluna esperada. Rode o <b>SQL-corrigir-criar-acesso.sql</b> e tente de novo.';
      }
      var box=modal.querySelector('#accErr');
      if(box){ box.style.display='block'; box.innerHTML='<b>Não consegui criar o acesso.</b><br>'+(friendly?(friendly+'<br>'):'')+'<span class="acc-err-raw">Detalhe do banco: '+esc(raw)+'</span>'; }
      var sv=modal.querySelector('#memberSave'); if(sv){ sv.disabled=false; sv.textContent=(isNew?'Adicionar':'Salvar'); }
      toast('Funcionário salvo, mas o acesso não. O motivo está na janela.','error');
    }
    function vincularMembro(memberId, userId){
      if(!memberId) return;
      sb.from('malba_store_members').update({ user_id:userId }).eq('id', memberId).then(function(rl){ if(!rl.error){ for(var i=0;i<ST.members.length;i++) if(String(ST.members[i].id)===String(memberId)) ST.members[i].user_id=userId; } });
    }
    function inserirConta(memberId){
      var ehAdminSetor=(accLvl==='sector_admin'||accLvl==='admin_geral'||accLvl==='super');
      var baseU={ name:name, sector:'lojas', access_level:accLvl, sector_role:(ehAdminSetor?'admin':'user'), role:(accLvl==='super'?'admin':'user'), email:accEmail, color:colorPick, initials:iniciais(name) };
      function tryInsert(pwField, isRetry){
        var urec=Object.assign({}, baseU); urec[pwField]=accPass;
        sb.from('malba_users').insert(urec).select().single().then(function(ru){
          if (ru.error || !ru.data) {
            var msg=(ru.error&&ru.error.message)?ru.error.message.toLowerCase():'';
            if (!isRetry && msg.indexOf('column')!==-1 && (msg.indexOf('password_hash')!==-1 || msg.indexOf("'password'")!==-1 || msg.indexOf('password')!==-1)) {
              tryInsert(pwField==='password_hash'?'password':'password_hash', true); return;
            }
            console.error('criar acesso:', ru.error); showAccErr(ru.error); return;
          }
          if(ST.allUsers) ST.allUsers.push(ru.data);
          auditLog('Criou acesso', name+' · '+(NIVEIS[accLvl]?NIVEIS[accLvl].label:accLvl));
          vincularMembro(memberId, ru.data.id); savePerms(ru.data.id, accPerms);
          finalize('Funcionário '+(isNew?'adicionado':'atualizado')+' com acesso','success');
        });
      }
      tryInsert('password_hash', false);
    }
    function criarConta(memberId){
      // evita duplicar: se o e-mail já tem conta, vincula a ela em vez de falhar
      sb.from('malba_users').select('id,name,email').ilike('email', accEmail).limit(1).then(function(ex){
        if (!ex.error && ex.data && ex.data.length){
          var existing=ex.data[0];
          var jaTem=false; for(var i=0;i<(ST.allUsers||[]).length;i++) if(String(ST.allUsers[i].id)===String(existing.id)) jaTem=true;
          if(!jaTem && ST.allUsers) ST.allUsers.push(existing);
          vincularMembro(memberId, existing.id);
          auditLog('Vinculou acesso existente', name+' · '+accEmail);
          finalize('Esse e-mail já tinha acesso — vinculei o funcionário a essa conta.','success');
          return;
        }
        inserirConta(memberId);
      });
    }
    if (isNew) {
      sb.from('malba_store_members').insert(rec).select().single().then(function(r){
        if (r.error || !r.data) { toast('Erro ao adicionar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Adicionar'; return; }
        ST.members.push(r.data); auditLog('Adicionou funcionário', name);
        if (makeUser) criarConta(r.data.id); else finalize();
      });
    } else {
      sb.from('malba_store_members').update(rec).eq('id', m.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar'; return; }
        for (var i=0;i<ST.members.length;i++) if (ST.members[i].id===m.id) { ST.members[i]=Object.assign(ST.members[i],rec); break; }
        if (makeUser) criarConta(m.id); else finalize();
      });
    }
  });

  if (!isNew) {
    modal.querySelector('#memberDel').addEventListener('click', function(){
      confirmDelete('Excluir o funcionário "'+(m.name||'')+'"?', function(){ sb.from('malba_store_members').delete().eq('id', m.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.members = ST.members.filter(function(x){ return x.id!==m.id; });
        close(); toast('Funcionário excluído','success'); renderPage();
      }); });
    });
  }
}

/* ========== [10b2] FICHA 360 DO COLABORADOR (hub de gestão da equipe) ========== */
function userDoMembro(member){
  if(!member) return null;
  var byId=null; (ST.allUsers||[]).forEach(function(u){ if(member.user_id && String(u.id)===String(member.user_id)) byId=u; });
  if(byId) return byId;
  var nm=(member.name||'').trim().toLowerCase(); if(!nm) return null; var found=null;
  (ST.allUsers||[]).forEach(function(u){ if((u.name||'').trim().toLowerCase()===nm && u.sector==='lojas') found=u; });
  return found;
}
function vendasMembroMes(member){
  if(!member) return 0;
  var mid=member.id; var u=userDoMembro(member); var uid=u?u.id:null; var s=0;
  (ST.salesEntries||[]).forEach(function(e){ if(!_inMonth(e.sale_date)) return; if((mid&&String(e.member_id)===String(mid)) || (uid&&String(e.user_id)===String(uid))) s+=Number(e.value)||0; });
  return s;
}
function metaMembroMes(member){
  var u=userDoMembro(member); if(!u) return null; var n=_ymNow(); var g=null;
  (ST.goals||[]).forEach(function(x){ if(x.month===n.m && x.year===n.y && String(x.user_id)===String(u.id)) g=x; });
  return g;
}
function tarefasMembroStats(member){
  var u=userDoMembro(member); if(!u) return {abertas:0,atrasadas:0,concluidas:0,total:0};
  return gestaoStats(function(t){ return String(t.assignee_id)===String(u.id); });
}
function ultimaAvalMembro(memberId){ var arr=avalsDoMembro(memberId); return arr.length?arr[arr.length-1]:null; }
function reqsDoMembro(member){
  if(!member) return []; var mid=member.id; var u=userDoMembro(member); var uid=u?u.id:null;
  return (ST.requests||[]).filter(function(r){ return (mid&&String(r.member_id)===String(mid))||(uid&&String(r.user_id)===String(uid)); }).sort(function(a,b){ return (b.created_at||'').localeCompare(a.created_at||''); });
}
function rankVendasMembro(member){
  var arr=(ST.members||[]).filter(function(m){ return m.is_active!==false; }).map(function(m){ return { id:m.id, v:vendasMembroMes(m) }; }).filter(function(x){ return x.v>0; }).sort(function(a,b){ return b.v-a.v; });
  var pos=0; for(var i=0;i<arr.length;i++){ if(String(arr[i].id)===String(member.id)){ pos=i+1; break; } }
  return { pos:pos, total:arr.length };
}

function openFichaColaborador(member){
  if(!canEdit()){ blockManage(); return; }
  var m = member; var showReset=false; var fiTab='resumo';
  var modal=document.createElement('div'); modal.className='modal-bg';
  function refreshMember(){ for(var i=0;i<ST.members.length;i++) if(String(ST.members[i].id)===String(m.id)){ m=ST.members[i]; break; } }
  function fiKpi(label,val,color,sub){ return '<div class="fi-kpi"><span class="fi-kpi-v" style="color:'+color+'">'+val+'</span><span class="fi-kpi-l">'+esc(label)+'</span><span class="fi-kpi-s">'+esc(sub)+'</span></div>'; }
  function fichaHTML(){
    refreshMember();
    var u=userDoMembro(m); var ini=iniciais(m.name); var inativo=m.is_active===false; var loja=storeName(m.store_unit_id)||'—';
    var g=metaMembroMes(m); var metaVal=g?Number(g.goal_value)||0:0; var real=g?realizadoMeta(g):0; var metaPct=metaVal>0?Math.min(100,Math.round(real/metaVal*100)):0;
    var vend=vendasMembroMes(m); var ts=tarefasMembroStats(m);
    var ua=ultimaAvalMembro(m.id); var uaNota=ua?Number(ua.nota_final)||0:0; var uaDiag=ua?diagnostico(uaNota):null; var rk=rankVendasMembro(m);
    var kpis='<div class="fi-kpis">'+
      fiKpi('Meta do mês', metaVal>0?(metaPct+'%'):'—', metaVal>0?(metaPct>=100?'#16A34A':'var(--u-accent)'):'var(--u-text3)', metaVal>0?(fmtBRL(real)+' / '+fmtBRL(metaVal)):'sem meta')+
      fiKpi('Vendas do mês', brlShort(vend), 'var(--u-green)', rk.pos?('#'+rk.pos+' de '+rk.total+' em vendas'):'sem vendas')+
      fiKpi('Tarefas atrasadas', ts.atrasadas, ts.atrasadas>0?'var(--u-red)':'var(--u-text3)', ts.abertas+' abertas · '+ts.concluidas+' feitas')+
      fiKpi('Última nota', ua?uaNota.toFixed(1):'—', uaDiag?uaDiag.color:'var(--u-text3)', ua?uaDiag.label:'sem avaliação')+
    '</div>';
    // Acesso
    var acesso;
    if(u){
      var nvL=NIVEIS[nivelDe(u)]||NIVEIS.colaborador;
      acesso='<div class="fi-acc has"><div class="fi-acc-top"><span class="fi-acc-ic ok">'+icon('users')+'</span><div class="fi-acc-tx"><b>'+esc(u.email||u.name)+'</b><i>'+esc(nvL.label)+' · acesso ativo</i></div></div>'+
        (showReset?'<div class="fi-acc-reset"><input type="text" id="fiNewPass" placeholder="Nova senha (mín. 4)"><button class="btn btn-primary" id="fiDoReset">Salvar senha</button></div>':'')+
        '<div class="fi-acc-actions"><button class="fi-link" id="fiReset">'+(showReset?'Cancelar':'Redefinir senha')+'</button><button class="fi-link danger" id="fiRemove">Remover acesso</button></div>'+
      '</div>';
    } else {
      var grantorRank=roleRank(ST.session);
      var nivelOpts=NIV_ORDER.filter(function(k){return NIVEIS[k].rank<=grantorRank;}).map(function(k){return '<option value="'+k+'"'+(k==='colaborador'?' selected':'')+'>'+NIVEIS[k].label+'</option>';}).join('');
      acesso='<div class="fi-acc none"><div class="fi-acc-top"><span class="fi-acc-ic">'+icon('bell')+'</span><div class="fi-acc-tx"><b>Sem acesso ao sistema</b><i>Crie um login para a pessoa ver o "Meu Dia", metas e avaliações.</i></div></div>'+
        '<div class="fi-acc-form"><div class="modal-grid2"><div class="modal-row"><input type="text" id="fiEmail" placeholder="e-mail de acesso"></div><div class="modal-row"><input type="text" id="fiPass" placeholder="senha"></div></div>'+
        '<div class="fi-acc-form-row"><select id="fiLevel">'+nivelOpts+'</select><button class="btn btn-primary" id="fiCreate">Criar acesso</button></div>'+
        '<div id="fiPermHolder"></div>'+
        '<div class="acc-err" id="fiAccErr" style="display:none"></div></div>'+
      '</div>';
    }
    // Meta
    var metaSec='<div class="fi-sec"><div class="fi-sec-h"><span>'+icon('target')+'Meta do mês</span><button class="fi-link" id="fiMeta">'+(g?'Editar meta':'Definir meta')+'</button></div>'+
      (metaVal>0?'<div class="fi-meta"><div class="fi-meta-bar"><span style="width:'+metaPct+'%;background:'+(metaPct>=100?'#16A34A':'var(--u-accent)')+'"></span></div><div class="fi-meta-sub">'+fmtBRL(real)+' de '+fmtBRL(metaVal)+' · <b style="color:'+(metaPct>=100?'#16A34A':'var(--u-accent)')+'">'+metaPct+'%</b></div></div>':'<div class="fi-empty">Nenhuma meta definida para este mês.</div>')+
    '</div>';
    // Desempenho
    var evo=avalEvolucaoRender(avalsDoMembro(m.id)); var perfBody='';
    if(ua){ var notasArr=Array.isArray(ua.notas)?ua.notas:[]; perfBody='<div class="aval-summary"><div class="asum-score" style="border-color:'+uaDiag.color+'"><span class="asum-num" style="color:'+uaDiag.color+'">'+uaNota.toFixed(1)+'</span><span class="asum-of">de 5</span></div><div class="asum-diag">'+diagBadge(uaNota)+'<p>'+esc(ua.periodo_label||fmtDate(ua.data_avaliacao))+'</p></div></div>'+critBarsHTML(notasArr)+(evo?('<div style="margin-top:8px">'+evo+'</div>'):''); }
    else perfBody='<div class="fi-empty">Ainda sem avaliação. Faça a primeira para acompanhar a evolução.</div>';
    var perfSec='<div class="fi-sec"><div class="fi-sec-h"><span>'+icon('trend')+'Desempenho</span><button class="fi-link" id="fiAval">Avaliar</button></div>'+perfBody+'</div>';
    // Comissões
    var coms=[]; (ST.comissoes||[]).forEach(function(c){ (c.rateio||[]).forEach(function(r){ if(String(r.member_id)===String(m.id)) coms.push({ label:(c.periodo_label||fmtDate(c.periodo_fim||c.periodo_inicio)), valor:r.valor }); }); });
    var comSec = coms.length?('<div class="fi-sec"><div class="fi-sec-h"><span>'+icon('dollar')+'Comissões</span></div><div class="fi-coms">'+coms.slice(0,6).map(function(c){return '<div class="fi-com"><span>'+esc(c.label||'Período')+'</span><b>'+fmtBRL(c.valor)+'</b></div>';}).join('')+'</div></div>'):'';
    // Solicitações
    var reqs=reqsDoMembro(m);
    var reqSec = reqs.length?('<div class="fi-sec"><div class="fi-sec-h"><span>'+icon('bell')+'Solicitações</span></div><div class="fi-reqs">'+reqs.slice(0,6).map(function(r){ var st=r.status||'pendente'; var act=st==='pendente'?'<div class="fi-req-act"><button class="req-btn ok" data-fireqok="'+esc(r.id)+'">Aprovar</button><button class="req-btn no" data-fireqno="'+esc(r.id)+'">Negar</button></div>':reqStatusChip(st); return '<div class="fi-req"><div class="fi-req-main"><b>'+esc(r.kind||'')+'</b>'+(r.title?'<span>'+esc(r.title)+'</span>':'')+'</div>'+act+'</div>'; }).join('')+'</div></div>'):'';

    var tabs='<div class="fi-tabs"><button class="fi-tab'+(fiTab==='resumo'?' on':'')+'" data-fitab="resumo">Resumo</button><button class="fi-tab'+(fiTab==='acompanhamento'?' on':'')+'" data-fitab="acompanhamento">Acompanhamento</button></div>';
    var body;
    if (fiTab==='acompanhamento') { body = acompanhamentoHTML(); }
    else {
      body = kpis +
        '<div class="fi-sec first"><div class="fi-sec-h"><span>'+icon('users')+'Acesso ao sistema</span></div>'+acesso+'</div>'+
        metaSec+perfSec+comSec+reqSec;
    }
    return '<div class="modal fi-modal">'+
      '<div class="fi-head"><span class="fi-av" style="background:'+(m.color||'#3B6FF7')+'">'+esc(ini)+'</span>'+
        '<div class="fi-id"><b>'+esc(m.name)+'</b><i>'+esc(m.role||'Sem função')+' · '+esc(loja)+'</i></div>'+
        '<span class="fi-sit '+(inativo?'off':'on')+'">'+(inativo?'Inativo':'Ativo')+'</span>'+
        '<button class="fi-edit" id="fiEdit" title="Editar dados">'+icon('gear')+'</button>'+
      '</div>'+ tabs + body +
      '<div class="modal-foot"><button class="btn btn-ghost" id="fiClose">Fechar</button></div>'+
    '</div>';
  }
  function acompanhamentoHTML(){
    var cks=checkinsDoMembro(m, 8); var pm=presencaMes(m);
    var presBody = cks.length ? '<div class="fi-checkins">'+cks.map(function(c){ return '<div class="fi-ck"><span class="fi-ck-d">'+fmtDate(c.work_date)+'</span><span class="fi-ck-t">'+(c.entrada?('entrada '+hhmm(c.entrada)):'sem entrada')+(c.saida?(' · saída '+hhmm(c.saida)):'')+'</span></div>'; }).join('')+'</div>' : '<div class="fi-empty">Sem registros de turno ainda. Aparecem quando a pessoa faz check-in no "Meu Dia".</div>';
    var presSec='<div class="fi-sec first"><div class="fi-sec-h"><span>'+icon('cal')+'Presença</span><span class="fi-badge">'+pm+' dia(s) no mês</span></div>'+presBody+'</div>';
    var notas=notasDoMembro(m);
    var notasList = notas.length ? '<div class="fi-notas">'+notas.slice(0,8).map(function(n){ return '<div class="fi-nota"><div class="fi-nota-h"><b>'+esc(n.author_name||'Gestor')+'</b><span>'+fmtDate(n.note_date||n.created_at)+'</span></div><p>'+esc(n.text||'')+'</p></div>'; }).join('')+'</div>' : '<div class="fi-empty">Nenhuma nota ainda.</div>';
    var notasSec='<div class="fi-sec"><div class="fi-sec-h"><span>'+icon('chat')+'Notas de 1:1</span></div><div class="fi-add"><textarea id="fiNota" placeholder="Anote o que foi conversado na conversa de acompanhamento..."></textarea><button class="btn btn-primary" id="fiAddNota">Salvar nota</button></div>'+notasList+'</div>';
    var kds=kudosDoMembro(m);
    var kdList = kds.length ? '<div class="fi-kudos">'+kds.slice(0,8).map(function(k){ return '<div class="fi-kudo"><span class="fk-msg">'+esc(k.message||'')+'</span><span class="fk-from">— '+esc(k.from_name||'Gestão')+' · '+fmtDate(k.created_at)+'</span></div>'; }).join('')+'</div>' : '<div class="fi-empty">Nenhum reconhecimento ainda. Que tal o primeiro?</div>';
    var kdSec='<div class="fi-sec"><div class="fi-sec-h"><span>'+icon('target')+'Reconhecimento (kudos)</span></div><div class="fi-add"><input type="text" id="fiKudo" placeholder="Ex: Mandou muito bem no atendimento de hoje!"><button class="btn btn-primary" id="fiSendKudo">Enviar</button></div>'+kdList+'</div>';
    return presSec+notasSec+kdSec;
  }
  function addNota1on1(){
    var el=modal.querySelector('#fiNota'); var txt=(el.value||'').trim(); if(!txt){ toast('Escreva a nota','error'); return; }
    var btn=modal.querySelector('#fiAddNota'); setBusy(btn,true);
    var rec={ sector:ST.sector, member_id:m.id, author_id:ST.session.user.id, author_name:ST.session.user.name, note_date:today(), text:txt };
    sb.from('malba_notes').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL de acompanhamento).','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Salvar nota'; return; } ST.notes1on1.unshift(r.data); auditLog('Nota 1:1', m.name); toast('Nota salva','success'); draw(); });
  }
  function enviarKudos(){
    var el=modal.querySelector('#fiKudo'); var msg=(el.value||'').trim(); if(!msg){ toast('Escreva o reconhecimento','error'); return; }
    var btn=modal.querySelector('#fiSendKudo'); btn.disabled=true; btn.textContent='Enviando...';
    var rec={ sector:ST.sector, member_id:m.id, from_user_id:ST.session.user.id, from_name:ST.session.user.name, message:msg };
    sb.from('malba_kudos').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui enviar (peça para rodar o SQL de acompanhamento).','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Enviar'; return; } ST.kudos.unshift(r.data); auditLog('Enviou kudos', m.name); toast('Reconhecimento enviado 🎉','success'); draw(); });
  }
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  function draw(){ modal.innerHTML=fichaHTML(); bind(); }
  function resetSenha(u, p, cb){
    if(!u){ cb(false); return; }
    function tryF(field, retry){ var payload={}; payload[field]=p; sb.from('malba_users').update(payload).eq('id',u.id).then(function(r){ if(r.error){ var msg=(r.error.message||'').toLowerCase(); if(!retry && msg.indexOf('column')!==-1){ tryF(field==='password_hash'?'password':'password_hash', true); return; } toast('Erro ao redefinir senha','error'); cb(false); return; } auditLog('Redefiniu senha', m.name); cb(true); }); }
    tryF('password_hash', false);
  }
  function removerAcesso(u, cb){
    sb.from('malba_users').delete().eq('id',u.id).then(function(r){ if(r.error){ toast('Erro ao remover','error'); return; } ST.allUsers=(ST.allUsers||[]).filter(function(x){return String(x.id)!==String(u.id);}); if(m.user_id){ sb.from('malba_store_members').update({user_id:null}).eq('id',m.id).then(function(){}); for(var i=0;i<ST.members.length;i++) if(String(ST.members[i].id)===String(m.id)) ST.members[i].user_id=null; } auditLog('Removeu acesso', m.name); cb(); });
  }
  function criarAcessoFicha(){
    var email=(modal.querySelector('#fiEmail').value||'').trim().toLowerCase(); var pass=(modal.querySelector('#fiPass').value||'').trim(); var lvl=modal.querySelector('#fiLevel').value||'user';
    var fiPerms=(lvl==='user')?readPerms(modal):{};
    var errBox=modal.querySelector('#fiAccErr'); if(errBox){ errBox.style.display='none'; errBox.innerHTML=''; }
    if(!email){ toast('Informe o e-mail','error'); return; } if(!pass){ toast('Defina a senha','error'); return; }
    var btn=modal.querySelector('#fiCreate'); btn.disabled=true; btn.textContent='Criando...';
    function linkTo(userId){ sb.from('malba_store_members').update({user_id:userId}).eq('id',m.id).then(function(){}); for(var k=0;k<ST.members.length;k++) if(String(ST.members[k].id)===String(m.id)) ST.members[k].user_id=userId; }
    sb.from('malba_users').select('id,name,email').ilike('email', email).limit(1).then(function(ex){
      if(!ex.error && ex.data && ex.data.length){ var exu=ex.data[0]; var jaTem=false; for(var i=0;i<(ST.allUsers||[]).length;i++) if(String(ST.allUsers[i].id)===String(exu.id)) jaTem=true; if(!jaTem) ST.allUsers.push(exu); linkTo(exu.id); auditLog('Vinculou acesso existente', m.name); toast('Esse e-mail já tinha acesso — vinculei.','success'); draw(); return; }
      var ehAdminSetor=(lvl==='sector_admin'||lvl==='admin_geral'||lvl==='super'); var baseU={ name:m.name, sector:'lojas', access_level:lvl, sector_role:(ehAdminSetor?'admin':'user'), role:(lvl==='super'?'admin':'user'), email:email, color:m.color||'#3B6FF7', initials:iniciais(m.name) };
      function tryIns(field, retry){ var urec=Object.assign({},baseU); urec[field]=pass; sb.from('malba_users').insert(urec).select().single().then(function(ru){
        if(ru.error||!ru.data){ var msg=(ru.error&&ru.error.message?ru.error.message:'').toLowerCase(); if(!retry && msg.indexOf('column')!==-1){ tryIns(field==='password_hash'?'password':'password_hash', true); return; } if(errBox){ errBox.style.display='block'; errBox.innerHTML='<b>Não consegui criar o acesso.</b><br><span class="acc-err-raw">'+esc(ru.error&&ru.error.message?ru.error.message:'erro')+'</span>'; } setBusy(btn,false); btn.textContent='Criar acesso'; return; }
        ST.allUsers.push(ru.data); linkTo(ru.data.id); savePerms(ru.data.id, fiPerms); auditLog('Criou acesso', m.name); toast('Acesso criado','success'); draw();
      }); }
      tryIns('password_hash', false);
    });
  }
  function bind(){
    modal.querySelector('#fiClose').addEventListener('click', close);
    var tb=modal.querySelectorAll('[data-fitab]'); for(var k=0;k<tb.length;k++) tb[k].addEventListener('click', function(){ fiTab=this.getAttribute('data-fitab'); draw(); });
    var an=modal.querySelector('#fiAddNota'); if(an) an.addEventListener('click', addNota1on1);
    var sk=modal.querySelector('#fiSendKudo'); if(sk) sk.addEventListener('click', enviarKudos);
    var ed=modal.querySelector('#fiEdit'); if(ed) ed.addEventListener('click', function(){ close(); openMemberModal(m); });
    var mt=modal.querySelector('#fiMeta'); if(mt) mt.addEventListener('click', function(){ var u=userDoMembro(m); var g=metaMembroMes(m); close(); if(g) openGoalModal(g); else openGoalModal(null, { store_unit_id:m.store_unit_id, user_id:u?u.id:null }); });
    var av=modal.querySelector('#fiAval'); if(av) av.addEventListener('click', function(){ close(); openAvaliacaoModal(null, { tipo:'membro', store_unit_id:m.store_unit_id, member_id:m.id }); });
    var rs=modal.querySelector('#fiReset'); if(rs) rs.addEventListener('click', function(){ showReset=!showReset; draw(); });
    var dr=modal.querySelector('#fiDoReset'); if(dr) dr.addEventListener('click', function(){ var btn=this; var u=userDoMembro(m); var p=(modal.querySelector('#fiNewPass').value||'').trim(); if(p.length<4){ toast('Senha muito curta (mín. 4)','error'); return; } setBusy(btn,true); resetSenha(u, p, function(ok){ if(ok){ showReset=false; toast('Senha redefinida','success'); draw(); } else { setBusy(btn,false); btn.textContent='Salvar senha'; } }); });
    var rm=modal.querySelector('#fiRemove'); if(rm) rm.addEventListener('click', function(){ var u=userDoMembro(m); if(!u) return; confirmDelete('Remover o acesso de '+m.name+'? A pessoa não poderá mais entrar (você pode recriar depois).', function(){ removerAcesso(u, function(){ toast('Acesso removido','success'); draw(); }); }); });
    var cr=modal.querySelector('#fiCreate'); if(cr) cr.addEventListener('click', criarAcessoFicha);
    var fiLv=modal.querySelector('#fiLevel');
    if(fiLv){ var fh=modal.querySelector('#fiPermHolder');
      var drawFiPerms=function(){ if(!fh) return; if(fiLv.value==='user'){ fh.innerHTML=permsPickerHTML('lojas', {}); bindPermsPicker(modal); } else { fh.innerHTML='<div class="perm-note-hier">Este nível já tem acesso completo pela hierarquia.</div>'; } };
      fiLv.addEventListener('change', drawFiPerms); drawFiPerms();
    }
    var oks=modal.querySelectorAll('[data-fireqok]'); for(var i=0;i<oks.length;i++) oks[i].addEventListener('click', function(){ decidirReq(this.getAttribute('data-fireqok'),'aprovado'); setTimeout(draw,60); });
    var nos=modal.querySelectorAll('[data-fireqno]'); for(var j=0;j<nos.length;j++) nos[j].addEventListener('click', function(){ decidirReq(this.getAttribute('data-fireqno'),'negado'); setTimeout(draw,60); });
  }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal);
  draw();
}

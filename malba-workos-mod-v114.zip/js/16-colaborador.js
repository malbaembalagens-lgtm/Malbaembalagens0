/* ============ COLABORADOR: registrar venda, solicitações, painel "Meu Dia" ============ */

var REQ_KINDS=['Folga / ausência','Troca de turno','Compra de material','Ajuste de ponto','Adiantamento','Outro'];
function openRequestModal(){
  var me=ST.session.user; var memberId=meuMemberId(); var storeId=meuStoreId();
  var kopts=REQ_KINDS.map(function(k){ return '<option value="'+esc(k)+'">'+esc(k)+'</option>'; }).join('');
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal">'+
    '<div class="modal-title-input" style="cursor:default">Pedir algo ao gestor</div>'+
    '<div class="modal-row"><label class="modal-label">Tipo</label><select id="rKind">'+kopts+'</select></div>'+
    '<div class="modal-row"><label class="modal-label">Resumo *</label><input type="text" id="rTitle" placeholder="ex: Folga dia 25" maxlength="80"></div>'+
    '<div class="modal-row"><label class="modal-label">Data (opcional)</label><input type="date" id="rDate" value=""></div>'+
    '<div class="modal-row"><label class="modal-label">Detalhes (opcional)</label><textarea id="rDetail" placeholder="Explique o pedido..."></textarea></div>'+
    '<div class="modal-note">Seu gestor recebe em Gestão → Solicitações e pode aprovar ou negar.</div>'+
    '<div class="modal-foot"><button class="btn btn-ghost" id="rCancel">Cancelar</button><button class="btn btn-primary" id="rSave">Enviar pedido</button></div>'+
  '</div>';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#rCancel').addEventListener('click', close);
  modal.querySelector('#rSave').addEventListener('click', function(){
    var title=(modal.querySelector('#rTitle').value||'').trim();
    if(!title){ toast('Escreva um resumo do pedido','error'); return; }
    var rec={ sector:ST.sector, store_unit_id:storeId, user_id:me.id, user_name:me.name, member_id:memberId, kind:modal.querySelector('#rKind').value, title:title, detail:(modal.querySelector('#rDetail').value||'').trim()||null, date_ref:(modal.querySelector('#rDate').value||null), status:'pendente' };
    var b=this; b.disabled=true; b.textContent='Enviando...';
    sb.from('malba_requests').insert(rec).select().single().then(function(r){
      if(r.error||!r.data){ toast('Não consegui enviar (peça ao admin para rodar o SQL de solicitações).','error'); console.error(r.error); setBusy(b,false); b.textContent='Enviar pedido'; return; }
      ST.requests.unshift(r.data); auditLog('Enviou solicitação', rec.kind+' · '+title); close(); toast('Pedido enviado ao gestor','success'); renderPage();
    });
  });
  document.body.appendChild(modal);
  modal.querySelector('#rTitle').focus();
}
function reqStatusChip(st){ var m={pendente:['#F59E0B','Pendente'],aprovado:['#16A34A','Aprovado'],negado:['#EF4444','Negado']}; var c=m[st]||m.pendente; return '<span class="req-chip" style="color:'+c[0]+';background:'+c[0]+'1a">'+c[1]+'</span>'; }
function decidirReq(id, status){
  var r=null; (ST.requests||[]).forEach(function(x){ if(String(x.id)===String(id)) r=x; }); if(!r) return;
  r.status=status; r.decided_by=ST.session.user.id; r.decided_by_name=ST.session.user.name;
  sb.from('malba_requests').update({ status:status, decided_by:ST.session.user.id, decided_by_name:ST.session.user.name, decided_at:new Date().toISOString() }).eq('id', id).then(function(rr){ if(rr.error) toast('Erro ao atualizar','error'); });
  auditLog((status==='aprovado'?'Aprovou':'Negou')+' solicitação', (r.kind||'')+' · '+(r.user_name||'')); toast('Solicitação '+(status==='aprovado'?'aprovada':'negada'),'success'); renderPage();
}
function solicitacoesHTML(){
  var sid=ST.gestaoStore||'';
  var list=(ST.requests||[]).filter(function(r){ return !sid || String(r.store_unit_id)===String(sid); });
  var ord={pendente:0,aprovado:1,negado:2};
  list.sort(function(a,b){ var sa=ord[a.status||'pendente'], sb2=ord[b.status||'pendente']; if(sa!==sb2) return sa-sb2; return (b.created_at||'').localeCompare(a.created_at||''); });
  var pend=list.filter(function(r){return (r.status||'pendente')==='pendente';}).length;
  var head='<div class="cfg-sec-head"><span>'+list.length+' solicitação(ões) · '+pend+' pendente(s)</span></div>';
  if(!list.length) return head+'<div class="empty-page"><div class="ep-ico">'+icon('bell')+'</div><h3>Nenhuma solicitação</h3><p>Quando a equipe pedir folga, troca de turno, material etc., aparece aqui para aprovar.</p></div>';
  var rows=list.map(function(r){
    var st=r.status||'pendente';
    var actions = st==='pendente'
      ? '<div class="req-actions"><button class="req-btn ok" data-reqok="'+esc(r.id)+'">Aprovar</button><button class="req-btn no" data-reqno="'+esc(r.id)+'">Negar</button></div>'
      : '<div class="req-decided">'+reqStatusChip(st)+(r.decided_by_name?'<span class="req-by">por '+esc(r.decided_by_name)+'</span>':'')+'</div>';
    return '<div class="req-row">'+
      '<div class="req-main"><div class="req-top"><b>'+esc(r.user_name||'—')+'</b><span class="req-kind">'+esc(r.kind||'')+'</span>'+(r.date_ref?'<span class="req-date">'+icon('cal')+fmtDate(r.date_ref)+'</span>':'')+'</div>'+
      (r.title?'<div class="req-title">'+esc(r.title)+'</div>':'')+
      (r.detail?'<div class="req-detail">'+esc(r.detail)+'</div>':'')+'</div>'+
      actions+
    '</div>';
  }).join('');
  return head+'<div class="req-list">'+rows+'</div>';
}
function hhmm(ts){ if(!ts) return '—'; try{ var d=new Date(ts); var h=d.getHours(), m=d.getMinutes(); return (h<10?'0':'')+h+':'+(m<10?'0':'')+m; }catch(e){ return '—'; } }
function checkinHojeDoUser(){ var me=String(ST.session.user.id); var t=today(); var found=null; (ST.checkins||[]).forEach(function(c){ if(String(c.user_id)===me && String(c.work_date).slice(0,10)===t) found=c; }); return found; }
function checkinsDoMembro(member, n){ if(!member) return []; var u=userDoMembro(member); var uid=u?u.id:null; var mid=member.id; var arr=(ST.checkins||[]).filter(function(c){ return (uid&&String(c.user_id)===String(uid))||(mid&&String(c.member_id)===String(mid)); }); arr.sort(function(a,b){ return String(b.work_date).localeCompare(String(a.work_date)); }); return n?arr.slice(0,n):arr; }
function presencaMes(member){ var c=0; checkinsDoMembro(member).forEach(function(x){ if(x.entrada && _inMonth(x.work_date)) c++; }); return c; }
function notasDoMembro(member){ if(!member) return []; return (ST.notes1on1||[]).filter(function(x){ return String(x.member_id)===String(member.id); }).sort(function(a,b){ return (b.created_at||'').localeCompare(a.created_at||''); }); }
function kudosDoMembro(member){ if(!member) return []; return (ST.kudos||[]).filter(function(x){ return String(x.member_id)===String(member.id); }).sort(function(a,b){ return (b.created_at||'').localeCompare(a.created_at||''); }); }
function kudosDoUser(){ var mids=meusMemberIds(); return (ST.kudos||[]).filter(function(x){ return mids.indexOf(String(x.member_id))!==-1; }).sort(function(a,b){ return (b.created_at||'').localeCompare(a.created_at||''); }); }
function registrarCheckin(tipo){
  var u=ST.session.user; var me=u.id; var t=today(); var existing=checkinHojeDoUser(); var nowIso=new Date().toISOString();
  if(tipo==='entrada'){
    if(existing && existing.entrada){ toast('Você já registrou entrada hoje','info'); return; }
    if(existing){ sb.from('malba_checkins').update({ entrada:nowIso }).eq('id',existing.id).then(function(r){ if(!r.error){ existing.entrada=nowIso; toast('Entrada registrada','success'); renderPage(); } else toast('Erro ao registrar','error'); }); }
    else { var mid=meuMemberId(); var sid=meuStoreId(); sb.from('malba_checkins').insert({ sector:ST.sector, store_unit_id:sid, user_id:me, member_id:mid, work_date:t, entrada:nowIso }).select().single().then(function(r){ if(!r.error && r.data){ ST.checkins.push(r.data); auditLog('Check-in (entrada)'); toast('Bom trabalho! Entrada registrada 👋','success'); renderPage(); } else { toast('Não consegui registrar (peça ao admin para rodar o SQL de acompanhamento).','error'); console.error(r.error); } }); }
  } else {
    if(!existing){ toast('Registre a entrada primeiro','info'); return; }
    sb.from('malba_checkins').update({ saida:nowIso }).eq('id',existing.id).then(function(r){ if(!r.error){ existing.saida=nowIso; auditLog('Check-in (saída)'); toast('Até amanhã! Saída registrada','success'); renderPage(); } else toast('Erro ao registrar','error'); });
  }
}
function checkinHojeDoMembro(member){ if(!member) return null; var t=today(); var u=userDoMembro(member); var uid=u?u.id:null; var found=null; (ST.checkins||[]).forEach(function(c){ if(String(c.work_date).slice(0,10)!==t) return; if((String(c.member_id)===String(member.id)) || (uid&&String(c.user_id)===String(uid))) found=c; }); return found; }
function togglePontoMembro(member){
  var ci=checkinHojeDoMembro(member); var nowIso=new Date().toISOString(); var u=userDoMembro(member); var uid=u?u.id:null; var t=today(); var nome=(member.name||'').split(' ')[0];
  if(!ci){ sb.from('malba_checkins').insert({ sector:ST.sector, store_unit_id:member.store_unit_id, user_id:uid, member_id:member.id, work_date:t, entrada:nowIso }).select().single().then(function(r){ if(!r.error&&r.data){ ST.checkins.push(r.data); auditLog('Ponto entrada', member.name); toast(nome+' — entrada '+hhmm(nowIso),'success'); renderPage(); } else { toast('Não consegui registrar (peça para rodar o SQL de acompanhamento).','error'); console.error(r.error); } }); }
  else if(!ci.entrada){ sb.from('malba_checkins').update({ entrada:nowIso }).eq('id',ci.id).then(function(r){ if(!r.error){ ci.entrada=nowIso; toast(nome+' — entrada '+hhmm(nowIso),'success'); renderPage(); } else toast('Erro ao registrar','error'); }); }
  else if(ci.entrada && !ci.saida){ sb.from('malba_checkins').update({ saida:nowIso }).eq('id',ci.id).then(function(r){ if(!r.error){ ci.saida=nowIso; auditLog('Ponto saída', member.name); toast(nome+' — saída '+hhmm(nowIso),'success'); renderPage(); } else toast('Erro ao registrar','error'); }); }
}
function pontoHTML(){
  var lojas = lojasGestao();
  var storeId = ST.store ? ST.store.id : (ST.taskStore||'');
  var selHTML='';
  if(!ST.store && lojas.length>1){ var op='<option value="">Selecione a loja</option>'+lojas.map(function(s){return '<option value="'+esc(s.id)+'"'+(String(storeId)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';}).join(''); selHTML='<select class="task-filter" id="pontoLoja">'+op+'</select>'; }
  else if(!ST.store && lojas.length===1){ storeId=lojas[0].id; }
  var mems = storeId ? membrosDaLoja(storeId).filter(function(m){return m.is_active!==false;}) : [];
  var hoje = new Date(); var dataStr = hoje.getDate()+' de '+MESES[hoje.getMonth()]+' de '+hoje.getFullYear();
  var rows;
  if(!storeId){ rows='<div class="empty-page"><div class="ep-ico">'+icon('clock')+'</div><h3>Escolha a loja</h3><p>Selecione a loja para bater o ponto da equipe.</p></div>'; }
  else if(!mems.length){ rows='<div class="empty-page"><div class="ep-ico">'+icon('users')+'</div><h3>Sem funcionários ativos</h3><p>Cadastre a equipe desta loja em Equipe.</p></div>'; }
  else {
    rows='<div class="ponto-list">'+mems.map(function(m){
      var ci=checkinHojeDoMembro(m); var ini=iniciais(m.name); var statusHTML, btnHTML;
      if(!ci || !ci.entrada){ statusHTML='<span class="pt-status none">ainda não chegou</span>'; btnHTML='<button class="pt-btn in" data-ponto="'+esc(m.id)+'">Cheguei</button>'; }
      else if(ci.entrada && !ci.saida){ statusHTML='<span class="pt-status in">entrou '+hhmm(ci.entrada)+'</span>'; btnHTML='<button class="pt-btn out" data-ponto="'+esc(m.id)+'">Saída</button>'; }
      else { statusHTML='<span class="pt-status done">'+hhmm(ci.entrada)+' → '+hhmm(ci.saida)+'</span>'; btnHTML='<span class="pt-done">'+icon('tasks')+'</span>'; }
      return '<div class="ponto-row"><span class="pt-av" style="background:'+(m.color||'#3B6FF7')+'">'+esc(ini)+'</span><div class="pt-info"><b>'+esc(m.name)+'</b>'+statusHTML+'</div>'+btnHTML+'</div>';
    }).join('')+'</div>';
  }
  var presentes = storeId ? mems.filter(function(m){ var c=checkinHojeDoMembro(m); return c&&c.entrada; }).length : 0;
  return '<div class="tasks-head"><div><h2>Ponto</h2><div class="sub">'+esc(dataStr)+' · '+presentes+' presente(s)</div></div>'+selHTML+'</div>'+rows;
}
function bindPonto(){
  var sel=document.getElementById('pontoLoja'); if(sel) sel.addEventListener('change', function(){ ST.taskStore=this.value; renderPage(); });
  var btns=app.querySelectorAll('[data-ponto]');
  for(var i=0;i<btns.length;i++) btns[i].addEventListener('click', function(){ var id=this.getAttribute('data-ponto'); var m=null; for(var k=0;k<ST.members.length;k++) if(String(ST.members[k].id)===String(id)){m=ST.members[k];break;} if(m) togglePontoMembro(m); });
}
function colaboradorInicioHTML(){
  var u=ST.session.user, me=String(u.id), hoje=today();
  var nome=(u.name||'').split(' ')[0];
  var heroSub = (ST.sector==='lojas') ? 'Seu espaço pessoal: sua meta, comissões, avaliações e pedidos.' : 'Seu espaço: suas vendas, sua meta e suas tarefas do dia.';
  var hero='<div class="cab-hero"><div class="cab-hero-badge"><span class="dot"></span> MEU PAINEL</div><h1 class="cab-hero-title">Bom te ver, <span>'+esc(nome)+'</span>! 👋</h1><p class="cab-hero-sub">'+heroSub+'</p></div>';
  var actions='<div class="cab-actions">'+
    '<button class="cab-act venda" id="cRegVenda"><span class="cab-ic">'+icon('dollar')+'</span><span class="cab-tx"><b>Registrar venda</b><i>Soma na sua meta</i></span></button>'+
    '<button class="cab-act pedir" id="cPedir"><span class="cab-ic">'+icon('bell')+'</span><span class="cab-tx"><b>Pedir algo</b><i>Folga, troca, material…</i></span></button>'+
  '</div>';
  var g=minhaMetaMes(); var metaVal=g?Number(g.goal_value)||0:0; var vend=vendasUserMes(me); var pct=metaVal>0?Math.min(100,Math.round(vend/metaVal*100)):0;
  var corM=pct>=100?'#16A34A':'var(--u-accent)';
  var metaCard = metaVal>0
    ? '<div class="cab-meta"><div class="cab-meta-top"><span>Minha meta de '+MESES[_ymNow().m-1]+'</span><b style="color:'+corM+'">'+pct+'%</b></div><div class="cab-meta-bar"><span style="width:'+pct+'%;background:'+corM+'"></span></div><div class="cab-meta-sub">'+fmtBRL(vend)+' de '+fmtBRL(metaVal)+'</div></div>'
    : '<div class="cab-meta"><div class="cab-meta-top"><span>Vendas registradas em '+MESES[_ymNow().m-1]+'</span><b>'+fmtBRL(vend)+'</b></div><div class="cab-meta-sub">Seu gestor ainda não definiu uma meta sua.</div></div>';
  var mine=filtrarRecorrentesHoje(ST.tasks.filter(function(t){ return String(t.assignee_id)===me; }));
  var foco=mine.filter(function(t){ var d=(t.due_date||'').slice(0,10); return t.status!=='feito'&&d&&d<=hoje; }).sort(function(a,b){return (a.due_date||'').localeCompare(b.due_date||'');});
  var tHTML = foco.length ? foco.map(function(t){ var pr=PRIO[t.priority]||PRIO.media; var late=(t.due_date||'').slice(0,10)<hoje; return '<button class="me-task" data-tid="'+esc(t.id)+'"><span class="me-dot" style="background:'+pr.color+'"></span><span class="me-task-t">'+esc(t.title)+'</span><span class="me-task-d'+(late?' late':'')+'">'+fmtDate(t.due_date)+'</span></button>'; }).join('') : '<div class="col-empty">Nada para hoje. 👏</div>';
  var myReqs=(ST.requests||[]).filter(function(r){return String(r.user_id)===me;}).sort(function(a,b){return (b.created_at||'').localeCompare(a.created_at||'');}).slice(0,5);
  var rHTML = myReqs.length ? myReqs.map(function(r){ return '<div class="cab-req"><span class="cab-req-k">'+esc(r.kind||'')+(r.title?(' · '+esc(r.title)):'')+'</span>'+reqStatusChip(r.status||'pendente')+'</div>'; }).join('') : '<div class="col-empty">Nenhum pedido. Use "Pedir algo".</div>';
  // check-in do turno
  var ci=checkinHojeDoUser(); var ciCard;
  if(!ci || !ci.entrada){ ciCard='<div class="cab-checkin"><div class="cci-info"><b>Vamos começar o dia?</b><i>Registre sua entrada com um toque.</i></div><button class="cci-btn in" id="ciEntrada">Cheguei</button></div>'; }
  else if(ci.entrada && !ci.saida){ ciCard='<div class="cab-checkin on"><div class="cci-info"><b>Entrada às '+hhmm(ci.entrada)+' ✓</b><i>Bom trabalho! Ao terminar, registre a saída.</i></div><button class="cci-btn out" id="ciSaida">Registrar saída</button></div>'; }
  else { ciCard='<div class="cab-checkin done"><div class="cci-info"><b>Turno registrado ✓</b><i>Entrada '+hhmm(ci.entrada)+' · Saída '+hhmm(ci.saida)+'</i></div><span class="cci-check">'+icon('tasks')+'</span></div>'; }
  // reconhecimentos recebidos
  var kud=kudosDoUser().slice(0,4);
  var kudCard = kud.length ? ('<div class="cab-panel"><div class="cab-panel-h">'+icon('target')+'<span>Reconhecimentos 🎉</span></div><div class="cab-kudos">'+kud.map(function(k){ return '<div class="cab-kudo"><span class="ck-msg">'+esc(k.message||'')+'</span><span class="ck-from">— '+esc(k.from_name||'Gestão')+'</span></div>'; }).join('')+'</div></div>') : '';
  // v78: agenda dos próximos 7 dias — vinha do painel "Meu Espaço" (solto); agora vive no Dashboard único
  var ate=addDays(hoje,7), agenda=[];
  (ST.events||[]).forEach(function(ev){ var d=(ev.date||'').slice(0,10); if(!(d>=hoje&&d<=ate))return; if(String(ev.sector||'')!==ST.sector)return; if(ev.scope==='me'&&String(ev.created_by)!==me)return; agenda.push({d:d,hora:ev.hora||'',label:ev.title,color:ev.color||'#0EA5E9',kind:'ev',scope:ev.scope,id:ev.id}); });
  mine.forEach(function(t){ if(t.status==='feito')return; var d=(t.due_date||'').slice(0,10); if(!(d>=hoje&&d<=ate))return; agenda.push({d:d,hora:'',label:t.title,color:(STATUS[t.status]||STATUS.todo).color,kind:'task',id:t.id}); });
  agenda.sort(function(a,b){ return (a.d+a.hora).localeCompare(b.d+b.hora); });
  var agHTML = agenda.length ? agenda.slice(0,10).map(function(it){ return '<div class="me-ag" data-agk="'+it.kind+'" data-agid="'+esc(it.id)+'"><span class="me-ag-date">'+fmtDate(it.d)+(it.hora?' · '+esc(it.hora):'')+'</span><span class="me-ag-dot" style="background:'+it.color+'"></span><span class="me-ag-l">'+esc(it.label)+(it.kind==='ev'?(it.scope==='me'?' · pessoal':' · equipe'):'')+'</span></div>'; }).join('') : '<div class="col-empty">Nada nos próximos 7 dias.</div>';
  var agendaCard = '<div class="cab-panel"><div class="cab-panel-h">'+icon('cal')+'<span>Minha agenda · 7 dias</span></div><div class="me-agenda">'+agHTML+'</div></div>';
  // ===== LOJAS: painel pessoal (só o que é dele — sem tarefas e sem ponto) =====
  if (ST.sector==='lojas') {
    var mids=meusMemberIds();
    var coms=[]; (ST.comissoes||[]).forEach(function(c){ (c.rateio||[]).forEach(function(r){ if(mids.indexOf(String(r.member_id))!==-1) coms.push({ label:(c.periodo_label||fmtDate(c.periodo_fim||c.periodo_inicio)), valor:r.valor, loja:storeName(c.store_unit_id) }); }); });
    var comHTML = coms.length ? coms.slice(0,6).map(function(c){ return '<div class="cab-com"><span class="cab-com-l">'+esc(c.label||'Período')+(c.loja?(' · '+esc(c.loja)):'')+'</span><b>'+fmtBRL(c.valor)+'</b></div>'; }).join('') : '<div class="col-empty">Suas comissões aparecerão aqui.</div>';
    var avals=ST.avaliacoes.filter(function(a){ return a.tipo==='membro' && mids.indexOf(String(a.member_id))!==-1; }).sort(function(a,b){return (b.data_avaliacao||'').localeCompare(a.data_avaliacao||'');});
    var latest=avals.length?avals[0]:null; var perfBlock='';
    if(latest){ var ln=Number(latest.nota_final)||0; var ld=diagnostico(ln); var lArr=Array.isArray(latest.notas)?latest.notas:[]; var evo=avalEvolucaoRender(avals); perfBlock='<div class="aval-summary"><div class="asum-score" style="border-color:'+ld.color+'"><span class="asum-num" style="color:'+ld.color+'">'+ln.toFixed(1)+'</span><span class="asum-of">de 5</span></div><div class="asum-diag">'+diagBadge(ln)+'<p>'+esc(latest.periodo_label||fmtDate(latest.data_avaliacao))+'</p></div></div>'+critBarsHTML(lArr)+(evo?('<div style="margin-top:8px">'+evo+'</div>'):''); }
    else perfBlock='<div class="col-empty">Você ainda não tem avaliação.</div>';
    return hero + muralHTML() + actions +
      '<div class="cab-grid2">'+
        '<div class="cab-panel"><div class="cab-panel-h">'+icon('target')+'<span>Minha meta</span></div>'+metaCard+'</div>'+
        '<div class="cab-panel"><div class="cab-panel-h">'+icon('dollar')+'<span>Minhas comissões</span></div><div class="cab-coms">'+comHTML+'</div></div>'+
      '</div>'+
      '<div class="cab-panel"><div class="cab-panel-h">'+icon('trend')+'<span>Meu desempenho</span></div>'+perfBlock+'</div>'+
      agendaCard + kudCard +
      '<div class="cab-panel"><div class="cab-panel-h">'+icon('bell')+'<span>Minhas solicitações</span></div><div class="cab-reqs">'+rHTML+'</div></div>';
  }
  // ===== VENDAS (e demais): dia a dia individual, com ponto e tarefas =====
  return hero + ciCard + muralHTML() + actions +
    '<div class="cab-grid2">'+
      '<div class="cab-panel"><div class="cab-panel-h">'+icon('target')+'<span>Minha meta</span></div>'+metaCard+'</div>'+
      '<div class="cab-panel"><div class="cab-panel-h">'+icon('tasks')+'<span>Minhas tarefas de hoje</span></div><div class="cab-tasks">'+tHTML+'</div></div>'+
    '</div>'+ agendaCard + kudCard +
    '<div class="cab-panel"><div class="cab-panel-h">'+icon('bell')+'<span>Minhas solicitações</span></div><div class="cab-reqs">'+rHTML+'</div></div>';
}
function bindColaboradorInicio(){
  bindMural();
  var rv=document.getElementById('cRegVenda'); if(rv) rv.addEventListener('click', openVendaModal);
  var pd=document.getElementById('cPedir'); if(pd) pd.addEventListener('click', openRequestModal);
  var ci1=document.getElementById('ciEntrada'); if(ci1) ci1.addEventListener('click', function(){ registrarCheckin('entrada'); });
  var ci2=document.getElementById('ciSaida'); if(ci2) ci2.addEventListener('click', function(){ registrarCheckin('saida'); });
  var ts=app.querySelectorAll('.cab-tasks .me-task[data-tid]');
  for(var i=0;i<ts.length;i++) ts[i].addEventListener('click', function(){ var t=taskById(this.getAttribute('data-tid')); if(t) openTaskModal(t); });
  // v78: agenda de 7 dias dentro do Dashboard
  var adm=isAdmin(ST.session);
  var ags=app.querySelectorAll('.me-agenda .me-ag[data-agk]');
  for(var j=0;j<ags.length;j++) ags[j].addEventListener('click', function(){
    var k=this.getAttribute('data-agk'), id=this.getAttribute('data-agid');
    if(k==='task'){ var t=taskById(id); if(t) openTaskModal(t); }
    else if(k==='ev'){ var ev=evById(id); if(ev){ if(adm||String(ev.created_by)===String(ST.session.user.id)) openEventModal(ev,null); else toast((ev.hora?ev.hora+' · ':'')+(ev.title||'Evento'),'info'); } }
  });
}
function timeAgo(ts){
  try{
    var d=new Date(ts), now=new Date(), s=Math.floor((now-d)/1000);
    if (s<60) return 'agora há pouco';
    if (s<3600) return 'há '+Math.floor(s/60)+' min';
    if (s<86400) return 'há '+Math.floor(s/3600)+' h';
    var dias=Math.floor(s/86400); if (dias===1) return 'ontem';
    if (dias<30) return 'há '+dias+' dias';
    return fmtDate(d.toISOString().slice(0,10));
  }catch(e){ return ''; }
}
function loadAtividade(){
  var box=document.getElementById('atvList'); if(!box) return;
  var q=sb.from('malba_admin_audit').select('*').order('created_at',{ascending:false}).limit(80);
  if (!isTopAdmin(ST.session)) q=q.eq('actor_sector', ST.sector);
  q.then(function(r){
    if (r.error){ box.innerHTML='<div class="atv-loading">Não foi possível carregar o histórico.</div>'; return; }
    var rows=r.data||[];
    if (rows.length===0){ box.innerHTML='<div class="empty-page"><div class="ep-ico">'+icon('search')+'</div><h3>Sem atividades ainda</h3><p>As ações (criar, editar e excluir) vão aparecer aqui conforme a equipe usa o sistema.</p></div>'; return; }
    box.innerHTML=rows.map(function(a){
      var nome=a.actor_name||'Alguém';
      var setor=SECTORS[a.actor_sector]?SECTORS[a.actor_sector].label:(a.actor_sector||'');
      return '<div class="atv-row">'+
        '<span class="atv-av">'+esc(iniciais(nome))+'</span>'+
        '<div class="atv-main"><b>'+esc(nome)+'</b> <span class="atv-act">'+esc(a.action||'')+'</span>'+(setor?'<i class="atv-sec">'+esc(setor)+'</i>':'')+'</div>'+
        '<span class="atv-time">'+timeAgo(a.created_at)+'</span>'+
      '</div>';
    }).join('');
  });
}

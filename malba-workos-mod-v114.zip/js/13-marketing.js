/* ========== [10h] RANKING (Vendas) ========== */
function rankingHTML() {
  var y=new Date().getFullYear(), m=new Date().getMonth()+1;
  var rows = ST.users.map(function(u){
    var g = ST.goals.filter(function(x){ return x.user_id===u.id && x.month===m && x.year===y; })[0];
    return { name:u.name, color:u.color||'#3B6FF7', val:(g?realizadoMeta(g):0), goal:(g?Number(g.goal_value)||0:0) };
  });
  rows.sort(function(a,b){ return b.val-a.val; });
  var max = rows.length ? Math.max(rows[0].val,1) : 1;
  var temDados = rows.some(function(r){ return r.val>0; });

  var body='';
  if (!temDados) {
    body = '<div class="empty-page"><div class="ep-ico">'+icon('trend')+'</div><h3>Ranking sem dados ainda</h3><p>As posições aparecem conforme o realizado das metas individuais for registrado (em Metas, atribua uma meta a cada vendedor).</p></div>';
  } else {
    body = '<div class="rank-list">';
    rows.forEach(function(r,i){
      var rk=i+1; var medal = rk===1?'gold':(rk===2?'silver':(rk===3?'bronze':''));
      var pct = r.val/max*100;
      var pctMeta = r.goal>0 ? (Math.round(r.val/r.goal*100)+'% da meta') : 'sem meta definida';
      body += '<div class="rank-row">'+
        '<span class="rank-pos '+medal+'">'+rk+'</span>'+
        '<span class="rank-av" style="background:'+r.color+'">'+esc(iniciais(r.name))+'</span>'+
        '<div class="rank-main"><b>'+esc(r.name)+'</b><i>'+pctMeta+'</i><div class="rank-bar"><span style="width:'+pct+'%;background:'+r.color+'"></span></div></div>'+
        '<span class="rank-val">'+fmtBRL(r.val)+'</span>'+
      '</div>';
    });
    body += '</div>';
  }
  return '<div class="tasks-head"><div><h2>Ranking de Vendedores</h2><div class="sub">'+MESES[m-1]+' / '+y+'</div></div></div>'+body;
}

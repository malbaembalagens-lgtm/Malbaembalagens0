/* ================= v79: CENTRAL DE ADMINISTRAÇÃO DE TAREFAS =================
   Painel de controle operacional do gestor. NÃO duplica o quadro de Tarefas:
   reusa o mesmo motor (ST.tasks, recorrência, openTaskModal) e só muda a leitura. */
var ADM_PAGE = 20; // quantas tarefas por grupo antes do "carregar mais"
function admF(){
  if(!ST.admF) ST.admF={ colab:'', loja:'', proj:'', prio:'', status:'', tipo:'', per:'', ini:'', fim:'', q:'' };
  return ST.admF;
}
var ADM_KIND_LB = { recorrente:'Recorrente', rotina:'Rotina', pop:'POP', normal:'Normal' };
// Escopo: o que o gestor enxerga, já com os filtros "de recorte" (loja, colaborador, projeto)
// Filtro "atrasada" não é um status do banco — é uma leitura. Tratado à parte:
/* ===== v82: ORGANIZAÇÃO DA CENTRAL — 3 lentes, rotina ≠ tarefa pontual =====
   A rotina aparece UMA vez (a regra, com as datas em que se repete),
   nunca 30 cópias. Tarefa pontual continua organizada por prazo. */
/* ============================================================
   v84 — CENTRAL DE ADMINISTRAÇÃO DE REGRAS
   Navegação em níveis: Setor → Colaborador → Categoria → Rotinas.
   Nunca lista ocorrências: só as REGRAS (uma linha por rotina).
   Preparada para centenas de colaboradores e milhares de rotinas:
   nada é renderizado antes de ser aberto, e tudo é paginado.
   ============================================================ */
var ADM_PG_PESSOAS = 24;  // colaboradores por página
var ADM_PG_REGRAS  = 25;  // regras por grupo antes do "carregar mais"

function admNav(){
  if(!ST.admNav) ST.admNav={ setor:ST.sector, pessoa:null, qP:'', qR:'', limP:ADM_PG_PESSOAS, limG:{}, freq:'', sit:'' };
  return ST.admNav;
}
function admEhUnica(t){ return !t.is_rule && !t.recur_group; }
function admFreqLb(r){ return !r.is_rule?'Única':(r.recurrence==='diaria'?'Diária':(r.recurrence==='semanal'?'Semanal':(r.recurrence==='mensal'?'Mensal':'—'))); }
function admProxExec(r){
  if(!r.is_rule) return (r.due_date||'').slice(0,10)||'';
  if(r.rec_paused) return '';
  var hoje=today();
  try { var d=occDatesForRule(r, hoje, addDays(hoje,400)); return d.length?d[0]:''; } catch(e){ return ''; }
}
// setores que este administrador pode inspecionar
function admSetores(){
  if(isSuper(ST.session)) return ['lojas','vendas','marketing','financeiro'];
  return [ST.sector];
}
// REGISTROS do setor escolhido: regras + tarefas únicas em aberto.
// O setor atual sai da memória; outros setores são buscados sob demanda (só as regras).
function admRegistrosDoSetor(setor){
  if(setor===ST.sector){
    var sid=boardStore();
    return (ST.tasks||[]).filter(function(t){
      if(t.archived_at) return false;
      if(String(t.sector||'')!==setor) return false;
      if(sid && String(t.store_unit_id)!==String(sid)) return false;
      return t.is_rule || (admEhUnica(t) && t.status!=='feito');
    });
  }
  var c=(ST.admCache||{})[setor];
  return c || null; // null = ainda carregando
}
function admCarregaSetor(setor, cb){
  if(!ST.admCache) ST.admCache={};
  if(ST.admCache[setor]) { cb(); return; }
  if(!sb){ ST.admCache[setor]=[]; cb(); return; }
  sb.from('malba_vl_tasks').select('*').eq('sector', setor).eq('is_rule', true).then(function(r){
    ST.admCache[setor] = (r.error||!r.data) ? [] : r.data;
    if(r.error) toast('Não consegui carregar o setor','error');
    cb();
  });
}
// pessoas do setor (malba_users já vem completo, então dá pra ver qualquer setor)
function admPessoasDoSetor(setor){
  return (ST.users||[]).filter(function(u){
    if(u.ativo===false || u.active===false) return false;
    return !u.sector || u.sector===setor || setor===ST.sector;
  });
}
// uma única varredura monta a contagem de TODO mundo (escala para centenas de pessoas)
function admMapaContagens(regs){
  var m={};
  function slot(k){ if(!m[k]) m[k]={ d:0, s:0, m:0, u:0, pausadas:0, total:0 }; return m[k]; }
  regs.forEach(function(r){
    var c=slot(r.assignee_id?String(r.assignee_id):'_sem');
    c.total++;
    if(!r.is_rule){ c.u++; return; }
    if(r.rec_paused) c.pausadas++;
    if(r.recurrence==='diaria') c.d++; else if(r.recurrence==='semanal') c.s++; else if(r.recurrence==='mensal') c.m++;
  });
  return m;
}
var ADM_ZERO={ d:0, s:0, m:0, u:0, pausadas:0, total:0 };
function admFiltraRegras(list){
  var n=admNav(), q=(n.qR||'').toLowerCase().trim();
  return list.filter(function(r){
    if(n.freq){
      if(n.freq==='unica'){ if(r.is_rule) return false; }
      else if(!r.is_rule || r.recurrence!==n.freq) return false;
    }
    if(n.sit==='ativa'   && !(r.is_rule && !r.rec_paused)) return false;
    if(n.sit==='pausada' && !(r.is_rule && r.rec_paused))  return false;
    if(!q) return true;
    var u=r.assignee_id?userById(r.assignee_id):null;
    return [r.title||'', r.description||'', r.tags||'', r.area||'', u?u.name:''].join(' ').toLowerCase().indexOf(q)!==-1;
  });
}

/* ---------- NÍVEL 1: colaboradores ---------- */
function admNivelPessoasHTML(regs){
  var n=admNav(), q=(n.qP||'').toLowerCase().trim();
  var pessoas=admPessoasDoSetor(n.setor).map(function(u){ return { id:u.id, nome:u.name, cor:u.color||'#3B6FF7' }; });
  if(regs.some(function(r){ return !r.assignee_id; })) pessoas.push({ id:'_sem', nome:'Sem responsável', cor:'#9aa1ad' });
  if(q) pessoas=pessoas.filter(function(p){ return p.nome.toLowerCase().indexOf(q)!==-1; });
  pessoas.sort(function(a,b){ return a.nome.localeCompare(b.nome); });
  if(!pessoas.length) return emptyState({ icon:'users', title:'Ninguém encontrado', text:q?'Nenhum colaborador com esse nome.':'Cadastre a equipe para distribuir as rotinas.' });

  var mapa=admMapaContagens(regs);
  var lim=Math.min(n.limP, pessoas.length);
  var linhas=pessoas.slice(0,lim).map(function(p){
    var c=mapa[String(p.id)]||ADM_ZERO;
    var chips='';
    if(c.d) chips+='<span class="pp-chip rot">'+c.d+' diária'+(c.d>1?'s':'')+'</span>';
    if(c.s) chips+='<span class="pp-chip rot">'+c.s+(c.s>1?' semanais':' semanal')+'</span>';
    if(c.m) chips+='<span class="pp-chip rot">'+c.m+(c.m>1?' mensais':' mensal')+'</span>';
    if(c.u) chips+='<span class="pp-chip">'+c.u+' única'+(c.u>1?'s':'')+'</span>';
    if(c.pausadas) chips+='<span class="pp-chip pause">'+c.pausadas+' pausada'+(c.pausadas>1?'s':'')+'</span>';
    if(!c.total) chips='<span class="pp-chip free">sem rotinas</span>';
    return '<button class="pp-card" data-admpessoa="'+esc(p.id)+'">'+
      '<span class="ar-av" style="background:'+p.cor+'">'+esc(iniciais(p.nome))+'</span>'+
      '<span class="pp-mid"><span class="pp-n">'+esc(p.nome)+'</span><span class="pp-chips">'+chips+'</span></span>'+
      '<span class="pp-go">'+icon('cal')+'</span>'+
    '</button>';
  }).join('');
  var mais = pessoas.length>lim ? '<button class="adm-more" id="admMaisP">Carregar mais colaboradores ('+(pessoas.length-lim)+' restantes)</button>' : '';
  return '<div class="pp-list">'+linhas+'</div>'+mais;
}

/* ---------- NÍVEL 2: categorias do colaborador ---------- */
function admLinhaRegraHTML(r){
  var u=r.assignee_id?userById(r.assignee_id):null;
  var prox=admProxExec(r);
  var proj=null; for(var i=0;i<(ST.projects||[]).length;i++) if(String(ST.projects[i].id)===String(r.project_id)) { proj=ST.projects[i]; break; }
  var pausada=!!r.rec_paused;
  var status = !r.is_rule ? '<span class="rg-st unica">'+esc((STATUS[r.status]||STATUS.todo).label)+'</span>'
             : (pausada?'<span class="rg-st pausada">Pausada</span>':'<span class="rg-st ativa">Ativa</span>');
  var padrao = r.is_rule ? descrevePadraoRegra(r) : (prox?('prazo '+fmtDate(prox)):'sem prazo');
  function col(lb,v){ return '<span class="rg-c"><i>'+lb+'</i><b>'+(v||'—')+'</b></span>'; }
  var acoes='<span class="rg-acoes">'+
      (!r.is_rule?'<button class="act-btn icon-only virar" data-qa="conv" data-qid="'+esc(r.id)+'" title="Transformar em rotina">'+icon('cal')+'<span>Virar rotina</span></button>':'')+
      '<button class="act-btn icon-only" data-qa="edit" data-qid="'+esc(r.id)+'" title="Editar">'+icon('edit')+'<span>Editar</span></button>'+
      '<button class="act-btn icon-only" data-qa="resp" data-qid="'+esc(r.id)+'" title="Trocar responsável">'+icon('users')+'<span>Responsável</span></button>'+
      '<button class="act-btn icon-only" data-qa="dup" data-qid="'+esc(r.id)+'" title="Duplicar">'+icon('copy')+'<span>Duplicar</span></button>'+
      '<button class="act-btn icon-only danger" data-qa="del" data-qid="'+esc(r.id)+'" title="Excluir">'+icon('trash')+'<span>Excluir</span></button>'+
    '</span>';
  var marcada=!!(ST.admSel||{})[r.id];
  return '<div class="adm-rw'+(marcada?' sel':'')+'" data-admwrap="'+esc(r.id)+'">'+
    '<label class="adm-ck"><input type="checkbox" data-admsel="'+esc(r.id)+'"'+(marcada?' checked':'')+'></label>'+
    '<div class="adm-row rg-row'+(pausada?' off':'')+'" data-admtask="'+esc(r.id)+'">'+
      '<span class="ar-prio" style="background:'+((PRIO[r.priority]||PRIO.media).color)+'"></span>'+
      '<span class="rg-nome"><b>'+esc(r.title||'(sem título)')+'</b><i>'+esc(padrao)+'</i></span>'+
      (r.is_rule?col('Próxima', prox?fmtDate(prox):'—'):'')+
      col('Horário', esc(r.rec_hora||'—'))+
      col('Projeto', proj?esc(proj.name):'—')+
      status + acoes +
    '</div>'+
  '</div>';
}
function admGrupoHTML(id, titulo, arr){
  var n=admNav();
  var aberto=(ST.admClosed||{})[id]!==true; // v89.2: ABERTO por padrão — fechar é opção, não obrigação
  var head='<div class="adm-group-h"><button class="agh-lb" data-admtoggle="'+id+'">🔁 <span>'+esc(titulo)+'</span></button><span class="agh-c">'+arr.length+'</span><span class="agh-sp"></span>'+
    (arr.length?'<button class="agh-ar" data-admtoggle="'+id+'">'+icon('cal')+'</button>':'')+'</div>';
  if(!arr.length) return '<div class="adm-group vazio">'+head+'</div>';
  if(!aberto) return '<div class="adm-group closed">'+head+'</div>'; // fechado: não renderiza nada dentro
  head=head.replace('<span class="agh-sp"></span>','<span class="agh-sp"></span><button class="agh-sel" data-admgsel="'+id+'">Selecionar todas</button>');
  var lim=Math.min(n.limG[id]||ADM_PG_REGRAS, arr.length);
  var mais = arr.length>lim ? '<button class="adm-more" data-admmore="'+id+'">Carregar mais ('+(arr.length-lim)+' restantes)</button>' : '';
  return '<div class="adm-group" data-admg="'+id+'">'+head+'<div class="adm-list">'+arr.slice(0,lim).map(admLinhaRegraHTML).join('')+mais+'</div></div>';
}
function admNivelCategoriasHTML(regs){
  var n=admNav();
  var pid=n.pessoa;
  var minhas=admFiltraRegras(regs.filter(function(r){ return pid==='_sem' ? !r.assignee_id : String(r.assignee_id)===String(pid); }));
  var R={ diaria:[], semanal:[], mensal:[], unica:[] };
  minhas.forEach(function(r){ if(!r.is_rule) R.unica.push(r); else if(R[r.recurrence]) R[r.recurrence].push(r); });
  var ord=function(a,b){ return String(a.title||'').localeCompare(String(b.title||'')); };
  R.diaria.sort(ord); R.semanal.sort(ord); R.mensal.sort(ord);
  R.unica.sort(function(a,b){ return (a.due_date||'zz').localeCompare(b.due_date||'zz'); });
  return admGrupoHTML('g-d','Tarefas Diárias', R.diaria)+
         admGrupoHTML('g-s','Tarefas Semanais', R.semanal)+
         admGrupoHTML('g-m','Tarefas Mensais', R.mensal)+
         admGrupoHTML('g-u','Tarefas Únicas', R.unica);
}

/* ---------- a tela ---------- */
function admTarefasHTML(){
  if(!isAdmin(ST.session)) return emptyState({ icon:'gear', title:'Acesso restrito', text:'A Central de Rotinas é exclusiva de administradores do setor.' });
  var n=admNav();
  var regs=admRegistrosDoSetor(n.setor);
  if(regs===null){ admCarregaSetor(n.setor, function(){ renderPage(); }); return '<div class="tasks-head"><div><h2>Central de Rotinas</h2></div></div><div class="pp-vazio">Carregando o setor...</div>'; }

  var setores=admSetores();
  var selSetor = setores.length>1
    ? '<select id="admSetor" class="adm-sel-setor">'+setores.map(function(s){ return '<option value="'+s+'"'+(n.setor===s?' selected':'')+'>'+esc((SECTORS[s]||{}).label||s)+'</option>'; }).join('')+'</select>'
    : '<span class="bc-fixo">'+esc((SECTORS[n.setor]||{}).label||n.setor)+'</span>';

  var pessoa = n.pessoa ? (n.pessoa==='_sem' ? {name:'Sem responsável'} : userById(n.pessoa)) : null;
  var trilha='<div class="adm-bc">'+icon('grid')+selSetor+
    (pessoa?('<span class="bc-sep">›</span><button class="bc-link" id="bcVoltar">Colaboradores</button><span class="bc-sep">›</span><b>'+esc(pessoa.name||'')+'</b>'):'')+
  '</div>';

  var filtros='<div class="adm-bar2">'+
    (pessoa
      ? '<input class="adm-search" id="admQR" placeholder="Buscar rotina..." value="'+esc(n.qR||'')+'">'
      : '<input class="adm-search" id="admQP" placeholder="Buscar colaborador..." value="'+esc(n.qP||'')+'">')+
    '<select id="admFreq"><option value="">Toda frequência</option><option value="diaria"'+(n.freq==='diaria'?' selected':'')+'>Diária</option><option value="semanal"'+(n.freq==='semanal'?' selected':'')+'>Semanal</option><option value="mensal"'+(n.freq==='mensal'?' selected':'')+'>Mensal</option><option value="unica"'+(n.freq==='unica'?' selected':'')+'>Única</option></select>'+
    '<select id="admSit"><option value="">Toda situação</option><option value="ativa"'+(n.sit==='ativa'?' selected':'')+'>Ativa</option><option value="pausada"'+(n.sit==='pausada'?' selected':'')+'>Pausada</option></select>'+
    '<button class="btn btn-primary btn-sm" id="admNovaRotina">'+icon('plus')+'Nova rotina</button>'+
  '</div>';

  var corpo = pessoa ? admNivelCategoriasHTML(regs) : admNivelPessoasHTML(admFiltraRegras(regs));
  var sub = pessoa ? 'Rotinas de '+esc((pessoa.name||'').split(' ')[0])+' — as ocorrências do dia a dia ficam no Kanban e no Calendário.'
                   : 'Escolha um colaborador para ver e configurar as rotinas dele.';
  return '<div class="tasks-head"><div><h2>Central de Rotinas</h2><div class="sub">'+sub+'</div></div></div>'+
    trilha + filtros + corpo;
}

function bindAdmTarefas(){
  if(!isAdmin(ST.session)) return;
  var n=admNav();
  function upd(){ renderPage(); }
  var ss=document.getElementById('admSetor');
  if(ss) ss.addEventListener('change', function(){ n.setor=this.value; n.pessoa=null; n.limP=ADM_PG_PESSOAS; ST.admSel={}; upd(); });
  var bv=document.getElementById('bcVoltar');
  if(bv) bv.addEventListener('click', function(){ n.pessoa=null; n.qR=''; ST.admSel={}; upd(); });
  var pcs=app.querySelectorAll('[data-admpessoa]');
  for(var i=0;i<pcs.length;i++) pcs[i].addEventListener('click', function(){ n.pessoa=this.getAttribute('data-admpessoa'); ST.admClosed={}; n.limG={}; ST.admSel={}; upd(); });
  var mp=document.getElementById('admMaisP');
  if(mp) mp.addEventListener('click', function(){ n.limP+=ADM_PG_PESSOAS; upd(); });
  function busca(id, campo){
    var e=document.getElementById(id); if(!e) return;
    e.addEventListener('input', function(){ var v=this.value; clearTimeout(window._admQT); window._admQT=setTimeout(function(){ n[campo]=v; upd(); }, 250); });
  }
  busca('admQP','qP'); busca('admQR','qR');
  var sf=document.getElementById('admFreq'); if(sf) sf.addEventListener('change', function(){ n.freq=this.value; upd(); });
  var si=document.getElementById('admSit');  if(si) si.addEventListener('change', function(){ n.sit=this.value; upd(); });
  var nv=document.getElementById('admNovaRotina');
  if(nv) nv.addEventListener('click', function(){ openTaskModal(null); });
  var tg=app.querySelectorAll('[data-admtoggle]');
  for(var j=0;j<tg.length;j++) tg[j].addEventListener('click', function(){
    var id=this.getAttribute('data-admtoggle'); if(!ST.admClosed) ST.admClosed={};
    ST.admClosed[id]=(ST.admClosed[id]!==true); // v89.2: alterna — true = fechado explicitamente
    upd();
  });
  var mr=app.querySelectorAll('[data-admmore]');
  for(var m=0;m<mr.length;m++) mr[m].addEventListener('click', function(){
    var id=this.getAttribute('data-admmore'); n.limG[id]=(n.limG[id]||ADM_PG_REGRAS)+ADM_PG_REGRAS; upd();
  });
  var wraps=app.querySelectorAll('[data-admwrap]');
  for(var w=0;w<wraps.length;w++) admBindRow(wraps[w]);
  var gs=app.querySelectorAll('[data-admgsel]');
  for(var g=0;g<gs.length;g++) gs[g].addEventListener('click', function(e){ e.stopPropagation(); admSelGrupo(this.getAttribute('data-admgsel')); });
  admLoteBar(); // v86: redesenha a barra depois de cada render
}
// ações rápidas da linha — sem abrir várias telas
/* ===== v85: TRANSFORMAR TAREFA ÚNICA EM ROTINA =====
   A própria tarefa vira a REGRA — mantém título, descrição, checklist,
   responsável e projeto. Daí o motor passa a gerar as ocorrências sozinho. */
function openConverterRotina(id){
  var t=taskById(id); if(!t) return;
  if(t.is_rule){ toast('Esta tarefa já é uma rotina','info'); return; }
  var ini=(t.due_date||'').slice(0,10)||today();
  var freq='diaria', uteis=true, hora=t.rec_hora||'', diaMes=_dParse(ini).getDate();
  var wds=[_dParse(ini).getDay()];

  var bg=document.createElement('div'); bg.className='modal-bg';
  bg.innerHTML='<div class="modal" style="max-width:440px">'+
    '<div class="wz-title">Transformar em rotina</div>'+
    '<div class="cv-alvo">'+icon('tasks')+'<b>'+esc(t.title||'')+'</b></div>'+
    '<div id="cvBody"></div>'+
    modalFoot({ saveLabel:'Criar rotina', cancelId:'cvCancel', saveId:'cvOk' })+
  '</div>';
  document.body.appendChild(bg);
  function close(){ if(bg.parentNode) bg.parentNode.removeChild(bg); }
  bg.addEventListener('click', function(e){ if(e.target===bg) close(); });
  bg.querySelector('#cvCancel').addEventListener('click', close);

  function regraFake(){
    return { recurrence:freq, rec_start:ini, rec_dias_uteis:(freq==='diaria'?uteis:false),
             rec_weekdays:(freq==='semanal'?JSON.stringify(wds):null) };
  }
  function desenha(){
    var extra='';
    if(freq==='diaria'){
      extra='<label class="rec-check"><input type="checkbox" id="cvUteis"'+(uteis?' checked':'')+'><span>Somente dias úteis (seg a sex)</span></label>';
    } else if(freq==='semanal'){
      var wdN=['D','S','T','Q','Q','S','S'], wdF=['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
      extra='<span class="sp-lb" style="margin-top:12px">Dias da semana</span><div class="rec-wd">'+wdN.map(function(nn,i){
        return '<button type="button" class="rec-wd-btn'+(wds.indexOf(i)!==-1?' on':'')+'" data-wd="'+i+'" title="'+wdF[i]+'">'+nn+'</button>'; }).join('')+'</div>';
    } else {
      extra='<span class="sp-lb" style="margin-top:12px">Dia do mês</span><input type="number" min="1" max="31" id="cvDiaMes" value="'+diaMes+'" class="cv-in">';
    }
    var prox=[]; try { prox=occDatesForRule(regraFake(), today(), addDays(today(),70)).slice(0,4); } catch(e){}
    bg.querySelector('#cvBody').innerHTML=
      '<div class="sp-row"><span class="sp-lb">Com que frequência se repete?</span><div class="sp-pills" id="cvFreq">'+
        [['diaria','Diária'],['semanal','Semanal'],['mensal','Mensal']].map(function(x){
          return '<button class="sp-pill'+(freq===x[0]?' on':'')+'" data-v="'+x[0]+'">'+x[1]+'</button>'; }).join('')+
      '</div>'+extra+'</div>'+
      '<div class="sp-grid2">'+
        '<div class="sp-row"><span class="sp-lb">Começa em</span><input type="date" id="cvIni" value="'+esc(ini)+'" class="cv-in"></div>'+
        '<div class="sp-row"><span class="sp-lb">Horário (opcional)</span><input type="time" id="cvHora" value="'+esc(hora)+'" class="cv-in"></div>'+
      '</div>'+
      '<div class="rec-preview">Repete <b>'+esc(descrevePadraoRegra(regraFake()))+'</b>'+(hora?(' às <b>'+esc(hora)+'</b>'):'')+'.<br>'+
        (prox.length?('Próximas: <b>'+prox.map(function(d){ return fmtDate(d); }).join(' · ')+'</b>')
                    :'<span style="color:var(--u-amber)">Nenhuma data cai nesse padrão — revise.</span>')+
        '<br><span style="opacity:.7">Roda pra sempre até você pausar. Você ajusta tudo depois no painel da rotina.</span></div>';
    var fb=bg.querySelectorAll('#cvFreq .sp-pill');
    for(var i=0;i<fb.length;i++) fb[i].addEventListener('click', function(){ freq=this.getAttribute('data-v'); desenha(); });
    var u=bg.querySelector('#cvUteis'); if(u) u.addEventListener('change', function(){ uteis=this.checked; desenha(); });
    var wb=bg.querySelectorAll('.rec-wd-btn');
    for(var j=0;j<wb.length;j++) wb[j].addEventListener('click', function(){
      var d=+this.getAttribute('data-wd'), ix=wds.indexOf(d);
      if(ix===-1) wds.push(d); else if(wds.length>1) wds.splice(ix,1); else return;
      wds.sort(function(a,b){ return a-b; }); desenha();
    });
    var dm=bg.querySelector('#cvDiaMes'); if(dm) dm.addEventListener('change', function(){
      diaMes=Math.max(1,Math.min(31,+this.value||1));
      var d=_dParse(ini); ini=_dFmt(new Date(d.getFullYear(), d.getMonth(), diaMes, 12,0,0)); desenha();
    });
    var ei=bg.querySelector('#cvIni'); if(ei) ei.addEventListener('change', function(){
      if(!this.value) return; ini=this.value; diaMes=_dParse(ini).getDate();
      if(freq==='semanal') wds=[_dParse(ini).getDay()];
      desenha();
    });
    var eh=bg.querySelector('#cvHora'); if(eh) eh.addEventListener('change', function(){ hora=this.value; desenha(); });
  }
  desenha();

  bg.querySelector('#cvOk').addEventListener('click', function(){
    var btn=this;
    var patch={
      is_rule:true, recur_group:uid()+'-'+Date.now(), recurrence:freq,
      rec_start:ini, rec_until:null, rec_paused:false,
      rec_dias_uteis:(freq==='diaria'?!!uteis:false),
      rec_weekdays:(freq==='semanal'?JSON.stringify(wds):null),
      rec_hora:hora||null, status:'todo', due_date:ini
    };
    setBusy(btn,true);
    sb.from('malba_vl_tasks').update(patch).eq('id', id).then(function(r){
      setBusy(btn,false);
      if(r.error){ toast('Erro ao criar a rotina','error'); console.error(r.error); return; }
      var k; for(k in patch) t[k]=patch[k];
      close();
      toast('Virou rotina: '+descrevePadraoRegra(t),'success');
      if(typeof materializarRecorrencias==='function'){
        Promise.resolve(materializarRecorrencias()).then(function(){ renderPage(); });
      } else renderPage();
    });
  });
}

function admAcaoRapida(acao, id){
  var t=taskById(id); if(!t) return;
  if(acao==='edit') return openTaskPanel(id);
  if(acao==='conv') return openConverterRotina(id);
  if(acao==='resp'){
    var uOpts='<option value="">Sem responsável</option>'+(ST.users||[]).map(function(u){ return '<option value="'+esc(u.id)+'"'+(String(u.id)===String(t.assignee_id)?' selected':'')+'>'+esc(u.name)+'</option>'; }).join('');
    return admPicker({ title:'Trocar responsável', campo:'<label class="modal-label">Responsável de "'+esc(t.title||'')+'"</label><select class="adm-pick" id="pkVal">'+uOpts+'</select>',
      onOk:function(v, close){ close(); admPatch(id, { assignee_id:v||null }, function(){ toast('Responsável alterado','success'); renderPage(); }); } });
  }
  if(acao==='dup'){
    var novo={ title:(t.title||'')+' (cópia)', description:t.description||'', priority:t.priority||'media', status:'todo',
      due_date:t.due_date||today(), area:t.area||'', tags:t.tags||'', task_kind:t.task_kind||'normal',
      assignee_id:t.assignee_id||null, project_id:t.project_id||null, sector:t.sector||ST.sector,
      created_by:ST.session.user.id, store_unit_id:t.store_unit_id||null };
    if(Array.isArray(t.subtasks)) novo.subtasks=t.subtasks.map(function(s){ return { id:uid(), text:s.text, done:false }; });
    if(t.is_rule){
      novo.is_rule=true; novo.recur_group=uid()+'-'+Date.now(); novo.recurrence=t.recurrence;
      novo.rec_start=t.rec_start||today(); novo.rec_until=t.rec_until||null; novo.rec_dias_uteis=!!t.rec_dias_uteis;
      novo.rec_weekdays=t.rec_weekdays||null; novo.rec_hora=t.rec_hora||null; novo.rec_paused=true;
    }
    return sb.from('malba_vl_tasks').insert(novo).select().single().then(function(r){
      if(r.error||!r.data){ toast('Erro ao duplicar','error'); console.error(r.error); return; }
      ST.tasks.unshift(r.data); toast(t.is_rule?'Rotina duplicada (pausada)':'Tarefa duplicada','success'); renderPage();
    });
  }
  if(acao==='del'){
    return confirmDelete((t.is_rule?'Excluir a rotina "':'Excluir a tarefa "')+(t.title||'')+'"?'+(t.is_rule?' As tarefas já criadas por ela continuam.':''), function(){
      sb.from('malba_vl_tasks').delete().eq('id', id).then(function(r){
        if(r.error){ toast('Erro ao excluir','error'); return; }
        ST.tasks=ST.tasks.filter(function(x){ return String(x.id)!==String(id); });
        toast('Excluído','success'); renderPage();
      });
    });
  }
}

/* ===== núcleo do painel: salvar e atualizar só o que mudou (v80/v81) ===== */
function admSaved(){
  var el=document.getElementById('spSaved'); if(!el) return;
  el.classList.add('on'); clearTimeout(window._spST);
  window._spST=setTimeout(function(){ el.classList.remove('on'); }, 1400);
}
function admPatch(id, patch, cb){
  var t=taskById(id); if(!t) return;
  var k; for(k in patch) t[k]=patch[k];
  sb.from('malba_vl_tasks').update(patch).eq('id', id).then(function(r){
    if(r.error){ toast('Erro ao salvar','error'); console.error(r.error); return; }
    admSaved(); admRefreshRow(id); admRefreshKpis(); if(cb) cb();
  });
}
function admRefreshRow(id){
  var el=app.querySelector('[data-admwrap="'+id+'"]'); if(!el) return;
  var t=taskById(id); if(!t){ el.parentNode.removeChild(el); return; }
  var tmp=document.createElement('div');
  tmp.innerHTML = admLinhaRegraHTML(t);
  var novo=tmp.firstChild; el.parentNode.replaceChild(novo, el);
  admBindRow(novo);
}
// liga clique (abre painel) + caixa de seleção de UMA linha
function admBindRow(wrap){
  var b=wrap.querySelector('[data-admtask]');
  if(b) b.addEventListener('click', function(){ openTaskPanel(this.getAttribute('data-admtask')); });
  var c=wrap.querySelector('[data-admsel]');
  if(c) c.addEventListener('change', function(){ admToggleSel(this.getAttribute('data-admsel'), this.checked); });
  // v84: ações rápidas na própria linha
  var qs=wrap.querySelectorAll('[data-qa]');
  for(var i=0;i<qs.length;i++) qs[i].addEventListener('click', function(e){
    e.stopPropagation(); e.preventDefault();
    admAcaoRapida(this.getAttribute('data-qa'), this.getAttribute('data-qid'));
  });
}
function admRefreshKpis(){ /* v84: a tela não tem mais barra de indicadores */ }
/* ===== v81: SELEÇÃO MÚLTIPLA + AÇÕES EM LOTE (fatia 3 da Central) ===== */
function admSel(){ if(!ST.admSel) ST.admSel={}; return ST.admSel; }
function admSelIds(){ var s=admSel(), out=[], k; for(k in s){ if(s[k]) out.push(k); } return out; }
function admToggleSel(id, on){
  var s=admSel();
  if(on) s[id]=true; else delete s[id];
  var w=app.querySelector('[data-admwrap="'+id+'"]'); if(w) w.classList.toggle('sel', !!on);
  admLoteBar();
}
function admLimpaSel(){
  ST.admSel={};
  var ws=app.querySelectorAll('.adm-rw.sel');
  for(var i=0;i<ws.length;i++) ws[i].classList.remove('sel');
  var cs=app.querySelectorAll('[data-admsel]');
  for(var j=0;j<cs.length;j++) cs[j].checked=false;
  admLoteBar();
}
// seleciona/desmarca todas as tarefas visíveis de um grupo
function admSelGrupo(gid){
  var g=app.querySelector('[data-admg="'+gid+'"]'); if(!g) return;
  var cs=g.querySelectorAll('[data-admsel]');
  var faltam=false;
  for(var i=0;i<cs.length;i++) if(!cs[i].checked) { faltam=true; break; }
  for(var j=0;j<cs.length;j++){ cs[j].checked=faltam; admToggleSel(cs[j].getAttribute('data-admsel'), faltam); }
}
// barra flutuante — só existe quando há seleção
function admLoteBar(){
  var ids=admSelIds();
  var bar=document.getElementById('admLote');
  if(!ids.length){ if(bar&&bar.parentNode) bar.parentNode.removeChild(bar); return; }
  if(!bar){
    bar=document.createElement('div'); bar.className='adm-lote'; bar.id='admLote';
    document.body.appendChild(bar);
  }
  // v86: prazo e concluir só existem para tarefas — regra não tem prazo nem se conclui
  var temTarefa=ids.some(function(i){ var t=taskById(i); return t && !t.is_rule; });
  var nReg=ids.filter(function(i){ var t=taskById(i); return t && t.is_rule; }).length;
  var resumo=ids.length+' selecionada'+(ids.length>1?'s':'')+(nReg?(' ('+nReg+' rotina'+(nReg>1?'s':'')+')'):'');
  bar.innerHTML='<span class="al-n">'+resumo+'</span><span class="al-sep"></span>'+
    '<button class="act-btn" data-lote="resp">'+icon('users')+'<span>Responsável</span></button>'+
    (temTarefa?'<button class="act-btn" data-lote="prazo">'+icon('cal')+'<span>Prazo</span></button>':'')+
    '<button class="act-btn" data-lote="prio">'+icon('target')+'<span>Prioridade</span></button>'+
    '<button class="act-btn" data-lote="proj">'+icon('folder')+'<span>Projeto</span></button>'+
    (temTarefa?'<button class="act-btn" data-lote="feito">'+icon('check')+'<span>Concluir</span></button>':'')+
    '<button class="act-btn" data-lote="arquivar">'+icon('archive')+'<span>Arquivar</span></button>'+
    '<button class="act-btn danger" data-lote="excluir">'+icon('trash')+'<span>Excluir</span></button>'+
    '<span class="al-sep"></span><button class="al-x" id="admLoteX" title="Limpar seleção">×</button>';
  var bs=bar.querySelectorAll('[data-lote]');
  for(var i=0;i<bs.length;i++) bs[i].addEventListener('click', function(){ admLoteAcao(this.getAttribute('data-lote')); });
  bar.querySelector('#admLoteX').addEventListener('click', admLimpaSel);
}
// escolhedor genérico (responsável / prazo / prioridade / projeto)
function admPicker(o){
  var bg=document.createElement('div'); bg.className='modal-bg';
  bg.innerHTML='<div class="modal" style="max-width:380px"><div class="wz-title">'+esc(o.title)+'</div>'+
    '<div class="modal-row">'+o.campo+'</div>'+
    modalFoot({ saveLabel:'Aplicar', cancelId:'pkCancel', saveId:'pkOk' })+'</div>';
  document.body.appendChild(bg);
  function close(){ if(bg.parentNode) bg.parentNode.removeChild(bg); }
  bg.addEventListener('click', function(e){ if(e.target===bg) close(); });
  bg.querySelector('#pkCancel').addEventListener('click', close);
  bg.querySelector('#pkOk').addEventListener('click', function(){
    var el=bg.querySelector('#pkVal'); o.onOk(el?el.value:null, close, this);
  });
  setTimeout(function(){ var el=bg.querySelector('#pkVal'); if(el) el.focus(); },30);
}
// aplica o mesmo patch em todas as selecionadas, numa única ida ao Supabase
function admLotePatch(patch, msg, lista){
  var ids=lista||admSelIds(); if(!ids.length) return;
  sb.from('malba_vl_tasks').update(patch).in('id', ids).then(function(r){
    if(r.error){ toast('Erro ao aplicar','error'); console.error(r.error); return; }
    ids.forEach(function(id){ var t=taskById(id); if(t){ var k; for(k in patch) t[k]=patch[k]; } });
    toast(msg+' ('+ids.length+')','success');
    admLimpaSel(); renderPage();
  });
}
function admLoteAcao(acao){
  var ids=admSelIds(); if(!ids.length) return;
  var n=ids.length;
  var soTarefas=ids.filter(function(i){ var t=taskById(i); return t && !t.is_rule; });
  var temRegra=ids.some(function(i){ var t=taskById(i); return t && t.is_rule; });
  if((acao==='feito'||acao==='prazo') && !soTarefas.length){ toast('Rotinas não têm prazo nem se concluem','info'); return; }
  if(acao==='resp'){
    var uOpts='<option value="">Sem responsável</option>'+(ST.users||[]).map(function(u){ return '<option value="'+esc(u.id)+'">'+esc(u.name)+'</option>'; }).join('');
    admPicker({ title:'Trocar responsável de '+n+' tarefa(s)', campo:'<label class="modal-label">Responsável</label><select class="adm-pick" id="pkVal">'+uOpts+'</select>',
      onOk:function(v, close){ close(); admLotePatch({ assignee_id:v||null }, 'Responsável alterado'); } });
  } else if(acao==='prazo'){
    admPicker({ title:'Alterar prazo de '+n+' tarefa(s)', campo:'<label class="modal-label">Novo prazo</label><input type="date" class="adm-pick" id="pkVal" value="'+today()+'">',
      onOk:function(v, close){ if(!v){ toast('Escolha uma data','error'); return; } close(); admLotePatch({ due_date:v }, 'Prazo alterado', soTarefas); } });
  } else if(acao==='prio'){
    admPicker({ title:'Alterar prioridade de '+n+' tarefa(s)', campo:'<label class="modal-label">Prioridade</label><select class="adm-pick" id="pkVal"><option value="alta">Alta</option><option value="media" selected>Média</option><option value="baixa">Baixa</option></select>',
      onOk:function(v, close){ close(); admLotePatch({ priority:v }, 'Prioridade alterada'); } });
  } else if(acao==='proj'){
    var pOpts='<option value="">Sem projeto</option>'+(ST.projects||[]).map(function(p){ return '<option value="'+esc(p.id)+'">'+esc(p.name)+'</option>'; }).join('');
    admPicker({ title:'Mover '+n+' tarefa(s) para projeto', campo:'<label class="modal-label">Projeto</label><select class="adm-pick" id="pkVal">'+pOpts+'</select>',
      onOk:function(v, close){ close(); admLotePatch({ project_id:v||null }, 'Tarefas movidas'); } });
  } else if(acao==='feito'){
    admLotePatch({ status:'feito' }, 'Tarefas concluídas', soTarefas);
  } else if(acao==='arquivar'){
    confirmDialog({ warn:true, icon:'archive', title:'Arquivar '+n+' tarefa(s)?', message:'Elas saem da operação mas continuam no histórico.', confirmLabel:'Arquivar',
      onConfirm:function(){ admLotePatch({ archived_at:new Date().toISOString() }, 'Tarefas arquivadas'); } });
  } else if(acao==='excluir'){
    confirmDelete('Excluir '+n+' item(ns)?'+(temRegra?' As tarefas já criadas pelas rotinas continuam.':' Não dá pra desfazer.'), function(){
      sb.from('malba_vl_tasks').delete().in('id', ids).then(function(r){
        if(r.error){ toast('Erro ao excluir','error'); console.error(r.error); return; }
        ST.tasks=ST.tasks.filter(function(x){ return ids.indexOf(String(x.id))===-1; });
        toast(n+' tarefa(s) excluída(s)','success'); admLimpaSel(); renderPage();
      });
    });
  }
}

function openTaskPanel(id){
  var t=taskById(id); if(!t) return;
  var ehRegra=!!t.is_rule; // v83: a regra é editada no mesmo painel
  var subs=(Array.isArray(t.subtasks)?t.subtasks:[]).map(function(s){ return { id:s.id||uid(), text:s.text||'', done:!!s.done }; });
  var rule=(typeof ruleForOccurrence==='function')?ruleForOccurrence(t):null;

  function optsFrom(arr, sel, vazio){
    var o='<option value="">'+esc(vazio)+'</option>';
    return o+arr.map(function(x){ return '<option value="'+esc(x.v)+'"'+(String(sel)===String(x.v)?' selected':'')+'>'+esc(x.l)+'</option>'; }).join('');
  }
  var uArr=(ST.users||[]).map(function(u){ return {v:u.id,l:u.name}; });
  var pArr=(ST.projects||[]).map(function(p){ return {v:p.id,l:p.name}; });
  function pills(id2, arr, sel){
    return '<div class="sp-pills" id="'+id2+'">'+arr.map(function(x){ return '<button class="sp-pill'+(sel===x.v?' on':'')+'" data-v="'+x.v+'">'+esc(x.l)+'</button>'; }).join('')+'</div>';
  }
  function subsHTML(){
    if(!subs.length) return '<div style="font-size:12.5px;color:var(--u-text3)">Sem itens no checklist.</div>';
    return subs.map(function(s,i){ return '<div class="sp-sub'+(s.done?' done':'')+'"><input type="checkbox" data-si="'+i+'"'+(s.done?' checked':'')+'><span>'+esc(s.text)+'</span><button class="sp-sub-x" data-sx="'+i+'">×</button></div>'; }).join('');
  }

  var bg=document.createElement('div'); bg.className='sp-bg';
  var sp=document.createElement('aside'); sp.className='sp';
  sp.innerHTML=
    '<div class="sp-head"><textarea class="sp-t" id="spTitle" rows="1">'+esc(t.title||'')+'</textarea><button class="sp-x" id="spClose">×</button></div>'+
    '<div class="sp-body">'+
      (rule?('<div class="sp-rec">'+icon('cal')+'<span>Faz parte da rotina <b>'+esc(descrevePadraoRegra(rule))+'</b></span><button class="sp-rec-b" id="spRule">Editar rotina</button></div>'):'')+
      (!ehRegra && !t.recur_group ? '<div class="sp-virar"><span>'+icon('cal')+'Tarefa avulsa — se ela se repete, o sistema pode criar sozinho.</span><button class="sp-virar-b" id="spVirar">Transformar em rotina</button></div>' : '')+
      (ehRegra ? '<div class="sp-rec-box" id="spRecBox"></div>'
               : '<div class="sp-row"><span class="sp-lb">Status</span>'+pills('spStatus',[{v:'todo',l:'A fazer'},{v:'fazendo',l:'Em andamento'},{v:'feito',l:'Concluída'}], t.status||'todo')+'</div>')+
      '<div class="sp-row"><span class="sp-lb">Prioridade</span>'+pills('spPrio',[{v:'alta',l:'Alta'},{v:'media',l:'Média'},{v:'baixa',l:'Baixa'}], t.priority||'media')+'</div>'+
      '<div class="sp-grid2">'+
        '<div class="sp-row"><span class="sp-lb">Responsável</span><select id="spAssignee">'+optsFrom(uArr, t.assignee_id, 'Sem responsável')+'</select></div>'+
        (ehRegra ? '<div class="sp-row"><span class="sp-lb">Horário</span><input type="time" id="spHora" value="'+esc(t.rec_hora||'')+'"></div>'
                 : '<div class="sp-row"><span class="sp-lb">Prazo</span><input type="date" id="spDate" value="'+esc((t.due_date||'').slice(0,10))+'"></div>')+
      '</div>'+
      '<div class="sp-row"><span class="sp-lb">Projeto</span><select id="spProj">'+optsFrom(pArr, t.project_id, 'Sem projeto')+'</select></div>'+
      '<div class="sp-row"><span class="sp-lb">Checklist</span><div id="spSubs">'+subsHTML()+'</div><input class="sp-sub-add" id="spSubAdd" placeholder="+ adicionar item (Enter)" maxlength="140"></div>'+
      '<div class="sp-row"><span class="sp-lb">Descrição</span><textarea id="spDesc" placeholder="Detalhes da tarefa...">'+esc(t.description||'')+'</textarea></div>'+
      '<div class="sp-row"><span class="sp-lb">Etiqueta / tags</span><textarea id="spTags" rows="1" placeholder="ex: caixa, fim de mês">'+esc(t.tags||'')+'</textarea></div>'+
    '</div>'+
    '<div class="sp-foot">'+
      actionBtn('duplicar','id="spDup"')+
      (ehRegra ? actionBtn(t.rec_paused?'retomar':'pausar','id="spPause"') : '')+
      actionBtn('arquivar','id="spArch"')+
      actionBtn('excluir','id="spDel"')+
      '<span class="sp-saved" id="spSaved">salvo ✓</span>'+
    '</div>';
  document.body.appendChild(bg); document.body.appendChild(sp);

  function fechar(){
    if(bg.parentNode) bg.parentNode.removeChild(bg);
    if(sp.parentNode) sp.parentNode.removeChild(sp);
    document.removeEventListener('keydown', onKey, true);
  }
  function onKey(e){ if(e.key==='Escape'){ e.preventDefault(); fechar(); } }
  document.addEventListener('keydown', onKey, true);
  bg.addEventListener('click', fechar);
  sp.querySelector('#spClose').addEventListener('click', fechar);

  // título e textos: salvam ao sair do campo
  function blurSave(elId, campo){
    var el=sp.querySelector('#'+elId); if(!el) return;
    el.addEventListener('blur', function(){
      var v=(this.value||'').trim(); var atual=(t[campo]||'');
      if(v===atual) return;
      if(campo==='title' && !v){ this.value=atual; return; }
      var p={}; p[campo]=v; admPatch(id, p);
    });
  }
  blurSave('spTitle','title'); blurSave('spDesc','description'); blurSave('spTags','tags');

  // pills
  function bindSpPills(sel, campo){
    var box=sp.querySelector(sel); if(!box) return;
    var bs=box.querySelectorAll('.sp-pill');
    for(var i=0;i<bs.length;i++) bs[i].addEventListener('click', function(){
      for(var k=0;k<bs.length;k++) bs[k].classList.remove('on');
      this.classList.add('on');
      var p={}; p[campo]=this.getAttribute('data-v'); admPatch(id, p);
    });
  }
  if(!ehRegra) bindSpPills('#spStatus','status');
  bindSpPills('#spPrio','priority');

  sp.querySelector('#spAssignee').addEventListener('change', function(){ admPatch(id, { assignee_id:this.value||null }); });
  sp.querySelector('#spProj').addEventListener('change', function(){ admPatch(id, { project_id:this.value||null }); });
  var elD=sp.querySelector('#spDate'); if(elD) elD.addEventListener('change', function(){ admPatch(id, { due_date:this.value||null }); });
  var elH=sp.querySelector('#spHora'); if(elH) elH.addEventListener('change', function(){ admPatch(id, { rec_hora:this.value||null }); });
  if(ehRegra) spRenderRec();

  // checklist
  function salvarSubs(){ admPatch(id, { subtasks:subs }); }
  function redesenhaSubs(){ sp.querySelector('#spSubs').innerHTML=subsHTML(); bindSubs(); }
  function bindSubs(){
    var cbs=sp.querySelectorAll('[data-si]');
    for(var i=0;i<cbs.length;i++) cbs[i].addEventListener('change', function(){
      subs[+this.getAttribute('data-si')].done=this.checked; salvarSubs(); redesenhaSubs();
    });
    var xs=sp.querySelectorAll('[data-sx]');
    for(var j=0;j<xs.length;j++) xs[j].addEventListener('click', function(){
      subs.splice(+this.getAttribute('data-sx'),1); salvarSubs(); redesenhaSubs();
    });
  }
  bindSubs();
  sp.querySelector('#spSubAdd').addEventListener('keydown', function(e){
    if(e.key!=='Enter') return; e.preventDefault();
    var v=(this.value||'').trim(); if(!v) return;
    subs.push({ id:uid(), text:v, done:false }); this.value='';
    salvarSubs(); redesenhaSubs();
  });

  // ===== v83: edição da recorrência dentro do painel =====
  function spRenderRec(){
    var box=sp.querySelector('#spRecBox'); if(!box) return;
    var freq=t.recurrence||'diaria';
    var wds=parseWeekdaysStr(t.rec_weekdays); if(!wds.length && t.rec_start) wds=[_dParse(t.rec_start).getDay()];
    var ini=(t.rec_start||'').slice(0,10)||today();
    var semFim=!t.rec_until;
    var extra='';
    if(freq==='diaria'){
      extra='<label class="rec-check"><input type="checkbox" id="spUteis"'+(t.rec_dias_uteis?' checked':'')+'><span>Somente dias úteis (seg a sex)</span></label>';
    } else if(freq==='semanal'){
      var wdN=['D','S','T','Q','Q','S','S'], wdF=['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
      extra='<span class="sp-lb" style="margin-top:10px">Dias da semana</span><div class="rec-wd">'+wdN.map(function(n,i){ return '<button type="button" class="rec-wd-btn'+(wds.indexOf(i)!==-1?' on':'')+'" data-wd="'+i+'" title="'+wdF[i]+'">'+n+'</button>'; }).join('')+'</div>';
    } else if(freq==='mensal'){
      extra='<span class="sp-lb" style="margin-top:10px">Dia do mês</span><input type="number" min="1" max="31" id="spDiaMes" value="'+(ini?_dParse(ini).getDate():1)+'">';
    }
    box.innerHTML=
      '<div class="sp-row"><span class="sp-lb">Frequência</span><div class="sp-pills" id="spFreq">'+
        [['diaria','Diária'],['semanal','Semanal'],['mensal','Mensal']].map(function(x){ return '<button class="sp-pill'+(freq===x[0]?' on':'')+'" data-v="'+x[0]+'">'+x[1]+'</button>'; }).join('')+
      '</div>'+extra+'</div>'+
      '<div class="sp-grid2">'+
        '<div class="sp-row"><span class="sp-lb">Início</span><input type="date" id="spIni" value="'+esc(ini)+'"></div>'+
        '<div class="sp-row"><span class="sp-lb">Fim</span><input type="date" id="spFim" value="'+esc((t.rec_until||'').slice(0,10))+'"'+(semFim?' disabled':'')+'></div>'+
      '</div>'+
      '<label class="rec-check"><input type="checkbox" id="spSemFim"'+(semFim?' checked':'')+'><span>Sem data fim (roda pra sempre)</span></label>'+
      '<div class="rec-preview">Repete <b>'+esc(descrevePadraoRegra(t))+'</b>'+(t.rec_hora?(' às <b>'+esc(t.rec_hora)+'</b>'):'')+'.'+
        (t.rec_paused?' <b style="color:var(--u-amber)">Pausada no momento.</b>':'')+'<br><span style="opacity:.7">O sistema cria a tarefa de cada dia sozinho — ela aparece no Kanban e no Calendário.</span></div>';
    // ao mudar a regra, limpa as ocorrências futuras e regenera (evita fantasma da configuração antiga)
    function aplicaRec(patch){
      admPatch(id, patch, function(){
        sb.from('malba_vl_tasks').delete().eq('recur_group', t.recur_group).eq('is_rule', false).gt('due_date', today()).neq('status','feito').then(function(){
          ST.tasks=ST.tasks.filter(function(x){ return !(String(x.recur_group)===String(t.recur_group) && !x.is_rule && (x.due_date||'').slice(0,10)>today() && x.status!=='feito'); });
          if(typeof materializarRecorrencias==='function') materializarRecorrencias();
          spRenderRec();
        });
      });
    }
    var fbs=box.querySelectorAll('#spFreq .sp-pill');
    for(var i=0;i<fbs.length;i++) fbs[i].addEventListener('click', function(){
      var v=this.getAttribute('data-v'); if(v===t.recurrence) return;
      var p={ recurrence:v };
      if(v==='semanal') p.rec_weekdays=JSON.stringify([_dParse(ini).getDay()]);
      if(v!=='semanal') p.rec_weekdays=null;
      if(v!=='diaria') p.rec_dias_uteis=false;
      aplicaRec(p);
    });
    var u=box.querySelector('#spUteis'); if(u) u.addEventListener('change', function(){ aplicaRec({ rec_dias_uteis:this.checked }); });
    var wbs=box.querySelectorAll('.rec-wd-btn');
    for(var j=0;j<wbs.length;j++) wbs[j].addEventListener('click', function(){
      var d=+this.getAttribute('data-wd'), ix=wds.indexOf(d);
      if(ix===-1) wds.push(d); else if(wds.length>1) wds.splice(ix,1); else return;
      aplicaRec({ rec_weekdays:JSON.stringify(wds.slice().sort(function(a,b){return a-b;})) });
    });
    var dm=box.querySelector('#spDiaMes'); if(dm) dm.addEventListener('change', function(){
      var dia=Math.max(1,Math.min(31,+this.value||1)); var d=_dParse(ini);
      var novo=_dFmt(new Date(d.getFullYear(), d.getMonth(), dia, 12,0,0));
      aplicaRec({ rec_start:novo });
    });
    var ei=box.querySelector('#spIni'); if(ei) ei.addEventListener('change', function(){ aplicaRec({ rec_start:this.value||null }); });
    var ef=box.querySelector('#spFim'); if(ef) ef.addEventListener('change', function(){ aplicaRec({ rec_until:this.value||null }); });
    var sf=box.querySelector('#spSemFim'); if(sf) sf.addEventListener('change', function(){ aplicaRec({ rec_until:this.checked?null:fimDoAnoDe(ini) }); });
  }
  var bVirar=sp.querySelector('#spVirar');
  if(bVirar) bVirar.addEventListener('click', function(){ fechar(); openConverterRotina(id); });
  var bPause=sp.querySelector('#spPause');
  if(bPause) bPause.addEventListener('click', function(){
    var novo=!t.rec_paused;
    function vai(){ admPatch(id, { rec_paused:novo }, function(){ toast(novo?'Rotina pausada':'Rotina retomada','success'); fechar(); renderPage(); }); }
    if(novo) confirmDialog({ warn:true, icon:'pause', title:'Pausar rotina?', message:'Ela para de gerar novas tarefas até você retomar. As já criadas continuam.', confirmLabel:'Pausar', onConfirm:vai });
    else vai();
  });
  if(rule) sp.querySelector('#spRule').addEventListener('click', function(){ fechar(); openRotinaModal(rule); });

  // ações
  sp.querySelector('#spDup').addEventListener('click', function(){
    var novo={ title:(t.title||'')+' (cópia)', description:t.description||'', priority:t.priority||'media', status:'todo',
      due_date:t.due_date||today(), area:t.area||'', tags:t.tags||'', task_kind:t.task_kind||'normal',
      assignee_id:t.assignee_id||null, project_id:t.project_id||null, sector:ST.sector,
      created_by:ST.session.user.id, store_unit_id:t.store_unit_id||null };
    if(ehRegra){ // v83: duplicar a REGRA copia toda a configuração da rotina (pausada, pra você revisar antes)
      novo.is_rule=true; novo.recur_group=uid()+'-'+Date.now(); novo.recurrence=t.recurrence;
      novo.rec_start=t.rec_start||today(); novo.rec_until=t.rec_until||null; novo.rec_dias_uteis=!!t.rec_dias_uteis;
      novo.rec_weekdays=t.rec_weekdays||null; novo.rec_hora=t.rec_hora||null; novo.rec_paused=true; novo.status='todo';
    }
    if(subs.length) novo.subtasks=subs.map(function(s){ return { id:uid(), text:s.text, done:false }; });
    var b=this; setBusy(b,true);
    sb.from('malba_vl_tasks').insert(novo).select().single().then(function(r){
      setBusy(b,false);
      if(r.error||!r.data){ toast('Erro ao duplicar','error'); console.error(r.error); return; }
      ST.tasks.unshift(r.data); toast('Tarefa duplicada','success'); fechar(); renderPage();
    });
  });
  sp.querySelector('#spArch').addEventListener('click', function(){
    confirmDialog({ warn:true, icon:'archive', title:'Arquivar tarefa?', message:'Ela sai da operação mas continua no histórico. Dá pra reverter no banco.', confirmLabel:'Arquivar', onConfirm:function(){
      admPatch(id, { archived_at:new Date().toISOString() }, function(){ toast('Tarefa arquivada','success'); fechar(); renderPage(); });
    }});
  });
  sp.querySelector('#spDel').addEventListener('click', function(){
    confirmDelete('Excluir a tarefa "'+(t.title||'')+'"?', function(){
      sb.from('malba_vl_tasks').delete().eq('id', id).then(function(r){
        if(r.error){ toast('Erro ao excluir','error'); return; }
        ST.tasks=ST.tasks.filter(function(x){ return String(x.id)!==String(id); });
        toast('Tarefa excluída','success'); fechar(); renderPage();
      });
    });
  });
  setTimeout(function(){ var el=sp.querySelector('#spTitle'); if(el) el.blur(); }, 10);
}


function gestaoTabsForSector(){
  var s=ST.sector, T=[];
  function add(id,label,ic){ T.push({id:id,label:label,icon:ic}); }
  if(isAdmin(ST.session)) add('tarefas','Rotinas da equipe','tasks'); // v79: central de administração de tarefas
  if(s==='lojas'){ add('visao','Visão geral','dashboard'); add('metas','Metas','target'); add('relatorio','Relatório','trend'); add('comissoes','Comissões','dollar'); add('avaliacoes','Avaliações','target'); add('solicitacoes','Solicitações','bell'); add('atividade','Atividade','search'); }
  else if(s==='marketing'){ add('metas','Metas','target'); add('relatorio','Relatório','trend'); add('orcamento','Orçamento','dollar'); add('atividade','Atividade','search'); }
  else if(s==='vendas'){ add('metas','Metas','target'); add('ranking','Ranking','trend'); add('atividade','Atividade','search'); }
  else { add('atividade','Atividade','search'); }
  return T;
}
function gestaoHTML() {
  if (!can('indicadores')) {
    return emptyState({ icon:'target', title:'Acesso restrito', text:'Esta área é para Supervisores, Gestores e Administradores.' });
  }
  var T=gestaoTabsForSector(); var ids=T.map(function(x){return x.id;});
  var tab = ST.gestaoTab || ids[0];
  if (ids.indexOf(tab)===-1){ tab=ids[0]; ST.gestaoTab=tab; } // v74: valida a aba pro setor atual
  var pend = pendingRequests().length;
  var tabs = '<div class="cfg-tabs">'+T.map(function(x){
    var badge = (x.id==='solicitacoes' && pend>0) ? ' <span class="tab-badge">'+pend+'</span>' : '';
    return '<button class="cfg-tab'+(tab===x.id?' on':'')+'" data-gtab="'+x.id+'">'+icon(x.icon)+x.label+badge+'</button>';
  }).join('')+'</div>';
  var body;
  if (tab==='tarefas') body=admTarefasHTML();
  else if (tab==='metas') body=metasHTML();
  else if (tab==='relatorio') body=(ST.sector==='lojas'?relatorioLojasHTML():relatorioHTML());
  else if (tab==='ranking') body=rankingHTML();
  else if (tab==='orcamento') body=orcamentoHTML();
  else if (tab==='avaliacoes') body=avaliacoesHTML();
  else if (tab==='atividade') body=atividadeHTML();
  else if (tab==='comissoes') body=comissoesHTML();
  else if (tab==='solicitacoes') body=solicitacoesHTML();
  else body=visaoGeralHTML();
  return '<div class="tasks-head"><div><h2>Gestão</h2><div class="sub">Metas, resultados e gestão do setor</div></div></div>'+tabs+'<div id="gestaoBody">'+body+'</div>';
}
function gestaoStats(filterFn){
  var hoje=today(); var o={abertas:0,atrasadas:0,concluidas:0,total:0};
  ST.tasks.forEach(function(t){
    if(t.is_rule) return; // v70
    if(t.recur_group && (t.due_date||'').slice(0,10)>hoje) return; // v71: ocorrência futura de rotina não conta como aberta
    if(!filterFn(t)) return;
    o.total++;
    var d=(t.due_date||'').slice(0,10);
    if(t.status==='feito') o.concluidas++;
    else { o.abertas++; if(d && d<hoje) o.atrasadas++; }
  });
  return o;
}
function lojaAvalMedia(lojaId){
  var soma=0,n=0;
  ST.avaliacoes.forEach(function(a){ if(String(a.store_unit_id)===String(lojaId) && a.nota_final!=null){ soma+=Number(a.nota_final); n++; } });
  return n? (soma/n):null;
}
function visaoGeralHTML(){
  function vgk(l,v,c){ return '<div class="vg-kpi"><div class="vg-kpi-v" style="color:'+c+'">'+v+'</div><div class="vg-kpi-l">'+l+'</div></div>'; }
  var lojas = lojasGestao();
  var selLoja = ST.gestaoStore||'';
  var lojaFilter = function(t){ return selLoja ? String(t.store_unit_id)===String(selLoja) : true; };
  var k = gestaoStats(lojaFilter);
  var sopts='<option value="">Todas as lojas</option>'+lojas.map(function(s){ return '<option value="'+esc(s.id)+'"'+(String(selLoja)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>'; }).join('');
  var vendasMesTotal=0; (ST.salesEntries||[]).forEach(function(e){ if(_inMonth(e.sale_date) && (!selLoja || String(e.store_unit_id)===String(selLoja))) vendasMesTotal+=Number(e.value)||0; });
  var kpis = '<div class="vg-kpis">'+
    vgk('Vendas (mês)', brlShort(vendasMesTotal), 'var(--u-green)')+
    vgk('Tarefas abertas', k.abertas, 'var(--u-accent)')+
    vgk('Atrasadas', k.atrasadas, 'var(--u-red)')+
    vgk('Concluídas', k.concluidas, 'var(--u-text2)')+
    vgk('Colaboradores', ST.users.length, 'var(--u-purple)')+
  '</div>';
  var lojasShow = selLoja ? lojas.filter(function(s){return String(s.id)===String(selLoja);}) : lojas;
  var lojaCards = lojasShow.map(function(s){
    var st=gestaoStats(function(t){ return String(t.store_unit_id)===String(s.id); });
    var media=lojaAvalMedia(s.id);
    var nf=membrosDaLoja(s.id).length;
    var ncom=ST.comissoes.filter(function(c){return String(c.store_unit_id)===String(s.id);}).length;
    return '<button class="vg-loja" data-vgloja="'+esc(s.id)+'">'+
      '<div class="vg-loja-h"><b>'+esc(s.name||('Loja '+s.store_number))+'</b>'+(media!=null?'<span class="vg-stars">★ '+media.toFixed(1)+'</span>':'')+'</div>'+
      '<div class="vg-loja-stats"><span><i style="color:var(--u-accent)">'+st.abertas+'</i>abertas</span><span><i style="color:var(--u-red)">'+st.atrasadas+'</i>atrasadas</span><span><i style="color:var(--u-green)">'+st.concluidas+'</i>feitas</span></div>'+
      '<div class="vg-loja-foot">'+nf+' funcionários · '+ncom+' comissões · ver tarefas →</div>'+
    '</button>';
  }).join('') || '<div class="col-empty">Nenhuma loja cadastrada.</div>';
  var colabRows = ST.users.map(function(u){
    var vendas=0; (ST.salesEntries||[]).forEach(function(e){ if(String(e.user_id)===String(u.id) && _inMonth(e.sale_date) && (!selLoja||String(e.store_unit_id)===String(selLoja))) vendas+=Number(e.value)||0; });
    return { u:u, st:gestaoStats(function(t){ return String(t.assignee_id)===String(u.id) && lojaFilter(t); }), vendas:vendas };
  }).filter(function(r){ return r.st.total>0 || r.vendas>0; }).sort(function(a,b){ return b.vendas-a.vendas || b.st.atrasadas-a.st.atrasadas || b.st.abertas-a.st.abertas; });
  var colabHTML = colabRows.length ? colabRows.map(function(r){
    return '<button class="vg-colab" data-vgcolab="'+esc(r.u.id)+'">'+
      '<span class="vg-colab-av" style="background:'+(r.u.color||'#3B6FF7')+'">'+esc(iniciais(r.u.name||'?'))+'</span>'+
      '<span class="vg-colab-name">'+esc(r.u.name||'')+'</span>'+
      '<span class="vg-colab-st">'+(r.vendas>0?'<i style="color:var(--u-green)">'+brlShort(r.vendas)+'</i> vendas · ':'')+'<i style="color:var(--u-red)">'+r.st.atrasadas+'</i> atrasadas · <i style="color:var(--u-accent)">'+r.st.abertas+'</i> abertas · <i style="color:var(--u-green)">'+r.st.concluidas+'</i> feitas</span>'+
    '</button>';
  }).join('') : '<div class="col-empty">Sem tarefas atribuídas ainda.</div>';
  return '<div class="vg-filterbar"><label class="vg-fl">Filtrar loja</label><select class="task-filter" id="vgLoja">'+sopts+'</select></div>'+
    kpis+
    '<div class="cfg-sec-head"><span>Por loja</span><span style="font-size:12px;color:var(--u-text3)">clique para ver as tarefas</span></div><div class="vg-lojas">'+lojaCards+'</div>'+
    '<div class="cfg-sec-head"><span>Por colaborador</span><span style="font-size:12px;color:var(--u-text3)">vendas do mês + tarefas</span></div><div class="vg-colabs">'+colabHTML+'</div>';
}
function atividadeHTML() {
  var escopo = isTopAdmin(ST.session) ? 'Todas as ações registradas no sistema' : ('Ações do setor '+(SECTORS[ST.sector]?SECTORS[ST.sector].label:''));
  return '<div class="cfg-sec-head"><span>Histórico de atividades</span><span style="font-size:12px;color:var(--u-text3)">'+escopo+'</span></div>'+
    '<div id="atvList" class="atv-list"><div class="atv-loading">Carregando atividades…</div></div>';
}

/* ----- Comissões ----- */
function comissoesHTML() {
  var list = ST.comissoes.slice();
  if (ST.sector==='lojas' && ST.store && !isSuper(ST.session)) list = list.filter(function(c){ return c.store_unit_id===ST.store.id; });
  var totalPago = list.reduce(function(s,c){ return s+(Number(c.total_comissao)||0); },0);
  var totalVendas = list.reduce(function(s,c){ return s+(Number(c.vendas_total)||0); },0);
  var summary = list.length ? '<div class="gestao-summary"><div class="gs-card"><span>Total em comissões</span><b>'+fmtBRL(totalPago)+'</b></div><div class="gs-card"><span>Vendas no período</span><b>'+fmtBRL(totalVendas)+'</b></div><div class="gs-card"><span>Lançamentos</span><b>'+list.length+'</b></div></div>' : '';
  var rows='';
  if (list.length===0) {
    rows = '<div class="empty-page"><div class="ep-ico">'+icon('dollar')+'</div><h3>Nenhuma comissão</h3><p>Lance as vendas e o sistema calcula a comissão de cada funcionário.</p></div>';
  } else {
    rows = '<div class="cfg-list">';
    list.forEach(function(c){
      var loja = storeName(c.store_unit_id) || 'Loja';
      var periodo = c.periodo_label || ((c.periodo_inicio?fmtDate(c.periodo_inicio):'')+(c.periodo_fim?(' a '+fmtDate(c.periodo_fim)):''));
      var n=(c.rateio||[]).length;
      rows += '<div class="com-row" data-cid="'+esc(c.id)+'">'+
        '<div class="crm-main"><b>'+esc(loja)+(periodo?' · '+esc(periodo):'')+'</b><i>Vendas '+fmtBRL(c.vendas_total)+' · '+n+' pessoa(s)</i></div>'+
        '<span class="com-val">'+fmtBRL(c.total_comissao)+'</span>'+
      '</div>';
    });
    rows += '</div>';
  }
  return '<div class="cfg-sec-head"><span>'+list.length+' lançamento(s)</span>'+(canEdit()?'<button class="btn-new" id="btnNovaComissao">'+icon('plus')+'Lançar comissões</button>':'')+'</div>'+summary+rows;
}

function openComissaoModal() {
  if(!canEdit()){ blockManage(); return; }
  var ls = lojasGestao();
  if (ls.length===0) { toast('Cadastre lojas primeiro','error'); return; }
  var mode='individual';
  function parseNum(s){ return parseFloat(String(s||'').replace(/\./g,'').replace(',', '.')) || 0; }

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<div class="modal-title-input" style="cursor:default">Lançar comissões</div>'+
      '<div class="modal-row"><label class="modal-label">Loja</label><select id="comLoja">'+ls.map(function(l){return '<option value="'+esc(l.id)+'">'+esc(l.name||('Loja '+l.store_number))+'</option>';}).join('')+'</select></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Início</label><input type="date" id="comIni" value="'+today()+'"></div><div class="modal-row"><label class="modal-label">Fim</label><input type="date" id="comFim" value="'+today()+'"></div></div>'+
      '<div class="modal-row"><label class="modal-label">Rótulo do período (opcional)</label><input type="text" id="comLabel" placeholder="ex: Semana 1 de Junho"></div>'+
      '<div class="modal-row"><label class="modal-label">Modelo de comissão</label><div class="pills" id="comMode"><button type="button" class="pill cm-pill on" data-m="individual">Individual</button><button type="button" class="pill cm-pill" data-m="rateio">Rateio igual</button></div><div class="com-mode-hint" id="comHint"></div></div>'+
      '<div id="comBody"></div>'+
      '<div class="com-total" id="comTotal"></div>'+
      '<div class="modal-foot"><button class="btn btn-ghost" id="comCancel">Cancelar</button><button class="btn btn-primary" id="comSave">Calcular e salvar</button></div>'+
    '</div>';
  document.body.appendChild(modal);

  var body=modal.querySelector('#comBody');
  function setHint(){ modal.querySelector('#comHint').textContent = mode==='individual' ? 'Cada funcionário ganha sobre as próprias vendas (o mais usado no varejo).' : 'Um valor total dividido igualmente entre a equipe ativa.'; }
  function renderBody(){
    var membros=membrosDaLoja(modal.querySelector('#comLoja').value);
    setHint();
    if (membros.length===0){ body.innerHTML='<div class="com-prev-empty" style="color:var(--u-amber)">Esta loja não tem funcionários ativos. Cadastre em Equipe.</div>'; modal.querySelector('#comTotal').innerHTML=''; return; }
    if (mode==='individual'){
      body.innerHTML =
        '<div class="modal-row"><label class="modal-label">% padrão (aplica a quem não tiver % próprio)</label><input type="text" id="comPctPadrao" inputmode="decimal" value="5"></div>'+
        '<div class="com-emp-head"><span>Funcionário</span><span>Vendas R$</span><span>%</span><span>Comissão</span></div>'+
        '<div class="com-emp-list">'+membros.map(function(m){
          return '<div class="com-emp-row">'+
            '<span class="com-emp-n"><span class="com-pessoa-av" style="background:'+(m.color||'#3B6FF7')+'">'+esc(iniciais(m.name))+'</span><span class="cen-txt">'+esc(m.name)+(m.role?'<i>'+esc(m.role)+'</i>':'')+'</span></span>'+
            '<input type="text" class="com-emp-base" data-mid="'+esc(m.id)+'" inputmode="decimal" placeholder="0">'+
            '<input type="text" class="com-emp-pct" data-mid="'+esc(m.id)+'" inputmode="decimal" placeholder="5">'+
            '<b class="com-emp-val" data-mid="'+esc(m.id)+'">R$ 0,00</b>'+
          '</div>';
        }).join('')+'</div>';
      var ins=modal.querySelectorAll('.com-emp-base,.com-emp-pct'); for(var i=0;i<ins.length;i++) ins[i].addEventListener('input', recomp);
      modal.querySelector('#comPctPadrao').addEventListener('input', recomp);
    } else {
      body.innerHTML='<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Total de vendas (R$)</label><input type="text" id="comVendas" inputmode="decimal" placeholder="0,00"></div><div class="modal-row"><label class="modal-label">% de comissão</label><input type="text" id="comPct" inputmode="decimal" value="5"></div></div><div class="com-preview" id="comPrev"></div>';
      modal.querySelector('#comVendas').addEventListener('input', recomp);
      modal.querySelector('#comPct').addEventListener('input', recomp);
    }
    recomp();
  }
  function recomp(){
    var membros=membrosDaLoja(modal.querySelector('#comLoja').value);
    var totalEl=modal.querySelector('#comTotal');
    if (membros.length===0){ totalEl.innerHTML=''; return; }
    if (mode==='individual'){
      var padrao=parseNum(modal.querySelector('#comPctPadrao').value);
      var total=0, vendas=0;
      var bases=modal.querySelectorAll('.com-emp-base');
      for (var i=0;i<bases.length;i++){
        var mid=bases[i].getAttribute('data-mid');
        var pctEl=modal.querySelector('.com-emp-pct[data-mid="'+mid+'"]');
        var pct=(pctEl && pctEl.value.trim()!=='')?parseNum(pctEl.value):padrao;
        var base=parseNum(bases[i].value);
        var val=base*pct/100; total+=val; vendas+=base;
        var vEl=modal.querySelector('.com-emp-val[data-mid="'+mid+'"]'); if(vEl) vEl.textContent=fmtBRL(val);
      }
      totalEl.innerHTML='Comissão total: <b>'+fmtBRL(total)+'</b> · Vendas lançadas '+fmtBRL(vendas);
    } else {
      var vendas2=parseNum(modal.querySelector('#comVendas').value);
      var pct2=parseNum(modal.querySelector('#comPct').value);
      var prev=modal.querySelector('#comPrev');
      if (vendas2<=0||pct2<=0){ prev.innerHTML='<div class="com-prev-empty">Preencha vendas e % para ver o rateio.</div>'; totalEl.innerHTML=''; return; }
      var total2=vendas2*pct2/100, por=total2/membros.length;
      prev.innerHTML=membros.map(function(m){ return '<div class="com-prev-row"><span class="com-pessoa-av" style="background:'+(m.color||'#3B6FF7')+'">'+esc(iniciais(m.name))+'</span><span style="flex:1">'+esc(m.name)+(m.role?' · '+esc(m.role):'')+'</span><b>'+fmtBRL(por)+'</b></div>'; }).join('');
      totalEl.innerHTML='Comissão total: <b>'+fmtBRL(total2)+'</b> · dividida entre '+membros.length+' pessoa(s)';
    }
  }

  modal.querySelector('#comLoja').addEventListener('change', renderBody);
  var pills=modal.querySelectorAll('.cm-pill');
  for (var p=0;p<pills.length;p++) pills[p].addEventListener('click', function(){ mode=this.getAttribute('data-m'); for(var x=0;x<pills.length;x++) pills[x].classList.remove('on'); this.classList.add('on'); renderBody(); });
  renderBody();

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#comCancel').addEventListener('click', close);

  modal.querySelector('#comSave').addEventListener('click', function(){
    var lojaId=modal.querySelector('#comLoja').value;
    var membros=membrosDaLoja(lojaId);
    if (membros.length===0){ toast('Esta loja não tem funcionários cadastrados','error'); return; }
    var rateio=[], vendasTotal=0, totalCom=0, pctRef=0;
    if (mode==='individual'){
      var padrao=parseNum(modal.querySelector('#comPctPadrao').value); pctRef=padrao;
      membros.forEach(function(m){
        var bi=modal.querySelector('.com-emp-base[data-mid="'+m.id+'"]');
        var pi=modal.querySelector('.com-emp-pct[data-mid="'+m.id+'"]');
        var base=parseNum(bi?bi.value:0);
        var pct=(pi&&pi.value.trim()!=='')?parseNum(pi.value):padrao;
        var val=Math.round(base*pct/100*100)/100;
        vendasTotal+=base; totalCom+=val;
        rateio.push({ member_id:m.id, nome:m.name, role:m.role||'', base:Math.round(base*100)/100, percentual:pct, valor:val });
      });
      if (totalCom<=0){ toast('Informe as vendas de pelo menos um funcionário','error'); return; }
    } else {
      var vendas=parseNum(modal.querySelector('#comVendas').value);
      var pct=parseNum(modal.querySelector('#comPct').value);
      if (vendas<=0){ toast('Informe o total de vendas','error'); return; }
      if (pct<=0){ toast('Informe o %','error'); return; }
      pctRef=pct; vendasTotal=vendas; totalCom=Math.round(vendas*pct/100*100)/100;
      var por=totalCom/membros.length;
      rateio=membros.map(function(m){ return { member_id:m.id, nome:m.name, role:m.role||'', base:null, percentual:pct, valor:Math.round(por*100)/100 }; });
    }
    var rec={ sector:'lojas', store_unit_id:lojaId, periodo_inicio:modal.querySelector('#comIni').value||null, periodo_fim:modal.querySelector('#comFim').value||null, periodo_label:(modal.querySelector('#comLabel').value||'').trim()||null, vendas_total:Math.round(vendasTotal*100)/100, percentual:pctRef, total_comissao:Math.round(totalCom*100)/100, rateio:rateio, created_by:ST.session.user.id };
    var saveBtn=modal.querySelector('#comSave'); setBusy(saveBtn,true);
    sb.from('malba_comissoes').insert(rec).select().single().then(function(r){
      if (r.error||!r.data){ toast('Erro ao salvar comissão','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Calcular e salvar'; return; }
      ST.comissoes.unshift(r.data); auditLog('Lançou comissão', (storeName(lojaId)||'Loja')); close(); toast('Comissão salva','success'); renderPage();
    });
  });
}

function comissaoDetalhe(c) {
  if(!canEdit()){ blockManage(); return; }
  var loja=storeName(c.store_unit_id)||'Loja';
  var periodo=c.periodo_label||((c.periodo_inicio?fmtDate(c.periodo_inicio):'')+(c.periodo_fim?(' a '+fmtDate(c.periodo_fim)):''));
  var rows=(c.rateio||[]).map(function(r){
    var det = (r.base!=null && r.base!==undefined) ? ('Vendas '+fmtBRL(r.base)+(r.percentual!=null?' · '+r.percentual+'%':'')) : (r.percentual!=null?(r.percentual+'% (rateio)'):'rateio');
    return '<div class="com-prev-row"><span class="com-pessoa-av" style="background:#3B6FF7">'+esc(iniciais(r.nome))+'</span><span style="flex:1">'+esc(r.nome)+(r.role?' · '+esc(r.role):'')+'<small style="display:block;color:var(--u-text3);font-size:11px">'+esc(det)+'</small></span><b>'+fmtBRL(r.valor)+'</b></div>';
  }).join('');
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal">'+
    '<div class="modal-title-input" style="cursor:default">'+esc(loja)+'</div>'+
    (periodo?'<div style="font-size:13px;color:var(--u-text3);margin:-6px 0 10px">'+esc(periodo)+'</div>':'')+
    '<div class="modal-row"><label class="modal-label">Rótulo do período (editável)</label><input type="text" id="comDetLabel" placeholder="ex: Semana 1 de Junho" value="'+esc(c.periodo_label||'')+'"></div>'+
    '<div class="com-det-totals"><div><span>Vendas</span><b>'+fmtBRL(c.vendas_total)+'</b></div><div><span>Comissão total</span><b style="color:var(--u-green)">'+fmtBRL(c.total_comissao)+'</b></div></div>'+
    '<div class="com-preview">'+rows+'</div>'+
    '<div class="modal-foot"><button class="btn btn-danger btn-del-wrap" id="comDel">Excluir</button><button class="btn btn-ghost" id="comDetClose">Fechar</button><button class="btn btn-primary" id="comDetSave">Salvar</button></div>'+
  '</div>';
  document.body.appendChild(modal);
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click',function(e){ if(e.target===modal) close(); });
  modal.querySelector('#comDetClose').addEventListener('click', close);
  modal.querySelector('#comDetSave').addEventListener('click', function(){
    var lbl=(modal.querySelector('#comDetLabel').value||'').trim()||null;
    var btn=this; setBusy(btn,true);
    sb.from('malba_comissoes').update({ periodo_label:lbl }).eq('id', c.id).then(function(r){
      if(r.error){ toast('Erro ao salvar','error'); setBusy(btn,false); btn.textContent='Salvar'; return; }
      c.periodo_label=lbl;
      for(var x=0;x<ST.comissoes.length;x++) if(ST.comissoes[x].id===c.id){ ST.comissoes[x].periodo_label=lbl; break; }
      auditLog('Editou comissão', (storeName(c.store_unit_id)||'Loja')); close(); toast('Atualizado','success'); renderPage();
    });
  });
  modal.querySelector('#comDel').addEventListener('click', function(){
    confirmDelete('Excluir este lançamento de comissão?', function(){ sb.from('malba_comissoes').delete().eq('id', c.id).then(function(r){
      if(r.error){ toast('Erro ao excluir','error'); return; }
      ST.comissoes=ST.comissoes.filter(function(x){return x.id!==c.id;});
      auditLog('Excluiu comissão', (storeName(c.store_unit_id)||'Loja')); close(); toast('Comissão excluída','success'); renderPage();
    }); });
  });
}

/* ----- Avaliações ----- */
function avaliacoesHTML() {
  var list = ST.avaliacoes.slice();
  if (ST.sector==='lojas' && ST.store && !isSuper(ST.session)) list = list.filter(function(a){ return a.store_unit_id===ST.store.id; });
  var rows='';
  if (list.length===0) {
    rows = emptyState({ icon:'target', title:'Nenhuma avaliação', text:'Avalie o desempenho das lojas e dos funcionários periodicamente.', cta:(canEdit()?'Nova avaliação':'') });
  } else {
    rows = '<div class="cfg-list">';
    list.forEach(function(a){
      var alvo;
      if (a.tipo==='membro') { var mm=null; for(var i=0;i<ST.members.length;i++) if(ST.members[i].id===a.member_id){mm=ST.members[i];break;} alvo = mm?mm.name:'Funcionário'; }
      else alvo = storeName(a.store_unit_id) || 'Loja';
      var stars = renderStarsRO(a.nota_final);
      rows += '<div class="aval-row" data-aid="'+esc(a.id)+'" style="cursor:pointer">'+
        '<span class="aval-tipo" style="background:'+(a.tipo==='membro'?'var(--u-accent-soft)':'var(--u-green-soft)')+';color:'+(a.tipo==='membro'?'var(--u-accent)':'var(--u-green)')+'">'+(a.tipo==='membro'?'Funcionário':'Loja')+'</span>'+
        '<div class="crm-main"><b>'+esc(alvo)+'</b><i>'+(a.periodo_label?esc(a.periodo_label)+' · ':'')+fmtDate(a.data_avaliacao)+'</i></div>'+
        '<span class="aval-stars">'+stars+' <b>'+(Number(a.nota_final)||0).toFixed(1)+'</b></span>'+
      '</div>';
    });
    rows += '</div>';
  }
  return '<div class="cfg-sec-head"><span>'+list.length+' avaliação(ões)</span>'+(canEdit()?'<button class="btn-new" id="btnNovaAvaliacao">'+icon('plus')+'Nova avaliação</button>':'')+'</div>'+rows;
}
function renderStarsRO(nota) {
  var n=Math.round(Number(nota)||0); var s='';
  for (var i=1;i<=5;i++) s += '<span class="star-ro'+(i<=n?' on':'')+'">★</span>';
  return s;
}

function openAvaliacaoModal(aval, preset) {
  if(!canEdit()){ blockManage(); return; }
  var ls = lojasGestao();
  if (ls.length===0) { toast('Cadastre lojas primeiro','error'); return; }
  var editing = !!aval;
  var tipo = editing ? (aval.tipo||'membro') : ((preset&&preset.tipo)||'membro');
  var step = 1;
  var pendingCrit = '';
  var curLoja = editing ? (aval.store_unit_id||ls[0].id) : ((preset&&preset.store_unit_id)||ls[0].id);
  var curMem = editing ? (aval.member_id||null) : ((preset&&preset.member_id)||null);
  var now=new Date();
  var refM = now.getMonth()+1, refY = now.getFullYear();
  if (editing) {
    if (aval.periodo_inicio) { var pp=String(aval.periodo_inicio).slice(0,10).split('-'); refY=Number(pp[0])||refY; refM=Number(pp[1])||refM; }
    else if (aval.data_avaliacao) { var dd=String(aval.data_avaliacao).slice(0,10).split('-'); refY=Number(dd[0])||refY; refM=Number(dd[1])||refM; }
  }
  var form = {
    data_aval: editing ? (aval.data_avaliacao||today()) : today(),
    ref_month: refM, ref_year: refY,
    obs: editing?(aval.observacao||''):'',
    fortes: editing?(aval.pontos_fortes||''):'',
    desenvolver: editing?(aval.pontos_desenvolver||''):'',
    plano: editing?(aval.plano_acao||''):''
  };

  function defaultsFor(tp){ return (tp==='loja'?CRIT_LOJA:CRIT_MEMBRO).map(function(c){ return {id:c.id,label:c.label,nota:0}; }); }
  function parseCrit(){
    if (editing) {
      var sn=aval.notas;
      if (Array.isArray(sn)) { var a=[]; sn.forEach(function(it){ if(it&&it.id!=null) a.push({id:String(it.id),label:it.label||'Critério',nota:Number(it.nota)||0}); }); if(a.length) return a; }
      else if (sn && typeof sn==='object') {
        var labels=sn._labels||{}; var list=defaultsFor(tipo); var seen={};
        list.forEach(function(c){ seen[c.id]=1; c.label=labels[c.id]||c.label; c.nota=Number(sn[c.id])||0; });
        Object.keys(sn).forEach(function(k){ if(k==='_labels'||seen[k]) return; list.push({id:String(k),label:labels[k]||'Critério',nota:Number(sn[k])||0}); });
        return list;
      }
    }
    return defaultsFor(tipo);
  }
  var critList = parseCrit();
  if(tipo==='membro' && !curMem){ var mm0=membrosDaLoja(curLoja); if(mm0.length) curMem=mm0[0].id; }

  function alvoLabel(){
    if (tipo==='membro'){ var mm=null; for(var i=0;i<ST.members.length;i++) if(String(ST.members[i].id)===String(curMem)){mm=ST.members[i];break;} return mm?mm.name:'Funcionário'; }
    return storeName(curLoja)||'Loja';
  }
  function mediaAtual(){ var soma=0,n=0; critList.forEach(function(c){ if(c.nota>0){ soma+=c.nota; n++; } }); return n>0?(soma/n):0; }

  function stepperHTML(){
    var steps=['Quem e quando','Competências','Feedback','Resumo'];
    return '<div class="aval-steps">'+steps.map(function(s,i){ var n=i+1; var cls=n===step?'on':(n<step?'done':''); return '<div class="aval-step '+cls+'"><span class="as-num">'+(n<step?'✓':n)+'</span><span class="as-lb">'+s+'</span></div>'; }).join('<span class="as-sep"></span>')+'</div>';
  }

  function step1HTML(){
    var lojaOpts = ls.map(function(l){ return '<option value="'+esc(l.id)+'"'+(String(curLoja)===String(l.id)?' selected':'')+'>'+esc(l.name||('Loja '+l.store_number))+'</option>'; }).join('');
    var moOpts=''; for(var mo=1;mo<=12;mo++) moOpts+='<option value="'+mo+'"'+(form.ref_month===mo?' selected':'')+'>'+MESES[mo-1]+'</option>';
    var periodo = '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Período avaliado</label><div class="ref-per"><select id="avMonth">'+moOpts+'</select><input type="text" id="avYear" inputmode="numeric" value="'+esc(form.ref_year)+'"></div></div><div class="modal-row"><label class="modal-label">Data da avaliação</label><input type="date" id="avDate" value="'+esc(form.data_aval)+'"></div></div>';
    if (editing) {
      return '<div class="aval-lock"><span class="aval-lock-ic">'+icon('target')+'</span><div class="aval-lock-tx"><b>'+esc(alvoLabel())+'</b><i>'+(tipo==='membro'?('Funcionário · '+esc(storeName(curLoja)||'')):'Loja')+'</i></div><span class="aval-lock-tag">alvo fixo</span></div>'+
        '<div class="modal-note">Para avaliar outra pessoa, feche e clique em "Nova avaliação". Assim nenhuma avaliação é sobrescrita.</div>'+
        periodo;
    }
    var tipoPills='<div class="modal-row"><label class="modal-label">O que você vai avaliar?</label><div class="pills" id="avTipo"><button type="button" class="pill av-tp'+(tipo==='membro'?' on':'')+'" data-tp="membro" style="color:var(--u-accent)"><span class="pdot" style="background:var(--u-accent)"></span>Funcionário</button><button type="button" class="pill av-tp'+(tipo==='loja'?' on':'')+'" data-tp="loja" style="color:var(--u-green)"><span class="pdot" style="background:var(--u-green)"></span>Loja</button></div></div>';
    var lojaRow='<div class="modal-row"><label class="modal-label">Loja</label><select id="avLoja">'+lojaOpts+'</select></div>';
    var membroBlock='';
    if (tipo==='membro') {
      var mem = membrosDaLoja(curLoja);
      var memOpts = mem.length ? mem.map(function(m){ return '<option value="'+esc(m.id)+'"'+(String(curMem)===String(m.id)?' selected':'')+'>'+esc(m.name)+'</option>'; }).join('') : '<option value="">Sem funcionários nesta loja</option>';
      membroBlock = '<div class="modal-row"><label class="modal-label">Funcionário</label><select id="avMembro">'+memOpts+'</select></div>';
    }
    return tipoPills+lojaRow+membroBlock+periodo;
  }

  function step2HTML(){
    var critHTML = critList.map(function(c,idx){
      var stars='';
      for (var i=1;i<=5;i++) stars += '<button type="button" class="star-pick'+(i<=c.nota?' on':'')+'" data-cidx="'+idx+'" data-val="'+i+'" title="'+SCALE_LABELS[i]+'">★</button>';
      return '<div class="aval-crit">'+
        '<input type="text" class="aval-crit-name" data-cidx="'+idx+'" value="'+esc(c.label)+'" maxlength="60" placeholder="Nome do critério">'+
        '<div class="aval-crit-right">'+
          '<div class="aval-stars-pick">'+stars+'</div>'+
          '<div class="aval-crit-tools">'+
            '<button type="button" class="aval-crit-mv" data-mvup="'+idx+'" title="Subir"'+(idx===0?' disabled':'')+'>↑</button>'+
            '<button type="button" class="aval-crit-mv" data-mvdn="'+idx+'" title="Descer"'+(idx===critList.length-1?' disabled':'')+'>↓</button>'+
            '<button type="button" class="aval-crit-del" data-rmcrit="'+idx+'" title="Remover critério">✕</button>'+
          '</div>'+
        '</div>'+
        (c.nota>0?'<div class="aval-crit-lb">'+SCALE_LABELS[c.nota]+'</div>':'')+
      '</div>';
    }).join('');
    var n=0; critList.forEach(function(c){ if(c.nota>0) n++; }); var media=mediaAtual();
    return '<div class="aval-scale-leg">1 Insuficiente · 2 Abaixo · 3 Adequado · 4 Bom · 5 Excelente</div>'+
      '<div class="aval-crits">'+critHTML+'</div>'+
      '<div class="aval-add"><input type="text" id="avNewCrit" placeholder="Adicionar critério (ex: Apresentação pessoal)" maxlength="60" value="'+esc(pendingCrit)+'"><button type="button" class="btn-add-crit" id="avAddCrit">+ Adicionar</button></div>'+
      '<div class="aval-media" id="avMedia">'+(n>0?('Média parcial: '+media.toFixed(1)+' de 5'):'Média: —')+'</div>';
  }

  function step3HTML(){
    return '<div class="modal-row"><label class="modal-label">Pontos fortes</label><textarea id="avFortes" placeholder="O que a pessoa/loja faz muito bem...">'+esc(form.fortes)+'</textarea></div>'+
      '<div class="modal-row"><label class="modal-label">Pontos a desenvolver</label><textarea id="avDesenv" placeholder="Onde precisa evoluir...">'+esc(form.desenvolver)+'</textarea></div>'+
      '<div class="modal-row"><label class="modal-label">Plano de ação / próximos passos (PDI)</label><textarea id="avPlano" placeholder="Ações combinadas, com prazos...">'+esc(form.plano)+'</textarea></div>'+
      '<div class="modal-row"><label class="modal-label">Observações gerais (opcional)</label><textarea id="avObs" placeholder="Comentários adicionais...">'+esc(form.obs)+'</textarea></div>';
  }

  function step4HTML(){
    var clean = critList.filter(function(c){ return (c.label||'').trim()!=='' && c.nota>0; }).map(function(c){ return {id:c.id,label:(c.label||'').trim(),nota:c.nota}; });
    var media=mediaAtual(); var diag=diagnostico(media);
    var blocks='';
    if((form.fortes||'').trim()) blocks+='<div class="asum-block fortes"><h5>Pontos fortes</h5><p>'+esc(form.fortes)+'</p></div>';
    if((form.desenvolver||'').trim()) blocks+='<div class="asum-block desenv"><h5>Pontos a desenvolver</h5><p>'+esc(form.desenvolver)+'</p></div>';
    if((form.plano||'').trim()) blocks+='<div class="asum-block plano"><h5>Plano de ação (PDI)</h5><p>'+esc(form.plano)+'</p></div>';
    return '<div class="aval-sum-head"><div><b>'+esc(alvoLabel())+'</b><i>'+MESES[form.ref_month-1]+' '+form.ref_year+' · avaliado em '+fmtDate(form.data_aval)+'</i></div></div>'+
      '<div class="aval-summary">'+
        '<div class="asum-score" style="border-color:'+diag.color+'"><span class="asum-num" style="color:'+diag.color+'">'+media.toFixed(1)+'</span><span class="asum-of">de 5</span></div>'+
        '<div class="asum-diag">'+diagBadge(media)+'<p>'+diag.rec+'</p></div>'+
      '</div>'+
      critBarsHTML(clean)+
      blocks;
  }

  function build() {
    var bodyHTML = step===1?step1HTML():(step===2?step2HTML():(step===3?step3HTML():step4HTML()));
    var nextLabel = step<4 ? 'Próximo →' : (editing?'Salvar avaliação':'Concluir e salvar');
    var backBtn = step>1 ? '<button class="btn btn-ghost" id="avBack">← Voltar</button>' : '';
    var delBtn = (editing && step===1) ? '<button class="btn btn-danger btn-del-wrap" id="avDel">Excluir</button>' : '';
    return '<div class="modal aval-wizard">'+
      '<div class="modal-title-input" style="cursor:default">'+(editing?'Editar avaliação':'Nova avaliação')+'</div>'+
      stepperHTML()+
      '<div class="aval-body">'+bodyHTML+'</div>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="avCancel">Cancelar</button>'+backBtn+'<button class="btn btn-primary" id="avNext">'+nextLabel+'</button></div>'+
    '</div>';
  }

  var modal=document.createElement('div'); modal.className='modal-bg';
  function captura(){
    var l=modal.querySelector('#avLoja'); if(l) curLoja=l.value;
    var m=modal.querySelector('#avMembro'); if(m) curMem=m.value;
    var mo=modal.querySelector('#avMonth'); if(mo) form.ref_month=parseInt(mo.value,10)||form.ref_month;
    var yr=modal.querySelector('#avYear'); if(yr) form.ref_year=parseInt(yr.value,10)||form.ref_year;
    var dt=modal.querySelector('#avDate'); if(dt) form.data_aval=dt.value||form.data_aval;
    var o=modal.querySelector('#avObs'); if(o) form.obs=o.value;
    var pf=modal.querySelector('#avFortes'); if(pf) form.fortes=pf.value;
    var pd=modal.querySelector('#avDesenv'); if(pd) form.desenvolver=pd.value;
    var pl=modal.querySelector('#avPlano'); if(pl) form.plano=pl.value;
    var nc=modal.querySelector('#avNewCrit'); if(nc) pendingCrit=nc.value;
    var names=modal.querySelectorAll('.aval-crit-name');
    for (var i=0;i<names.length;i++){ var idx=parseInt(names[i].getAttribute('data-cidx'),10); if(critList[idx]) critList[idx].label=names[i].value; }
  }
  function addCrit(){
    captura();
    var v=(pendingCrit||'').trim();
    if(!v){ var el=modal.querySelector('#avNewCrit'); if(el) el.focus(); return; }
    critList.push({ id:'c_'+Date.now().toString(36)+Math.floor(Math.random()*900+100), label:v, nota:0 }); pendingCrit='';
    rerender(false);
    setTimeout(function(){ var n2=modal.querySelector('#avNewCrit'); if(n2) n2.focus(); },20);
  }
  function rerender(keep){ if(keep) captura(); modal.innerHTML = build(); bindAll(); }
  function bindAll() {
    var tps=modal.querySelectorAll('.av-tp');
    for (var i=0;i<tps.length;i++) tps[i].addEventListener('click', function(){ captura(); tipo=this.getAttribute('data-tp'); critList=defaultsFor(tipo); pendingCrit=''; if(tipo==='membro'){ var mm=membrosDaLoja(curLoja); curMem=mm.length?mm[0].id:null; } rerender(false); });
    var lojaSel=modal.querySelector('#avLoja');
    if (lojaSel) lojaSel.addEventListener('change', function(){ captura(); var mm=membrosDaLoja(curLoja); curMem=(tipo==='membro'&&mm.length)?mm[0].id:null; rerender(false); });
    var memSel=modal.querySelector('#avMembro');
    if (memSel) memSel.addEventListener('change', function(){ curMem=this.value; });
    var stars=modal.querySelectorAll('.star-pick');
    for (var s=0;s<stars.length;s++) stars[s].addEventListener('click', function(){ captura(); var idx=parseInt(this.getAttribute('data-cidx'),10); if(critList[idx]) critList[idx].nota=parseInt(this.getAttribute('data-val'),10); rerender(false); });
    var ups=modal.querySelectorAll('[data-mvup]');
    for (var u=0;u<ups.length;u++) ups[u].addEventListener('click', function(){ captura(); var idx=parseInt(this.getAttribute('data-mvup'),10); if(idx>0){ var t=critList[idx-1]; critList[idx-1]=critList[idx]; critList[idx]=t; } rerender(false); });
    var dns=modal.querySelectorAll('[data-mvdn]');
    for (var d2=0;d2<dns.length;d2++) dns[d2].addEventListener('click', function(){ captura(); var idx=parseInt(this.getAttribute('data-mvdn'),10); if(idx<critList.length-1){ var t=critList[idx+1]; critList[idx+1]=critList[idx]; critList[idx]=t; } rerender(false); });
    var addc=modal.querySelector('#avAddCrit');
    if (addc) addc.addEventListener('click', addCrit);
    var ncEl=modal.querySelector('#avNewCrit');
    if (ncEl) ncEl.addEventListener('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); addCrit(); } });
    var rms=modal.querySelectorAll('[data-rmcrit]');
    for (var r=0;r<rms.length;r++) rms[r].addEventListener('click', function(){ captura(); var idx=parseInt(this.getAttribute('data-rmcrit'),10); critList.splice(idx,1); rerender(false); });
    var cancel=modal.querySelector('#avCancel'); if(cancel) cancel.addEventListener('click', close);
    var back=modal.querySelector('#avBack'); if(back) back.addEventListener('click', function(){ captura(); if(step>1) step--; rerender(false); });
    var nextB=modal.querySelector('#avNext'); if(nextB) nextB.addEventListener('click', next);
    var del=modal.querySelector('#avDel'); if(del) del.addEventListener('click', excluir);
  }
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  function next(){
    captura();
    if(step===1){ if(!editing && tipo==='membro' && !curMem){ toast('Selecione um funcionário','error'); return; } step=2; rerender(false); return; }
    if(step===2){ var hasNota=critList.some(function(c){return c.nota>0;}); if(!hasNota){ toast('Dê nota a pelo menos um critério','error'); return; } step=3; rerender(false); return; }
    if(step===3){ step=4; rerender(false); return; }
    salvar();
  }
  function excluir(){
    confirmDelete('Excluir esta avaliação?', function(){ sb.from('malba_avaliacoes').delete().eq('id',aval.id).then(function(r){
      if(r.error){ toast('Erro ao excluir','error'); return; }
      ST.avaliacoes=ST.avaliacoes.filter(function(x){return x.id!==aval.id;});
      auditLog('Excluiu avaliação', alvoLabel()); close(); toast('Avaliação excluída','success'); renderPage();
    }); });
  }
  function salvar() {
    captura();
    var memberId = (tipo==='membro') ? curMem : null;
    if (tipo==='membro' && !memberId) { step=1; rerender(false); toast('Selecione um funcionário','error'); return; }
    var clean = critList.filter(function(c){ return (c.label||'').trim()!==''; });
    var soma=0,n=0; clean.forEach(function(c){ if(c.nota>0){ soma+=c.nota; n++; } });
    if (n===0) { step=2; rerender(false); toast('Dê nota a pelo menos um critério','error'); return; }
    var media=soma/n;
    var notasToSave = clean.map(function(c){ return { id:c.id, label:(c.label||'').trim(), nota:c.nota||0 }; });
    var lastDay=new Date(form.ref_year, form.ref_month, 0).getDate();
    var mm2=(form.ref_month<10?'0':'')+form.ref_month;
    var pIni = form.ref_year+'-'+mm2+'-01';
    var pFim = form.ref_year+'-'+mm2+'-'+(lastDay<10?'0':'')+lastDay;
    var pLabel = MESES[form.ref_month-1]+' '+form.ref_year;
    var base={ sector:'lojas', tipo:tipo, store_unit_id:curLoja, member_id:memberId, periodo_label:pLabel, data_avaliacao:form.data_aval||today(), notas:notasToSave, nota_final:Math.round(media*10)/10, observacao:(form.obs||'').trim()||null, created_by: editing?(aval.created_by||ST.session.user.id):ST.session.user.id };
    var full=Object.assign({}, base, { periodo_inicio:pIni, periodo_fim:pFim, pontos_fortes:(form.fortes||'').trim()||null, pontos_desenvolver:(form.desenvolver||'').trim()||null, plano_acao:(form.plano||'').trim()||null });
    var btn=modal.querySelector('#avNext'); if(btn){ setBusy(btn,true); }
    function done(row){
      if(editing){ for(var i=0;i<ST.avaliacoes.length;i++) if(ST.avaliacoes[i].id===aval.id){ ST.avaliacoes[i]=Object.assign(ST.avaliacoes[i], row); break; } }
      else if(row){ ST.avaliacoes.unshift(row); }
      auditLog(editing?'Editou avaliação':'Criou avaliação', alvoLabel()); close(); toast(editing?'Avaliação atualizada':'Avaliação salva','success'); renderPage();
    }
    function fail(err){ if(btn){ btn.disabled=false; btn.textContent=(editing?'Salvar avaliação':'Concluir e salvar'); } toast('Erro ao salvar','error'); console.error(err); }
    function tryWith(rec, isRetry){
      if(editing){
        sb.from('malba_avaliacoes').update(rec).eq('id', aval.id).then(function(r){
          if(r.error){ if(!isRetry){ toast('Salvando sem os campos novos (rode o SQL de avaliação).','info'); tryWith(base, true); } else fail(r.error); return; }
          done(rec);
        });
      } else {
        sb.from('malba_avaliacoes').insert(rec).select().single().then(function(r){
          if(r.error||!r.data){ if(!isRetry){ tryWith(base, true); } else fail(r.error||{}); return; }
          done(r.data);
        });
      }
    }
    tryWith(full, false);
  }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal);
  rerender(false);
}

function avaliacaoDetalhe(a){
  if(!a) return;
  var alvo = a.tipo==='membro' ? (function(){ var mm=null; for(var i=0;i<ST.members.length;i++) if(String(ST.members[i].id)===String(a.member_id)){mm=ST.members[i];break;} return mm?mm.name:'Funcionário'; })() : (storeName(a.store_unit_id)||'Loja');
  var nota=Number(a.nota_final)||0; var diag=diagnostico(nota);
  var by=null; for(var i=0;i<ST.users.length;i++) if(String(ST.users[i].id)===String(a.created_by)){by=ST.users[i];break;}
  var notasArr = Array.isArray(a.notas) ? a.notas : (a.notas && typeof a.notas==='object' ? Object.keys(a.notas).filter(function(k){return k!=='_labels';}).map(function(k){ var lbl=(a.notas._labels&&a.notas._labels[k])||k; return {id:k,label:lbl,nota:Number(a.notas[k])||0}; }) : []);
  var blocks='';
  if(a.pontos_fortes) blocks+='<div class="asum-block fortes"><h5>Pontos fortes</h5><p>'+esc(a.pontos_fortes)+'</p></div>';
  if(a.pontos_desenvolver) blocks+='<div class="asum-block desenv"><h5>Pontos a desenvolver</h5><p>'+esc(a.pontos_desenvolver)+'</p></div>';
  if(a.plano_acao) blocks+='<div class="asum-block plano"><h5>Plano de ação (PDI)</h5><p>'+esc(a.plano_acao)+'</p></div>';
  if(a.observacao) blocks+='<div class="asum-block"><h5>Observações</h5><p>'+esc(a.observacao)+'</p></div>';
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal aval-wizard">'+
    '<div class="modal-title-input" style="cursor:default">Avaliação · '+esc(alvo)+'</div>'+
    '<div class="aval-det-meta"><span class="aval-tipo" style="background:'+(a.tipo==='membro'?'var(--u-accent-soft)':'var(--u-green-soft)')+';color:'+(a.tipo==='membro'?'var(--u-accent)':'var(--u-green)')+'">'+(a.tipo==='membro'?'Funcionário':'Loja')+'</span><span>'+(a.periodo_label?esc(a.periodo_label)+' · ':'')+'avaliado em '+fmtDate(a.data_avaliacao)+'</span>'+(by?'<span>· por '+esc(by.name)+'</span>':'')+'</div>'+
    '<div class="aval-summary">'+
      '<div class="asum-score" style="border-color:'+diag.color+'"><span class="asum-num" style="color:'+diag.color+'">'+nota.toFixed(1)+'</span><span class="asum-of">de 5</span></div>'+
      '<div class="asum-diag">'+diagBadge(nota)+'<p>'+diag.rec+'</p></div>'+
    '</div>'+
    critBarsHTML(notasArr)+
    blocks+
    (a.tipo==='membro' ? (function(){ var evo=avalEvolucaoRender(avalsDoMembro(a.member_id)); return evo?('<div class="aval-evo-sec"><h5 class="aval-evo-h">Evolução mês a mês</h5>'+evo+'</div>'):''; })() : '')+
    '<div class="modal-foot"><button class="btn btn-danger btn-del-wrap" id="adDel">Excluir</button><button class="btn btn-ghost" id="adClose">Fechar</button>'+(canEdit()?'<button class="btn btn-primary" id="adEdit">Editar</button>':'')+'</div>'+
  '</div>';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#adClose').addEventListener('click', close);
  var ed=modal.querySelector('#adEdit'); if(ed) ed.addEventListener('click', function(){ close(); openAvaliacaoModal(a); });
  modal.querySelector('#adDel').addEventListener('click', function(){
    confirmDelete('Excluir esta avaliação?', function(){ sb.from('malba_avaliacoes').delete().eq('id',a.id).then(function(r){
      if(r.error){ toast('Erro ao excluir','error'); return; }
      ST.avaliacoes=ST.avaliacoes.filter(function(x){return x.id!==a.id;});
      auditLog('Excluiu avaliação', alvo); close(); toast('Avaliação excluída','success'); renderPage();
    }); });
  });
  document.body.appendChild(modal);
}

function bindGestao() {
  if (!canEdit()) return;
  var tabs=app.querySelectorAll('.cfg-tab');
  for (var i=0;i<tabs.length;i++) tabs[i].addEventListener('click', function(){ ST.gestaoTab=this.getAttribute('data-gtab'); renderPage(); });
  // v74: liga os eventos da tela aninhada na aba ativa
  var gt=ST.gestaoTab||'';
  if (gt==='tarefas'){ bindAdmTarefas(); }
  else if (gt==='metas'){ if(typeof bindMetas==='function') bindMetas(); }
  else if (gt==='relatorio'){ if(ST.sector==='lojas'){ if(typeof bindRelatorioLojas==='function') bindRelatorioLojas(); } else { if(typeof bindRelatorio==='function') bindRelatorio(); } }
  else if (gt==='orcamento'){ if(typeof bindOrcamento==='function') bindOrcamento(); }
  var nc=document.getElementById('btnNovaComissao'); if(nc) nc.addEventListener('click', openComissaoModal);
  var na=document.getElementById('btnNovaAvaliacao'); if(na) na.addEventListener('click', function(){ openAvaliacaoModal(); });
  var crows=app.querySelectorAll('.com-row[data-cid]');
  for (var z=0;z<crows.length;z++) crows[z].addEventListener('click', function(){
    var id=this.getAttribute('data-cid'); var c=null;
    for (var x=0;x<ST.comissoes.length;x++) if (String(ST.comissoes[x].id)===String(id)) { c=ST.comissoes[x]; break; }
    if (c) comissaoDetalhe(c);
  });
  var arows=app.querySelectorAll('.aval-row[data-aid]');
  for (var y=0;y<arows.length;y++) arows[y].addEventListener('click', function(){
    var id=this.getAttribute('data-aid'); var a=null;
    for (var x=0;x<ST.avaliacoes.length;x++) if (String(ST.avaliacoes[x].id)===String(id)) { a=ST.avaliacoes[x]; break; }
    if (a) avaliacaoDetalhe(a);
  });
  if ((ST.gestaoTab||'')==='atividade') loadAtividade();
  // Visão geral: filtro de loja + drill
  var vgl=document.getElementById('vgLoja');
  if (vgl) vgl.addEventListener('change', function(){ ST.gestaoStore=this.value; renderPage(); });
  var vgLojas=app.querySelectorAll('.vg-loja[data-vgloja]');
  for (var li=0;li<vgLojas.length;li++) vgLojas[li].addEventListener('click', function(){
    ST.taskStore=this.getAttribute('data-vgloja'); ST.taskAssignee=''; ST.page='tarefas'; renderPage();
  });
  var vgColabs=app.querySelectorAll('.vg-colab[data-vgcolab]');
  for (var ci=0;ci<vgColabs.length;ci++) vgColabs[ci].addEventListener('click', function(){
    ST.taskAssignee=this.getAttribute('data-vgcolab'); ST.taskStore=ST.gestaoStore||''; ST.page='tarefas'; renderPage();
  });
  var rok=app.querySelectorAll('[data-reqok]');
  for (var ro=0;ro<rok.length;ro++) rok[ro].addEventListener('click', function(){ decidirReq(this.getAttribute('data-reqok'),'aprovado'); });
  var rno=app.querySelectorAll('[data-reqno]');
  for (var rn=0;rn<rno.length;rn++) rno[rn].addEventListener('click', function(){ decidirReq(this.getAttribute('data-reqno'),'negado'); });
}

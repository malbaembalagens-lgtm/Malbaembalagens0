/* ========== [11] ROTEAMENTO DE PÁGINAS ========== */
function meusMemberIds(){
  var me=String(ST.session.user.id);
  var byId=[];
  (ST.members||[]).forEach(function(m){ if(m.user_id && String(m.user_id)===me) byId.push(String(m.id)); });
  if (byId.length) return byId;
  var nome=((ST.session.user.name)||'').trim().toLowerCase(); var ids=[];
  (ST.members||[]).forEach(function(m){ if((m.name||'').trim().toLowerCase()===nome) ids.push(String(m.id)); });
  return ids;
}
/* ===== Mural de avisos (comunicação com a equipe) — reaproveita malba_events ===== */
function avisosAtivos(){
  var lim=addDays(today(),-21);
  return (ST.events||[]).filter(function(ev){ return ev.kind==='aviso' && ev.scope==='team' && String(ev.sector||'')===String(ST.sector) && (ev.date||'')>=lim; })
    .sort(function(a,b){ return (String(b.date)+(b.created_at||'')).localeCompare(String(a.date)+(a.created_at||'')); });
}
function muralHTML(){
  var avisos=avisosAtivos();
  var canPost=canEdit();
  if (avisos.length===0 && !canPost) return '';
  var btn = canPost ? '<button class="mural-add" id="btnNovoAviso">'+icon('plus')+'Aviso à equipe</button>' : '';
  var items = avisos.length ? avisos.slice(0,4).map(function(ev){
    var del = (canPost||String(ev.created_by)===String(ST.session.user.id)) ? '<button class="mural-del" data-avdel="'+esc(ev.id)+'" title="Remover">✕</button>' : '';
    return '<div class="mural-item"><span class="mural-ic">'+icon('bell')+'</span><div class="mural-body"><div class="mural-msg">'+esc(ev.title)+'</div><div class="mural-meta">'+esc(ev.created_by_name||'Equipe')+' · '+fmtDate(ev.date)+'</div></div>'+del+'</div>';
  }).join('') : '<div class="mural-empty">Nenhum aviso agora. Use "Aviso à equipe" para comunicar algo importante a todos.</div>';
  return '<div class="mural"><div class="mural-head"><span class="mural-title">'+icon('bell')+'Mural de avisos</span>'+btn+'</div><div class="mural-list">'+items+'</div></div>';
}
function bindMural(){
  var b=document.getElementById('btnNovoAviso');
  if (b) b.addEventListener('click', postAvisoModal);
  var dels=app.querySelectorAll('[data-avdel]');
  for (var i=0;i<dels.length;i++) dels[i].addEventListener('click', function(e){
    e.stopPropagation();
    var id=this.getAttribute('data-avdel');
    confirmDelete('Remover este aviso?', function(){ sb.from('malba_events').delete().eq('id', id).then(function(r){ if(r.error){ toast('Erro ao remover','error'); return; } ST.events=ST.events.filter(function(x){return String(x.id)!==String(id);}); auditLog('Removeu aviso'); toast('Aviso removido','success'); renderPage(); }); });
  });
}
function postAvisoModal(){
  if(!canEdit()){ blockManage(); return; }
  var me=ST.session.user;
  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Aviso à equipe</div>'+
    '<div class="modal-row"><label class="modal-label">Mensagem</label><textarea id="avMsg" placeholder="Ex: Amanhã reunião às 9h. Cheguem 10 min antes." maxlength="280"></textarea></div>'+
    '<div class="modal-note">Aparece no Mural de avisos para toda a equipe do setor (fica 21 dias).</div>'+
    '<div class="modal-foot"><button class="btn btn-ghost" id="avCancel">Cancelar</button><button class="btn btn-primary" id="avPost">Publicar</button></div></div>';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#avCancel').addEventListener('click', close);
  modal.querySelector('#avPost').addEventListener('click', function(){
    var msg=(modal.querySelector('#avMsg').value||'').trim(); if(!msg){ toast('Escreva a mensagem','error'); return; }
    var rec={ sector:ST.sector, title:msg, date:today(), hora:null, kind:'aviso', scope:'team', color:'#3B6FF7', store_unit_id:null, created_by:me.id, created_by_name:me.name };
    var btn=this; btn.disabled=true; btn.textContent='Publicando...';
    sb.from('malba_events').insert(rec).select().single().then(function(r){
      if(r.error||!r.data){ toast('Erro ao publicar (rodou o SQL de eventos?)','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Publicar'; return; }
      ST.events.push(r.data); auditLog('Publicou aviso', msg.slice(0,40)); close(); toast('Aviso publicado','success'); renderPage();
    });
  });
  document.body.appendChild(modal);
  modal.querySelector('#avMsg').focus();
}
function renderPage() {
  if (ST.page!=='chat') chatTeardown();
  var _lb=document.getElementById('admLote'); if(_lb&&_lb.parentNode) _lb.parentNode.removeChild(_lb); // v81
  // v74: telas de resultado e Ponto abrem SEMPRE dentro do hub (Gestão/Equipe) — navegação unificada + compat de rotas/deep-links
  if (ST.page==='calendario' && pageAllowed('calendario', ST.session)){ ST.taskView='calendario'; ST.page='tarefas'; } // v88
  if (ST.page==='projetos' && pageAllowed('projetos', ST.session)){ ST.taskView='projetos'; ST.page='tarefas'; }        // v88
  if (ST.page==='admtarefas'){ ST.gestaoTab='tarefas'; ST.page='gestao'; } // v79
  if (ST.page==='kpis'){ ST.page='inicio'; } // v78: painel de KPIs foi absorvido pelo Dashboard único
  if (GESTAO_CHILDREN.indexOf(ST.page)!==-1){ ST.gestaoTab=ST.page; ST.page='gestao'; }
  else if (ST.page==='ponto'){ ST.equipeTab='ponto'; ST.page='equipe'; }
  if (ST.page!=='perfil' && !pageAllowed(ST.page, ST.session)) { ST.page='inicio'; }
  // Perfil é uma página especial, fora do menu de setores
  if (ST.page==='perfil') { renderShell(perfilHTML(), 'Meu Perfil'); bindPerfil(); return; }
  var pages=PAGES[ST.sector]||PAGES.lojas; var pg=null;
  for (var i=0;i<pages.length;i++) if (pages[i].id===ST.page) { pg=pages[i]; break; }
  if (!pg || !pg.enabled) {
    // página inexistente ou ainda não construída → mostra placeholder (ou cai pra tarefas)
    if (!pg) { ST.page='inicio'; renderPage(); return; }
    renderShell('<div class="empty-page"><div class="ep-ico">'+icon(pg.icon)+'</div><h3>'+esc(pg.label)+'</h3><p>Esta área entra numa próxima fase da reconstrução.</p></div>', pg.label);
    return;
  }
  if (pg.id==='tarefas') {
    renderShell(tarefasHTML(), 'Tarefas'); bindTarefas();
  } else if (pg.id==='equipe') {
    renderShell(equipeHTML(), 'Equipe'); bindEquipe();
  } else if (pg.id==='metas') {
    renderShell(metasHTML(), 'Metas'); bindMetas();
  } else if (pg.id==='estrategia') {
    renderShell(estrategiaHTML(), 'Estratégia'); bindEstrategia();
  } else if (pg.id==='docs') {
    renderShell(ST.docOpen ? docsEditorHTML() : docsHTML(), 'Documentos'); bindDocs();
  } else if (pg.id==='crm') {
    renderShell(crmHTML(), 'CRM'); bindCRM();
  } else if (pg.id==='projetos') {
    renderShell(projetosHTML(), 'Projetos'); bindProjetos();
  } else if (pg.id==='config') {
    renderShell(centralHTML(), 'Cadastros'); bindCentral();
  } else if (pg.id==='campanhas') {
    renderShell(campanhasHTML(), 'Campanhas'); bindCampanhas();
  } else if (pg.id==='calendario') {
    renderShell(calendarioHTML(), 'Calendário'); bindCalendario();
  } else if (pg.id==='ranking') {
    renderShell(rankingHTML(), 'Ranking');
  } else if (pg.id==='kpis') {
    renderShell(kpisHTML(), 'KPIs'); bindKPIs();
  } else if (pg.id==='gestao') {
    renderShell(gestaoHTML(), 'Gestão'); bindGestao();
  } else if (pg.id==='chat') {
    renderShell(chatHTML(), 'Chat'); bindChat();
  } else if (pg.id==='ponto') {
    renderShell(pontoHTML(), 'Ponto'); bindPonto();
  } else if (pg.id==='relatorio') {
    if (ST.sector==='lojas') { renderShell(relatorioLojasHTML(), 'Relatório'); bindRelatorioLojas(); }
    else { renderShell(relatorioHTML(), 'Relatório'); bindRelatorio(); }
  } else if (pg.id==='orcamento') {
    renderShell(orcamentoHTML(), 'Orçamento'); bindOrcamento();
  } else if (pg.id==='conteudo') {
    renderShell(conteudoHTML(), 'Conteúdo'); bindConteudo();
  } else if (pg.id==='biblioteca') {
    renderShell(bibliotecaHTML(), 'Biblioteca'); bindBiblioteca();
  } else if (pg.id==='inicio') {
    if (isColaboradorPessoal(ST.session)) { renderShell(colaboradorInicioHTML(), 'Início'); bindColaboradorInicio(); }
    else if (ST.sector==='lojas' && ST.store) { renderShell(lojaPainelHTML(), 'Início'); bindLojaPainel(); }
    else { renderShell(dashboardHTML(), 'Início'); bindDashboard(); }
  }
}

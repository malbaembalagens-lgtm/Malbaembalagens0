/* ========== [8] CASCA ========== */
// v89.3: submenu contextual do menu lateral (Gestão / Configurações)
function navSubmenu(pageId){
  var atual, itens=[];
  if(pageId==='gestao'){
    var T=gestaoTabsForSector();
    atual = ST.gestaoTab || (T[0]||{}).id;
    itens = T.map(function(x){ return { id:x.id, label:x.label }; });
  } else if(pageId==='config' && isTopAdmin(ST.session)){
    atual = ST.configTab || 'usuarios';
    itens = [{id:'usuarios',label:'Usuários'},{id:'lojas',label:'Lojas'},{id:'banners',label:'Banners'}];
  } else {
    return '';
  }
  if(itens.length<=1) return '';
  return '<div class="nav-sub">'+itens.map(function(x){
    return '<button class="nav-sub-item'+(x.id===atual?' on':'')+'" data-subpage="'+pageId+'" data-subtab="'+x.id+'">'+esc(x.label)+'</button>';
  }).join('')+'</div>';
}
function renderShell(innerHTML, title) {
  var s=SECTORS[ST.sector]||SECTORS.lojas;
  var u=ST.session.user;
  var roleLabel = roleNivelLabel(ST.session);
  var pages=PAGES[ST.sector]||PAGES.lojas;
  pages = pages.filter(function(pg){ return !pg.hidden && pageAllowed(pg.id, ST.session); }); // v74: hidden fora do menu (segue na paleta Cmd+K)
  var nav='';
  var focoTarefas = navTaskCount();
  GROUP_ORDER.forEach(function(gname){
    var items=pages.filter(function(pg){ return (pg.group||'OPERAÇÃO')===gname; });
    if (items.length===0) return;
    nav += '<div class="nav-group">'+gname+'</div>';
    items.forEach(function(pg){
      var active = (pg.id===ST.page || PAGE_PARENT[ST.page]===pg.id)?' active':''; // v74: acende o pai quando numa aba filha
      var dis = pg.enabled?'':' disabled';
      var soon = pg.enabled?'':'<span class="nav-soon">em breve</span>';
      var badge = (pg.id==='tarefas' && focoTarefas>0) ? '<span class="nav-badge">'+focoTarefas+'</span>' : '';
      nav += '<button class="nav-item'+active+'"'+dis+' data-page="'+pg.id+'">'+icon(pg.icon)+'<span>'+esc(pg.label)+'</span>'+(badge||soon)+'</button>';
      // v89.3: submenu contextual — só quando o pai está ativo
      if(active && !pg.hidden){ nav += navSubmenu(pg.id); }
    });
  });
  render(
    '<div class="app-shell"><aside class="side">'+
      '<div class="side-brand"><div class="side-brand-logo">'+brandMark('sm')+'</div><span class="side-brand-sec" style="--c:'+s.color+'">'+icon(s.icon)+esc(s.label)+'</span></div>'+
      '<button class="side-user" id="sideUser">'+(u.avatar?'<span class="avatar" style="background:center/cover url(\''+u.avatar+'\')"></span>':'<span class="avatar" style="background:'+(u.color||s.color)+'">'+esc(u.initials)+'</span>')+'<span class="side-user-txt"><b>'+esc(u.name.split(' ')[0])+'</b><i>'+roleLabel+'</i></span></button>'+
      '<nav class="nav">'+nav+'</nav>'+
      '<button class="btn-logout" id="btnSair">'+icon('logout')+'<span>Sair</span></button>'+
      '<div class="side-version" title="Versão no ar">'+esc(APP_BUILD)+'</div>'+
    '</aside><div class="side-overlay" id="sideOverlay"></div><main class="main">'+
      '<header class="top"><button class="top-burger" id="topBurger" aria-label="Abrir menu"><span></span><span></span><span></span></button><span class="top-title">'+esc(title||'')+'</span><div class="top-spacer"></div>'+
        (function(){
          if (!(isSuper(ST.session) && ST.sector==='lojas' && !ST.store && (ST.storeUnits||[]).length)) return '';
          var op='<option value="">Todas as lojas</option>'+(ST.storeUnits||[]).map(function(su){ return '<option value="'+esc(su.id)+'"'+(String(ST.viewStore)===String(su.id)?' selected':'')+'>'+esc(su.name||('Loja '+su.store_number))+'</option>'; }).join('');
          return '<select class="top-store" id="topStore" title="Loja em foco">'+op+'</select>';
        })()+
        '<span class="top-online" id="topOnline"><i></i><span>Online</span></span>'+
        '<div class="top-search"><span class="ts-ico">'+icon('search')+'</span><input id="topSearch" placeholder="Buscar em tudo..." autocomplete="off"><span class="ts-kbd" id="tsKbd">Ctrl K</span><div class="ts-results" id="topResults"></div></div>'+
        '<button class="top-theme" id="themeToggle" title="'+(getTheme()==='dark'?'Modo claro':'Modo escuro')+'">'+icon(getTheme()==='dark'?'sun':'moon')+'</button>'+
        '<button class="btn btn-primary top-novo" id="topNovo">'+icon('plus')+'<span>Novo</span></button>'+
      '</header>'+
      '<section class="content" id="content">'+innerHTML+'</section>'+
    '</main></div>'
  );
  document.getElementById('btnSair').addEventListener('click', logout);
  var sideUser=document.getElementById('sideUser');
  if (sideUser) sideUser.addEventListener('click', function(){ ST.page='perfil'; ST.openProject=null; navigate(ST.sector+'/perfil'); renderPage(); });
  // v89.3: cliques nos itens de submenu — pulam direto para a aba
  document.querySelectorAll('[data-subpage]').forEach(function(el){
    el.addEventListener('click', function(e){
      e.stopPropagation();
      var pg=this.getAttribute('data-subpage'), tab=this.getAttribute('data-subtab');
      if(pg==='gestao') ST.gestaoTab=tab;
      else if(pg==='config') ST.configTab=tab;
      ST.page=pg; renderPage();
    });
  });
  var navBtns=app.querySelectorAll('.nav-item:not([disabled])');
  for (var i=0;i<navBtns.length;i++) {
    navBtns[i].addEventListener('click', function(){ var pid=this.getAttribute('data-page'); if(pid==='equipe') ST.equipeTab='equipe'; if(pid==='tarefas') ST.taskView='kanban'; if(pid==='gestao') ST.gestaoTab=null; ST.page=pid; ST.openProject=null; navigate(ST.sector+'/'+pid); renderPage(); });
  }
  bindTopbar();
  var _burger=document.getElementById('topBurger');
  var _shell=app.querySelector('.app-shell');
  var _ovl=document.getElementById('sideOverlay');
  if(_burger&&_shell) _burger.addEventListener('click', function(){ _shell.classList.toggle('side-open'); });
  if(_ovl&&_shell) _ovl.addEventListener('click', function(){ _shell.classList.remove('side-open'); });
}

/* ----- Topbar: Online, busca e Novo ----- */
function setOnlineState() {
  var el=document.getElementById('topOnline'); if(!el) return;
  var on = (typeof navigator==='undefined') ? true : navigator.onLine;
  el.classList.toggle('off', !on);
  var txt=el.querySelector('span'); if(txt) txt.textContent = on?'Online':'Offline';
}
function novoContextual() {
  if (!canEdit()) { return openTaskModal(null); } // usuário comum só cria tarefa
  var pg=ST.page;
  if (pg==='campanhas') return openCampaignModal(null);
  if (pg==='conteudo') return openContentModal(null);
  if (pg==='biblioteca') return openCriativoModal(null);
  if (pg==='crm') return openClientModal(null);
  if (pg==='docs') { if(!docPodeCriar()) return blockManage(); return docsCriar('branco', null); }
  if (pg==='estrategia') {
    if(!estrPodeEditar()) return blockManage();
    if (estrTab()==='objetivos') return openObjetivoModal(null);
    if (estrTab()==='planejamento' || estrTab()==='projetos'){ toast('Vá em 🎯 Objetivos para criar um novo, ou clique num objetivo aqui para planejar.','info'); return; }
    if (estrTab()==='dashboard'){ toast('O botão + cria novos itens — vá em 💡 Ideias ou 🎯 Objetivos.','info'); return; }
    return openIdeiaModal(null);
  }
  if (pg==='projetos') { if(ST.openProject) return openTaskModal(null); return openProjectModal(null); }
  if (pg==='tarefas' && (ST.taskView||'')==='projetos') { if(ST.openProject) return openTaskModal(null); return openProjectModal(null); }
  if (pg==='metas') return openMetaModal(null); // v113
  if (pg==='equipe') return openMemberModal(null);
  if (pg==='config'){
    var ct=ST.configTab||'usuarios';
    if (ct==='lojas') return openStoreModal(null);
    if (ct==='banners') return openBannerModal(null);
    return openUserModal(null);
  }
  if (pg==='gestao'){
    var gt=ST.gestaoTab||'';
    if (gt==='tarefas') return openTaskModal(null);
    if (gt==='metas') return openMetaModal(null); // v113
    if (gt==='avaliacoes') return openAvaliacaoModal();
    return openComissaoModal();
  }
  return openTaskModal(null); // inicio, tarefas, calendario, ranking, etc.
}
function globalSearch(q) {
  q=(q||'').toLowerCase().trim(); if(!q) return [];
  var res=[];
  // v112: pessoas — só se admin/gestor podem ver (colaborador não busca por pessoas)
  if (isAdmin(ST.session)){
    var pessoasVis = (ST.allUsers||[]);
    // gestor: só do próprio setor
    if (!isSuper(ST.session)) pessoasVis = pessoasVis.filter(function(u){ return String(u.sector||'')===String(ST.sector); });
    pessoasVis.forEach(function(u){
      if ((u.name||'').toLowerCase().indexOf(q)>=0 || (u.email||'').toLowerCase().indexOf(q)>=0){
        var setLb = u.sector ? ((SECTORS[u.sector]||{label:u.sector}).label) : '';
        res.push({k:'user',label:u.name||u.email,sub:'Pessoa'+(setLb?' · '+setLb:''),color:'#3B6FF7',ref:u});
      }
    });
  }
  // v112: equipes — mesma visibilidade que a Central de Cadastros
  if (isAdmin(ST.session) && typeof equipesVisiveis === 'function'){
    equipesVisiveis().forEach(function(e){
      if (e.is_active===false) return;
      if ((e.name||'').toLowerCase().indexOf(q)>=0 || (e.description||'').toLowerCase().indexOf(q)>=0){
        var setLb = e.sector ? ((SECTORS[e.sector]||{label:e.sector}).label) : 'Cruzada';
        res.push({k:'equipe',label:e.name,sub:'Equipe · '+setLb,color:'#8B5CF6',ref:e});
      }
    });
  }
  // v112: departamentos (só Admin geral)
  if (isSuper(ST.session)){
    (ST.departamentos||[]).forEach(function(d){
      if ((d.label||'').toLowerCase().indexOf(q)>=0){
        res.push({k:'depto',label:d.label,sub:'Departamento',color:d.color||'#3B6FF7',ref:d});
      }
    });
  }
  // v112: documentos — respeita permissão de leitura por doc
  (ST.docs||[]).forEach(function(d){
    if (d.is_deleted) return;
    if ((d.title||'').toLowerCase().indexOf(q)>=0){
      // se docPermDe existir, respeita
      if (typeof docPermDe==='function'){
        var p = docPermDe(d, ST.session && ST.session.user);
        if (p==='nenhum') return;
      }
      res.push({k:'doc',label:d.title||'Sem título',sub:'Documento',color:'#0EA5E9',ref:d});
    }
  });
  (ST.tasks||[]).forEach(function(t){ if(t.is_rule) return; if((t.title||'').toLowerCase().indexOf(q)>=0) res.push({k:'task',label:t.title,sub:'Tarefa',color:'#3B6FF7',ref:t}); });
  (ST.clients||[]).forEach(function(c){ if((c.name||'').toLowerCase().indexOf(q)>=0||(c.company||'').toLowerCase().indexOf(q)>=0) res.push({k:'client',label:c.name,sub:'Cliente'+(c.company?' · '+c.company:''),color:'#00ACC1',ref:c}); });
  (ST.projects||[]).forEach(function(p){ if((p.name||'').toLowerCase().indexOf(q)>=0) res.push({k:'project',label:p.name,sub:'Projeto',color:'#FB8C00',ref:p}); });
  (ST.campaigns||[]).forEach(function(c){ if((c.name||'').toLowerCase().indexOf(q)>=0) res.push({k:'campaign',label:c.name,sub:'Campanha',color:'#8B5CF6',ref:c}); });
  return res.slice(0,12); // v112: 8 → 12
}
function openSearchResult(r) {
  if (r.k==='task') openTaskModal(r.ref);
  else if (r.k==='client') openClientModal(r.ref);
  else if (r.k==='campaign') openCampaignModal(r.ref);
  else if (r.k==='project') { ST.openProject=r.ref.id; ST.page='projetos'; navigate(ST.sector+'/projetos'); renderPage(); }
  // v112: novos tipos
  else if (r.k==='user') { openUserModal(r.ref); }
  else if (r.k==='equipe') {
    ST.page='config'; ST.central = ST.central || {}; ST.central.nav='equipe'; ST.central.equipeId=r.ref.id;
    navigate(ST.sector+'/config'); renderPage();
  }
  else if (r.k==='depto') {
    ST.page='config'; ST.central = ST.central || {}; ST.central.nav='departamentos';
    navigate(ST.sector+'/config'); renderPage();
  }
  else if (r.k==='doc') {
    ST.page='docs'; ST.docOpen = r.ref.id;
    navigate(ST.sector+'/docs'); renderPage();
  }
}
function bindTopbar() {
  setOnlineState();
  var kbd=document.getElementById('tsKbd'); if(kbd) kbd.addEventListener('click', openCommandPalette);
  var tt=document.getElementById('themeToggle'); if(tt) tt.addEventListener('click', toggleTheme);
  var ts2=document.getElementById('topStore'); if(ts2) ts2.addEventListener('change', function(){ ST.viewStore=this.value||null; renderPage(); });
  var novo=document.getElementById('topNovo');
  if (novo) novo.addEventListener('click', novoContextual);
  var inp=document.getElementById('topSearch'), box=document.getElementById('topResults');
  if (inp && box) {
    function renderResults() {
      var rs=globalSearch(inp.value);
      if (!inp.value.trim()) { box.classList.remove('on'); box.innerHTML=''; return; }
      if (rs.length===0) { box.classList.add('on'); box.innerHTML='<div class="ts-empty">Nada encontrado</div>'; return; }
      box.innerHTML = rs.map(function(r,i){ return '<button class="ts-item" data-i="'+i+'"><span class="ts-dot" style="background:'+r.color+'"></span><span class="ts-l">'+esc(r.label)+'</span><span class="ts-s">'+esc(r.sub)+'</span></button>'; }).join('');
      box.classList.add('on');
      var items=box.querySelectorAll('.ts-item');
      for (var i=0;i<items.length;i++) (function(idx){ items[idx].addEventListener('mousedown', function(e){ e.preventDefault(); inp.value=''; box.classList.remove('on'); openSearchResult(rs[idx]); }); })(i);
    }
    inp.addEventListener('input', renderResults);
    inp.addEventListener('focus', renderResults);
    inp.addEventListener('blur', function(){ setTimeout(function(){ box.classList.remove('on'); }, 150); });
  }
}

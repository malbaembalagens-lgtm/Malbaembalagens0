/* ========== [10c] METAS (metas mensais por loja) ========== */
var MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

function fmtBRL(v) {
  var n = Number(v)||0;
  return 'R$ ' + n.toLocaleString('pt-BR', { minimumFractionDigits:2, maximumFractionDigits:2 });
}

// metas visíveis: loja vê as da própria loja (e as do setor inteiro); admin vê todas.
function visibleGoals() {
  var sid = boardStore();
  if (sid) return ST.goals.filter(function(g){ return String(g.store_unit_id)===String(sid) || !g.store_unit_id; });
  return ST.goals;
}

/* v90: Metas unificadas — casca comum, motor por setor.
   Todo setor entra por metasHTML(). O layout, cabeçalho e navegação
   de mês são um só; o cálculo continua no motor certo (vendas/marketing). */
function metasHTML() {
  if (deptoComoModelo('marketing')) return mktMetasHTML();
  var admin = isAdmin(ST.session);
  var gs = visibleGoals().slice().sort(function(a,b){
    if (b.year!==a.year) return b.year-a.year;
    return b.month-a.month;
  });
  var sub = (deptoComoModelo('lojas') && ST.store && !admin) ? ('Metas de '+esc(ST.store.name||('Loja '+ST.store.store_number))) : 'Metas mensais'; // v106b
  var btn = admin ? '<button class="btn-new" id="btnNovaMeta">'+icon('plus')+'Nova meta</button>' : '';
  var storeFilter='';
  if (admin && ST.sector==='lojas' && !ST.store && (ST.storeUnits||[]).length>0) {
    var so='<option value="">Todas as lojas</option>'+ST.storeUnits.map(function(s){return '<option value="'+esc(s.id)+'"'+(String(ST.taskStore)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>';}).join('');
    storeFilter='<select class="task-filter" id="metaStore" title="Ver loja">'+so+'</select>';
  }
  // resumo do mês corrente (acompanhamento)
  var now2=new Date(), ym=now2.getFullYear(), mm2=now2.getMonth()+1;
  var curGs=gs.filter(function(g){ return g.month===mm2 && g.year===ym; });
  var tMeta=curGs.reduce(function(s,g){ return s+(Number(g.goal_value)||0); },0);
  var tReal=curGs.reduce(function(s,g){ return s+realizadoMeta(g); },0);
  var tPct=tMeta>0?Math.min(100,Math.round(tReal/tMeta*100)):0;
  var resumo = curGs.length ? ('<div class="metas-resumo"><div class="mr-top"><span>Acompanhamento de '+MESES[mm2-1]+'</span><b>'+tPct+'% da meta</b></div><div class="mr-bar"><span style="width:'+tPct+'%"></span></div><div class="mr-sub">'+fmtBRL(tReal)+' de '+fmtBRL(tMeta)+'</div></div>') : '';

  var cards = '';
  if (gs.length === 0) {
    var msg = admin ? 'Crie a primeira meta mensal pelo botão acima.' : 'O administrador ainda não definiu metas.';
    cards = emptyState({ span:true, icon:'target', title:'Nenhuma meta ainda', text:msg, cta:(canEdit()?'Nova meta':'') });
  } else {
    gs.forEach(function(g){ cards += goalCardHTML(g); });
  }
  return '<div class="tasks-head"><div><h2>Metas</h2><div class="sub">'+sub+'</div></div><div class="tasks-head-r">'+storeFilter+btn+'</div></div>'+resumo+'<div class="goals-grid">'+cards+'</div>';
}

/* ----- metas de marketing (indicadores próprios: faturamento do site, leads, seguidores, alcance) ----- */
var MKT_METRICS = {
  faturamento_site: { label:'Faturamento do site', unit:'brl', auto:true,  icon:'dollar' },
  leads:            { label:'Leads',                unit:'num', auto:false, icon:'users' },
  seguidores:       { label:'Seguidores',           unit:'num', auto:false, icon:'megaphone' },
  alcance:          { label:'Alcance',              unit:'num', auto:false, icon:'trend' },
  outro:            { label:'Outro',                unit:'num', auto:false, icon:'target' }
};
var MKT_ORDER = ['faturamento_site','leads','seguidores','alcance','outro'];
function fmtNumBR(v){ v=Math.round(Number(v)||0); try{ return v.toLocaleString('pt-BR'); }catch(e){ return ''+v; } }
function siteFatMesAno(m,y){ var mm=(m<10?'0':'')+m; var ld=new Date(y,m,0).getDate(); return siteFatRange(y+'-'+mm+'-01', y+'-'+mm+'-'+((ld<10?'0':'')+ld)); }
function mktMetaActual(g){ var p=MKT_METRICS[g.metric]; if(p&&p.auto&&g.metric==='faturamento_site') return siteFatMesAno(g.month,g.year); return Number(g.actual)||0; }
function mktFmt(v,unit){ return unit==='brl' ? fmtBRL(v) : fmtNumBR(v); }
function mktRingSVG(pct,cor){ var R=42,C=2*Math.PI*R,off=C*(1-pct/100); return '<svg class="goal-ring" viewBox="0 0 100 100"><circle cx="50" cy="50" r="'+R+'" fill="none" stroke="var(--u-bg2)" stroke-width="9"/><circle cx="50" cy="50" r="'+R+'" fill="none" stroke="'+cor+'" stroke-width="9" stroke-linecap="round" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+off.toFixed(1)+'" transform="rotate(-90 50 50)"/><text x="50" y="50" text-anchor="middle" dominant-baseline="central" font-size="22" font-weight="800" fill="var(--u-text)" font-family="Sora">'+pct+'%</text></svg>'; }
function mktMetasHTML(){
  var n=_ymNow();
  var cur=(ST.mktMetas||[]).filter(function(g){ return (g.sector||'marketing')==='marketing' && g.month===n.m && g.year===n.y; });
  cur.sort(function(a,b){ return MKT_ORDER.indexOf(a.metric)-MKT_ORDER.indexOf(b.metric); });
  // v90: subtítulo e botão idênticos aos de vendas/lojas
  var btn = canEdit() ? '<button class="btn-new" id="btnNovaMktMeta">'+icon('plus')+'Nova meta</button>' : '';
  var sub = 'Metas do marketing · '+MESES[n.m-1]+' '+n.y;
  var cards = cur.length ? cur.map(mktMetaCard).join('') : emptyState({ span:true, icon:'target', title:'Sem metas neste mês', text:'Defina os alvos do marketing: faturamento do site, leads, seguidores e alcance.', cta:(canEdit()?'Nova meta':'') });
  return '<div class="tasks-head"><div><h2>Metas</h2><div class="sub">'+sub+'</div></div><div class="tasks-head-r">'+btn+'</div></div><div class="goals-grid">'+cards+'</div>';
}
function mktMetaCard(g){
  var preset=MKT_METRICS[g.metric]||MKT_METRICS.outro; var unit=g.unit||preset.unit;
  var target=Number(g.target)||0; var actual=mktMetaActual(g); var pct=target>0?Math.min(100,Math.round(actual/target*100)):0;
  var cor=pct>=100?'#16A34A':(pct>=60?'#8B5CF6':(pct>=30?'#F59E0B':'#EF4444'));
  return '<div class="goal-card mkt" data-mktid="'+esc(g.id)+'"><div class="goal-head"><div><b>'+esc(g.label||preset.label)+(preset.auto?' <span class="mm-auto">Bling</span>':'')+'</b><i>'+MESES[(g.month||1)-1]+' '+(g.year||'')+'</i></div></div>'+
    mktRingSVG(pct,cor)+
    '<div class="goal-vals"><div class="gv"><small>Realizado</small><span style="color:'+cor+'">'+mktFmt(actual,unit)+'</span></div><div class="gv"><small>Meta</small><span>'+mktFmt(target,unit)+'</span></div></div>'+
  '</div>';
}
function bindMktMetas(){
  var nova=document.getElementById('btnNovaMktMeta'); if(nova && canEdit()) nova.addEventListener('click', function(){ openMktMetaModal(null); });
  if(!canEdit()) return;
  var cards=app.querySelectorAll('.goal-card.mkt'); for(var i=0;i<cards.length;i++) cards[i].addEventListener('click', function(){ var id=this.getAttribute('data-mktid'); var g=null; for(var k=0;k<ST.mktMetas.length;k++) if(String(ST.mktMetas[k].id)===String(id)){g=ST.mktMetas[k];break;} if(g) openMktMetaModal(g); });
}
function openMktMetaModal(goal){
  if(!canEdit()){ blockManage(); return; }
  var isNew=!goal; var now=new Date();
  var g=goal ? Object.assign({}, goal) : { metric:'faturamento_site', label:'', target:'', actual:'', unit:'brl', month:now.getMonth()+1, year:now.getFullYear() };
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  function capture(){ var t=modal.querySelector('#mmTarget'); if(t) g.target=t.value; var a=modal.querySelector('#mmActual'); if(a) g.actual=a.value; var l=modal.querySelector('#mmLabel'); if(l) g.label=l.value; var u=modal.querySelector('#mmUnit'); if(u) g.unit=u.value; var mo=modal.querySelector('#mmMonth'); if(mo) g.month=parseInt(mo.value,10); var y=modal.querySelector('#mmYear'); if(y) g.year=parseInt(y.value,10)||g.year; }
  function draw(){
    var preset=MKT_METRICS[g.metric]||MKT_METRICS.outro; var unit=g.unit||preset.unit; var isOutro=g.metric==='outro'; var isAuto=!!preset.auto;
    var metricOpts=MKT_ORDER.map(function(k){ return '<option value="'+k+'"'+(g.metric===k?' selected':'')+'>'+MKT_METRICS[k].label+'</option>'; }).join('');
    var moOpts=''; for(var mo=1;mo<=12;mo++) moOpts+='<option value="'+mo+'"'+((g.month||now.getMonth()+1)===mo?' selected':'')+'>'+MESES[mo-1]+'</option>';
    var labelRow = isOutro ? '<div class="modal-row"><label class="modal-label">Nome da meta *</label><input type="text" id="mmLabel" placeholder="ex: Engajamento" value="'+esc(g.label||'')+'"></div>' : '';
    var unitRow = isOutro ? '<div class="modal-row"><label class="modal-label">Tipo de valor</label><select id="mmUnit"><option value="num"'+(unit==='num'?' selected':'')+'>Número</option><option value="brl"'+(unit==='brl'?' selected':'')+'>R$ (dinheiro)</option></select></div>' : '';
    var actualRow = isAuto ? '<div class="modal-note">O realizado desta meta vem <b>automaticamente do Bling</b> (faturamento do site do mês). Não precisa preencher.</div>' : '<div class="modal-row"><label class="modal-label">Valor atual (realizado)</label><input type="text" id="mmActual" inputmode="decimal" placeholder="0" value="'+esc(g.actual!=null&&g.actual!==''?g.actual:'')+'"><div style="font-size:11px;color:var(--u-text3);margin-top:5px">Atualize conforme o mês avança (ex: leads, seguidores, alcance).</div></div>';
    var delBtn=isNew?'':'<button class="btn btn-danger btn-del-wrap" id="mmDel">Excluir</button>';
    modal.innerHTML='<div class="modal">'+
      '<div class="modal-title-input" style="cursor:default">'+(isNew?'Nova meta de marketing':'Editar meta')+'</div>'+
      '<div class="modal-row"><label class="modal-label">Indicador</label><select id="mmMetric">'+metricOpts+'</select></div>'+
      labelRow+unitRow+
      '<div class="modal-row"><label class="modal-label">Meta / alvo do mês *</label><input type="text" id="mmTarget" inputmode="decimal" placeholder="0" value="'+esc(g.target!=null&&g.target!==''?g.target:'')+'"></div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Mês</label><select id="mmMonth">'+moOpts+'</select></div><div class="modal-row"><label class="modal-label">Ano</label><input type="text" id="mmYear" inputmode="numeric" value="'+esc(g.year||now.getFullYear())+'"></div></div>'+
      actualRow+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="mmCancel">Cancelar</button><button class="btn btn-primary" id="mmSave">'+(isNew?'Criar meta':'Salvar')+'</button></div>'+
    '</div>';
    var mtr=modal.querySelector('#mmMetric'); if(mtr) mtr.addEventListener('change', function(){ capture(); g.metric=this.value; var p=MKT_METRICS[g.metric]; if(p){ g.unit=p.unit; if(g.metric!=='outro') g.label=''; } draw(); });
    modal.querySelector('#mmCancel').addEventListener('click', close);
    modal.querySelector('#mmSave').addEventListener('click', save);
    var d=modal.querySelector('#mmDel'); if(d) d.addEventListener('click', del);
  }
  function save(){
    capture();
    var preset=MKT_METRICS[g.metric]||MKT_METRICS.outro;
    var label=(g.metric==='outro')?(g.label||'').trim():preset.label;
    if(!label){ toast('Dê um nome à meta','error'); return; }
    var target=_parseBRL(g.target); if(target<=0){ toast('Informe o alvo da meta','error'); return; }
    var unit=(g.metric==='outro')?(g.unit||'num'):preset.unit;
    var rec={ sector:'marketing', month:g.month||(now.getMonth()+1), year:g.year||now.getFullYear(), metric:g.metric, label:label, target:target, unit:unit };
    if(!preset.auto) rec.actual=_parseBRL(g.actual);
    var btn=modal.querySelector('#mmSave'); setBusy(btn,true);
    if(isNew){ sb.from('malba_mkt_metas').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL de metas de marketing).','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Criar meta'; return; } ST.mktMetas.push(r.data); auditLog('Criou meta de marketing', label); close(); toast('Meta criada','success'); renderPage(); }); }
    else { sb.from('malba_mkt_metas').update(rec).eq('id',goal.id).then(function(r){ if(r.error){ toast('Erro ao salvar','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Salvar'; return; } for(var i=0;i<ST.mktMetas.length;i++) if(String(ST.mktMetas[i].id)===String(goal.id)) ST.mktMetas[i]=Object.assign(ST.mktMetas[i],rec); auditLog('Editou meta de marketing', label); close(); toast('Meta atualizada','success'); renderPage(); }); }
  }
  function del(){ confirmDelete('Excluir esta meta?', function(){ sb.from('malba_mkt_metas').delete().eq('id',goal.id).then(function(r){ if(r.error){ toast('Erro ao excluir','error'); return; } ST.mktMetas=ST.mktMetas.filter(function(x){return String(x.id)!==String(goal.id);}); close(); toast('Meta excluída','success'); renderPage(); }); }); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal); draw();
}

/* ----- Relatório mensal de Marketing (resumo executivo, pronto para apresentar) ----- */
function relMesRef(){ var d=new Date(); return { m: ST.relM || (d.getMonth()+1), y: ST.relY || d.getFullYear() }; }
function relSetMes(delta){ var r=relMesRef(); var m=r.m+delta, y=r.y; while(m<1){m+=12;y--;} while(m>12){m-=12;y++;} var d=new Date(); if(y>d.getFullYear() || (y===d.getFullYear() && m>d.getMonth()+1)) return; ST.relM=m; ST.relY=y; renderPage(); }
function relatorioHTML(){
  var r=relMesRef(); var m=r.m, y=r.y;
  var pm=(m===1?12:m-1), py=(m===1?y-1:y);
  var mmStr=(m<10?'0':'')+m; var ld=new Date(y,m,0).getDate();
  var mStart=y+'-'+mmStr+'-01', mEnd=y+'-'+mmStr+'-'+((ld<10?'0':'')+ld);
  var fatAtual=siteFatMesAno(m,y), fatAnt=siteFatMesAno(pm,py);
  var varPct = fatAnt>0 ? Math.round((fatAtual-fatAnt)/fatAnt*100) : (fatAtual>0?100:0);
  var metas=(ST.mktMetas||[]).filter(function(g){ return (g.sector||'marketing')==='marketing' && g.month===m && g.year===y; }).sort(function(a,b){ return MKT_ORDER.indexOf(a.metric)-MKT_ORDER.indexOf(b.metric); });
  var batidas=metas.filter(function(g){ var t=Number(g.target)||0; return t>0 && mktMetaActual(g)>=t; }).length;
  var camps=(ST.campaigns||[]).filter(function(c){ var s=(c.start_date||'').slice(0,10), e=(c.end_date||'').slice(0,10); if(!s && !e) return false; return (!e || e>=mStart) && (!s || s<=mEnd); });
  var campAtivas=camps.filter(function(c){ return campStatus(c).label==='Ativa'; }).length;
  var tasksFeito=(ST.tasks||[]).filter(function(t){ if(t.is_rule) return false; if(t.status!=='feito') return false; var d=(t.due_date||'').slice(0,10); return d>=mStart && d<=mEnd; }).length;
  var projAtivos=(ST.projects||[]).filter(function(p){ return p.status!=='concluido'; }).length;

  var canPrev=true; var d0=new Date(); var canNext=!(y>d0.getFullYear() || (y===d0.getFullYear() && m>=d0.getMonth()+1));
  var head='<div class="rep-head rep-noprint"><div><h2>Relatório</h2><div class="sub">Marketing · resumo do mês</div></div>'+
    '<div class="rep-tools"><button class="rep-nav" id="relPrev">‹</button><span class="rep-month">'+MESES[m-1]+' '+y+'</span><button class="rep-nav" id="relNext"'+(canNext?'':' disabled')+'>›</button><button class="btn-new" id="relPrint">'+icon('folder')+'Imprimir / PDF</button></div></div>';
  var printHead='<div class="rep-print-head"><h1>Relatório de Marketing — '+MESES[m-1]+' '+y+'</h1><p>MALBA Embalagens · gerado em '+fmtDate(today())+'</p></div>';

  function kpi(v,l,s,c){ return '<div class="rep-kpi"><span class="rep-kpi-v" style="color:'+(c||'var(--u-text)')+'">'+v+'</span><span class="rep-kpi-l">'+esc(l)+'</span>'+(s?'<span class="rep-kpi-s">'+s+'</span>':'')+'</div>'; }
  var varTag = fatAnt>0 ? ('<span class="rep-var '+(varPct>=0?'up':'down')+'">'+(varPct>=0?'▲ +':'▼ ')+varPct+'%</span>') : '<span class="rep-var flat">sem base</span>';
  var kpis='<div class="rep-kpis">'+
    kpi(brlShort(fatAtual),'Faturamento do site', varTag+' vs '+MES_ABR[pm-1], '#16A34A')+
    kpi(batidas+'/'+metas.length,'Metas batidas', metas.length?'no mês':'sem metas', '#8B5CF6')+
    kpi(campAtivas,'Campanhas ativas', camps.length+' no mês', '#3B6FF7')+
    kpi(tasksFeito,'Tarefas concluídas', 'no mês', '#0EA5E9')+
  '</div>';

  // faturamento do site + tendência 3 meses
  var t3=[]; for(var i=2;i>=0;i--){ var tm=m-i, ty=y; while(tm<1){tm+=12;ty--;} t3.push({ m:tm, y:ty, v:siteFatMesAno(tm,ty) }); }
  var maxT=Math.max(1,t3[0].v,t3[1].v,t3[2].v);
  var trend=t3.map(function(x){ var hh=Math.max(6,Math.round(x.v/maxT*100)); var cur=(x.m===m&&x.y===y); return '<div class="rep-tb"><span class="rep-tb-v">'+brlShort(x.v)+'</span><div class="rep-tb-track"><div class="rep-tb-bar" style="height:'+hh+'%;background:'+(cur?'#8B5CF6':'var(--u-border2)')+'"></div></div><span class="rep-tb-l">'+MES_ABR[x.m-1]+'</span></div>'; }).join('');
  var siteSec='<div class="rep-card"><div class="rep-card-h">'+icon('dollar')+'<h3>Faturamento do site</h3></div><div class="rep-site"><div class="rep-site-big"><span class="rep-site-v">'+fmtBRL(fatAtual)+'</span>'+varTag+'<small>mês anterior: '+fmtBRL(fatAnt)+'</small></div><div class="rep-trend">'+trend+'</div></div></div>';

  // metas do marketing
  var metasBody = metas.length ? metas.map(function(g){ var preset=MKT_METRICS[g.metric]||MKT_METRICS.outro; var unit=g.unit||preset.unit; var tg=Number(g.target)||0; var ac=mktMetaActual(g); var pct=tg>0?Math.min(100,Math.round(ac/tg*100)):0; var cor=pct>=100?'#16A34A':(pct>=60?'#8B5CF6':(pct>=30?'#F59E0B':'#EF4444')); return '<div class="rep-goal"><div class="rep-goal-top"><span>'+esc(g.label||preset.label)+'</span><b style="color:'+cor+'">'+pct+'%</b></div><div class="rep-goal-bar"><span style="width:'+pct+'%;background:'+cor+'"></span></div><div class="rep-goal-sub">'+mktFmt(ac,unit)+' de '+mktFmt(tg,unit)+'</div></div>'; }).join('') : '<div class="dash-empty">Nenhuma meta definida neste mês.</div>';
  var metasSec='<div class="rep-card"><div class="rep-card-h">'+icon('target')+'<h3>Metas do marketing</h3></div>'+metasBody+'</div>';

  // campanhas do mês
  var campsBody = camps.length ? camps.map(function(c){ var st=campStatus(c); var tks=c.tasks||[]; var done=tks.filter(function(x){return x.done;}).length; var pct=tks.length?Math.round(done/tks.length*100):0; return '<div class="rep-camp"><span class="rep-camp-dot" style="background:'+(c.color||'#8B5CF6')+'"></span><div class="rep-camp-main"><b>'+esc(c.name)+'</b><i>'+(c.start_date?fmtDate(c.start_date):'')+(c.end_date?(' → '+fmtDate(c.end_date)):'')+(tks.length?(' · '+pct+'% ('+done+'/'+tks.length+')'):'')+'</i></div><span class="crm-status" style="color:'+st.color+';background:'+st.color+'18">'+st.label+'</span></div>'; }).join('') : '<div class="dash-empty">Nenhuma campanha no período.</div>';
  var campsSec='<div class="rep-card"><div class="rep-card-h">'+icon('megaphone')+'<h3>Campanhas do mês</h3></div>'+campsBody+'</div>';

  // produtividade
  var prodSec='<div class="rep-card"><div class="rep-card-h">'+icon('dashboard')+'<h3>Produtividade</h3></div><div class="rep-prod"><div class="rep-prod-i"><b>'+tasksFeito+'</b><span>tarefas concluídas</span></div><div class="rep-prod-i"><b>'+projAtivos+'</b><span>projetos ativos</span></div><div class="rep-prod-i"><b>'+camps.length+'</b><span>campanhas no mês</span></div></div></div>';

  return head + printHead + kpis + siteSec + '<div class="rep-grid2">'+metasSec+campsSec+'</div>' + prodSec;
}
function bindRelatorio(){
  var pv=document.getElementById('relPrev'); if(pv) pv.addEventListener('click', function(){ relSetMes(-1); });
  var nx=document.getElementById('relNext'); if(nx) nx.addEventListener('click', function(){ relSetMes(1); });
  var pr=document.getElementById('relPrint'); if(pr) pr.addEventListener('click', function(){ window.print(); });
}

/* ----- Orçamento de marketing (verba planejada x gasto real, por canal) ----- */
var MKT_CANAIS = [
  { key:'meta',          label:'Meta Ads',        color:'#1877F2' },
  { key:'google',        label:'Google Ads',      color:'#EA4335' },
  { key:'instagram',     label:'Instagram',       color:'#E1306C' },
  { key:'influenciador', label:'Influenciadores', color:'#8B5CF6' },
  { key:'conteudo',      label:'Conteúdo',        color:'#F59E0B' },
  { key:'outro',         label:'Outro',           color:'#64748B' }
];
function canalLabel(k){ for(var i=0;i<MKT_CANAIS.length;i++) if(MKT_CANAIS[i].key===k) return MKT_CANAIS[i].label; return 'Outro'; }
function canalColor(k){ for(var i=0;i<MKT_CANAIS.length;i++) if(MKT_CANAIS[i].key===k) return MKT_CANAIS[i].color; return '#64748B'; }
function _inMesAno(dateStr,m,y){ var d=(dateStr||'').slice(0,10); if(!d) return false; var p=d.split('-'); return Number(p[0])===y && Number(p[1])===m; }
function orcRows(){ return (ST.mktBudget||[]); }
function mktPlano(channel,m,y){ var v=0; orcRows().forEach(function(r){ if(r.kind==='plan' && r.channel===channel && r.month===m && r.year===y) v=Number(r.value)||0; }); return v; }
function mktPlanoRow(channel,m,y){ var f=null; orcRows().forEach(function(r){ if(r.kind==='plan' && r.channel===channel && r.month===m && r.year===y) f=r; }); return f; }
function mktGastoCanal(channel,m,y){ var s=0; orcRows().forEach(function(r){ if(r.kind==='expense' && r.channel===channel && _inMesAno(r.spend_date,m,y)) s+=Number(r.value)||0; }); return s; }
function mktVerbaMes(m,y){ var s=0; orcRows().forEach(function(r){ if(r.kind==='plan' && r.month===m && r.year===y) s+=Number(r.value)||0; }); return s; }
function mktGastoMes(m,y){ var s=0; orcRows().forEach(function(r){ if(r.kind==='expense' && _inMesAno(r.spend_date,m,y)) s+=Number(r.value)||0; }); return s; }
function gastosDoMes(m,y){ return orcRows().filter(function(r){ return r.kind==='expense' && _inMesAno(r.spend_date,m,y); }).sort(function(a,b){ return String(b.spend_date).localeCompare(String(a.spend_date)); }); }
function orcMesRef(){ var d=new Date(); return { m: ST.orcM || (d.getMonth()+1), y: ST.orcY || d.getFullYear() }; }
function orcSetMes(delta){ var r=orcMesRef(); var m=r.m+delta, y=r.y; while(m<1){m+=12;y--;} while(m>12){m-=12;y++;} var d=new Date(); if(y>d.getFullYear() || (y===d.getFullYear() && m>d.getMonth()+1)) return; ST.orcM=m; ST.orcY=y; renderPage(); }
function orcamentoHTML(){
  var r=orcMesRef(); var m=r.m, y=r.y;
  var verba=mktVerbaMes(m,y), gasto=mktGastoMes(m,y), saldo=verba-gasto;
  var pct=verba>0?Math.round(gasto/verba*100):(gasto>0?100:0); var over=gasto>verba && verba>0;
  var barColor = over?'#EF4444':(pct>=85?'#F59E0B':'#8B5CF6');
  var d0=new Date(); var canNext=!(y>d0.getFullYear() || (y===d0.getFullYear() && m>=d0.getMonth()+1));
  var btn = canEdit()?'<button class="btn-new" id="btnLancarGasto">'+icon('plus')+'Lançar gasto</button>':'';
  var head='<div class="rep-head"><div><h2>Orçamento</h2><div class="sub">Verba planejada × gasto real, por canal</div></div><div class="rep-tools"><button class="rep-nav" id="orcPrev">‹</button><span class="rep-month">'+MESES[m-1]+' '+y+'</span><button class="rep-nav" id="orcNext"'+(canNext?'':' disabled')+'>›</button>'+btn+'</div></div>';
  var resumo='<div class="orc-resumo"><div class="orc-r-grid"><div><span class="orc-r-l">Verba do mês</span><b class="orc-r-v">'+fmtBRL(verba)+'</b></div><div><span class="orc-r-l">Gasto</span><b class="orc-r-v" style="color:'+(over?'#EF4444':'var(--u-text)')+'">'+fmtBRL(gasto)+'</b></div><div><span class="orc-r-l">Saldo</span><b class="orc-r-v" style="color:'+(saldo<0?'#EF4444':'#16A34A')+'">'+fmtBRL(saldo)+'</b></div></div><div class="orc-r-bar"><span style="width:'+Math.min(100,pct)+'%;background:'+barColor+'"></span></div><div class="orc-r-sub">'+pct+'% da verba usada'+(over?' · acima do previsto!':'')+'</div></div>';
  var canais = MKT_CANAIS.map(function(cn){
    var pl=mktPlano(cn.key,m,y); var ga=mktGastoCanal(cn.key,m,y); var sal=pl-ga; var cp=pl>0?Math.min(100,Math.round(ga/pl*100)):(ga>0?100:0); var ov=ga>pl&&pl>0;
    return '<div class="orc-canal"><div class="orc-canal-h"><span class="orc-canal-dot" style="background:'+cn.color+'"></span><b>'+cn.label+'</b>'+(canEdit()?'<button class="orc-set" data-setverba="'+cn.key+'">'+(pl>0?'editar verba':'definir verba')+'</button>':'')+'</div><div class="orc-canal-bar"><span style="width:'+cp+'%;background:'+(ov?'#EF4444':cn.color)+'"></span></div><div class="orc-canal-vals"><span>Gasto <b>'+fmtBRL(ga)+'</b></span><span>Verba <b>'+fmtBRL(pl)+'</b></span><span style="color:'+(sal<0?'#EF4444':'#16A34A')+'">Saldo '+fmtBRL(sal)+'</span></div></div>';
  }).join('');
  var gastos=gastosDoMes(m,y);
  var gBody = gastos.length ? gastos.map(function(e){ return '<button class="orc-exp" data-expid="'+esc(e.id)+'"><span class="orc-exp-dot" style="background:'+canalColor(e.channel)+'"></span><div class="orc-exp-main"><b>'+fmtBRL(e.value)+'</b><i>'+canalLabel(e.channel)+(e.note?(' · '+esc(e.note)):'')+'</i></div><span class="orc-exp-d">'+fmtDate(e.spend_date)+'</span></button>'; }).join('') : '<div class="dash-empty">Nenhum gasto lançado neste mês. Use "Lançar gasto".</div>';
  return head + resumo + '<div class="cfg-sec-head"><span>Por canal</span></div><div class="orc-canais">'+canais+'</div><div class="cfg-sec-head"><span>Gastos do mês</span>'+(gastos.length?'<span style="font-size:12px;color:var(--u-text3)">clique para editar</span>':'')+'</div><div class="orc-exps">'+gBody+'</div>';
}
function bindOrcamento(){
  var pv=document.getElementById('orcPrev'); if(pv) pv.addEventListener('click', function(){ orcSetMes(-1); });
  var nx=document.getElementById('orcNext'); if(nx) nx.addEventListener('click', function(){ orcSetMes(1); });
  var lg=document.getElementById('btnLancarGasto'); if(lg && canEdit()) lg.addEventListener('click', function(){ openGastoModal(null); });
  var sv=app.querySelectorAll('[data-setverba]'); for(var i=0;i<sv.length;i++) sv[i].addEventListener('click', function(){ openVerbaModal(this.getAttribute('data-setverba')); });
  var ex=app.querySelectorAll('.orc-exp[data-expid]'); for(var j=0;j<ex.length;j++) ex[j].addEventListener('click', function(){ var id=this.getAttribute('data-expid'); var e=null; for(var k=0;k<ST.mktBudget.length;k++) if(String(ST.mktBudget[k].id)===String(id)){e=ST.mktBudget[k];break;} if(e) openGastoModal(e); });
}
function openVerbaModal(channel){
  if(!canEdit()){ blockManage(); return; }
  var r=orcMesRef(); var m=r.m, y=r.y; var existing=mktPlanoRow(channel,m,y);
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Verba · '+canalLabel(channel)+'</div>'+
    '<div class="modal-row"><label class="modal-label">Verba planejada para '+MESES[m-1]+' '+y+' (R$)</label><input type="text" id="vbVal" inputmode="decimal" placeholder="0,00" value="'+esc(existing?existing.value:'')+'"></div>'+
    '<div class="modal-note">Quanto você planeja investir neste canal no mês. Compare depois com o gasto real.</div>'+
    '<div class="modal-foot">'+(existing?'<button class="btn btn-danger btn-del-wrap" id="vbDel">Remover</button>':'')+'<button class="btn btn-ghost" id="vbCancel">Cancelar</button><button class="btn btn-primary" id="vbSave">Salvar</button></div></div>';
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#vbCancel').addEventListener('click', close);
  var del=modal.querySelector('#vbDel'); if(del) del.addEventListener('click', function(){ sb.from('malba_mkt_budget').delete().eq('id',existing.id).then(function(rr){ if(rr.error){ toast('Erro ao remover','error'); return; } ST.mktBudget=ST.mktBudget.filter(function(x){return String(x.id)!==String(existing.id);}); close(); toast('Verba removida','success'); renderPage(); }); });
  modal.querySelector('#vbSave').addEventListener('click', function(){
    var val=_parseBRL(modal.querySelector('#vbVal').value); if(val<0){ toast('Valor inválido','error'); return; }
    var btn=this; setBusy(btn,true);
    if(existing){ sb.from('malba_mkt_budget').update({ value:val }).eq('id',existing.id).then(function(rr){ if(rr.error){ toast('Erro ao salvar','error'); setBusy(btn,false); btn.textContent='Salvar'; return; } existing.value=val; close(); toast('Verba atualizada','success'); renderPage(); }); }
    else { var rec={ sector:'marketing', kind:'plan', month:m, year:y, channel:channel, value:val }; sb.from('malba_mkt_budget').insert(rec).select().single().then(function(rr){ if(rr.error||!rr.data){ toast('Não consegui salvar (peça para rodar o SQL de orçamento).','error'); console.error(rr.error); setBusy(btn,false); btn.textContent='Salvar'; return; } ST.mktBudget.push(rr.data); close(); toast('Verba definida','success'); renderPage(); }); }
  });
  document.body.appendChild(modal); modal.querySelector('#vbVal').focus();
}
function openGastoModal(expense){
  if(!canEdit()){ blockManage(); return; }
  var isNew=!expense; var r=orcMesRef();
  var e=expense||{ channel:'meta', value:'', spend_date:today(), note:'', campaign_id:null };
  var canalOpts=MKT_CANAIS.map(function(cn){ return '<option value="'+cn.key+'"'+(e.channel===cn.key?' selected':'')+'>'+cn.label+'</option>'; }).join('');
  var campOpts='<option value="">— sem campanha —</option>'+(ST.campaigns||[]).map(function(c){ return '<option value="'+esc(c.id)+'"'+(String(e.campaign_id)===String(c.id)?' selected':'')+'>'+esc(c.name)+'</option>'; }).join('');
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  var delBtn=isNew?'':'<button class="btn btn-danger btn-del-wrap" id="gtDel">Excluir</button>';
  modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">'+(isNew?'Lançar gasto':'Editar gasto')+'</div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Canal</label><select id="gtCanal">'+canalOpts+'</select></div><div class="modal-row"><label class="modal-label">Valor (R$) *</label><input type="text" id="gtVal" inputmode="decimal" placeholder="0,00" value="'+esc(e.value!=null&&e.value!==''?e.value:'')+'"></div></div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Data</label><input type="date" id="gtDate" value="'+esc((e.spend_date||today()).slice(0,10))+'"></div><div class="modal-row"><label class="modal-label">Campanha (opcional)</label><select id="gtCamp">'+campOpts+'</select></div></div>'+
    '<div class="modal-row"><label class="modal-label">Descrição (opcional)</label><input type="text" id="gtNote" placeholder="ex: impulsionamento post dia das mães" value="'+esc(e.note||'')+'"></div>'+
    '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="gtCancel">Cancelar</button><button class="btn btn-primary" id="gtSave">'+(isNew?'Lançar':'Salvar')+'</button></div></div>';
  modal.addEventListener('click', function(ev){ if(ev.target===modal) close(); });
  modal.querySelector('#gtCancel').addEventListener('click', close);
  var del=modal.querySelector('#gtDel'); if(del) del.addEventListener('click', function(){ confirmDelete('Excluir este gasto?', function(){ sb.from('malba_mkt_budget').delete().eq('id',expense.id).then(function(rr){ if(rr.error){ toast('Erro ao excluir','error'); return; } ST.mktBudget=ST.mktBudget.filter(function(x){return String(x.id)!==String(expense.id);}); close(); toast('Gasto excluído','success'); renderPage(); }); }); });
  modal.querySelector('#gtSave').addEventListener('click', function(){
    var val=_parseBRL(modal.querySelector('#gtVal').value); if(val<=0){ toast('Informe o valor do gasto','error'); return; }
    var dt=modal.querySelector('#gtDate').value||today(); var pp=dt.split('-');
    var rec={ sector:'marketing', kind:'expense', channel:modal.querySelector('#gtCanal').value, value:val, spend_date:dt, month:Number(pp[1])||null, year:Number(pp[0])||null, note:(modal.querySelector('#gtNote').value||'').trim()||null, campaign_id:(modal.querySelector('#gtCamp').value||null) };
    var btn=this; setBusy(btn,true);
    if(isNew){ sb.from('malba_mkt_budget').insert(rec).select().single().then(function(rr){ if(rr.error||!rr.data){ toast('Não consegui salvar (peça para rodar o SQL de orçamento).','error'); console.error(rr.error); setBusy(btn,false); btn.textContent='Lançar'; return; } ST.mktBudget.push(rr.data); auditLog('Lançou gasto de marketing', canalLabel(rec.channel)+' R$ '+val.toFixed(2)); close(); toast('Gasto lançado','success'); renderPage(); }); }
    else { sb.from('malba_mkt_budget').update(rec).eq('id',expense.id).then(function(rr){ if(rr.error){ toast('Erro ao salvar','error'); setBusy(btn,false); btn.textContent='Salvar'; return; } for(var i=0;i<ST.mktBudget.length;i++) if(String(ST.mktBudget[i].id)===String(expense.id)) ST.mktBudget[i]=Object.assign(ST.mktBudget[i],rec); close(); toast('Gasto atualizado','success'); renderPage(); }); }
  });
  document.body.appendChild(modal); modal.querySelector('#gtVal').focus();
}

/* ----- Conteúdo: calendário editorial + pipeline com aprovação ----- */
var CONTENT_STATUS = {
  ideia:     { label:'Ideia',        color:'#64748B' },
  producao:  { label:'Em produção',  color:'#3B6FF7' },
  aprovacao: { label:'Aprovação',    color:'#F59E0B' },
  agendado:  { label:'Agendado',     color:'#8B5CF6' },
  publicado: { label:'Publicado',    color:'#16A34A' }
};
var CONTENT_ORDER = ['ideia','producao','aprovacao','agendado','publicado'];
var CONTENT_CHANS = [
  { key:'instagram', label:'Instagram', color:'#E1306C' },
  { key:'facebook',  label:'Facebook',  color:'#1877F2' },
  { key:'tiktok',    label:'TikTok',    color:'#111827' },
  { key:'email',     label:'E-mail',    color:'#F59E0B' },
  { key:'blog',      label:'Blog',      color:'#16A34A' },
  { key:'youtube',   label:'YouTube',   color:'#EF4444' },
  { key:'whatsapp',  label:'WhatsApp',  color:'#25D366' },
  { key:'outro',     label:'Outro',     color:'#64748B' }
];
var CONTENT_TYPES = ['Post','Reels','Story','Carrossel','E-mail','Blog','Vídeo','Anúncio','Outro'];
function contentChanLabel(k){ for(var i=0;i<CONTENT_CHANS.length;i++) if(CONTENT_CHANS[i].key===k) return CONTENT_CHANS[i].label; return 'Outro'; }
function contentChanColor(k){ for(var i=0;i<CONTENT_CHANS.length;i++) if(CONTENT_CHANS[i].key===k) return CONTENT_CHANS[i].color; return '#64748B'; }
function contentMesRef(){ var d=new Date(); return { m: ST.conM || (d.getMonth()+1), y: ST.conY || d.getFullYear() }; }
function contentSetMes(delta){ var r=contentMesRef(); var m=r.m+delta, y=r.y; while(m<1){m+=12;y--;} while(m>12){m-=12;y++;} ST.conM=m; ST.conY=y; renderPage(); }

function conteudoHTML(){
  var view=ST.contentView||'pipeline';
  var toggle='<div class="team-seg"><button class="'+(view==='pipeline'?'on':'')+'" data-cview="pipeline">Pipeline</button><button class="'+(view==='calendario'?'on':'')+'" data-cview="calendario">Calendário</button></div>';
  var btn=canEdit()?'<button class="btn-new" id="btnNovoConteudo">'+icon('plus')+'Novo conteúdo</button>':'';
  var body = view==='calendario' ? contentCalendarHTML() : contentPipelineHTML();
  return '<div class="tasks-head"><div><h2>Conteúdo</h2><div class="sub">Planejamento editorial · o que publicar, quando e onde</div></div><div class="cfg-head-btns">'+toggle+btn+'</div></div>'+body;
}
function contentCardHTML(it){
  var appr = (it.status==='aprovacao' && canEdit()) ? '<div class="ck-appr"><button class="ck-appr-ok" data-approve="'+esc(it.id)+'">Aprovar</button><button class="ck-appr-no" data-reject="'+esc(it.id)+'">Ajustar</button></div>' : '';
  return '<div class="ck-card" data-cid="'+esc(it.id)+'"><div class="ck-card-t">'+esc(it.title)+'</div><div class="ck-card-m"><span class="ck-chan" style="--cc:'+contentChanColor(it.channel)+'">'+esc(contentChanLabel(it.channel))+'</span>'+(it.ctype?'<span class="ck-type">'+esc(it.ctype)+'</span>':'')+(it.pub_date?'<span class="ck-date">'+fmtDate(it.pub_date)+'</span>':'')+'</div>'+(it.owner_name?'<div class="ck-owner">'+esc(it.owner_name)+'</div>':'')+appr+'</div>';
}
function contentPipelineHTML(){
  var items=(ST.contentItems||[]);
  var cols=CONTENT_ORDER.map(function(st){
    var list=items.filter(function(x){return (x.status||'ideia')===st;}).sort(function(a,b){return (a.pub_date||'').localeCompare(b.pub_date||'');});
    var cards=list.length ? list.map(contentCardHTML).join('') : '<div class="col-empty">—</div>';
    var s=CONTENT_STATUS[st];
    return '<div class="ck-col"><div class="ck-col-h"><span class="ck-dot" style="background:'+s.color+'"></span>'+s.label+' <i>'+list.length+'</i></div><div class="ck-col-b">'+cards+'</div></div>';
  }).join('');
  return '<div class="ck-board">'+cols+'</div>';
}
function contentCalendarHTML(){
  var r=contentMesRef(); var m=r.m, y=r.y;
  var first=new Date(y,m-1,1); var startDow=first.getDay(); var days=new Date(y,m,0).getDate();
  var items=(ST.contentItems||[]).filter(function(x){ return _inMesAno(x.pub_date,m,y); });
  var byDay={}; items.forEach(function(it){ var d=Number((it.pub_date||'').slice(8,10)); (byDay[d]=byDay[d]||[]).push(it); });
  var dows=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
  var headRow=dows.map(function(d){return '<div class="cc-dow">'+d+'</div>';}).join('');
  var cells='';
  for(var i=0;i<startDow;i++) cells+='<div class="cc-cell empty"></div>';
  var td=new Date();
  for(var dd=1;dd<=days;dd++){
    var its=byDay[dd]||[];
    var chips=its.slice(0,4).map(function(it){ var s=CONTENT_STATUS[it.status||'ideia']; return '<button class="cc-chip" data-cid="'+esc(it.id)+'" style="--cc:'+s.color+'" title="'+esc(it.title)+' · '+esc(contentChanLabel(it.channel))+'">'+esc(it.title)+'</button>'; }).join('')+(its.length>4?('<span class="cc-more">+'+(its.length-4)+' mais</span>'):'');
    var isToday=(y===td.getFullYear()&&m===td.getMonth()+1&&dd===td.getDate());
    cells+='<button class="cc-cell'+(isToday?' today':'')+'" data-cday="'+dd+'"><span class="cc-day">'+dd+'</span><div class="cc-chips">'+chips+'</div></button>';
  }
  var nav='<div class="rep-tools" style="margin-bottom:14px"><button class="rep-nav" id="ccPrev">‹</button><span class="rep-month">'+MESES[m-1]+' '+y+'</span><button class="rep-nav" id="ccNext">›</button></div>';
  return nav+'<div class="cc-grid">'+headRow+cells+'</div>';
}
function bindConteudo(){
  var vw=app.querySelectorAll('[data-cview]'); for(var i=0;i<vw.length;i++) vw[i].addEventListener('click', function(){ ST.contentView=this.getAttribute('data-cview'); renderPage(); });
  var nv=document.getElementById('btnNovoConteudo'); if(nv && canEdit()) nv.addEventListener('click', function(){ openContentModal(null); });
  var pv=document.getElementById('ccPrev'); if(pv) pv.addEventListener('click', function(){ contentSetMes(-1); });
  var nx=document.getElementById('ccNext'); if(nx) nx.addEventListener('click', function(){ contentSetMes(1); });
  var ap=app.querySelectorAll('[data-approve]'); for(var a=0;a<ap.length;a++) ap[a].addEventListener('click', function(e){ e.stopPropagation(); mudarStatusConteudo(this.getAttribute('data-approve'),'agendado','Conteúdo aprovado'); });
  var rj=app.querySelectorAll('[data-reject]'); for(var r2=0;r2<rj.length;r2++) rj[r2].addEventListener('click', function(e){ e.stopPropagation(); mudarStatusConteudo(this.getAttribute('data-reject'),'producao','Enviado para ajuste'); });
  var cards=app.querySelectorAll('[data-cid]'); for(var c=0;c<cards.length;c++) cards[c].addEventListener('click', function(){ var id=this.getAttribute('data-cid'); var it=null; for(var k=0;k<ST.contentItems.length;k++) if(String(ST.contentItems[k].id)===String(id)){it=ST.contentItems[k];break;} if(it) openContentModal(it); });
  var days=app.querySelectorAll('.cc-cell[data-cday]'); for(var d2=0;d2<days.length;d2++) days[d2].addEventListener('click', function(e){ if(e.target.closest('.cc-chip')) return; if(!canEdit()) return; var r=contentMesRef(); var dd=parseInt(this.getAttribute('data-cday'),10); var mm=(r.m<10?'0':'')+r.m; var dstr=r.y+'-'+mm+'-'+((dd<10?'0':'')+dd); openContentModal(null, dstr); });
}
function mudarStatusConteudo(id, status, msg){
  if(!canEdit()){ blockManage(); return; }
  var it=null; for(var k=0;k<ST.contentItems.length;k++) if(String(ST.contentItems[k].id)===String(id)){it=ST.contentItems[k];break;} if(!it) return;
  it.status=status; sb.from('malba_content').update({ status:status }).eq('id',id).then(function(r){ if(r.error) toast('Erro ao atualizar','error'); });
  auditLog('Conteúdo → '+((CONTENT_STATUS[status]||{}).label||status), it.title); toast(msg||'Status atualizado','success'); renderPage();
}
function openContentModal(item, presetDate){
  if(!canEdit()){ blockManage(); return; }
  var isNew=!item;
  var it=item||{ title:'', channel:'instagram', ctype:'Post', pub_date:(presetDate||today()), status:'ideia', owner_id:null, owner_name:'', caption:'', link:'', note:'' };
  var chanOpts=CONTENT_CHANS.map(function(c){ return '<option value="'+c.key+'"'+(it.channel===c.key?' selected':'')+'>'+c.label+'</option>'; }).join('');
  var typeOpts=CONTENT_TYPES.map(function(t){ return '<option value="'+esc(t)+'"'+(it.ctype===t?' selected':'')+'>'+t+'</option>'; }).join('');
  var statusOpts=CONTENT_ORDER.map(function(s){ return '<option value="'+s+'"'+((it.status||'ideia')===s?' selected':'')+'>'+CONTENT_STATUS[s].label+'</option>'; }).join('');
  var ownerOpts='<option value="">— sem responsável —</option>'+(ST.users||[]).map(function(u){ return '<option value="'+esc(u.id)+'"'+(String(it.owner_id)===String(u.id)?' selected':'')+'>'+esc(u.name)+'</option>'; }).join('');
  var delBtn=isNew?'':'<button class="btn btn-danger btn-del-wrap" id="ctDel">Excluir</button>';
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.innerHTML='<div class="modal">'+
    '<input class="modal-title-input" id="ctTitle" placeholder="Título do conteúdo..." value="'+esc(it.title)+'">'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Canal</label><select id="ctChan">'+chanOpts+'</select></div><div class="modal-row"><label class="modal-label">Formato</label><select id="ctType">'+typeOpts+'</select></div></div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Data de publicação</label><input type="date" id="ctDate" value="'+esc((it.pub_date||today()).slice(0,10))+'"></div><div class="modal-row"><label class="modal-label">Etapa</label><select id="ctStatus">'+statusOpts+'</select></div></div>'+
    '<div class="modal-row"><label class="modal-label">Responsável</label><select id="ctOwner">'+ownerOpts+'</select></div>'+
    '<div class="modal-row"><label class="modal-label">Legenda / texto</label><textarea id="ctCaption" placeholder="O texto do post, e-mail, legenda...">'+esc(it.caption||'')+'</textarea></div>'+
    '<div class="modal-row"><label class="modal-label">Link (arte, referência)</label><input type="text" id="ctLink" placeholder="https://..." value="'+esc(it.link||'')+'"></div>'+
    '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="ctCancel">Cancelar</button><button class="btn btn-primary" id="ctSave">'+(isNew?'Criar':'Salvar')+'</button></div>'+
  '</div>';
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#ctCancel').addEventListener('click', close);
  modal.querySelector('#ctTitle').focus();
  var del=modal.querySelector('#ctDel'); if(del) del.addEventListener('click', function(){ confirmDelete('Excluir este conteúdo?', function(){ sb.from('malba_content').delete().eq('id',item.id).then(function(r){ if(r.error){ toast('Erro ao excluir','error'); return; } ST.contentItems=ST.contentItems.filter(function(x){return String(x.id)!==String(item.id);}); close(); toast('Conteúdo excluído','success'); renderPage(); }); }); });
  modal.querySelector('#ctSave').addEventListener('click', function(){
    var title=(modal.querySelector('#ctTitle').value||'').trim(); if(!title){ toast('Dê um título','error'); return; }
    var ownerEl=modal.querySelector('#ctOwner'); var oid=ownerEl.value||null; var oname=''; if(oid){ for(var i=0;i<ST.users.length;i++) if(String(ST.users[i].id)===String(oid)) oname=ST.users[i].name; }
    var rec={ sector:'marketing', title:title, channel:modal.querySelector('#ctChan').value, ctype:modal.querySelector('#ctType').value, pub_date:(modal.querySelector('#ctDate').value||today()), status:modal.querySelector('#ctStatus').value, owner_id:oid, owner_name:oname||null, caption:(modal.querySelector('#ctCaption').value||'').trim()||null, link:(modal.querySelector('#ctLink').value||'').trim()||null };
    var btn=this; setBusy(btn,true);
    if(isNew){ sb.from('malba_content').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL de conteúdo).','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Criar'; return; } ST.contentItems.push(r.data); auditLog('Criou conteúdo', title); close(); toast('Conteúdo criado','success'); renderPage(); }); }
    else { sb.from('malba_content').update(rec).eq('id',item.id).then(function(r){ if(r.error){ toast('Erro ao salvar','error'); setBusy(btn,false); btn.textContent='Salvar'; return; } for(var i=0;i<ST.contentItems.length;i++) if(String(ST.contentItems[i].id)===String(item.id)) ST.contentItems[i]=Object.assign(ST.contentItems[i],rec); close(); toast('Conteúdo atualizado','success'); renderPage(); }); }
  });
  document.body.appendChild(modal);
}

/* ----- Biblioteca de criativos + Gerador de UTM ----- */
var CRIATIVO_KINDS = {
  arte:     { label:'Arte',     color:'#8B5CF6' },
  legenda:  { label:'Legenda',  color:'#3B6FF7' },
  texto:    { label:'Texto',    color:'#16A34A' },
  hashtags: { label:'Hashtags', color:'#F59E0B' }
};
function copyText(txt, ok){
  txt=txt||'';
  function fb(){ var ta=document.createElement('textarea'); ta.value=txt; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.focus(); ta.select(); try{ document.execCommand('copy'); toast(ok||'Copiado!','success'); }catch(e){ toast('Não consegui copiar','error'); } document.body.removeChild(ta); }
  try{ if(navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(txt).then(function(){ toast(ok||'Copiado!','success'); }, fb); } else fb(); }catch(e){ fb(); }
}
function bibliotecaHTML(){
  var items=(ST.creativos||[]); var kind=ST.bibKind||'todos'; var q=(ST.bibQ||'').trim().toLowerCase();
  var list=items.filter(function(x){
    if(kind!=='todos' && (x.kind||'texto')!==kind) return false;
    if(!q) return true;
    return (x.title||'').toLowerCase().indexOf(q)!==-1 || (x.content||'').toLowerCase().indexOf(q)!==-1 || (x.tags||'').toLowerCase().indexOf(q)!==-1;
  });
  var chips=['todos','arte','legenda','texto','hashtags'].map(function(k){ var lb=k==='todos'?'Todos':CRIATIVO_KINDS[k].label; var n=(k==='todos')?items.length:items.filter(function(x){return (x.kind||'texto')===k;}).length; return '<button class="crm-chip'+(kind===k?' on':'')+'" data-bibkind="'+k+'">'+lb+' <i>'+n+'</i></button>'; }).join('');
  var btns=(canEdit()?'<button class="btn-new" id="btnNovoCriativo">'+icon('plus')+'Novo item</button>':'')+'<button class="btn-sync" id="btnUtm">'+icon('trend')+'Gerar link (UTM)</button>';
  var cards=list.length ? list.map(criativoCardHTML).join('') : emptyState({ span:true, icon:'image', title:'Biblioteca vazia', text:'Guarde aqui artes, legendas, textos e hashtags que você reaproveita.', cta:(canEdit()?'Novo item':'') });
  return '<div class="tasks-head"><div><h2>Biblioteca</h2><div class="sub">Artes, legendas e textos reaproveitáveis</div></div><div class="cfg-head-btns">'+btns+'</div></div>'+
    '<div class="crm-chips">'+chips+'</div>'+
    '<div class="crm-search">'+icon('search')+'<input id="bibSearch" placeholder="Buscar por título, texto ou tag..." value="'+esc(ST.bibQ||'')+'"></div>'+
    '<div class="bib-grid">'+cards+'</div>';
}
function criativoCardHTML(it){
  var k=CRIATIVO_KINDS[it.kind||'texto']||CRIATIVO_KINDS.texto; var isArte=(it.kind==='arte');
  var preview = isArte ? (it.url?('<a class="bib-link" href="'+esc(it.url)+'" target="_blank" rel="noopener" data-stop="1">'+esc(it.url)+'</a>'):'')+(it.content?'<div class="bib-text">'+esc(it.content)+'</div>':'') : ('<div class="bib-text">'+esc(it.content||'')+'</div>');
  var copyVal = isArte ? (it.url||'') : (it.content||'');
  var tags = (it.tags||'').split(',').map(function(t){return t.trim();}).filter(Boolean).slice(0,5).map(function(t){return '<span class="bib-tag">#'+esc(t.replace(/^#/,''))+'</span>';}).join('');
  return '<div class="bib-card" data-bibid="'+esc(it.id)+'"><div class="bib-h"><span class="bib-kind" style="--kc:'+k.color+'">'+k.label+'</span>'+(it.channel?'<span class="bib-chan">'+esc(contentChanLabel(it.channel))+'</span>':'')+'</div><div class="bib-t">'+esc(it.title||'(sem título)')+'</div>'+preview+(tags?'<div class="bib-tags">'+tags+'</div>':'')+'<div class="bib-actions"><button class="bib-copy" data-copy="'+esc(encodeURIComponent(copyVal))+'" data-stop="1">'+icon('folder')+'Copiar</button>'+(isArte&&it.url?'<a class="bib-open" href="'+esc(it.url)+'" target="_blank" rel="noopener" data-stop="1">Abrir</a>':'')+'</div></div>';
}
function bindBiblioteca(){
  var chips=app.querySelectorAll('[data-bibkind]'); for(var i=0;i<chips.length;i++) chips[i].addEventListener('click', function(){ ST.bibKind=this.getAttribute('data-bibkind'); renderPage(); });
  var s=document.getElementById('bibSearch'); if(s) s.addEventListener('input', function(){ var v=this.value.trim().toLowerCase(); ST.bibQ=this.value; var cs=app.querySelectorAll('.bib-card'); for(var j=0;j<cs.length;j++){ var t=(cs[j].textContent||'').toLowerCase(); cs[j].style.display=(!v||t.indexOf(v)!==-1)?'':'none'; } });
  var nv=document.getElementById('btnNovoCriativo'); if(nv && canEdit()) nv.addEventListener('click', function(){ openCriativoModal(null); });
  var ut=document.getElementById('btnUtm'); if(ut) ut.addEventListener('click', function(){ openUtmModal(); });
  var cps=app.querySelectorAll('[data-copy]'); for(var c=0;c<cps.length;c++) cps[c].addEventListener('click', function(e){ e.stopPropagation(); copyText(decodeURIComponent(this.getAttribute('data-copy')||''), 'Copiado!'); });
  var st=app.querySelectorAll('.bib-card [data-stop]'); for(var z=0;z<st.length;z++) st[z].addEventListener('click', function(e){ e.stopPropagation(); });
  if(!canEdit()) return;
  var cards=app.querySelectorAll('.bib-card[data-bibid]'); for(var k=0;k<cards.length;k++) cards[k].addEventListener('click', function(){ var id=this.getAttribute('data-bibid'); var it=null; for(var q=0;q<ST.creativos.length;q++) if(String(ST.creativos[q].id)===String(id)){it=ST.creativos[q];break;} if(it) openCriativoModal(it); });
}
function openCriativoModal(item){
  if(!canEdit()){ blockManage(); return; }
  var isNew=!item; var it=item||{ title:'', kind:'legenda', channel:'', content:'', url:'', tags:'' };
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  var g={ title:it.title, kind:it.kind||'legenda', channel:it.channel||'', content:it.content||'', url:it.url||'', tags:it.tags||'' };
  function cap(){ var t=modal.querySelector('#crTitle'); if(t) g.title=t.value; var c=modal.querySelector('#crContent'); if(c) g.content=c.value; var u=modal.querySelector('#crUrl'); if(u) g.url=u.value; var tg=modal.querySelector('#crTags'); if(tg) g.tags=tg.value; var ch=modal.querySelector('#crChan'); if(ch) g.channel=ch.value; }
  function draw(){
    var kindOpts=Object.keys(CRIATIVO_KINDS).map(function(k){ return '<option value="'+k+'"'+(g.kind===k?' selected':'')+'>'+CRIATIVO_KINDS[k].label+'</option>'; }).join('');
    var chanOpts='<option value="">— nenhum —</option>'+CONTENT_CHANS.map(function(c){ return '<option value="'+c.key+'"'+(g.channel===c.key?' selected':'')+'>'+c.label+'</option>'; }).join('');
    var isArte=(g.kind==='arte');
    var urlRow = isArte ? '<div class="modal-row"><label class="modal-label">Link da arte *</label><input type="text" id="crUrl" placeholder="https://... (Drive, Canva, imagem)" value="'+esc(g.url)+'"></div>' : '';
    var contentRow = '<div class="modal-row"><label class="modal-label">'+(isArte?'Descrição (opcional)':'Texto / conteúdo *')+'</label><textarea id="crContent" placeholder="'+(isArte?'Do que é essa arte...':'A legenda, texto ou hashtags para reutilizar...')+'">'+esc(g.content)+'</textarea></div>';
    var delBtn=isNew?'':'<button class="btn btn-danger btn-del-wrap" id="crDel">Excluir</button>';
    modal.innerHTML='<div class="modal">'+
      '<input class="modal-title-input" id="crTitle" placeholder="Título (ex: Legenda Dia das Mães)" value="'+esc(g.title)+'">'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Tipo</label><select id="crKind">'+kindOpts+'</select></div><div class="modal-row"><label class="modal-label">Canal (opcional)</label><select id="crChan">'+chanOpts+'</select></div></div>'+
      urlRow+contentRow+
      '<div class="modal-row"><label class="modal-label">Tags (separadas por vírgula)</label><input type="text" id="crTags" placeholder="promo, datas, institucional" value="'+esc(g.tags)+'"></div>'+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="crCancel">Cancelar</button><button class="btn btn-primary" id="crSave">'+(isNew?'Salvar':'Salvar')+'</button></div>'+
    '</div>';
    var kd=modal.querySelector('#crKind'); if(kd) kd.addEventListener('change', function(){ cap(); g.kind=this.value; draw(); });
    modal.querySelector('#crCancel').addEventListener('click', close);
    modal.querySelector('#crSave').addEventListener('click', save);
    var d=modal.querySelector('#crDel'); if(d) d.addEventListener('click', del);
  }
  function save(){
    cap();
    var title=(g.title||'').trim(); if(!title){ toast('Dê um título','error'); return; }
    if(g.kind==='arte' && !(g.url||'').trim()){ toast('Informe o link da arte','error'); return; }
    if(g.kind!=='arte' && !(g.content||'').trim()){ toast('Escreva o texto','error'); return; }
    var rec={ sector:'marketing', title:title, kind:g.kind, channel:(g.channel||null), content:(g.content||'').trim()||null, url:(g.url||'').trim()||null, tags:(g.tags||'').trim()||null };
    var btn=modal.querySelector('#crSave'); setBusy(btn,true);
    if(isNew){ sb.from('malba_creativos').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL da biblioteca).','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Salvar'; return; } ST.creativos.unshift(r.data); auditLog('Criou criativo', title); close(); toast('Item salvo','success'); renderPage(); }); }
    else { sb.from('malba_creativos').update(rec).eq('id',item.id).then(function(r){ if(r.error){ toast('Erro ao salvar','error'); setBusy(btn,false); btn.textContent='Salvar'; return; } for(var i=0;i<ST.creativos.length;i++) if(String(ST.creativos[i].id)===String(item.id)) ST.creativos[i]=Object.assign(ST.creativos[i],rec); close(); toast('Item atualizado','success'); renderPage(); }); }
  }
  function del(){ confirmDelete('Excluir este item?', function(){ sb.from('malba_creativos').delete().eq('id',item.id).then(function(r){ if(r.error){ toast('Erro ao excluir','error'); return; } ST.creativos=ST.creativos.filter(function(x){return String(x.id)!==String(item.id);}); close(); toast('Item excluído','success'); renderPage(); }); }); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal); draw();
}
var UTM_SOURCES=['instagram','facebook','google','tiktok','youtube','email','whatsapp','bio'];
var UTM_MEDIUMS=['cpc','social','stories','feed','email','organic','bio','influencer'];
function buildUtm(base, p){
  base=(base||'').trim(); if(!base) return '';
  if(!/^https?:\/\//i.test(base)) base='https://'+base;
  var qs=[]; ['utm_source','utm_medium','utm_campaign','utm_term','utm_content'].forEach(function(k){ var v=(p[k]||'').trim(); if(v) qs.push(k+'='+encodeURIComponent(v)); });
  if(!qs.length) return base;
  var sep=base.indexOf('?')!==-1?'&':'?'; return base+sep+qs.join('&');
}
function openUtmModal(){
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  var srcList=UTM_SOURCES.map(function(s){return '<option value="'+s+'">';}).join('');
  var medList=UTM_MEDIUMS.map(function(s){return '<option value="'+s+'">';}).join('');
  modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Gerar link rastreável (UTM)</div>'+
    '<div class="modal-row"><label class="modal-label">Link de destino *</label><input type="text" id="utmBase" placeholder="site.com.br/produto" ></div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Origem (source)</label><input type="text" id="utmSource" list="utmSrc" placeholder="instagram"><datalist id="utmSrc">'+srcList+'</datalist></div><div class="modal-row"><label class="modal-label">Mídia (medium)</label><input type="text" id="utmMedium" list="utmMed" placeholder="social"><datalist id="utmMed">'+medList+'</datalist></div></div>'+
    '<div class="modal-row"><label class="modal-label">Campanha (campaign)</label><input type="text" id="utmCampaign" placeholder="dia_das_maes"></div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Termo (opcional)</label><input type="text" id="utmTerm" placeholder=""></div><div class="modal-row"><label class="modal-label">Conteúdo (opcional)</label><input type="text" id="utmContent" placeholder="story1"></div></div>'+
    '<div class="utm-out-wrap"><label class="modal-label">Seu link</label><div class="utm-out" id="utmOut">—</div></div>'+
    '<div class="modal-foot"><button class="btn btn-ghost" id="utmClose">Fechar</button><button class="btn btn-primary" id="utmCopy">Copiar link</button></div>'+
  '</div>';
  function fields(){ return { utm_source:modal.querySelector('#utmSource').value, utm_medium:modal.querySelector('#utmMedium').value, utm_campaign:modal.querySelector('#utmCampaign').value, utm_term:modal.querySelector('#utmTerm').value, utm_content:modal.querySelector('#utmContent').value }; }
  function recompute(){ var link=buildUtm(modal.querySelector('#utmBase').value, fields()); modal.querySelector('#utmOut').textContent = link || '—'; return link; }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#utmClose').addEventListener('click', close);
  ['#utmBase','#utmSource','#utmMedium','#utmCampaign','#utmTerm','#utmContent'].forEach(function(sel){ var el=modal.querySelector(sel); if(el) el.addEventListener('input', recompute); });
  modal.querySelector('#utmCopy').addEventListener('click', function(){ var link=recompute(); if(!link){ toast('Preencha o link de destino','error'); return; } copyText(link, 'Link copiado!'); });
  document.body.appendChild(modal); modal.querySelector('#utmBase').focus(); recompute();
}

/* ----- Checklist de abertura/fechamento (rotina diária por loja, na aba Tarefas) ----- */
var CHECK_TURNOS = [ { key:'abertura', label:'Abertura', icon:'sun' }, { key:'fechamento', label:'Fechamento', icon:'moon' } ];
function checklistItemsDoTurno(turno){ return (ST.checklistItems||[]).filter(function(x){ return (x.sector||'lojas')==='lojas' && x.turno===turno && x.active!==false; }).sort(function(a,b){ return (a.ordem||0)-(b.ordem||0); }); }
function checklistDoneFor(itemId, storeId, date){ var f=null; (ST.checklistDone||[]).forEach(function(r){ if(String(r.item_id)===String(itemId) && String(r.store_unit_id)===String(storeId) && String(r.work_date).slice(0,10)===date) f=r; }); return f; }
function _nextOrdemChk(turno){ var mx=0; checklistItemsDoTurno(turno).forEach(function(it){ if((it.ordem||0)>mx) mx=it.ordem; }); return mx+1; }
function toggleChecklistItem(item, storeId){
  if(!storeId) return; var d=today(); var existing=checklistDoneFor(item.id, storeId, d); var u=ST.session.user; var nowIso=new Date().toISOString();
  if(existing){ var nd=!existing.done; sb.from('malba_checklist_done').update({ done:nd, done_by:u.id, done_by_name:u.name, done_at:(nd?nowIso:null) }).eq('id',existing.id).then(function(r){ if(!r.error){ existing.done=nd; existing.done_by=u.id; existing.done_by_name=u.name; existing.done_at=(nd?nowIso:null); renderPage(); } else toast('Erro ao marcar','error'); }); }
  else { sb.from('malba_checklist_done').insert({ item_id:item.id, store_unit_id:storeId, work_date:d, done:true, done_by:u.id, done_by_name:u.name, done_at:nowIso }).select().single().then(function(r){ if(!r.error&&r.data){ ST.checklistDone.push(r.data); renderPage(); } else { toast('Não consegui marcar (peça para rodar o SQL do checklist).','error'); console.error(r.error); } }); }
}
function rotinaHTML(){
  var sid = boardStore();
  if (!sid) return '<div class="empty-page"><div class="ep-ico">'+icon('clock')+'</div><h3>Escolha a loja</h3><p>Selecione a loja no filtro acima para ver a rotina do dia.</p></div>';
  var d = today();
  var editBtn = canManage() ? '<button class="rot-edit" id="btnEditRotina">'+icon('gear')+'Editar rotina</button>' : '';
  var blocks = CHECK_TURNOS.map(function(t){
    var items = checklistItemsDoTurno(t.key);
    var doneCount = items.filter(function(it){ var dr=checklistDoneFor(it.id, sid, d); return dr && dr.done; }).length;
    var rows = items.length ? items.map(function(it){
      var dr = checklistDoneFor(it.id, sid, d); var done = dr && dr.done;
      var who = done ? ('<span class="rot-who">'+esc((dr.done_by_name||'').split(' ')[0])+' · '+hhmm(dr.done_at)+'</span>') : '';
      return '<button class="rot-item'+(done?' done':'')+'" data-check="'+esc(it.id)+'"><span class="rot-box">'+(done?icon('tasks'):'')+'</span><span class="rot-label">'+esc(it.label)+'</span>'+who+'</button>';
    }).join('') : '<div class="col-empty">Nenhum item neste turno.'+(canManage()?' Use "Editar rotina".':'')+'</div>';
    var pct = items.length ? Math.round(doneCount/items.length*100) : 0;
    return '<div class="rot-block"><div class="rot-block-h">'+icon(t.icon)+'<b>'+t.label+'</b><span class="rot-prog'+(items.length&&doneCount===items.length?' full':'')+'">'+doneCount+'/'+items.length+'</span></div><div class="rot-bar"><span style="width:'+pct+'%"></span></div><div class="rot-items">'+rows+'</div></div>';
  }).join('');
  var hoje = new Date(); var dataStr = hoje.getDate()+' de '+MESES[hoje.getMonth()]+' de '+hoje.getFullYear();
  var lojaNome = storeName(sid) || '';
  return '<div class="rot-head"><div class="rot-head-l">'+icon('clock')+'<div><b>Rotina do dia</b><i>'+esc(dataStr)+(lojaNome?(' · '+esc(lojaNome)):'')+'</i></div></div>'+editBtn+'</div><div class="rot-blocks">'+blocks+'</div>'+caixaCardHTML(sid, d);
}
function bindRotina(){
  var sid=boardStore();
  var eb=document.getElementById('btnEditRotina'); if(eb) eb.addEventListener('click', openRotinaConfig);
  var cb=document.getElementById('btnCaixa'); if(cb) cb.addEventListener('click', function(){ openCaixaModal(sid, caixaDoDia(sid, today())); });
  var items=app.querySelectorAll('.rot-item[data-check]');
  for(var i=0;i<items.length;i++) items[i].addEventListener('click', function(){ var id=this.getAttribute('data-check'); var it=null; for(var k=0;k<ST.checklistItems.length;k++) if(String(ST.checklistItems[k].id)===String(id)){it=ST.checklistItems[k];break;} if(it && sid) toggleChecklistItem(it, sid); });
}
function openRotinaConfig(){
  if(!canManage()){ blockManage(); return; }
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  function draw(){
    var blocks=CHECK_TURNOS.map(function(t){
      var items=checklistItemsDoTurno(t.key);
      var rows=items.length ? items.map(function(it){ return '<div class="rc-item"><input type="text" class="rc-input" data-itemid="'+esc(it.id)+'" value="'+esc(it.label)+'"><button class="rc-del" data-delitem="'+esc(it.id)+'" title="Remover">'+icon('logout')+'</button></div>'; }).join('') : '<div class="col-empty" style="margin:4px 0">Sem itens ainda.</div>';
      return '<div class="rc-block"><div class="rc-block-h">'+icon(t.icon)+t.label+'</div><div class="rc-items">'+rows+'</div><div class="rc-add"><input type="text" class="rc-new" id="rcNew_'+t.key+'" placeholder="Novo item de '+t.label.toLowerCase()+'..."><button class="btn btn-primary rc-addbtn" data-addturno="'+t.key+'">Adicionar</button></div></div>';
    }).join('');
    modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Editar rotina da loja</div><div class="modal-note">Estes itens valem para <b>todas as lojas</b>. A equipe marca o que foi feito a cada dia. Edite o texto direto no campo.</div>'+blocks+'<div class="modal-foot"><button class="btn btn-primary" id="rcClose">Concluído</button></div></div>';
    bind();
  }
  function bind(){
    modal.querySelector('#rcClose').addEventListener('click', close);
    var adds=modal.querySelectorAll('[data-addturno]');
    for(var a=0;a<adds.length;a++) adds[a].addEventListener('click', function(){ var turno=this.getAttribute('data-addturno'); var inp=modal.querySelector('#rcNew_'+turno); var label=(inp.value||'').trim(); if(!label){ inp.focus(); return; } var rec={ sector:'lojas', turno:turno, label:label, ordem:_nextOrdemChk(turno), active:true }; this.disabled=true; sb.from('malba_checklist_items').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL do checklist).','error'); console.error(r.error); draw(); return; } ST.checklistItems.push(r.data); draw(); }); });
    var dels=modal.querySelectorAll('[data-delitem]');
    for(var d=0;d<dels.length;d++) dels[d].addEventListener('click', function(){ var id=this.getAttribute('data-delitem'); confirmDelete('Remover este item da rotina?', function(){ sb.from('malba_checklist_items').delete().eq('id',id).then(function(r){ if(r.error){ toast('Erro ao remover','error'); return; } ST.checklistItems=ST.checklistItems.filter(function(x){return String(x.id)!==String(id);}); draw(); }); }); });
    var inputs=modal.querySelectorAll('.rc-input');
    for(var i=0;i<inputs.length;i++) inputs[i].addEventListener('change', function(){ var id=this.getAttribute('data-itemid'); var label=(this.value||'').trim(); if(!label){ this.value=''; return; } sb.from('malba_checklist_items').update({ label:label }).eq('id',id).then(function(r){ if(!r.error){ for(var k=0;k<ST.checklistItems.length;k++) if(String(ST.checklistItems[k].id)===String(id)) ST.checklistItems[k].label=label; } else toast('Erro ao salvar','error'); }); });
  }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal); draw();
}

/* ----- Fechamento de caixa diário (por loja/dia) ----- */
function caixaDoDia(storeId, date){ var f=null; (ST.caixas||[]).forEach(function(c){ if(String(c.store_unit_id)===String(storeId) && String(c.work_date).slice(0,10)===date) f=c; }); return f; }
function caixaCardHTML(sid, d){
  var c = caixaDoDia(sid, d);
  if (c) {
    var esp=Number(c.esperado||0), cont=Number(c.contado||0), dif=cont-esp;
    var cor = dif===0 ? '#16A34A' : (dif>0 ? '#F59E0B' : '#EF4444');
    var difLabel = dif===0 ? 'Bateu certinho' : (dif>0 ? 'Sobra no caixa' : 'Falta no caixa');
    return '<div class="caixa-card done"><div class="caixa-h">'+icon('dollar')+'<b>Fechamento de caixa</b><button class="caixa-edit" id="btnCaixa">editar</button></div>'+
      '<div class="caixa-vals"><div class="cx-v"><small>Esperado</small><span>'+fmtBRL(esp)+'</span></div><div class="cx-v"><small>Contado</small><span>'+fmtBRL(cont)+'</span></div><div class="cx-v big"><small>Diferença</small><span style="color:'+cor+'">'+(dif>0?'+':'')+fmtBRL(dif)+'</span><i style="color:'+cor+'">'+difLabel+'</i></div></div>'+
      (c.obs?'<div class="caixa-obs">'+icon('chat')+'<span>'+esc(c.obs)+'</span></div>':'')+
      '<div class="caixa-by">Fechado por '+esc((c.done_by_name||'—').split(' ')[0])+(c.closed_at?(' · '+hhmm(c.closed_at)):'')+'</div>'+
    '</div>';
  }
  return '<div class="caixa-card empty"><div class="caixa-h">'+icon('dollar')+'<b>Fechamento de caixa</b></div><p class="caixa-empty-txt">Ainda não fechado hoje. Registre o valor esperado e o contado — o sistema calcula a diferença.</p><button class="btn btn-primary" id="btnCaixa">Fechar caixa do dia</button></div>';
}
function openCaixaModal(storeId, existing){
  if(!storeId) return;
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  var esp = existing&&existing.esperado!=null ? existing.esperado : '';
  var cont = existing&&existing.contado!=null ? existing.contado : '';
  var obs = existing ? (existing.obs||'') : '';
  var delBtn = existing ? '<button class="btn btn-danger btn-del-wrap" id="cxDel">Excluir</button>' : '';
  modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Fechamento de caixa</div>'+
    '<div class="modal-note">'+esc(storeName(storeId)||'Loja')+' · '+fmtDate(today())+'</div>'+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Valor esperado (R$)</label><input type="text" id="cxEsp" inputmode="decimal" placeholder="0,00" value="'+esc(esp!==''?esp:'')+'"></div><div class="modal-row"><label class="modal-label">Valor contado (R$)</label><input type="text" id="cxCont" inputmode="decimal" placeholder="0,00" value="'+esc(cont!==''?cont:'')+'"></div></div>'+
    '<div class="cx-dif-box" id="cxDifBox">Diferença: <b id="cxDif">R$ 0,00</b></div>'+
    '<div class="modal-row"><label class="modal-label">Observação</label><textarea id="cxObs" placeholder="Ex: sangria de R$ 200, troco inicial, etc.">'+esc(obs)+'</textarea></div>'+
    '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="cxCancel">Cancelar</button><button class="btn btn-primary" id="cxSave">'+(existing?'Salvar':'Fechar caixa')+'</button></div>'+
  '</div>';
  function recompute(){ var e=_parseBRL(modal.querySelector('#cxEsp').value); var c=_parseBRL(modal.querySelector('#cxCont').value); var dif=c-e; var box=modal.querySelector('#cxDifBox'); var el=modal.querySelector('#cxDif'); el.textContent=(dif>0?'+':'')+fmtBRL(dif); var cor=dif===0?'#16A34A':(dif>0?'#F59E0B':'#EF4444'); el.style.color=cor; box.style.borderColor=cor; }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#cxCancel').addEventListener('click', close);
  modal.querySelector('#cxEsp').addEventListener('input', recompute);
  modal.querySelector('#cxCont').addEventListener('input', recompute);
  var del=modal.querySelector('#cxDel'); if(del) del.addEventListener('click', function(){ confirmDelete('Excluir o fechamento de caixa de hoje?', function(){ sb.from('malba_caixa').delete().eq('id',existing.id).then(function(r){ if(r.error){ toast('Erro ao excluir','error'); return; } ST.caixas=ST.caixas.filter(function(x){return String(x.id)!==String(existing.id);}); close(); toast('Fechamento excluído','success'); renderPage(); }); }); });
  modal.querySelector('#cxSave').addEventListener('click', function(){
    var e=_parseBRL(modal.querySelector('#cxEsp').value); var c=_parseBRL(modal.querySelector('#cxCont').value);
    var u=ST.session.user; var rec={ store_unit_id:storeId, work_date:today(), esperado:e, contado:c, diferenca:(c-e), obs:(modal.querySelector('#cxObs').value||'').trim()||null, done_by:u.id, done_by_name:u.name, closed_at:new Date().toISOString() };
    var btn=this; setBusy(btn,true);
    if(existing){ sb.from('malba_caixa').update(rec).eq('id',existing.id).then(function(r){ if(r.error){ toast('Erro ao salvar','error'); setBusy(btn,false); btn.textContent='Salvar'; return; } for(var i=0;i<ST.caixas.length;i++) if(String(ST.caixas[i].id)===String(existing.id)) ST.caixas[i]=Object.assign(ST.caixas[i],rec); close(); toast('Caixa atualizado','success'); renderPage(); }); }
    else { sb.from('malba_caixa').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL do caixa).','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Fechar caixa'; return; } ST.caixas.push(r.data); auditLog('Fechou o caixa', storeName(storeId)); close(); toast('Caixa fechado','success'); renderPage(); }); }
  });
  document.body.appendChild(modal); recompute(); modal.querySelector('#cxEsp').focus();
}

/* ----- Relatório de Lojas (indicadores de qualidade da venda, para reunião) ----- */
function blingOrdersStoreMonth(storeId, m, y){ var s=0; (ST.blingFat||[]).forEach(function(f){ if(String(f.store_unit_id)!==String(storeId)) return; var d=(f.ref_date||'').slice(0,10); var p=d.split('-'); if(Number(p[0])===Number(y)&&Number(p[1])===Number(m)) s+=Number(f.orders_count)||0; }); return s; }
function metricasEntry(storeId, m, y){ var f=null; (ST.lojaMetricas||[]).forEach(function(x){ if(String(x.store_unit_id)===String(storeId) && x.month===m && x.year===y) f=x; }); return f; }
function lojaMetaValorMes(storeId, m, y){ var meta=0, real=0; (ST.goals||[]).forEach(function(g){ if(g.month===m && g.year===y && String(g.store_unit_id)===String(storeId)){ meta+=Number(g.goal_value)||0; real+=realizadoMeta(g); } }); return { meta:meta, real:real, pct: meta>0?Math.min(100,Math.round(real/meta*100)):0 }; }
function lojaMetricasMes(storeId, m, y){
  var e=metricasEntry(storeId, m, y);
  var fatBling=blingFatStoreMonth(storeId, m, y), vendasBling=blingOrdersStoreMonth(storeId, m, y);
  var fat=(e&&Number(e.faturamento)>0)?Number(e.faturamento):fatBling;
  var vendas=(e&&Number(e.num_vendas)>0)?Number(e.num_vendas):vendasBling;
  var itens=e?Number(e.num_itens)||0:0, visitantes=e?Number(e.num_visitantes)||0:0;
  return { fat:fat, vendas:vendas, itens:itens, visitantes:visitantes,
    ticket: vendas>0?fat/vendas:0, itensPorVenda: vendas>0?itens/vendas:0, conversao: visitantes>0?(vendas/visitantes*100):0 };
}
function vendasMembroMesAno(member, m, y){ if(!member) return 0; var u=userDoMembro(member); var uid=u?u.id:null; var mid=member.id; var s=0; (ST.salesEntries||[]).forEach(function(e){ var d=(e.sale_date||'').slice(0,10); var p=d.split('-'); if(Number(p[0])!==Number(y)||Number(p[1])!==Number(m)) return; if((mid&&String(e.member_id)===String(mid))||(uid&&String(e.user_id)===String(uid))) s+=Number(e.value)||0; }); return s; }
function lrMesRef(){ var d=new Date(); return { m: ST.lrM || (d.getMonth()+1), y: ST.lrY || d.getFullYear() }; }
function lrSetMes(delta){ var r=lrMesRef(); var m=r.m+delta, y=r.y; while(m<1){m+=12;y--;} while(m>12){m-=12;y++;} var d=new Date(); if(y>d.getFullYear()||(y===d.getFullYear()&&m>d.getMonth()+1)) return; ST.lrM=m; ST.lrY=y; renderPage(); }
function lrFmtItens(v){ return (Math.round(v*10)/10).toLocaleString('pt-BR'); }
function lrFmtConv(v){ return (Math.round(v*10)/10).toLocaleString('pt-BR')+'%'; }

function relatorioLojasHTML(){
  var r=lrMesRef(); var m=r.m, y=r.y;
  var lojas=(ST.storeUnits||[]).filter(function(s){ return !s.is_site; });
  var storeFixed = ST.store ? ST.store.id : null;
  var sid = storeFixed || ST.lrStore || '';
  var d0=new Date(); var canNext=!(y>d0.getFullYear()||(y===d0.getFullYear()&&m>=d0.getMonth()+1));
  var storeSel = storeFixed ? '' : ('<select class="task-filter" id="lrStore"><option value="">Todas as lojas</option>'+lojas.map(function(s){ return '<option value="'+esc(s.id)+'"'+(String(sid)===String(s.id)?' selected':'')+'>'+esc(s.name||('Loja '+s.store_number))+'</option>'; }).join('')+'</select>');
  var head='<div class="rep-head rep-noprint"><div><h2>Relatório</h2><div class="sub">Lojas · indicadores do mês</div></div><div class="rep-tools">'+storeSel+'<button class="rep-nav" id="lrPrev">‹</button><span class="rep-month">'+MESES[m-1]+' '+y+'</span><button class="rep-nav" id="lrNext"'+(canNext?'':' disabled')+'>›</button><button class="btn-new" id="lrPrint">'+icon('folder')+'Imprimir / PDF</button></div></div>';
  var focoNome = sid ? (storeName(sid)||'Loja') : 'Todas as lojas';
  var printHead='<div class="rep-print-head"><h1>Relatório de Lojas — '+esc(focoNome)+' — '+MESES[m-1]+' '+y+'</h1><p>MALBA Embalagens · gerado em '+fmtDate(today())+'</p></div>';
  var body = sid ? lojaReportSingle(sid, m, y) : lojaReportConsolidado(lojas, m, y);
  return head + printHead + body;
}
function kpiCard(v,l,s,c){ return '<div class="rep-kpi"><span class="rep-kpi-v" style="color:'+(c||'var(--u-text)')+'">'+v+'</span><span class="rep-kpi-l">'+esc(l)+'</span>'+(s?'<span class="rep-kpi-s">'+s+'</span>':'')+'</div>'; }
function lojaReportSingle(sid, m, y){
  var pm=(m===1?12:m-1), py=(m===1?y-1:y);
  var cur=lojaMetricasMes(sid, m, y); var ant=lojaMetricasMes(sid, pm, py);
  var varPct = ant.fat>0 ? Math.round((cur.fat-ant.fat)/ant.fat*100) : (cur.fat>0?100:0);
  var varTag = ant.fat>0 ? ('<span class="rep-var '+(varPct>=0?'up':'down')+'">'+(varPct>=0?'▲ +':'▼ ')+varPct+'%</span>') : '<span class="rep-var flat">sem base</span>';
  var meta=lojaMetaValorMes(sid, m, y);
  var kpis='<div class="rep-kpis">'+
    kpiCard(brlShort(cur.fat),'Faturamento', varTag+' vs '+MES_ABR[pm-1], '#16A34A')+
    kpiCard(fmtBRL(cur.ticket),'Ticket médio', cur.vendas+' vendas', '#3B6FF7')+
    kpiCard(cur.itensPorVenda>0?lrFmtItens(cur.itensPorVenda):'—','Itens por venda', cur.itens+' itens', '#8B5CF6')+
    kpiCard(cur.conversao>0?lrFmtConv(cur.conversao):'—','Conversão', cur.visitantes>0?(cur.visitantes+' visitantes'):'sem visitantes', '#F59E0B')+
  '</div>';
  // faturamento + tendência 3 meses
  var t3=[]; for(var i=2;i>=0;i--){ var tm=m-i, ty=y; while(tm<1){tm+=12;ty--;} t3.push({ m:tm, y:ty, v:lojaMetricasMes(sid,tm,ty).fat }); }
  var maxT=Math.max(1,t3[0].v,t3[1].v,t3[2].v);
  var trend=t3.map(function(x){ var hh=Math.max(6,Math.round(x.v/maxT*100)); var isc=(x.m===m&&x.y===y); return '<div class="rep-tb"><span class="rep-tb-v">'+brlShort(x.v)+'</span><div class="rep-tb-track"><div class="rep-tb-bar" style="height:'+hh+'%;background:'+(isc?'#3B6FF7':'var(--u-border2)')+'"></div></div><span class="rep-tb-l">'+MES_ABR[x.m-1]+'</span></div>'; }).join('');
  var fatSec='<div class="rep-card"><div class="rep-card-h">'+icon('dollar')+'<h3>Faturamento</h3></div><div class="rep-site"><div class="rep-site-big"><span class="rep-site-v">'+fmtBRL(cur.fat)+'</span>'+varTag+'<small>mês anterior: '+fmtBRL(ant.fat)+'</small></div><div class="rep-trend">'+trend+'</div></div></div>';
  // meta
  var metaSec='<div class="rep-card"><div class="rep-card-h">'+icon('target')+'<h3>Meta do mês</h3></div>'+(meta.meta>0?('<div class="rep-goal"><div class="rep-goal-top"><span>Atingimento</span><b style="color:'+(meta.pct>=100?'#16A34A':'#3B6FF7')+'">'+meta.pct+'%</b></div><div class="rep-goal-bar"><span style="width:'+meta.pct+'%;background:'+(meta.pct>=100?'#16A34A':'#3B6FF7')+'"></span></div><div class="rep-goal-sub">'+fmtBRL(meta.real)+' de '+fmtBRL(meta.meta)+'</div></div>'):'<div class="dash-empty">Sem meta definida para este mês.</div>')+'</div>';
  // volume + lançar
  var launch = canManage() ? '<button class="rep-launch" id="lrLancar">'+icon('plus')+'Lançar indicadores</button>' : '';
  var volSec='<div class="rep-card"><div class="rep-card-h">'+icon('trend')+'<h3>Volume do mês</h3>'+launch+'</div><div class="rep-prod"><div class="rep-prod-i"><b>'+fmtNumBR(cur.vendas)+'</b><span>vendas</span></div><div class="rep-prod-i"><b>'+fmtNumBR(cur.itens)+'</b><span>itens vendidos</span></div><div class="rep-prod-i"><b>'+fmtNumBR(cur.visitantes)+'</b><span>visitantes</span></div></div></div>';
  // ranking vendedores da loja
  var mems=(ST.members||[]).filter(function(x){ return x.is_active!==false && String(x.store_unit_id)===String(sid); }).map(function(x){ return { m:x, v:vendasMembroMesAno(x, m, y) }; }).filter(function(x){ return x.v>0; }).sort(function(a,b){ return b.v-a.v; }).slice(0,5);
  var rankSec = mems.length ? ('<div class="rep-card"><div class="rep-card-h">'+icon('users')+'<h3>Ranking de vendedores</h3></div><div class="lr-rank">'+mems.map(function(x,i){ return '<div class="lr-rank-row"><span class="lr-rank-pos">'+(i+1)+'º</span><span class="lr-rank-av" style="background:'+(x.m.color||'#3B6FF7')+'">'+esc(iniciais(x.m.name))+'</span><span class="lr-rank-nm">'+esc(x.m.name)+'</span><b>'+brlShort(x.v)+'</b></div>'; }).join('')+'</div></div>') : '';
  return kpis + fatSec + '<div class="rep-grid2">'+metaSec+volSec+'</div>' + produtoSecHTML(sid, m, y) + rankSec;
}
function lojaReportConsolidado(lojas, m, y){
  var pm=(m===1?12:m-1), py=(m===1?y-1:y);
  var tot={fat:0,vendas:0,itens:0,visitantes:0}, totAnt={fat:0};
  var rows=lojas.map(function(s){ var c=lojaMetricasMes(s.id,m,y); var meta=lojaMetaValorMes(s.id,m,y); tot.fat+=c.fat; tot.vendas+=c.vendas; tot.itens+=c.itens; tot.visitantes+=c.visitantes; totAnt.fat+=lojaMetricasMes(s.id,pm,py).fat; return { s:s, c:c, meta:meta }; });
  var ticket=tot.vendas>0?tot.fat/tot.vendas:0; var itensPV=tot.vendas>0?tot.itens/tot.vendas:0; var conv=tot.visitantes>0?(tot.vendas/tot.visitantes*100):0;
  var varPct=totAnt.fat>0?Math.round((tot.fat-totAnt.fat)/totAnt.fat*100):(tot.fat>0?100:0);
  var varTag=totAnt.fat>0?('<span class="rep-var '+(varPct>=0?'up':'down')+'">'+(varPct>=0?'▲ +':'▼ ')+varPct+'%</span>'):'<span class="rep-var flat">sem base</span>';
  var metaTot=rows.reduce(function(a,x){ return a+x.meta.meta; },0), realTot=rows.reduce(function(a,x){ return a+x.meta.real; },0); var metaPct=metaTot>0?Math.min(100,Math.round(realTot/metaTot*100)):0;
  var kpis='<div class="rep-kpis">'+
    kpiCard(brlShort(tot.fat),'Faturamento total', varTag+' vs '+MES_ABR[pm-1], '#16A34A')+
    kpiCard(fmtBRL(ticket),'Ticket médio', tot.vendas+' vendas', '#3B6FF7')+
    kpiCard(conv>0?lrFmtConv(conv):'—','Conversão', tot.visitantes>0?(tot.visitantes+' visitantes'):'—', '#F59E0B')+
    kpiCard(metaTot>0?(metaPct+'%'):'—','Meta atingida', 'consolidado', metaPct>=100?'#16A34A':'#8B5CF6')+
  '</div>';
  // comparativo entre lojas
  var trows=rows.map(function(x){ var c=x.c; return '<tr data-lrstore="'+esc(x.s.id)+'"><td class="lr-td-nm">'+esc(x.s.name||('Loja '+x.s.store_number))+'</td><td>'+brlShort(c.fat)+'</td><td>'+fmtBRL(c.ticket)+'</td><td>'+(c.itensPorVenda>0?lrFmtItens(c.itensPorVenda):'—')+'</td><td>'+(c.conversao>0?lrFmtConv(c.conversao):'—')+'</td><td><span class="lr-meta-badge" style="color:'+(x.meta.pct>=100?'#16A34A':(x.meta.pct>=60?'#3B6FF7':'#EF4444'))+'">'+(x.meta.meta>0?(x.meta.pct+'%'):'—')+'</span></td></tr>'; }).join('');
  var table='<div class="rep-card"><div class="rep-card-h">'+icon('store')+'<h3>Comparativo entre lojas</h3>'+(canManage()?'<span class="lr-hint">clique numa loja para lançar indicadores</span>':'')+'</div><div class="lr-table-wrap"><table class="lr-table"><thead><tr><th>Loja</th><th>Faturamento</th><th>Ticket médio</th><th>Itens/venda</th><th>Conversão</th><th>% Meta</th></tr></thead><tbody>'+trows+'</tbody></table></div></div>';
  return kpis + table;
}
function bindRelatorioLojas(){
  var ss=document.getElementById('lrStore'); if(ss) ss.addEventListener('change', function(){ ST.lrStore=this.value; renderPage(); });
  var pv=document.getElementById('lrPrev'); if(pv) pv.addEventListener('click', function(){ lrSetMes(-1); });
  var nx=document.getElementById('lrNext'); if(nx) nx.addEventListener('click', function(){ lrSetMes(1); });
  var pr=document.getElementById('lrPrint'); if(pr) pr.addEventListener('click', function(){ window.print(); });
  var r=lrMesRef();
  var lc=document.getElementById('lrLancar'); if(lc) lc.addEventListener('click', function(){ var sid=ST.store?ST.store.id:ST.lrStore; if(sid) openMetricasModal(sid, r.m, r.y); });
  var lp=document.getElementById('lrProdutos'); if(lp) lp.addEventListener('click', function(){ var sid=ST.store?ST.store.id:ST.lrStore; if(sid) openProdutosModal(sid, r.m, r.y); });
  var ip=document.getElementById('lrImportProd'); if(ip) ip.addEventListener('click', function(){
    var sid=ST.store?ST.store.id:ST.lrStore; if(!sid){ toast('Selecione uma loja','error'); return; }
    var btn=this, old=btn.innerHTML; btn.disabled=true; btn.textContent='Importando...';
    toast('Buscando produtos no Bling... pode levar 1-2 min','success');
    fetch(SUPABASE_URL+'/functions/v1/bling-produtos', { method:'POST', headers:{ 'Authorization':'Bearer '+SUPABASE_ANON_KEY, 'apikey':SUPABASE_ANON_KEY, 'Content-Type':'application/json' }, body:JSON.stringify({ store_unit_id:sid, month:r.m, year:r.y }) })
      .then(function(res){ return res.json().catch(function(){ return { httpStatus:res.status }; }); })
      .then(function(d){ btn.disabled=false; btn.innerHTML=old; console.log('[bling-produtos]', d);
        if(!d||d.ok!==true){ toast('Importação: '+((d&&(d.message||d.error))||('falha HTTP '+(d&&d.httpStatus||''))),'error'); return; }
        var r0=(d.results||[])[0]||{}; if(r0.erro){ toast('Bling: '+r0.erro,'error'); return; }
        toast('Importados '+(r0.produtos||0)+' produto(s) de '+(r0.pedidos||0)+' pedido(s)'+(r0.parcial?' — parcial (muitos pedidos), rode de novo':'')+'!','success');
        loadData().then(function(){ renderPage(); });
      }).catch(function(e){ btn.disabled=false; btn.innerHTML=old; console.error(e); toast('Erro ao importar: '+e.message,'error'); });
  });
  var trs=app.querySelectorAll('[data-lrstore]'); if(canManage()) for(var i=0;i<trs.length;i++) trs[i].addEventListener('click', function(){ openMetricasModal(this.getAttribute('data-lrstore'), r.m, r.y); });
}
function openMetricasModal(storeId, m, y){
  if(!canManage()){ blockManage(); return; }
  var existing=metricasEntry(storeId, m, y);
  var fatBling=blingFatStoreMonth(storeId, m, y), vendasBling=blingOrdersStoreMonth(storeId, m, y);
  var modal=document.createElement('div'); modal.className='modal-bg';
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  var itens=existing&&existing.num_itens!=null?existing.num_itens:'';
  var vis=existing&&existing.num_visitantes!=null?existing.num_visitantes:'';
  var ovVendas=existing&&Number(existing.num_vendas)>0?existing.num_vendas:'';
  var ovFat=existing&&Number(existing.faturamento)>0?existing.faturamento:'';
  var blingInfo = (fatBling>0||vendasBling>0) ? ('<div class="modal-note">Do Bling neste mês: <b>'+fmtBRL(fatBling)+'</b> em <b>'+vendasBling+'</b> venda(s). Você só precisa informar itens e visitantes.</div>') : '<div class="modal-note">Sem dados do Bling neste mês. Informe também vendas e faturamento abaixo.</div>';
  var delBtn=existing?'<button class="btn btn-danger btn-del-wrap" id="mtDel">Excluir</button>':'';
  modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Indicadores · '+esc(storeName(storeId)||'Loja')+'</div>'+
    '<div class="modal-note">'+MESES[m-1]+' '+y+'</div>'+blingInfo+
    '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Itens vendidos (total)</label><input type="text" id="mtItens" inputmode="numeric" placeholder="0" value="'+esc(itens!==''?itens:'')+'"></div><div class="modal-row"><label class="modal-label">Visitantes (total)</label><input type="text" id="mtVis" inputmode="numeric" placeholder="0" value="'+esc(vis!==''?vis:'')+'"></div></div>'+
    '<div class="mt-adv"><div class="mt-adv-h">Opcional — se a loja não usa Bling</div><div class="modal-grid2"><div class="modal-row"><label class="modal-label">Nº de vendas</label><input type="text" id="mtVendas" inputmode="numeric" placeholder="(usa o Bling)" value="'+esc(ovVendas!==''?ovVendas:'')+'"></div><div class="modal-row"><label class="modal-label">Faturamento (R$)</label><input type="text" id="mtFat" inputmode="decimal" placeholder="(usa o Bling)" value="'+esc(ovFat!==''?ovFat:'')+'"></div></div></div>'+
    '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="mtCancel">Cancelar</button><button class="btn btn-primary" id="mtSave">Salvar</button></div>'+
  '</div>';
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#mtCancel').addEventListener('click', close);
  var del=modal.querySelector('#mtDel'); if(del) del.addEventListener('click', function(){ confirmDelete('Excluir os indicadores deste mês?', function(){ sb.from('malba_loja_metricas').delete().eq('id',existing.id).then(function(r){ if(r.error){ toast('Erro ao excluir','error'); return; } ST.lojaMetricas=ST.lojaMetricas.filter(function(x){return String(x.id)!==String(existing.id);}); close(); toast('Indicadores excluídos','success'); renderPage(); }); }); });
  modal.querySelector('#mtSave').addEventListener('click', function(){
    var num=function(id){ var v=(modal.querySelector(id).value||'').replace(/\./g,'').replace(',','.').replace(/[^0-9.]/g,''); return v?Number(v):0; };
    var rec={ store_unit_id:storeId, month:m, year:y, num_itens:num('#mtItens'), num_visitantes:num('#mtVis'), num_vendas:num('#mtVendas'), faturamento:_parseBRL(modal.querySelector('#mtFat').value) };
    var btn=this; setBusy(btn,true);
    if(existing){ sb.from('malba_loja_metricas').update(rec).eq('id',existing.id).then(function(r){ if(r.error){ toast('Erro ao salvar','error'); setBusy(btn,false); btn.textContent='Salvar'; return; } for(var i=0;i<ST.lojaMetricas.length;i++) if(String(ST.lojaMetricas[i].id)===String(existing.id)) ST.lojaMetricas[i]=Object.assign(ST.lojaMetricas[i],rec); close(); toast('Indicadores atualizados','success'); renderPage(); }); }
    else { sb.from('malba_loja_metricas').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL de indicadores).','error'); console.error(r.error); setBusy(btn,false); btn.textContent='Salvar'; return; } ST.lojaMetricas.push(r.data); auditLog('Lançou indicadores', storeName(storeId)); close(); toast('Indicadores salvos','success'); renderPage(); }); }
  });
  document.body.appendChild(modal); modal.querySelector('#mtItens').focus();
}

/* ----- Produtos mais vendidos por categoria (relatório de lojas) ----- */
function produtosLoja(storeId, m, y){ return (ST.lojaProdutos||[]).filter(function(x){ return String(x.store_unit_id)===String(storeId) && x.month===m && x.year===y; }); }
function categoriasUsadas(){ var seen={}; (ST.lojaProdutos||[]).forEach(function(x){ var c=(x.categoria||'').trim(); if(c) seen[c]=1; }); return Object.keys(seen).sort(); }
function produtoSecHTML(sid, m, y){
  var manageBtn = canManage() ? ('<div class="rep-card-btns"><button class="rep-launch" id="lrImportProd">'+icon('trend')+'Importar do Bling</button><button class="rep-launch alt" id="lrProdutos">'+icon('plus')+'Gerenciar</button></div>') : '';
  var prods = produtosLoja(sid, m, y);
  if(!prods.length) return '<div class="rep-card"><div class="rep-card-h">'+icon('grid')+'<h3>Produtos mais vendidos por categoria</h3>'+manageBtn+'</div><div class="dash-empty">Nenhum produto lançado neste mês.'+(canManage()?' Use "Gerenciar produtos".':'')+'</div></div>';
  var byCat={}; prods.forEach(function(p){ var c=p.categoria||'Sem categoria'; (byCat[c]=byCat[c]||{itens:[],fat:0,qtd:0}); byCat[c].itens.push(p); byCat[c].fat+=Number(p.faturamento)||0; byCat[c].qtd+=Number(p.quantidade)||0; });
  var cats=Object.keys(byCat).sort(function(a,b){ return byCat[b].fat-byCat[a].fat; });
  var maxFat=Math.max.apply(null,cats.map(function(c){return byCat[c].fat;}).concat([1]));
  var blocks=cats.map(function(c){ var g=byCat[c]; var items=g.itens.slice().sort(function(a,b){ return (Number(b.quantidade)||0)-(Number(a.quantidade)||0); }).slice(0,6); var pct=Math.round(g.fat/maxFat*100); var rows=items.map(function(p,i){ return '<div class="lp-prod"><span class="lp-prod-pos">'+(i+1)+'</span><span class="lp-prod-nm">'+esc(p.produto)+'</span><span class="lp-prod-q">'+fmtNumBR(p.quantidade)+' un</span><b>'+brlShort(p.faturamento)+'</b></div>'; }).join(''); return '<div class="lp-cat"><div class="lp-cat-h"><b>'+esc(c)+'</b><span>'+fmtNumBR(g.qtd)+' un · '+brlShort(g.fat)+'</span></div><div class="lp-cat-bar"><span style="width:'+pct+'%"></span></div><div class="lp-prods">'+rows+'</div></div>'; }).join('');
  return '<div class="rep-card"><div class="rep-card-h">'+icon('grid')+'<h3>Produtos mais vendidos por categoria</h3>'+manageBtn+'</div><div class="lp-cats">'+blocks+'</div></div>';
}
function openProdutosModal(storeId, m, y){
  if(!canManage()){ blockManage(); return; }
  var modal=document.createElement('div'); modal.className='modal-bg'; var editing=null;
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  function draw(){
    var prods=produtosLoja(storeId,m,y).slice().sort(function(a,b){ return (Number(b.quantidade)||0)-(Number(a.quantidade)||0); });
    var cats=categoriasUsadas(); var datalist='<datalist id="prodCats">'+cats.map(function(c){return '<option value="'+esc(c)+'">';}).join('')+'</datalist>';
    var list = prods.length ? prods.map(function(p){ return '<div class="pd-row'+(editing&&String(editing.id)===String(p.id)?' editing':'')+'" data-editprod="'+esc(p.id)+'"><div class="pd-row-main"><b>'+esc(p.produto)+'</b><span>'+esc(p.categoria||'—')+' · '+fmtNumBR(p.quantidade)+' un · '+brlShort(p.faturamento)+'</span></div><button class="pd-del" data-delprod="'+esc(p.id)+'" title="Remover">'+icon('logout')+'</button></div>'; }).join('') : '<div class="col-empty">Nenhum produto ainda.</div>';
    var f = editing || { produto:'', categoria:'', quantidade:'', faturamento:'' };
    modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Produtos · '+esc(storeName(storeId)||'Loja')+'</div><div class="modal-note">'+MESES[m-1]+' '+y+' · lance os itens mais vendidos (do seu relatório do Bling).</div>'+
      '<div class="pd-form"><div class="modal-grid2"><div class="modal-row"><label class="modal-label">Produto</label><input type="text" id="pdNome" value="'+esc(f.produto||'')+'" placeholder="ex: Sacola kraft M"></div><div class="modal-row"><label class="modal-label">Categoria</label><input type="text" id="pdCat" list="prodCats" value="'+esc(f.categoria||'')+'" placeholder="ex: Sacolas"></div></div>'+datalist+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Quantidade</label><input type="text" id="pdQtd" inputmode="numeric" value="'+esc(f.quantidade!==''&&f.quantidade!=null?f.quantidade:'')+'" placeholder="0"></div><div class="modal-row"><label class="modal-label">Faturamento (R$)</label><input type="text" id="pdFat" inputmode="decimal" value="'+esc(f.faturamento!==''&&f.faturamento!=null?f.faturamento:'')+'" placeholder="0,00"></div></div>'+
      '<div class="pd-form-btns"><button class="btn btn-primary" id="pdSave">'+(editing?'Salvar':'Adicionar produto')+'</button>'+(editing?'<button class="btn btn-ghost" id="pdCancelEdit">Cancelar edição</button>':'')+'</div></div>'+
      '<div class="pd-list">'+list+'</div>'+
      '<div class="modal-foot"><button class="btn btn-ghost" id="pdClose">Concluído</button></div>'+
    '</div>';
    bind();
  }
  function bind(){
    modal.querySelector('#pdClose').addEventListener('click', close);
    modal.querySelector('#pdSave').addEventListener('click', save);
    var ce=modal.querySelector('#pdCancelEdit'); if(ce) ce.addEventListener('click', function(){ editing=null; draw(); });
    var eds=modal.querySelectorAll('[data-editprod]'); for(var i=0;i<eds.length;i++) eds[i].addEventListener('click', function(e){ if(e.target.closest('[data-delprod]')) return; var id=this.getAttribute('data-editprod'); for(var k=0;k<ST.lojaProdutos.length;k++) if(String(ST.lojaProdutos[k].id)===String(id)){ editing=ST.lojaProdutos[k]; break; } draw(); });
    var dels=modal.querySelectorAll('[data-delprod]'); for(var d=0;d<dels.length;d++) dels[d].addEventListener('click', function(e){ e.stopPropagation(); var id=this.getAttribute('data-delprod'); sb.from('malba_loja_produtos').delete().eq('id',id).then(function(r){ if(r.error){ toast('Erro ao remover','error'); return; } ST.lojaProdutos=ST.lojaProdutos.filter(function(x){return String(x.id)!==String(id);}); if(editing&&String(editing.id)===String(id)) editing=null; draw(); renderPage(); }); });
  }
  function save(){
    var nome=(modal.querySelector('#pdNome').value||'').trim(); if(!nome){ toast('Informe o produto','error'); return; }
    var num=function(id){ var v=(modal.querySelector(id).value||'').replace(/\./g,'').replace(',','.').replace(/[^0-9.]/g,''); return v?Number(v):0; };
    var rec={ store_unit_id:storeId, month:m, year:y, produto:nome, categoria:(modal.querySelector('#pdCat').value||'').trim()||'Sem categoria', quantidade:num('#pdQtd'), faturamento:_parseBRL(modal.querySelector('#pdFat').value) };
    var btn=modal.querySelector('#pdSave'); setBusy(btn,true);
    if(editing){ sb.from('malba_loja_produtos').update(rec).eq('id',editing.id).then(function(r){ if(r.error){ toast('Erro ao salvar','error'); btn.disabled=false; return; } for(var i=0;i<ST.lojaProdutos.length;i++) if(String(ST.lojaProdutos[i].id)===String(editing.id)) ST.lojaProdutos[i]=Object.assign(ST.lojaProdutos[i],rec); editing=null; draw(); renderPage(); }); }
    else { sb.from('malba_loja_produtos').insert(rec).select().single().then(function(r){ if(r.error||!r.data){ toast('Não consegui salvar (peça para rodar o SQL de produtos).','error'); console.error(r.error); btn.disabled=false; return; } ST.lojaProdutos.push(r.data); draw(); renderPage(); }); }
  }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  document.body.appendChild(modal); draw();
}

function goalCardHTML(g) {
  var meta = Number(g.goal_value)||0;
  var real = realizadoMeta(g);
  var pct = meta>0 ? Math.min(100, Math.round((real/meta)*100)) : 0;
  var who = g.user_id ? userById(g.user_id) : null;
  var alvo = who ? (esc(who.name)+(g.store_unit_id?(' · '+esc(storeName(g.store_unit_id))):'')) : ((g.store_unit_id) ? esc(storeName(g.store_unit_id)) : 'Todo o setor');
  var cor = pct>=100 ? '#16A34A' : (pct>=60 ? '#3B6FF7' : (pct>=30 ? '#F59E0B' : '#EF4444'));
  // anel SVG
  var R=42, C=2*Math.PI*R, off=C*(1-pct/100);
  var ring = '<svg class="goal-ring" viewBox="0 0 100 100"><circle cx="50" cy="50" r="'+R+'" fill="none" stroke="var(--u-bg2)" stroke-width="9"/><circle cx="50" cy="50" r="'+R+'" fill="none" stroke="'+cor+'" stroke-width="9" stroke-linecap="round" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+off.toFixed(1)+'" transform="rotate(-90 50 50)"/><text x="50" y="50" text-anchor="middle" dominant-baseline="central" font-size="22" font-weight="800" fill="var(--u-text)" font-family="Sora">'+pct+'%</text></svg>';
  var regNote='';
  if (g.user_id) { var vreg=vendasUserMes(g.user_id); if (vreg>0) regNote='<div class="goal-reg">Vendedor registrou: <b>'+fmtBRL(vreg)+'</b> este mês</div>'; }
  return '<div class="goal-card" data-id="'+esc(g.id)+'">'+
    '<div class="goal-head"><div><b>'+esc(MESES[(g.month||1)-1])+' '+esc(g.year||'')+'</b><i>'+alvo+'</i></div></div>'+
    ring+
    '<div class="goal-vals"><div class="gv"><small>Realizado</small><span style="color:'+cor+'">'+fmtBRL(real)+'</span></div><div class="gv"><small>Meta</small><span>'+fmtBRL(meta)+'</span></div></div>'+
    regNote+
  '</div>';
}

function bindMetas() {
  if (deptoComoModelo('marketing')) { bindMktMetas(); return; }
  var admin = isAdmin(ST.session);
  var nova = document.getElementById('btnNovaMeta');
  if (nova && admin) nova.addEventListener('click', function(){ openGoalModal(null); });
  var ms=document.getElementById('metaStore');
  if (ms) ms.addEventListener('change', function(){ ST.taskStore=this.value; renderPage(); });
  if (!admin) return;
  var cards = app.querySelectorAll('.goal-card');
  for (var i=0;i<cards.length;i++) {
    cards[i].addEventListener('click', function(){
      var id=this.getAttribute('data-id'); var g=null;
      for (var k=0;k<ST.goals.length;k++) if (String(ST.goals[k].id)===String(id)) { g=ST.goals[k]; break; }
      if (g) openGoalModal(g);
    });
  }
}

// v113: wrapper único — decide qual modal abrir pelo contexto do setor.
// A refatoração completa (unificar campos, reduzir código) vem no Bloco 2 depois da modularização.
function openMetaModal(goal, preset){
  if (typeof deptoComoModelo==='function' && deptoComoModelo('marketing')){
    return openMktMetaModal(goal);
  }
  return openGoalModal(goal, preset);
}

function openGoalModal(goal, preset) {
  if(!canEdit()){ blockManage(); return; }
  var isNew = !goal;
  var now = new Date();
  var g = goal || { month:now.getMonth()+1, year:now.getFullYear(), goal_value:'', actual_value:0, store_unit_id:(preset&&preset.store_unit_id)||null, user_id:(preset&&preset.user_id)||null };

  var monthOpts='';
  for (var mo=1;mo<=12;mo++) monthOpts += '<option value="'+mo+'"'+(g.month===mo?' selected':'')+'>'+MESES[mo-1]+'</option>';

  // seletor de alvo: lojas -> loja + vendedor; vendas -> vendedor
  var lojaSelectHTML='';
  if (ST.sector==='lojas') {
    var opts='<option value="">Todo o setor</option>';
    ST.storeUnits.forEach(function(s){
      var nm=s.name||('Loja '+s.store_number);
      opts += '<option value="'+esc(s.id)+'"'+(g.store_unit_id===s.id?' selected':'')+'>'+esc(nm)+'</option>';
    });
    var luopts='<option value="">Loja inteira</option>';
    ST.users.forEach(function(u){ luopts += '<option value="'+esc(u.id)+'"'+(g.user_id===u.id?' selected':'')+'>'+esc(u.name)+'</option>'; });
    lojaSelectHTML='<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Loja</label><select id="gStore">'+opts+'</select></div><div class="modal-row"><label class="modal-label">Vendedor (opcional)</label><select id="gUser">'+luopts+'</select></div></div>';
  } else if (ST.sector==='vendas') {
    var uopts='<option value="">Meta geral do setor</option>';
    ST.users.forEach(function(u){ uopts += '<option value="'+esc(u.id)+'"'+(g.user_id===u.id?' selected':'')+'>'+esc(u.name)+'</option>'; });
    lojaSelectHTML='<div class="modal-row"><label class="modal-label">Vendedor (entra no ranking)</label><select id="gUser">'+uopts+'</select></div>';
  }

  function storeBlingConnected(sid){ if(!sid) return false; var b=blingDaLoja(sid); return !!(b && b.connected); }
  var initBlConn = storeBlingConnected(g.store_unit_id);
  var realizadoField = (!isNew && initBlConn)
    ? '<div class="modal-row"><label class="modal-label">Realizado (R$)</label><div class="goal-real-ro"><span class="grr-val">'+fmtBRL(Number(g.actual_value)||0)+'</span><span class="grr-tag">atualizado pelo Bling</span><button type="button" class="grr-clear" id="gClearReal">Limpar e usar o Bling</button></div><div style="font-size:11px;color:var(--u-text3);margin-top:6px">Esta loja tem o Bling conectado — o realizado é sincronizado automaticamente. Se este número estiver errado, clique em "Limpar e usar o Bling" e depois em <b>Sincronizar Bling</b>.</div></div>'
    : '<div class="modal-row"><label class="modal-label">Realizado (R$) <span style="font-weight:600;color:var(--u-text3);text-transform:none;letter-spacing:0">• opcional</span></label><input type="text" id="gActual" inputmode="decimal" placeholder="0,00" value="'+(g.actual_value?esc(g.actual_value):'')+'"><div style="font-size:11px;color:var(--u-text3);margin-top:5px">Use vírgula nos centavos (ex.: 40155,08). Se a loja tiver Bling conectado, este valor passa a vir do Bling automaticamente.</div></div>';

  var delBtn = isNew ? '' : '<button class="btn btn-danger btn-del-wrap" id="goalDel">Excluir</button>';

  var modal=document.createElement('div'); modal.className='modal-bg';
  modal.innerHTML =
    '<div class="modal">'+
      '<div class="modal-title-input" style="cursor:default">'+(isNew?'Nova meta':'Editar meta')+'</div>'+
      '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Mês</label><select id="gMonth">'+monthOpts+'</select></div><div class="modal-row"><label class="modal-label">Ano</label><input type="text" id="gYear" value="'+esc(g.year||now.getFullYear())+'"></div></div>'+
      lojaSelectHTML+
      '<div class="modal-row"><label class="modal-label">Valor da meta (R$) *</label><input type="text" id="gValue" inputmode="decimal" placeholder="0,00" value="'+(g.goal_value!=null && g.goal_value!==''?esc(g.goal_value):'')+'"></div>'+
      realizadoField+
      '<div class="modal-foot">'+delBtn+'<button class="btn btn-ghost" id="goalCancel">Cancelar</button><button class="btn btn-primary" id="goalSave">'+(isNew?'Criar meta':'Salvar')+'</button></div>'+
    '</div>';
  document.body.appendChild(modal);

  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#goalCancel').addEventListener('click', close);
  var clearBtn = modal.querySelector('#gClearReal');
  if (clearBtn) clearBtn.addEventListener('click', function(){
    if(!isAdmin(ST.session)) return;
    var bt=this; bt.disabled=true; bt.textContent='Limpando...';
    sb.from('malba_sales_goals').update({ actual_value:null }).eq('id', g.id).then(function(r){
      if(r.error){ toast('Erro ao limpar','error'); setBusy(bt,false); bt.textContent='Limpar e usar o Bling'; return; }
      for (var i=0;i<ST.goals.length;i++) if (ST.goals[i].id===g.id) { ST.goals[i].actual_value=null; break; }
      auditLog('Limpou realizado da meta (usar Bling)'); close(); toast('Pronto! Agora clique em Sincronizar Bling.','success'); renderPage();
    });
  });

  function parseNum(s){ return parseFloat(String(s||'').replace(/\./g,'').replace(',', '.')) || 0; }

  modal.querySelector('#goalSave').addEventListener('click', function(){
    if (!isAdmin(ST.session)) { toast('Apenas o administrador pode definir metas','error'); return; }
    var val = parseNum(modal.querySelector('#gValue').value);
    if (!val || val<=0) { toast('Informe o valor da meta','error'); return; }
    var lojaEl = modal.querySelector('#gStore');
    var userEl = modal.querySelector('#gUser');
    var selStore = (lojaEl && lojaEl.value) ? lojaEl.value : null;
    var rec = {
      sector: ST.sector,
      month: parseInt(modal.querySelector('#gMonth').value,10),
      year: parseInt(modal.querySelector('#gYear').value,10) || now.getFullYear(),
      goal_value: val,
      store_unit_id: selStore,
      user_id: (userEl && userEl.value) ? userEl.value : null
    };
    var gActualEl = modal.querySelector('#gActual');
    if (gActualEl && !storeBlingConnected(selStore)) rec.actual_value = parseNum(gActualEl.value);
    var saveBtn=modal.querySelector('#goalSave'); setBusy(saveBtn,true);
    if (isNew) {
      sb.from('malba_sales_goals').insert(rec).select().single().then(function(r){
        if (r.error || !r.data) { toast('Erro ao criar meta','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Criar meta'; return; }
        ST.goals.push(r.data); auditLog('Criou meta'); close(); toast('Meta criada','success'); renderPage();
      });
    } else {
      sb.from('malba_sales_goals').update(rec).eq('id', g.id).then(function(r){
        if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(saveBtn,false); saveBtn.textContent='Salvar'; return; }
        for (var i=0;i<ST.goals.length;i++) if (ST.goals[i].id===g.id) { ST.goals[i]=Object.assign(ST.goals[i],rec); break; }
        close(); toast('Meta atualizada','success'); renderPage();
      });
    }
  });

  if (!isNew) {
    modal.querySelector('#goalDel').addEventListener('click', function(){
      confirmDelete('Excluir a meta de '+MESES[(g.month||1)-1]+'/'+g.year+'?', function(){ sb.from('malba_sales_goals').delete().eq('id', g.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.goals = ST.goals.filter(function(x){ return x.id!==g.id; });
        close(); toast('Meta excluída','success'); renderPage();
      }); });
    });
  }
}

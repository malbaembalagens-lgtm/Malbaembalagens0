/* ========== [10m] PALETA DE COMANDOS (Ctrl/Cmd+K) — padrão dos melhores sistemas ========== */
function goToPage(id){ ST.page=id; ST.openProject=null; navigate(ST.sector+'/'+id); renderPage(); }
function buildCommands() {
  var cmds=[]; var admin=isAdmin(ST.session);
  var pages=PAGES[ST.sector]||PAGES.lojas;
  pages = pages.filter(function(pg){ return pageAllowed(pg.id, ST.session); });
  pages.forEach(function(pg){ if(pg.enabled) cmds.push({ cat:'Ir para', label:pg.label, icon:pg.icon, run:function(){ goToPage(pg.id); } }); });
  cmds.push({ cat:'Ir para', label:'Meu Perfil', icon:'users', run:function(){ ST.page='perfil'; navigate(ST.sector+'/perfil'); renderPage(); } });
  // ações de criação
  cmds.push({ cat:'Criar', label:'Nova tarefa', icon:'plus', run:function(){ openTaskModal(null); } });
  if (admin) {
    if (deptoComoModelo('marketing')) cmds.push({ cat:'Criar', label:'Nova campanha', icon:'plus', run:function(){ openCampaignModal(null); } });
    cmds.push({ cat:'Criar', label:'Novo cliente', icon:'plus', run:function(){ openClientModal(null); } });
    cmds.push({ cat:'Criar', label:'Novo projeto', icon:'plus', run:function(){ openProjectModal(null); } });
    cmds.push({ cat:'Criar', label:'Nova meta', icon:'plus', run:function(){ openGoalModal(null); } });
    if (ST.sector==='lojas') {
      cmds.push({ cat:'Criar', label:'Cadastrar funcionário', icon:'plus', run:function(){ openMemberModal(null); } });
      cmds.push({ cat:'Criar', label:'Lançar comissão', icon:'dollar', run:function(){ ST.page='gestao'; ST.gestaoTab='comissoes'; navigate(ST.sector+'/gestao'); renderPage(); setTimeout(openComissaoModal,60); } });
    }
  }
  cmds.push({ cat:'Ajuda', label:'Atalhos de teclado', icon:'search', run:openShortcutsHelp });
  cmds.push({ cat:'Conta', label:'Sair da conta', icon:'logout', run:logout });
  return cmds;
}
function openCommandPalette() {
  if (document.getElementById('cmdkBg') || !ST.session) return;
  var cmds=buildCommands(), sel=0, filtered=cmds;
  var iconFor={ task:'tasks', client:'users', project:'folder', campaign:'megaphone', user:'users', equipe:'users', depto:'grid', doc:'folder' }; // v112
  var bg=document.createElement('div'); bg.className='cmdk-bg'; bg.id='cmdkBg';
  bg.innerHTML='<div class="cmdk"><div class="cmdk-input-wrap">'+icon('search')+'<input id="cmdkInput" placeholder="Buscar em tudo — páginas, pessoas, equipes, documentos, tarefas..." autocomplete="off"><span class="cmdk-esc">esc</span></div><div class="cmdk-list" id="cmdkList"></div></div>';
  document.body.appendChild(bg);
  var input=bg.querySelector('#cmdkInput'), list=bg.querySelector('#cmdkList');

  function compute(q){
    q=(q||'').toLowerCase().trim();
    var base=cmds.filter(function(c){ return !q || c.label.toLowerCase().indexOf(q)>=0; });
    var content = q ? globalSearch(q).map(function(r){ return { cat:'Resultados', label:r.label, sub:r.sub, icon:iconFor[r.k]||'dashboard', run:function(){ openSearchResult(r); } }; }) : [];
    return base.concat(content);
  }
  function render(){
    if (filtered.length===0){ list.innerHTML='<div class="cmdk-empty">Nada encontrado</div>'; return; }
    var lastCat=null, html='';
    filtered.forEach(function(c,i){
      if (c.cat!==lastCat){ html+='<div class="cmdk-cat">'+esc(c.cat)+'</div>'; lastCat=c.cat; }
      html+='<button class="cmdk-item'+(i===sel?' on':'')+'" data-i="'+i+'">'+icon(c.icon||'dashboard')+'<span class="cmdk-l">'+esc(c.label)+'</span>'+(c.sub?'<span class="cmdk-s">'+esc(c.sub)+'</span>':'')+'</button>';
    });
    list.innerHTML=html;
    var on=list.querySelector('.cmdk-item.on'); if(on && on.scrollIntoView) on.scrollIntoView({block:'nearest'});
    var items=list.querySelectorAll('.cmdk-item');
    for (var k=0;k<items.length;k++){
      items[k].addEventListener('mousedown', function(e){ e.preventDefault(); exec(parseInt(this.getAttribute('data-i'),10)); });
      items[k].addEventListener('mousemove', function(){ var ni=parseInt(this.getAttribute('data-i'),10); if(ni!==sel){ sel=ni; var its=list.querySelectorAll('.cmdk-item'); for(var z=0;z<its.length;z++) its[z].classList.toggle('on', z===sel); } });
    }
  }
  function exec(i){ var c=filtered[i]; if(!c) return; close(); c.run(); }
  function close(){ document.removeEventListener('keydown', onKey, true); if(bg.parentNode) bg.parentNode.removeChild(bg); }
  function onKey(e){
    if (e.key==='Escape'){ e.preventDefault(); close(); }
    else if (e.key==='ArrowDown'){ e.preventDefault(); sel=Math.min(sel+1, filtered.length-1); render(); }
    else if (e.key==='ArrowUp'){ e.preventDefault(); sel=Math.max(sel-1, 0); render(); }
    else if (e.key==='Enter'){ e.preventDefault(); exec(sel); }
  }
  filtered=compute(''); render();
  input.addEventListener('input', function(){ sel=0; filtered=compute(input.value); render(); });
  document.addEventListener('keydown', onKey, true);
  bg.addEventListener('click', function(e){ if(e.target===bg) close(); });
  setTimeout(function(){ input.focus(); }, 30);
}

function openShortcutsHelp() {
  if (document.getElementById('shHelp')) return;
  var rows=[
    { k:['Ctrl/⌘','K'], d:'Abrir a paleta de comandos' },
    { k:['/'], d:'Ir para a busca' },
    { k:['N'], d:'Nova tarefa' },
    { k:['?'], d:'Mostrar estes atalhos' },
    { k:['Esc'], d:'Fechar janelas' }
  ];
  var modal=document.createElement('div'); modal.className='modal-bg'; modal.id='shHelp';
  modal.innerHTML='<div class="modal"><div class="modal-title-input" style="cursor:default">Atalhos de teclado</div><div class="sh-list">'+
    rows.map(function(r){ return '<div class="sh-row"><span class="sh-keys">'+r.k.map(function(k){ return '<kbd>'+esc(k)+'</kbd>'; }).join('<span class="sh-plus">+</span>')+'</span><span class="sh-desc">'+esc(r.d)+'</span></div>'; }).join('')+
    '</div><div class="modal-foot"><button class="btn btn-ghost" id="shClose">Fechar</button></div></div>';
  document.body.appendChild(modal);
  function close(){ if(modal.parentNode) modal.parentNode.removeChild(modal); }
  modal.addEventListener('click', function(e){ if(e.target===modal) close(); });
  modal.querySelector('#shClose').addEventListener('click', close);
}

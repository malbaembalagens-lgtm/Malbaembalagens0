/* ========== [10e] PROJETOS (com marcos/etapas) ========== */
var PROJ_COLORS = ['#3B6FF7','#16A34A','#F59E0B','#8B5CF6','#EF4444','#0EA5E9'];
var MS_STATUS = { todo:{label:'A fazer',color:'#9aa1ad'}, fazendo:{label:'Em andamento',color:'#3B6FF7'}, feito:{label:'Concluída',color:'#16A34A'} };

function projectMilestones(pid) {
  return ST.milestones.filter(function(m){ return String(m.project_id)===String(pid); })
    .sort(function(a,b){ return (a.position||0)-(b.position||0); });
}
function projProgress(pid) {
  var ms = projectMilestones(pid);
  if (ms.length===0) return 0;
  var done = ms.filter(function(m){ return m.status==='feito'; }).length;
  return Math.round((done/ms.length)*100);
}
function msById(id){ for(var k=0;k<ST.milestones.length;k++) if(String(ST.milestones[k].id)===String(id)) return ST.milestones[k]; return null; }

function projetosHTML() {
  // se um projeto está aberto, mostra o detalhe
  if (ST.openProject) return projetoDetalheHTML(ST.openProject);

  var ps = ST.projects;
  var cards = '';
  if (ps.length===0) {
    cards = emptyState({ span:true, icon:'folder', title:'Nenhum projeto ainda', text:'Projetos reúnem as tarefas e etapas de um objetivo maior.', cta:(canEdit()?'Criar projeto':'') });
  } else {
    ps.forEach(function(pr){ cards += projectCardHTML(pr); });
  }
  return '<div class="tasks-head"><div><h2>Projetos</h2><div class="sub">'+ps.length+' projeto(s)</div></div>'+(canEdit()?'<button class="btn-new" id="btnNovoProjeto">'+icon('plus')+'Novo projeto</button>':'')+'</div><div class="proj-grid">'+cards+'</div>';
}

function projectCardHTML(pr) {
  var cor = pr.color || '#3B6FF7';
  var pct = projProgress(pr.id);
  var ms = projectMilestones(pr.id);
  var membros = (pr.members||[]).map(function(uid){ var u=userById(uid); return u?'<span class="proj-av" style="background:'+(u.color||cor)+'" title="'+esc(u.name)+'">'+esc(iniciais(u.name))+'</span>':''; }).join('');
  var prazo = pr.end_date ? ('Prazo: '+fmtDate(pr.end_date)) : '';
  return '<div class="proj-card" data-id="'+esc(pr.id)+'">'+
    '<span class="proj-bar" style="background:'+cor+'"></span>'+
    '<div class="proj-body"><b>'+esc(pr.name)+'</b>'+(pr.description?'<p>'+esc(pr.description)+'</p>':'')+
    '<div class="proj-prog"><div class="proj-prog-bar"><span style="width:'+pct+'%;background:'+cor+'"></span></div><small>'+pct+'% · '+ms.length+' etapa(s)</small></div>'+
    '<div class="proj-foot"><div class="proj-avs">'+membros+'</div>'+(prazo?'<span class="proj-prazo">'+prazo+'</span>':'')+'</div>'+
    '</div></div>';
}

function bindProjetos() {
  if (ST.openProject) { bindProjetoDetalhe(); return; }
  var novo = document.getElementById('btnNovoProjeto');
  if (novo) novo.addEventListener('click', function(){ openProjectModal(null); });
  var cards = app.querySelectorAll('.proj-card');
  for (var i=0;i<cards.length;i++) {
    cards[i].addEventListener('click', function(){ ST.openProject = this.getAttribute('data-id'); renderPage(); });
  }
}

/* ----- Detalhe do projeto ----- */
var expandedMs = null; // id da etapa com painel de passos aberto

function subtaskPanelHTML(m) {
  var subs = m.subtasks || [];
  var items = subs.length ? subs.map(function(s,idx){
    return '<label class="ms-sub"><input type="checkbox" data-subtoggle="'+esc(m.id)+':'+idx+'"'+(s.done?' checked':'')+'><span'+(s.done?' class="done"':'')+'>'+esc(s.title)+'</span><button class="ms-sub-del" data-subdel="'+esc(m.id)+':'+idx+'">✕</button></label>';
  }).join('') : '<div class="ms-sub-empty">Nenhum passo ainda.</div>';
  return '<div class="ms-subs">'+items+'<div class="ms-sub-add"><input type="text" data-subinput="'+esc(m.id)+'" placeholder="Novo passo..."><button class="btn btn-ghost" data-subadd="'+esc(m.id)+'">+ Add</button></div></div>';
}

function projetoDetalheHTML(pid) {
  var pr=null;
  for (var i=0;i<ST.projects.length;i++) if (String(ST.projects[i].id)===String(pid)) { pr=ST.projects[i]; break; }
  if (!pr) { ST.openProject=null; return projetosHTML(); }
  var cor = pr.color || '#3B6FF7';
  var pct = projProgress(pr.id);
  var ms = projectMilestones(pr.id);

  var rows = '';
  if (ms.length===0) {
    rows = '<div class="col-empty">Nenhuma etapa ainda. Adicione a primeira abaixo.</div>';
  } else {
    ms.forEach(function(m){
      var st = MS_STATUS[m.status] || MS_STATUS.todo;
      var u = m.assignee_id ? userById(m.assignee_id) : null;
      var av = u ? '<span class="ms-av" style="background:'+(u.color||cor)+'" title="'+esc(u.name)+'">'+esc(iniciais(u.name))+'</span>' : '';
      var subs = m.subtasks || [];
      var subDone = subs.filter(function(s){ return s.done; }).length;
      var expanded = String(expandedMs)===String(m.id);
      var stepsChip = subs.length
        ? '<button class="ms-steps'+(expanded?' on':'')+'" data-msexp="'+esc(m.id)+'">'+subDone+'/'+subs.length+' passos</button>'
        : '<button class="ms-steps add'+(expanded?' on':'')+'" data-msexp="'+esc(m.id)+'">+ passos</button>';
      rows += '<div class="ms-block">'+
        '<div class="ms-row">'+
          '<button class="ms-check" data-mscheck="'+esc(m.id)+'" style="border-color:'+st.color+';background:'+(m.status==='feito'?st.color:'transparent')+'">'+(m.status==='feito'?icon('tasks'):'')+'</button>'+
          '<span class="ms-name'+(m.status==='feito'?' done':'')+'">'+esc(m.name)+'</span>'+
          stepsChip+
          (m.date?'<span class="ms-date">'+fmtDate(m.date)+'</span>':'')+av+
          '<button class="ms-status" data-msstatus="'+esc(m.id)+'" style="color:'+st.color+';background:'+st.color+'18">'+st.label+'</button>'+
        '</div>'+
        (expanded ? subtaskPanelHTML(m) : '')+
      '</div>';
    });
  }

  return ''+
    '<button class="btn-back" id="projBack">← Voltar aos projetos</button>'+
    '<div class="proj-detail-head" style="border-left:4px solid '+cor+'">'+
      '<div><h2>'+esc(pr.name)+'</h2>'+(pr.description?'<p>'+esc(pr.description)+'</p>':'')+'</div>'+
      (canEdit()?'<button class="btn btn-ghost" id="projEdit">Editar projeto</button>':'')+
    '</div>'+
    '<div class="proj-prog big"><div class="proj-prog-bar"><span style="width:'+pct+'%;background:'+cor+'"></span></div><small>'+pct+'% concluído · '+ms.length+' etapa(s)</small></div>'+
    '<div class="ms-sec"><div class="ms-sec-h">Etapas</div>'+rows+'</div>'+
    (canEdit()?'<div class="ms-add"><input id="msName" placeholder="Nova etapa..."><input type="date" id="msDate"><select id="msResp"><option value="">Responsável</option>'+ST.users.map(function(u){return '<option value="'+esc(u.id)+'">'+esc(u.name)+'</option>';}).join('')+'</select><button class="btn btn-primary" id="msAdd">Adicionar</button></div>':'');
}

function bindProjetoDetalhe() {
  var back=document.getElementById('projBack');
  if (back) back.addEventListener('click', function(){ ST.openProject=null; renderPage(); });
  var edit=document.getElementById('projEdit');
  if (edit) edit.addEventListener('click', function(){
    var pr=null; for (var i=0;i<ST.projects.length;i++) if (String(ST.projects[i].id)===String(ST.openProject)) { pr=ST.projects[i]; break; }
    if (pr) openProjectModal(pr);
  });
  // marcar etapa como feita/refazer (alterna feito <-> todo) — só admin
  if (canEdit()) {
  var checks=app.querySelectorAll('[data-mscheck]');
  for (var i=0;i<checks.length;i++) {
    checks[i].addEventListener('click', function(e){
      e.stopPropagation();
      var id=this.getAttribute('data-mscheck'); var mm=msById(id);
      if (!mm) return;
      var novo = mm.status==='feito' ? 'todo' : 'feito';
      mm.status = novo;
      sb.from('malba_vl_milestones').update({ status:novo }).eq('id', mm.id).then(function(r){ if (r.error) toast('Erro ao atualizar etapa','error'); });
      renderPage();
    });
  }
  // status: cicla todo -> fazendo -> feito (pelo selo de status)
  var stbtns=app.querySelectorAll('[data-msstatus]');
  for (var j=0;j<stbtns.length;j++) {
    stbtns[j].addEventListener('click', function(){
      var id=this.getAttribute('data-msstatus'); var mm=msById(id);
      if (!mm) return;
      var ordem=['todo','fazendo','feito'];
      mm.status = ordem[(ordem.indexOf(mm.status||'todo')+1)%3];
      sb.from('malba_vl_milestones').update({ status:mm.status }).eq('id', mm.id);
      renderPage();
    });
  }
  } // fim mutações de etapa (admin)
  // expandir/recolher painel de passos
  var exps=app.querySelectorAll('[data-msexp]');
  for (var e=0;e<exps.length;e++) {
    exps[e].addEventListener('click', function(){
      var id=this.getAttribute('data-msexp');
      expandedMs = (String(expandedMs)===String(id)) ? null : id;
      renderPage();
    });
  }
  // marcar passo (subtarefa) — só admin
  if (canEdit()) {
  var subToggles=app.querySelectorAll('[data-subtoggle]');
  for (var s=0;s<subToggles.length;s++) {
    subToggles[s].addEventListener('change', function(){
      var pr=this.getAttribute('data-subtoggle').split(':'); var mm=msById(pr[0]);
      if (!mm || !mm.subtasks) return;
      mm.subtasks[+pr[1]].done = this.checked;
      sb.from('malba_vl_milestones').update({ subtasks:mm.subtasks }).eq('id', mm.id);
      renderPage();
    });
  }
  // excluir passo
  var subDels=app.querySelectorAll('[data-subdel]');
  for (var d=0;d<subDels.length;d++) {
    subDels[d].addEventListener('click', function(ev){
      ev.preventDefault(); ev.stopPropagation();
      var pr=this.getAttribute('data-subdel').split(':'); var mm=msById(pr[0]);
      if (!mm || !mm.subtasks) return;
      mm.subtasks.splice(+pr[1],1);
      sb.from('malba_vl_milestones').update({ subtasks:mm.subtasks }).eq('id', mm.id);
      renderPage();
    });
  }
  // adicionar passo
  var subAdds=app.querySelectorAll('[data-subadd]');
  for (var a2=0;a2<subAdds.length;a2++) {
    subAdds[a2].addEventListener('click', function(){
      var id=this.getAttribute('data-subadd'); var mm=msById(id);
      if (!mm) return;
      var inp=app.querySelector('[data-subinput="'+id+'"]');
      var titulo=(inp&&inp.value||'').trim();
      if (!titulo) return;
      mm.subtasks = mm.subtasks || [];
      mm.subtasks.push({ title:titulo, done:false });
      sb.from('malba_vl_milestones').update({ subtasks:mm.subtasks }).eq('id', mm.id);
      renderPage();
    });
  }
  // adicionar etapa
  var addBtn=document.getElementById('msAdd');
  if (addBtn) addBtn.addEventListener('click', function(){
    var name=(document.getElementById('msName').value||'').trim();
    if (!name) { toast('Informe o nome da etapa','error'); return; }
    var pos=projectMilestones(ST.openProject).length;
    var rec={ project_id:ST.openProject, name:name, date:document.getElementById('msDate').value||null, assignee_id:document.getElementById('msResp').value||null, status:'todo', position:pos, subtasks:[] };
    addBtn.disabled=true; addBtn.textContent='...';
    sb.from('malba_vl_milestones').insert(rec).select().single().then(function(r){
      if (r.error || !r.data) { toast('Erro ao adicionar etapa','error'); console.error(r.error); setBusy(addBtn,false); addBtn.textContent='Adicionar'; return; }
      ST.milestones.push(r.data); toast('Etapa adicionada','success'); renderPage();
    });
  });
  } // fim mutações de passos/etapa (admin)
}

/* ----- Modal de criar/editar projeto ----- */
function openProjectModal(project) {
  if(!canEdit()){ blockManage(); return; }
  var isNew=!project;
  var pr=project||{ name:'', description:'', start_date:'', end_date:'', status:'andamento', color:'#3B6FF7', members:[] };
  var membros=(pr.members||[]).slice();
  // v76: preenchimento automático — novo projeto já começa hoje e com você na equipe
  if(isNew){ if(!pr.start_date) pr.start_date=today(); if(!membros.length && ST.session && ST.session.user) membros=[ST.session.user.id]; }
  var colorPick=pr.color||'#3B6FF7';

  var colorBtns=PROJ_COLORS.map(function(c){ return '<button type="button" class="color-dot'+(colorPick===c?' on':'')+'" data-color="'+c+'" style="background:'+c+'"></button>'; }).join('');
  var memHTML='';
  ST.users.forEach(function(u){
    var on=membros.indexOf(u.id)!==-1;
    memHTML += '<label class="member-pick'+(on?' on':'')+'"><input type="checkbox" data-member="'+esc(u.id)+'"'+(on?' checked':'')+'><span class="member-pick-av" style="background:'+(u.color||'#3B6FF7')+'">'+esc(iniciais(u.name))+'</span>'+esc(u.name)+'</label>';
  });
  if (ST.users.length===0) memHTML='<div style="font-size:12px;color:var(--u-text3)">Nenhuma pessoa no setor</div>';

  var lojaInfo = ST.store ? ('<div class="wz-auto">'+icon('store')+'<span>Loja <b>'+esc(ST.store.name||('Loja '+ST.store.store_number))+'</b> — preenchida automaticamente</span></div>') : '';

  var step1 = '<input class="modal-title-input" id="pName" placeholder="Nome do projeto..." value="'+esc(pr.name)+'" data-review="Nome">'+
    '<div class="modal-row"><label class="modal-label">Descrição</label><textarea id="pDesc" placeholder="Sobre o projeto..." data-review="Descrição">'+esc(pr.description||'')+'</textarea></div>'+
    '<div class="modal-row"><label class="modal-label">Cor</label><div class="color-row" id="pColors">'+colorBtns+'</div></div>';
  var step2 = '<div class="modal-grid2"><div class="modal-row"><label class="modal-label">Início</label><input type="date" id="pStart" value="'+esc((pr.start_date||'').split('T')[0])+'" data-review="Início"></div><div class="modal-row"><label class="modal-label">Prazo</label><input type="date" id="pEnd" value="'+esc((pr.end_date||'').split('T')[0])+'" data-review="Prazo"></div></div>'+
    '<div class="wz-auto">'+icon('target')+'<span>Situação inicial: <b>Em andamento</b> — automático</span></div>';
  var step3 = '<div class="modal-row"><label class="modal-label">Equipe do projeto (responsáveis)</label><div class="member-picks">'+memHTML+'</div></div>'+lojaInfo+
    (isNew ? '' : docsVinculadosBlocoHTML('projeto', pr.id)); // v100

  formWizard({
    title: isNew?'Novo projeto':'Editar projeto',
    editing: !isNew,
    del: !isNew, delLabel:'Excluir',
    steps: [
      { html: step1, validate: function(bg){ var n=(bg.querySelector('#pName').value||'').trim(); if(!n){ toast('Informe o nome do projeto','error'); return false; } return true; } },
      { html: step2 },
      { html: step3 }
    ],
    reviewExtra: function(bg){
      var sel=[]; bg.querySelectorAll('[data-member]:checked').forEach(function(cb){ var u=userById(cb.getAttribute('data-member')); if(u) sel.push(u.name); });
      var eq = sel.length ? esc(sel.join(', ')) : '<i>—</i>';
      var cor = '<span style="display:inline-block;width:14px;height:14px;border-radius:4px;background:'+colorPick+';vertical-align:-2px"></span>';
      return '<div class="wz-rev-row"><span class="wz-rev-l">Equipe</span><span class="wz-rev-v">'+eq+'</span></div>'+
             '<div class="wz-rev-row"><span class="wz-rev-l">Cor</span><span class="wz-rev-v">'+cor+'</span></div>';
    },
    onReady: function(bg){
      bindDocsVinculados(bg); // v100
      var dots=bg.querySelectorAll('.color-dot');
      for (var i=0;i<dots.length;i++) dots[i].addEventListener('click', function(){ for(var k=0;k<dots.length;k++) dots[k].classList.remove('on'); this.classList.add('on'); colorPick=this.getAttribute('data-color'); });
      var memCbs=bg.querySelectorAll('[data-member]');
      for (var j=0;j<memCbs.length;j++) memCbs[j].addEventListener('change', function(){ this.closest('.member-pick').classList.toggle('on', this.checked); });
    },
    onSave: function(bg, close, btn){
      var name=(bg.querySelector('#pName').value||'').trim();
      if (!name) { toast('Informe o nome do projeto','error'); return; }
      var sel=[]; bg.querySelectorAll('[data-member]:checked').forEach(function(cb){ sel.push(cb.getAttribute('data-member')); });
      var rec={ sector:ST.sector, name:name, description:(bg.querySelector('#pDesc').value||'').trim(), start_date:bg.querySelector('#pStart').value||null, end_date:bg.querySelector('#pEnd').value||null, members:sel, store_unit_id:ST.store?ST.store.id:null, color:colorPick, status:pr.status||'andamento' };
      setBusy(btn,true);
      if (isNew) {
        sb.from('malba_vl_projects').insert(rec).select().single().then(function(r){
          if (r.error || !r.data) { toast('Erro ao criar projeto','error'); console.error(r.error); setBusy(btn,false); return; }
          ST.projects.unshift(r.data); auditLog('Criou projeto', name); close(); toast('Projeto criado','success'); renderPage();
        });
      } else {
        sb.from('malba_vl_projects').update(rec).eq('id', pr.id).then(function(r){
          if (r.error) { toast('Erro ao salvar','error'); console.error(r.error); setBusy(btn,false); return; }
          for (var i=0;i<ST.projects.length;i++) if (ST.projects[i].id===pr.id) { ST.projects[i]=Object.assign(ST.projects[i],rec); break; }
          close(); toast('Projeto atualizado','success'); renderPage();
        });
      }
    },
    onDelete: function(close){
      confirmDelete('Excluir o projeto "'+(pr.name||'')+'" e todas as etapas?', function(){ sb.from('malba_vl_projects').delete().eq('id', pr.id).then(function(r){
        if (r.error) { toast('Erro ao excluir','error'); return; }
        ST.projects = ST.projects.filter(function(x){ return x.id!==pr.id; });
        ST.milestones = ST.milestones.filter(function(x){ return String(x.project_id)!==String(pr.id); });
        ST.openProject=null; close(); toast('Projeto excluído','success'); renderPage();
      }); });
    }
  });
}

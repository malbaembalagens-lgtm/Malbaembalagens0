/* ============================================================
   v96: MÓDULO DOCUMENTOS — Fase 1
   Central de documentos por setor. Pastas em profundidade
   ilimitada (nested via parent_id), documentos com autor,
   favoritos, arquivados, compartilhamento simples (equipe do setor).
   Editor: EditorJS (carregado sob demanda no modal).
   ============================================================ */

/* ---------- Load: puxa pastas e documentos do setor ---------- */
function loadDocs(sector){
  if(!sb){ ST.docFolders=[]; ST.docs=[]; return; }
  try {
    sb.from('malba_doc_folders').select('*').eq('sector', sector).then(function(r){
      if(r.error){ console.warn('Docs: rode o SQL Fase 1. Detalhe:', r.error.message); ST.docFolders=[]; return; }
      ST.docFolders = r.data || [];
      if (ST.page==='docs' && !ST.docOpen) renderPage(); // não re-renderiza com o editor aberto
    }, function(){ ST.docFolders=[]; });
    // v99: comentários do setor — um query só, alimenta o contador da lista
    sb.from('malba_doc_comments').select('id, doc_id, parent_id, resolved').eq('sector', sector).then(function(rc){
      if (rc.error || !rc.data) return;
      ST.docCommentCount = {};
      rc.data.forEach(function(c){
        if (c.resolved || c.parent_id) return;
        ST.docCommentCount[c.doc_id] = (ST.docCommentCount[c.doc_id]||0) + 1;
      });
      if (ST.page==='docs' && !ST.docOpen) renderPage(); // não re-renderiza com o editor aberto
    }, function(){});
    sb.from('malba_docs').select('id, sector, title, doc_type, folder_id, author_id, visibility, default_perm, shares, unit_id, links, is_archived, is_favorite_by, tags, updated_at, created_at').eq('sector', sector).then(function(r){
      if(r.error){ ST.docs=[]; return; }
      ST.docs = r.data || [];
      if (ST.page==='docs' && !ST.docOpen) renderPage(); // não re-renderiza com o editor aberto
    }, function(){ ST.docs=[]; });
  } catch(e){ ST.docFolders=[]; ST.docs=[]; }
}

/* ---------- Estado local ---------- */
function docView(){ return ST.docView || 'lista'; }        // lista | grade
function docTab(){ return ST.docTab || 'todos'; }          // todos | meus | compartilhados | privados | atas | arquivados | favoritos | recentes | folder:<id>
function docQ(){ return ST.docQ || ''; }
function docPodeCriar(){ return can('docs') && !isViewer(); }
function isViewer(){ var nv=nivelDe(ST.session&&ST.session.user); return nv==='viewer'; }

/* ---------- Documento pertence a esta lista? ---------- */
function docPertenceAba(d, tab){
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';
  // v97: só entra na lista o que a pessoa realmente pode ver
  if (!docPodeVer(d)) return false;
  var arqui = d.is_archived;
  if (tab==='arquivados') return arqui;
  if (arqui) return false;
  if (tab==='meus')            return String(d.author_id||'')===eu;
  if (tab==='compartilhados')  return String(d.author_id||'')!==eu; // v97: já passou pelo docPodeVer
  if (tab==='privados')        return (d.visibility||'setor')==='privado' && String(d.author_id||'')===eu;
  if (tab==='atas')            return (d.doc_type||'')==='ata';
  if (tab==='favoritos')       return Array.isArray(d.is_favorite_by) && d.is_favorite_by.indexOf(eu)!==-1;
  if (tab==='recentes'){
    var seteDias = new Date(Date.now()-7*24*3600*1000).toISOString();
    return (d.updated_at||'')>=seteDias;
  }
  if (tab==='vinculados')      return docLinksDe(d).length>0; // v100
  if (tab.indexOf('folder:')===0) return String(d.folder_id||'')===tab.slice(7);
  return true; // 'todos'
}

/* ---------- Tela principal ---------- */
function docsHTML(){
  if (!(can('docs') || permsHas('docs'))){
    return emptyState({ icon:'folder', title:'Acesso restrito', text:'Módulo Documentos exige permissão.' });
  }
  var novaBtn = docPodeCriar() ? '<button class="btn-new" id="btnNovoDoc">'+icon('plus')+'Novo documento</button>' : '';
  var sub = 'Central de documentos · '+(SECTORS[ST.sector]?SECTORS[ST.sector].label:'');
  var head = '<div class="tasks-head"><div><h2>Documentos</h2><div class="sub">'+esc(sub)+'</div></div><div class="tasks-head-r">'+novaBtn+'</div></div>';

  var corpo = (docTab()==='dashboard') ? docsDashboardHTML() : docsListHTML(); // v100
  return head + '<div class="docs-wrap">'+docsSideHTML()+'<div class="docs-main">'+corpo+'</div></div>';
}

/* ---------- Sidebar: abas fixas + pastas em árvore ---------- */
function docsSideHTML(){
  var tab = docTab();
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';
  var docs = (ST.docs||[]);
  function cont(fn){ return docs.filter(function(d){ return !d.is_archived && fn(d); }).length; }
  var contTotal = docs.filter(function(d){ return !d.is_archived; }).length;
  var contMeus = cont(function(d){ return String(d.author_id||'')===eu; });
  var contComp = cont(function(d){ return String(d.author_id||'')!==eu && (d.visibility||'setor')!=='privado'; });
  var contPriv = cont(function(d){ return (d.visibility||'setor')==='privado' && String(d.author_id||'')===eu; });
  var contAtas = cont(function(d){ return (d.doc_type||'')==='ata'; });
  var contArqu = docs.filter(function(d){ return d.is_archived; }).length;
  var contFav = cont(function(d){ return Array.isArray(d.is_favorite_by) && d.is_favorite_by.indexOf(eu)!==-1; });
  var seteDias = new Date(Date.now()-7*24*3600*1000).toISOString();
  var contRec = cont(function(d){ return (d.updated_at||'')>=seteDias; });

  function item(id, label, count, icone){
    var on = id===tab ? ' on' : '';
    return '<button class="docs-side-item'+on+'" data-doc-tab="'+id+'"><span>'+esc(icone||'')+' '+esc(label)+'</span><span class="docs-count">'+count+'</span></button>';
  }

  var contVinc = docs.filter(function(d){ return !d.is_archived && docLinksDe(d).length>0; }).length; // v100
  var g1 = '<div class="docs-side-group">'+
    item('dashboard','Painel', '', '📊')+
    item('todos','Todos os documentos', contTotal, '📁')+
    item('meus','Meus documentos', contMeus, '👤')+
    item('compartilhados','Compartilhados comigo', contComp, '👥')+
    item('privados','Privados', contPriv, '🔒')+
    item('atas','Atas de reunião', contAtas, '📝')+
    item('vinculados','Vinculados', contVinc, '🔗')+
    item('arquivados','Arquivados', contArqu, '🗂')+
  '</div>';
  var g2 = '<div class="docs-side-group">'+
    item('favoritos','Favoritos', contFav, '⭐')+
    item('recentes','Recentes', contRec, '🕓')+
  '</div>';

  // pastas — nested; renderiza a raiz e chama recursivo
  var g3Head = '<div class="docs-side-group-h">📂 Pastas'+(docPodeCriar()?' <button class="docs-side-add" id="btnNovaPasta" title="Nova pasta">+</button>':'')+'</div>';
  var g3Body = docsFolderTreeHTML(null, 0);
  var g3 = '<div class="docs-side-group folders">'+g3Head+g3Body+'</div>';

  return '<aside class="docs-side">'+g1+g2+g3+'</aside>';
}

/* ---------- Árvore de pastas (recursiva, sem limite de profundidade) ---------- */
function docsFolderTreeHTML(parentId, depth){
  var folders = (ST.docFolders||[]).filter(function(f){ return String(f.parent_id||'')===String(parentId||''); });
  folders.sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); });
  if (!folders.length && depth===0){
    return '<div class="docs-folder-empty">Nenhuma pasta ainda</div>';
  }
  var tab = docTab();
  return '<div class="docs-folder-tree" style="padding-left:'+(depth*10)+'px">'+folders.map(function(f){
    var docCount = (ST.docs||[]).filter(function(d){ return !d.is_archived && String(d.folder_id||'')===String(f.id); }).length;
    var childCount = (ST.docFolders||[]).filter(function(x){ return String(x.parent_id||'')===String(f.id); }).length;
    var on = tab==='folder:'+f.id ? ' on' : '';
    var expanded = ST.docFolderOpen && ST.docFolderOpen[f.id];
    var expander = childCount>0 ? '<span class="docs-folder-toggle" data-folder-toggle="'+esc(f.id)+'">'+(expanded?'▾':'▸')+'</span>' : '<span class="docs-folder-toggle empty">·</span>';
    return '<div class="docs-folder-row">'+
      '<div class="docs-folder-item'+on+'" data-folder-id="'+esc(f.id)+'">'+
        expander+
        '<span class="docs-folder-lb">📁 '+esc(f.name)+'</span>'+
        '<span class="docs-folder-c">'+docCount+'</span>'+
      '</div>'+
      (expanded && childCount>0 ? docsFolderTreeHTML(f.id, depth+1) : '')+
    '</div>';
  }).join('')+'</div>';
}

/* ---------- Templates (Parte C usa isso pra criar doc estruturado) ---------- */
var DOC_TEMPLATES = [
  { key:'branco', icon:'📌', label:'Em branco', doc_type:'geral', body: null },
  { key:'ata', icon:'📋', label:'Ata de reunião', doc_type:'ata', body: docTplAta() },
  { key:'pop', icon:'📑', label:'POP', doc_type:'pop', body: docTplPOP() },
  { key:'manual', icon:'📘', label:'Manual', doc_type:'manual', body: docTplManual() },
  { key:'wiki', icon:'📚', label:'Wiki', doc_type:'wiki', body: docTplWiki() },
  { key:'planejamento', icon:'📊', label:'Planejamento', doc_type:'planejamento', body: docTplPlanejamento() },
  { key:'estrategia', icon:'📈', label:'Estratégia', doc_type:'estrategia', body: docTplEstrategia() }
];

/* ---------- Lista principal ---------- */
function docsListHTML(){
  var tab = docTab();
  var lista = (ST.docs||[]).filter(function(d){ return docPertenceAba(d, tab); });
  var q = docQ().toLowerCase();
  if (q) lista = lista.filter(function(d){
    // v98: casa por título, tag OU pelo conteúdo (resultado que veio do servidor)
    return (d.title||'').toLowerCase().indexOf(q)!==-1 ||
           ((d.tags||[]).join(' ').toLowerCase().indexOf(q)!==-1) ||
           (ST.docHits && ST.docHits[d.id]);
  });
  // ordena por atualização recente
  lista.sort(function(a,b){ return (b.updated_at||'').localeCompare(a.updated_at||''); });

  // barra: templates + busca + toggle de visão
  var templates = docPodeCriar() ? '<div class="doc-tpls">'+DOC_TEMPLATES.map(function(t){
    return '<button class="doc-tpl" data-tpl="'+t.key+'"><span class="doc-tpl-ic">'+t.icon+'</span><span>'+esc(t.label)+'</span></button>';
  }).join('')+'</div>' : '';
  var busca = '<input type="search" class="task-filter" id="docQ" placeholder="Buscar no título, tags e dentro dos documentos..." value="'+esc(docQ())+'">';
  var vt = docView();
  var toggle = '<div class="view-toggle doc-vtog">'+
    '<button class="vt-btn'+(vt==='lista'?' on':'')+'" data-doc-view="lista">'+icon('grid')+'Lista</button>'+
    '<button class="vt-btn'+(vt==='grade'?' on':'')+'" data-doc-view="grade">'+icon('dashboard')+'Grade</button>'+
  '</div>';
  var filtros = '<div class="doc-filtros">'+busca+toggle+'</div>';
  // v98: aviso do que a busca está fazendo
  if (docQ()){
    if (ST.docBuscando) filtros += '<div class="doc-busca-aviso">procurando dentro dos documentos…</div>';
    else if (ST.docHits){
      var nHits = Object.keys(ST.docHits).length;
      filtros += '<div class="doc-busca-aviso ok">'+(nHits ? (nHits+' documento'+(nHits>1?'s':'')+' com esse texto no conteúdo') : 'nenhum documento com esse texto no conteúdo')+'</div>';
    }
  }

  var body;
  if (lista.length===0){
    body = emptyState({
      icon:'folder',
      title: q ? 'Nenhum documento com esse filtro' : 'Nenhum documento por aqui ainda',
      text: docPodeCriar() ? 'Use um dos modelos acima ou clique em "Novo documento" para criar em branco.' : 'Os documentos vão aparecer aqui quando forem criados.',
      span:true
    });
  } else if (vt==='grade'){
    body = '<div class="doc-grade">'+lista.map(docCardHTML).join('')+'</div>';
  } else {
    body = docsTableHTML(lista);
  }
  return templates + filtros + body;
}

function docsTableHTML(lista){
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';
  var rows = lista.map(function(d){
    var au = userById(d.author_id);
    var quem = au ? au.name : '—';
    var fav = Array.isArray(d.is_favorite_by) && d.is_favorite_by.indexOf(eu)!==-1;
    var pasta = d.folder_id ? (ST.docFolders||[]).find(function(f){ return String(f.id)===String(d.folder_id); }) : null;
    var pastaLb = pasta ? '📁 '+esc(pasta.name) : '—';
    var vis = docShareLabel(d); // v97
    var upd = d.updated_at ? esc(tempoRelativo(d.updated_at)) : '—';
    var tipoIc = docTipoIcon(d.doc_type);
    var tags = (d.tags||[]).slice(0,3).map(function(t){ return '<span class="doc-tag">'+esc(t)+'</span>'; }).join('');
    // v98: trecho do conteúdo quando a busca casou lá dentro
    var trecho = (ST.docHits && ST.docHits[d.id]) ? '<div class="doc-trecho">'+docDestacar(ST.docHits[d.id], docQ())+'</div>' : '';
    // v99: quantos comentários em aberto
    var nc = (ST.docCommentCount && ST.docCommentCount[d.id]) || docComentariosAbertos(d.id);
    var badge = nc ? ' <span class="doc-lista-coment" title="'+nc+' comentário'+(nc>1?'s':'')+' em aberto">💬 '+nc+'</span>' : '';
    // v100: vínculos na linha
    var nl = docLinksDe(d).length;
    if (nl) badge += ' <span class="doc-lista-coment" title="'+nl+' vínculo'+(nl>1?'s':'')+'">🔗 '+nl+'</span>';
    return '<tr data-doc-id="'+esc(d.id)+'">'+
      '<td class="doc-td-star"><button class="doc-fav'+(fav?' on':'')+'" data-doc-fav="'+esc(d.id)+'" title="'+(fav?'Desfavoritar':'Favoritar')+'">'+(fav?'★':'☆')+'</button></td>'+
      '<td class="doc-td-title"><span class="doc-tipo-ic">'+tipoIc+'</span><b>'+esc(d.title||'(sem título)')+'</b>'+badge+' <span class="doc-tags-inline">'+tags+'</span>'+trecho+'</td>'+
      '<td>'+pastaLb+'</td>'+
      '<td>'+esc(quem)+'</td>'+
      '<td>'+vis+'</td>'+
      '<td>'+upd+'</td>'+
    '</tr>';
  }).join('');
  return '<div class="doc-table-wrap"><table class="doc-table">'+
    '<thead><tr><th></th><th>Nome</th><th>Pasta</th><th>Autor</th><th>Compartilhamento</th><th>Atualizado</th></tr></thead>'+
    '<tbody>'+rows+'</tbody>'+
  '</table></div>';
}

function docCardHTML(d){
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';
  var au = userById(d.author_id);
  var fav = Array.isArray(d.is_favorite_by) && d.is_favorite_by.indexOf(eu)!==-1;
  var tipoIc = docTipoIcon(d.doc_type);
  var upd = d.updated_at ? tempoRelativo(d.updated_at) : '';
  return '<div class="doc-card" data-doc-id="'+esc(d.id)+'">'+
    '<div class="doc-card-top">'+
      '<span class="doc-tipo-ic">'+tipoIc+'</span>'+
      '<button class="doc-fav'+(fav?' on':'')+'" data-doc-fav="'+esc(d.id)+'" title="'+(fav?'Desfavoritar':'Favoritar')+'">'+(fav?'★':'☆')+'</button>'+
    '</div>'+
    '<h4 class="doc-card-title">'+esc(d.title||'(sem título)')+'</h4>'+
    '<div class="doc-card-foot"><span>'+esc(au?au.name:'—')+'</span><span>'+esc(upd)+'</span></div>'+
  '</div>';
}

function docTipoIcon(t){
  return { ata:'📝', pop:'📑', manual:'📘', wiki:'📚', planejamento:'📊', estrategia:'📈' }[t] || '📄';
}

/* ---------- Templates: geram o JSON inicial do EditorJS ---------- */
function tpl_para(text){ return { type:'paragraph', data:{ text: text||'' } }; }
function tpl_header(text, level){ return { type:'header', data:{ text:text||'', level: level||2 } }; }
function tpl_checklist(itens){ return { type:'checklist', data:{ items: (itens||[]).map(function(t){ return { text:t, checked:false }; }) } }; }
function tpl_list(itens, style){ return { type:'list', data:{ style: style||'unordered', items: itens||[] } }; }
function tpl_delim(){ return { type:'delimiter', data:{} }; }

function docTplAta(){
  return { blocks:[
    tpl_header('Ata de reunião', 1),
    tpl_para('<b>Data:</b> '+fmtDate(today())),
    tpl_para('<b>Participantes:</b> '),
    tpl_delim(),
    tpl_header('Objetivos', 2),
    tpl_list(['(o que a reunião precisa resolver)']),
    tpl_header('Assuntos discutidos', 2),
    tpl_list(['']),
    tpl_header('Decisões', 2),
    tpl_list(['']),
    tpl_header('Pendências', 2),
    tpl_checklist(['(cada item vira uma tarefa com o botão no topo)']),
    tpl_header('Próximas ações', 2),
    tpl_checklist([''])
  ]};
}
function docTplPOP(){
  return { blocks:[
    tpl_header('POP — Procedimento Operacional Padrão', 1),
    tpl_para('<b>Objetivo:</b> '),
    tpl_para('<b>Área/Setor:</b> '),
    tpl_para('<b>Responsável:</b> '),
    tpl_delim(),
    tpl_header('Passo a passo', 2),
    tpl_list(['Passo 1', 'Passo 2', 'Passo 3'], 'ordered'),
    tpl_header('Materiais necessários', 2),
    tpl_list(['']),
    tpl_header('Cuidados / atenções', 2),
    tpl_list([''])
  ]};
}
function docTplManual(){
  return { blocks:[
    tpl_header('Manual', 1),
    tpl_para('<i>Escreva aqui a apresentação do manual.</i>'),
    tpl_delim(),
    tpl_header('Índice', 2),
    tpl_list(['Introdução', 'Como usar', 'Perguntas frequentes']),
    tpl_header('Introdução', 2),
    tpl_para(''),
    tpl_header('Como usar', 2),
    tpl_para(''),
    tpl_header('Perguntas frequentes', 2),
    tpl_para('')
  ]};
}
function docTplWiki(){
  return { blocks:[
    tpl_header('Wiki', 1),
    tpl_para('Documentação viva. Vai crescendo. Pode ser editado por quem tiver acesso.'),
    tpl_delim(),
    tpl_header('Tópicos', 2),
    tpl_list([''])
  ]};
}
function docTplPlanejamento(){
  return { blocks:[
    tpl_header('Planejamento', 1),
    tpl_header('Contexto', 2),  tpl_para(''),
    tpl_header('Objetivo', 2),   tpl_para(''),
    tpl_header('Escopo', 2),     tpl_list(['']),
    tpl_header('Cronograma', 2), tpl_list(['']),
    tpl_header('Responsáveis', 2), tpl_para(''),
    tpl_header('Riscos', 2),     tpl_list([''])
  ]};
}
function docTplEstrategia(){
  return { blocks:[
    tpl_header('Plano Estratégico', 1),
    tpl_header('Diagnóstico', 2),        tpl_para(''),
    tpl_header('Objetivos estratégicos', 2), tpl_list(['']),
    tpl_header('Indicadores', 2),         tpl_para(''),
    tpl_header('Iniciativas', 2),         tpl_list(['']),
    tpl_header('Prazo', 2),               tpl_para('')
  ]};
}

/* ============================================================
   v96: MÓDULO DOCUMENTOS — Parte B (CRUD + Editor)
   ============================================================ */

/* ---------- Cria um novo documento a partir de um template ---------- */
function docsCriar(tplKey, folderId){
  if (!docPodeCriar()){ blockManage(); return; }
  var tpl = DOC_TEMPLATES.find(function(t){ return t.key===tplKey; }) || DOC_TEMPLATES[0];
  var eu = ST.session && ST.session.user ? ST.session.user : null;
  var payload = {
    sector: ST.sector,
    title: tpl.key==='branco' ? 'Sem título' : tpl.label,
    doc_type: tpl.doc_type,
    folder_id: folderId || null,
    author_id: eu ? eu.id : null,
    visibility: 'setor',
    default_perm: 'editar',  // v97
    shares: [],              // v97
    links: [],               // v100
    body: tpl.body,
    plain_text: docBodyParaTexto(tpl.body), // v98
    is_archived: false,
    is_favorite_by: [],
    tags: []
  };
  sb.from('malba_docs').insert(payload).select().single().then(function(r){
    if (r.error || !r.data){ toast('Não consegui criar: '+(r.error && r.error.message || ''),'error'); return; }
    if (!ST.docs) ST.docs=[];
    ST.docs.unshift(r.data);
    toast('Documento criado','success');
    openDocEditor(r.data);
  });
}

/* ---------- Ações rápidas (arquivar, favoritar, duplicar, mover, excluir) ---------- */
function docsFavToggle(id){
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
  if (!d) return;
  var fav = Array.isArray(d.is_favorite_by) ? d.is_favorite_by.slice() : [];
  var idx = fav.indexOf(eu);
  if (idx>=0) fav.splice(idx,1); else fav.push(eu);
  d.is_favorite_by = fav; // otimista
  renderPage();
  sb.from('malba_docs').update({ is_favorite_by: fav }).eq('id', d.id).then(function(r){
    if (r.error){ toast('Não consegui salvar favorito','error'); }
  });
}

function docsArquivar(id, arquivar){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
  if (!d) return;
  if (!docPodeAdmin(d)){ toast('Você não tem acesso de Admin neste documento.','error'); return; } // v97
  var novo = arquivar!==false;
  d.is_archived = novo; renderPage();
  sb.from('malba_docs').update({ is_archived: novo }).eq('id', id).then(function(r){
    if (r.error){ toast('Não consegui arquivar','error'); d.is_archived = !novo; renderPage(); return; }
    toast(novo?'Documento arquivado':'Documento restaurado','success');
  });
}

function docsExcluir(id){
  var dd = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
  if (dd && !docPodeAdmin(dd)){ toast('Você não tem acesso de Admin neste documento.','error'); return; } // v97
  confirmDialog({
    title:'Excluir este documento?', message:'A ação não pode ser desfeita. Prefira arquivar para manter no histórico.',
    danger:true, confirmLabel:'Excluir',
    onConfirm: function(){
      sb.from('malba_docs').delete().eq('id', id).then(function(r){
        if (r.error){ toast('Não consegui excluir','error'); return; }
        ST.docs = (ST.docs||[]).filter(function(x){ return String(x.id)!==String(id); });
        toast('Documento excluído','success'); renderPage();
      });
    }
  });
}

function docsDuplicar(id){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
  if (!d) return;
  var eu = ST.session && ST.session.user ? ST.session.user : null;
  var copia = {
    sector: d.sector, title: (d.title||'Sem título') + ' (cópia)',
    doc_type: d.doc_type, folder_id: d.folder_id, author_id: eu?eu.id:null,
    visibility: d.visibility||'setor', default_perm: d.default_perm||'editar',
    shares: [], // v97: a cópia não herda convites — quem duplicou decide de novo
    body: d.body, is_archived:false,
    is_favorite_by: [], tags: d.tags||[]
  };
  sb.from('malba_docs').insert(copia).select().single().then(function(r){
    if (r.error || !r.data){ toast('Não consegui duplicar','error'); return; }
    ST.docs.unshift(r.data);
    toast('Documento duplicado','success'); renderPage();
  });
}

function docsMover(id, folderId){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
  if (!d) return;
  if (!docPodeEditar(d)){ toast('Você tem acesso de leitura neste documento.','error'); return; } // v97
  var antes = d.folder_id;
  d.folder_id = folderId || null; renderPage();
  sb.from('malba_docs').update({ folder_id: folderId||null }).eq('id', id).then(function(r){
    if (r.error){ d.folder_id = antes; renderPage(); toast('Não consegui mover','error'); return; }
    toast('Documento movido','success');
  });
}

/* ---------- Pastas: criar, renomear, excluir ---------- */
function docsNovaPasta(parentId){
  if (!docPodeCriar()){ blockManage(); return; }
  makeModal({
    title:'Nova pasta', width:400,
    body:'<div class="modal-row"><label class="modal-label">Nome da pasta</label><input type="text" id="pfName" placeholder="Ex: Marketing" autocomplete="off"></div>'+
         (parentId ? '<p class="modal-note">Vai virar subpasta de: '+esc((ST.docFolders||[]).find(function(f){return String(f.id)===String(parentId);}).name||'')+'</p>' : ''),
    saveLabel:'Criar pasta',
    onSave: function(close, root){
      var nome = (root.querySelector('#pfName').value||'').trim();
      if (!nome){ toast('Informe o nome','error'); return; }
      var payload = { sector:ST.sector, name:nome, parent_id: parentId||null };
      sb.from('malba_doc_folders').insert(payload).select().single().then(function(r){
        if (r.error || !r.data){ toast('Não consegui criar pasta: '+(r.error&&r.error.message||''),'error'); return; }
        if (!ST.docFolders) ST.docFolders=[];
        ST.docFolders.push(r.data);
        // já expande o pai se tiver
        if (parentId){ ST.docFolderOpen = ST.docFolderOpen||{}; ST.docFolderOpen[parentId] = true; }
        close(); toast('Pasta criada','success'); renderPage();
      });
    }
  });
}

/* ---------- Editor: EditorJS via CDN ---------- */
var _editorJsPromise = null;
function carregarEditorJS(){
  if (_editorJsPromise) return _editorJsPromise;
  if (window.EditorJS) { _editorJsPromise = Promise.resolve(); return _editorJsPromise; }
  _editorJsPromise = new Promise(function(resolve, reject){
    // uma tag pra cada script — carrega em sequência
    var libs = [
      'https://cdn.jsdelivr.net/npm/@editorjs/editorjs@2.30.6/dist/editorjs.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/header@2.8.7/dist/header.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/list@1.9.0/dist/list.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/checklist@1.6.0/dist/checklist.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/table@2.3.0/dist/table.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/code@2.9.0/dist/code.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/quote@2.6.0/dist/quote.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/delimiter@1.4.0/dist/delimiter.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/warning@1.4.1/dist/warning.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/marker@1.4.0/dist/marker.umd.min.js',
      'https://cdn.jsdelivr.net/npm/@editorjs/inline-code@1.5.1/dist/inline-code.umd.min.js'
    ];
    var i = 0;
    function next(){
      if (i>=libs.length){ resolve(); return; }
      var s = document.createElement('script');
      s.src = libs[i++]; s.onload = next;
      s.onerror = function(){ reject(new Error('Falha ao carregar '+s.src)); };
      document.head.appendChild(s);
    }
    next();
  });
  return _editorJsPromise;
}

/* ---------- Editor: tela inteira (renderiza fora do modal padrão) ---------- */
var _docEditorAtual = null; // { holder, editor, id, saving, dirty }

function openDocEditor(d){
  // v97: sem permissão nem abre
  if (!docPodeVer(d)){ toast('Você não tem acesso a este documento.','error'); return; }
  var podeEditar = docPodeEditar(d);
  _docEditorAtual = {
    id: d.id, editor:null, holder:null, saving:false, dirty:false, doc:d,
    readOnly: !podeEditar, carregando:true, bodyAtual:null
  };
  ST.docOpen = d.id;
  renderPage(); // desenha o wrapper (com o aviso de "carregando")

  // o corpo completo não vem no load da lista — busca sob demanda
  sb.from('malba_docs').select('body').eq('id', d.id).single().then(function(rb){
    if (!rb.error && rb.data) d.body = rb.data.body;
    prosseguir();
  }, prosseguir);

  function prosseguir(){
    var ctx = _docEditorAtual;
    if (!ctx || ctx.id!==d.id) return; // o usuário já saiu
    ctx.carregando = false;
    ctx.bodyAtual = d.body;
    // v98: guarda como estava ANTES desta sessão — vira a versão do histórico
    ctx.bodyOriginal = d.body;
    ctx.versaoSalva = false;
    docsMontarEditorJS(d);
    // v99: comentários chegam depois e só atualizam o contador — NUNCA re-renderizam
    // a página, senão o editor recém-montado seria apagado da tela.
    docsCarregarComentarios(d.id).then(function(){ docsAtualizarBadgeComentarios(d.id); });
  }
}

/* ---------- Monta (ou remonta) o EditorJS no holder atual ---------- */
function docsMontarEditorJS(d){
  var ctx = _docEditorAtual;
  if (!ctx || ctx.id!==d.id) return;
  carregarEditorJS().then(function(){
    var holder = document.getElementById('editorjsHolder');
    if (!holder) return;                       // saiu da tela
    if (ctx.editor && ctx.holder===holder) return; // já está montado neste holder
    var body = null;
    try {
      var bruto = ctx.bodyAtual != null ? ctx.bodyAtual : d.body;
      body = bruto ? (typeof bruto==='string' ? JSON.parse(bruto) : bruto) : null;
    } catch(e){ body = null; }
    if (body && !body.blocks) body = { blocks: [] };
    holder.innerHTML = '';
    var ed = new window.EditorJS({
      holder: holder,
      readOnly: ctx.readOnly,
      autofocus: !ctx.readOnly,
      placeholder: 'Comece a escrever aqui...',
      data: body || { blocks: [{ type:'paragraph', data:{ text:'' } }] },
      tools: docEditorTools(),
      onChange: function(){ if (_docEditorAtual && !_docEditorAtual.readOnly) { _docEditorAtual.dirty = true; docsAgendarAutosave(); } }
    });
    ctx.editor = ed;
    ctx.holder = holder;
  }, function(){
    var h = document.getElementById('editorjsHolder');
    if (h) h.innerHTML = '<div class="empty-page"><p>Não consegui carregar o editor. Sua conexão consegue acessar cdn.jsdelivr.net?</p></div>';
  });
}

/* ---------- Depois de qualquer re-render, garante que o editor volte ---------- */
function docsGarantirEditorMontado(){
  if (!ST.docOpen) return;
  var ctx = _docEditorAtual;
  if (!ctx || ctx.id!==ST.docOpen || ctx.carregando) return;
  var holder = document.getElementById('editorjsHolder');
  if (!holder) return;
  if (ctx.editor && ctx.holder===holder) return; // continua vivo
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(ST.docOpen); });
  if (!d) return;
  ctx.editor = null; ctx.holder = null;
  docsMontarEditorJS(d);
}

/* ---------- Guarda o conteúdo antes de um re-render intencional ---------- */
function docsPreservarConteudo(depois){
  var ctx = _docEditorAtual;
  if (!ctx || !ctx.editor || ctx.readOnly){ depois(); return; }
  ctx.editor.save().then(function(data){
    ctx.bodyAtual = data;
    ctx.editor = null; ctx.holder = null;
    depois();
  }).catch(function(){ ctx.editor = null; ctx.holder = null; depois(); });
}

/* ---------- Atualiza só o contador de comentários, sem re-render ---------- */
function docsAtualizarBadgeComentarios(docId){
  if (ST.docOpen!==docId) return;
  var btn = document.getElementById('docComent');
  if (!btn) return;
  var n = docComentariosAbertos(docId);
  btn.innerHTML = '💬 Comentários' + (n ? ' <b class="doc-coment-badge">'+n+'</b>' : '');
}

function docEditorTools(){
  return {
    header:     { class: window.Header,     inlineToolbar: true, config:{ placeholder:'Cabeçalho', levels:[1,2,3,4], defaultLevel:2 } },
    list:       { class: window.List,       inlineToolbar: true },
    checklist:  { class: window.Checklist,  inlineToolbar: true },
    table:      { class: window.Table,      inlineToolbar: true, config:{ rows:2, cols:2 } },
    code:       { class: window.CodeTool },
    quote:      { class: window.Quote,      inlineToolbar: true },
    delimiter:  { class: window.Delimiter },
    warning:    { class: window.Warning,    inlineToolbar: true },
    marker:     { class: window.Marker,     shortcut:'CMD+SHIFT+M' },
    inlineCode: { class: window.InlineCode, shortcut:'CMD+SHIFT+C' }
  };
}

/* ---------- Autosave debounced (1.5s de silêncio) ---------- */
var _autosaveTimer = null;
function docsAgendarAutosave(){
  if (_autosaveTimer) clearTimeout(_autosaveTimer);
  _autosaveTimer = setTimeout(docsSalvarAgora, 1500);
}
function docsSalvarAgora(){
  if (!_docEditorAtual || !_docEditorAtual.editor || _docEditorAtual.saving) return;
  if (_docEditorAtual.readOnly) return; // v97
  var ctx = _docEditorAtual;
  ctx.saving = true; docsMostrarStatus('salvando');
  ctx.editor.save().then(function(data){
    // v98: uma versão por sessão — guarda como estava antes de você mexer
    if (!ctx.versaoSalva){
      ctx.versaoSalva = true;
      var docAtual = (ST.docs||[]).find(function(x){ return String(x.id)===String(ctx.id); });
      docsGravarVersao(ctx.id, ctx.bodyOriginal, docAtual ? docAtual.title : null, 'antes desta edição');
    }
    return sb.from('malba_docs').update({ body: data, plain_text: docBodyParaTexto(data), updated_at: new Date().toISOString() }).eq('id', ctx.id).select().single().then(function(r){
      ctx.saving = false;
      if (r.error){ docsMostrarStatus('erro'); return; }
      ctx.dirty = false;
      ctx.bodyAtual = data; // guarda o último estado bom — usado se a tela re-renderizar
      // atualiza cache local
      var idx = (ST.docs||[]).findIndex(function(x){ return String(x.id)===String(ctx.id); });
      if (idx>=0 && r.data){ ST.docs[idx] = Object.assign(ST.docs[idx], { updated_at: r.data.updated_at }); }
      docsMostrarStatus('salvo');
    });
  }).catch(function(){ ctx.saving=false; docsMostrarStatus('erro'); });
}

function docsMostrarStatus(kind){
  var el = document.getElementById('docSaveStatus');
  if (!el) return;
  if (kind==='salvando') el.innerHTML = '<span class="doc-save saving">salvando…</span>';
  else if (kind==='salvo') el.innerHTML = '<span class="doc-save ok">✓ salvo</span>';
  else if (kind==='erro') el.innerHTML = '<span class="doc-save err">erro ao salvar</span>';
}

/* ---------- Editor: fechar (salva pendente e volta pra lista) ---------- */
function docsFecharEditor(){
  if (!_docEditorAtual){ ST.docOpen = null; renderPage(); return; }
  var ctx = _docEditorAtual;
  function limpar(){ _docEditorAtual = null; ST.docOpen = null; ST.docPainelComentarios = false; renderPage(); }
  function gravar(data){
    sb.from('malba_docs').update({ body: data, plain_text: docBodyParaTexto(data) }).eq('id', ctx.id).then(function(){
      var idx = (ST.docs||[]).findIndex(function(x){ return String(x.id)===String(ctx.id); });
      if (idx>=0) ST.docs[idx].body = data;
      limpar();
    }, limpar);
  }
  if (!ctx.dirty || ctx.readOnly){ limpar(); return; }
  if (ctx.editor){ ctx.editor.save().then(gravar).catch(limpar); return; }
  if (ctx.bodyAtual){ gravar(ctx.bodyAtual); return; } // editor foi desmontado — usa o que está em memória
  limpar();
}

/* ---------- Editor: renderiza o wrapper ---------- */
function docsEditorHTML(){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(ST.docOpen); });
  if (!d) return docsHTML(); // caiu do estado — volta pra lista
  var titulo = d.title || 'Sem título';
  // v97: selo do nível de acesso e trava do título
  var perm = docPermDe(d) || 'visualizar';
  var podeEd = docPermRank(perm) >= 3;
  var selo = podeEd
    ? ''
    : '<span class="doc-perm-selo">'+DOC_PERMS[perm].ic+' Somente '+esc(DOC_PERMS[perm].label.toLowerCase())+'</span>';
  var btnShare = docPodeAdmin(d) ? '<button class="doc-editor-share" id="docShare" title="Compartilhar">🔗 Compartilhar</button>' : '';
  var btnHist = '<button class="doc-editor-share" id="docHist" title="Histórico de versões">🕓 Histórico</button>'; // v98
  // v99: comentários e (na ata) pendências
  var nAbertos = docComentariosAbertos(d.id);
  var btnComent = '<button class="doc-editor-share'+(ST.docPainelComentarios?' on':'')+'" id="docComent" title="Comentários">💬 Comentários'+(nAbertos?' <b class="doc-coment-badge">'+nAbertos+'</b>':'')+'</button>';
  var nLinks = docLinksDe(d).length; // v100
  var btnLink = docPodeEditar(d) ? '<button class="doc-editor-share" id="docLink" title="Vincular a projeto, tarefa, cliente...">🔗 Vínculos'+(nLinks?' <b class="doc-link-badge">'+nLinks+'</b>':'')+'</button>' : '';
  var btnPend = (d.doc_type==='ata' && docPodeVer(d))
    ? '<button class="doc-editor-share destaque" id="docPend" title="Criar tarefas a partir das pendências">✅ Pendências → tarefas</button>' : '';
  return '<div class="doc-editor-wrap">'+
    '<div class="doc-editor-head">'+
      '<button class="doc-editor-back" id="docBack">← Voltar</button>'+
      '<input type="text" class="doc-editor-title" id="docTitle" value="'+esc(titulo)+'" placeholder="Título do documento"'+(podeEd?'':' readonly')+'>'+
      selo+
      '<span id="docSaveStatus"></span>'+
      btnPend+
      btnLink+
      btnComent+
      btnHist+
      btnShare+
      '<button class="btn-new doc-editor-menu" id="docMenu" title="Ações">⋯</button>'+
    '</div>'+
    (nLinks ? '<div class="doc-link-barra">'+docLinksDe(d).map(function(l){ return docLinkChipHTML(l, false); }).join('')+'</div>' : '')+
    '<div class="doc-editor-cols'+(ST.docPainelComentarios?' com-painel':'')+'">'+  // v99
      '<div class="doc-editor-body">'+
        '<div id="editorjsHolder">'+((_docEditorAtual && _docEditorAtual.id===d.id && _docEditorAtual.carregando) ? '<div class="doc-editor-load">Abrindo o documento…</div>' : '')+'</div>'+
      '</div>'+
      docsPainelComentariosHTML(d.id)+
    '</div>'+
  '</div>';
}

/* ---------- Bind: cliques na tela de documentos ---------- */
function bindDocs(){
  // se está no editor, bind diferente
  if (ST.docOpen){
    var back = document.getElementById('docBack');
    if (back) back.addEventListener('click', docsFecharEditor);
    var share = document.getElementById('docShare');
    if (share) share.addEventListener('click', function(){ docsCompartilhar(ST.docOpen); }); // v97
    var hist = document.getElementById('docHist');
    if (hist) hist.addEventListener('click', function(){ docsAbrirHistorico(ST.docOpen); }); // v98
    // v99
    var bc = document.getElementById('docComent');
    if (bc) bc.addEventListener('click', function(){
      // guarda o bloco onde o cursor estava, pra ancorar o comentário
      if (!ST.docPainelComentarios) ST.docBlocoSelecionado = docsCapturarBlocoAtual();
      ST.docPainelComentarios = !ST.docPainelComentarios;
      docsPreservarConteudo(function(){ renderPage(); }); // não perde o que está escrito
    });
    var bl = document.getElementById('docLink');
    if (bl) bl.addEventListener('click', function(){ docsVincular(ST.docOpen); }); // v100
    var bp = document.getElementById('docPend');
    if (bp) bp.addEventListener('click', function(){ docsPendenciasEmTarefas(ST.docOpen); });
    if (ST.docPainelComentarios){
      docsCarregarComentarios(ST.docOpen).then(function(){ docsPainelComentariosRender(ST.docOpen); });
    }
    var titulo = document.getElementById('docTitle');
    if (titulo && !(_docEditorAtual && _docEditorAtual.readOnly)){ // v97
      titulo.addEventListener('input', function(){
        if (_docEditorAtual) _docEditorAtual.dirty = true;
        // debounce próprio para o título
        clearTimeout(_tituloTimer);
        _tituloTimer = setTimeout(function(){
          var novo = (titulo.value||'').trim() || 'Sem título';
          sb.from('malba_docs').update({ title: novo }).eq('id', ST.docOpen).then(function(){
            var idx = (ST.docs||[]).findIndex(function(x){ return String(x.id)===String(ST.docOpen); });
            if (idx>=0) ST.docs[idx].title = novo;
          });
        }, 800);
      });
    }
    var menu = document.getElementById('docMenu');
    if (menu) menu.addEventListener('click', function(e){ docsAbrirMenuAcoes(e.target, ST.docOpen); });
    docsGarantirEditorMontado(); // remonta o editor depois de qualquer re-render da página
    return;
  }

  // lista principal
  var novo = document.getElementById('btnNovoDoc');
  if (novo) novo.addEventListener('click', function(){ docsCriar('branco', docTab().indexOf('folder:')===0 ? docTab().slice(7) : null); });

  var pasta = document.getElementById('btnNovaPasta');
  if (pasta) pasta.addEventListener('click', function(e){ e.stopPropagation(); docsNovaPasta(null); });

  if (docTab()==='dashboard') bindDocsDashboard(); // v100
  // abas fixas
  document.querySelectorAll('[data-doc-tab]').forEach(function(b){
    b.addEventListener('click', function(){ ST.docTab = this.getAttribute('data-doc-tab'); renderPage(); });
  });
  // pastas
  document.querySelectorAll('[data-folder-id]').forEach(function(b){
    b.addEventListener('click', function(e){
      if (e.target.closest('[data-folder-toggle]')) return;
      ST.docTab = 'folder:'+this.getAttribute('data-folder-id'); renderPage();
    });
  });
  document.querySelectorAll('[data-folder-toggle]').forEach(function(t){
    t.addEventListener('click', function(e){
      e.stopPropagation();
      var id = this.getAttribute('data-folder-toggle');
      ST.docFolderOpen = ST.docFolderOpen || {};
      ST.docFolderOpen[id] = !ST.docFolderOpen[id];
      renderPage();
    });
  });

  // templates
  document.querySelectorAll('[data-tpl]').forEach(function(b){
    b.addEventListener('click', function(){
      var folder = docTab().indexOf('folder:')===0 ? docTab().slice(7) : null;
      docsCriar(this.getAttribute('data-tpl'), folder);
    });
  });

  // busca
  var q = document.getElementById('docQ');
  if (q){ var t=null; q.addEventListener('input', function(){
    var v=this.value; clearTimeout(t);
    t=setTimeout(function(){
      ST.docQ=v;
      if (!v){ ST.docHits=null; ST.docBuscando=false; }
      renderPage();
      // v98: busca no conteúdo em paralelo (a partir de 3 letras)
      clearTimeout(_buscaConteudoTimer);
      _buscaConteudoTimer = setTimeout(function(){ docsBuscarNoConteudo(v); }, 180);
    }, 220);
  }); }

  // toggle de visão
  document.querySelectorAll('[data-doc-view]').forEach(function(b){
    b.addEventListener('click', function(){ ST.docView = this.getAttribute('data-doc-view'); renderPage(); });
  });

  // favoritar (na linha)
  document.querySelectorAll('[data-doc-fav]').forEach(function(b){
    b.addEventListener('click', function(e){ e.stopPropagation(); docsFavToggle(this.getAttribute('data-doc-fav')); });
  });

  // clique numa linha/card → abre editor
  document.querySelectorAll('[data-doc-id]').forEach(function(el){
    el.addEventListener('click', function(e){
      if (e.target.closest('[data-doc-fav]')) return;
      var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(el.getAttribute('data-doc-id')); });
      if (d) openDocEditor(d);
    });
  });
}

var _tituloTimer = null;

/* ---------- Menu de ações rápidas ---------- */
function docsAbrirMenuAcoes(anchor, id){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
  if (!d) return;
  // v97: cada ação exige um nível diferente
  var podeEd = docPodeEditar(d);
  var podeAd = docPodeAdmin(d);
  var pastas = '<option value="">— sem pasta —</option>' + (ST.docFolders||[]).map(function(f){
    return '<option value="'+esc(f.id)+'"'+(String(d.folder_id||'')===String(f.id)?' selected':'')+'>'+esc(f.name)+'</option>';
  }).join('');
  var moverRow = podeEd
    ? '<div class="modal-row"><label class="modal-label">Mover para pasta</label><select id="acMover">'+pastas+'</select></div>'
    : '<p class="modal-note">Você tem acesso de leitura neste documento. Peça ao autor para liberar edição.</p>';
  var botoes = '<button class="doc-acao" data-acao="duplicar">📄 Duplicar</button>'+
               '<button class="doc-acao" data-acao="historico">🕓 Histórico</button>';
  if (podeEd) botoes += '<button class="doc-acao" data-acao="vinculos">🔗 Vínculos</button>'; // v100
  if (d.doc_type==='ata') botoes += '<button class="doc-acao" data-acao="pendencias">✅ Pendências → tarefas</button>'; // v99
  if (podeAd){
    botoes += '<button class="doc-acao" data-acao="compartilhar">🔗 Compartilhar</button>'+
              '<button class="doc-acao" data-acao="arquivar">'+(d.is_archived?'♻️ Restaurar':'🗂 Arquivar')+'</button>'+
              '<button class="doc-acao danger" data-acao="excluir">🗑 Excluir</button>';
  }
  makeModal({
    title:'Ações do documento', width:420,
    body: moverRow + '<div class="doc-acoes-grid">'+botoes+'</div>',
    saveLabel: podeEd ? 'Aplicar mudanças' : 'Fechar',
    onSave: function(close, root){
      var sel = root.querySelector('#acMover');
      if (sel){
        var nova = sel.value || null;
        if (String(nova||'') !== String(d.folder_id||'')) docsMover(id, nova);
      }
      close();
    }
  });
  // liga os botões — precisa esperar o modal existir
  setTimeout(function(){
    document.querySelectorAll('[data-acao]').forEach(function(b){
      b.addEventListener('click', function(){
        var acao = this.getAttribute('data-acao');
        document.querySelectorAll('.modal-bg').forEach(function(m){ m.remove(); });
        if (acao==='duplicar') docsDuplicar(id);
        else if (acao==='compartilhar') docsCompartilhar(id); // v97
        else if (acao==='historico') docsAbrirHistorico(id);   // v98
        else if (acao==='pendencias') docsPendenciasEmTarefas(id); // v99
        else if (acao==='vinculos') docsVincular(id);              // v100
        else if (acao==='arquivar') docsArquivar(id, !d.is_archived);
        else if (acao==='excluir'){ docsExcluir(id); if (ST.docOpen===id) docsFecharEditor(); }
      });
    });
  }, 50);
}

/* ============================================================
   v97: MÓDULO DOCUMENTOS — Fase 2 (Compartilhamento granular)
   Alvos: privado · unidade/loja · setor inteiro · pessoas específicas
   Níveis: visualizar < comentar < editar < admin
   shares = JSONB [{ type:'user'|'unidade', id, perm }]
   ============================================================ */

var DOC_PERMS = {
  visualizar: { label:'Visualizar', rank:1, ic:'👁' },
  comentar:   { label:'Comentar',   rank:2, ic:'💬' },
  editar:     { label:'Editar',     rank:3, ic:'✏️' },
  admin:      { label:'Admin',      rank:4, ic:'🔑' }
};
var DOC_PERM_ORDER = ['visualizar','comentar','editar','admin'];

var DOC_VIS = {
  privado: { label:'Privado',             ic:'🔒', desc:'Só você e quem convidar' },
  unidade: { label:'Minha unidade',       ic:'🏪', desc:'Quem trabalha na mesma loja' },
  setor:   { label:'Setor inteiro',       ic:'👥', desc:'Todo mundo do setor' },
  pessoas: { label:'Pessoas específicas', ic:'🙋', desc:'Só quem estiver na lista' }
};
var DOC_VIS_ORDER = ['privado','unidade','setor','pessoas'];

function docPermRank(p){ return (DOC_PERMS[p] && DOC_PERMS[p].rank) || 0; }

/* ---------- Permissão efetiva de alguém sobre um documento ---------- */
function docPermDe(d, userId){
  if (!d) return null;
  var u = userId
    ? (ST.allUsers||ST.users||[]).find(function(x){ return String(x.id)===String(userId); })
    : (ST.session && ST.session.user);
  if (!u) return null;
  var uid = String(u.id);
  var nv = nivelDe(u);

  // 1) autor manda no próprio documento
  if (String(d.author_id||'')===uid) return nv==='viewer' ? 'admin' : 'admin';

  // 2) Admin do sistema e Gestor administram tudo do setor
  if (nv==='admin' || nv==='gestor') return 'admin';

  var melhor = null;
  function sobe(p){ if (p && docPermRank(p) > docPermRank(melhor)) melhor = p; }

  // 3) convite explícito (pessoa ou unidade)
  var shares = Array.isArray(d.shares) ? d.shares : [];
  for (var i=0;i<shares.length;i++){
    var s = shares[i];
    if (s.type==='user' && String(s.id)===uid) sobe(s.perm);
    if (s.type==='unidade' && u.store_unit_id && String(s.id)===String(u.store_unit_id)) sobe(s.perm);
    // v113: compartilhamento com equipe — a pessoa está na equipe compartilhada?
    if (s.type==='equipe'){
      var eq = (ST.equipes||[]).find(function(x){ return String(x.id)===String(s.id); });
      if (eq && (eq.membros||[]).map(String).indexOf(uid)!==-1) sobe(s.perm);
    }
  }

  // 4) visibilidade ampla
  var vis = d.visibility || 'setor';
  var padrao = d.default_perm || 'editar';
  if (vis==='setor' && String(u.sector||'')===String(d.sector||'')) sobe(padrao);
  if (vis==='unidade' && u.store_unit_id && String(u.store_unit_id)===String(d.unit_id||'')) sobe(padrao);

  // 5) Visualizador nunca passa de leitura, não importa o que foi compartilhado
  if (nv==='viewer' && docPermRank(melhor) > 1) melhor = 'visualizar';

  return melhor;
}

function docPodeVer(d){      return docPermRank(docPermDe(d)) >= 1; }
function docPodeComentar(d){ return docPermRank(docPermDe(d)) >= 2; }
function docPodeEditar(d){   return docPermRank(docPermDe(d)) >= 3; }
function docPodeAdmin(d){    return docPermRank(docPermDe(d)) >= 4; }

/* ---------- Rótulo do compartilhamento (coluna da lista) ---------- */
function docShareLabel(d){
  var vis = d.visibility || 'setor';
  var n = (Array.isArray(d.shares) ? d.shares : []).length;
  var extra = n ? ' +'+n : '';
  if (vis==='privado') return '🔒 Privado'+extra;
  if (vis==='pessoas') return '🙋 '+n+' pessoa'+(n===1?'':'s');
  if (vis==='unidade') return '🏪 Unidade'+extra;
  return '👥 Setor'+extra;
}

/* ---------- Modal de compartilhamento ---------- */
function docsCompartilhar(id){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
  if (!d){ toast('Documento não encontrado','error'); return; }
  if (!docPodeAdmin(d)){ toast('Só quem tem acesso de Admin pode compartilhar este documento.','error'); return; }

  // cópia de trabalho — só grava ao salvar
  var vis = d.visibility || 'setor';
  var padrao = d.default_perm || 'editar';
  var shares = (Array.isArray(d.shares) ? d.shares : []).map(function(s){ return { type:s.type, id:String(s.id), perm:s.perm }; });
  var unitId = d.unit_id || (ST.store ? ST.store.id : null);

  var pessoas = (ST.allUsers||ST.users||[]).filter(function(u){
    return String(u.sector||'')===String(ST.sector) && String(u.id)!==String(d.author_id||'');
  });
  var unidades = (ST.storeUnits||[]).slice();

  function permSelect(valor, attr){
    return '<select class="doc-share-perm" '+attr+'>'+DOC_PERM_ORDER.map(function(p){
      return '<option value="'+p+'"'+(valor===p?' selected':'')+'>'+DOC_PERMS[p].ic+' '+DOC_PERMS[p].label+'</option>';
    }).join('')+'</select>';
  }

  function visHTML(){
    return '<div class="doc-vis-grid">'+DOC_VIS_ORDER.map(function(k){
      var v = DOC_VIS[k];
      return '<button type="button" class="doc-vis-opt'+(vis===k?' on':'')+'" data-vis="'+k+'">'+
        '<span class="doc-vis-ic">'+v.ic+'</span>'+
        '<span class="doc-vis-lb">'+esc(v.label)+'</span>'+
        '<span class="doc-vis-desc">'+esc(v.desc)+'</span>'+
      '</button>';
    }).join('')+'</div>';
  }

  function padraoHTML(){
    if (vis==='privado' || vis==='pessoas') return '';
    var quem = vis==='unidade' ? 'da unidade' : 'do setor';
    return '<div class="doc-share-padrao"><span>Todo mundo '+quem+' pode:</span>'+permSelect(padrao,'id="dsPadrao"')+'</div>';
  }

  function nomeDoAlvo(s){
    if (s.type==='unidade'){
      var un = unidades.find(function(x){ return String(x.id)===String(s.id); });
      return { ic:'🏪', nome: un ? un.name : 'Unidade removida' };
    }
    // v113: compartilhamento com equipe
    if (s.type==='equipe'){
      var eq = (ST.equipes||[]).find(function(x){ return String(x.id)===String(s.id); });
      return { ic:'👥', nome: eq ? (eq.name+' ('+((eq.membros||[]).length)+' pessoas)') : 'Equipe removida' };
    }
    var pe = (ST.allUsers||ST.users||[]).find(function(x){ return String(x.id)===String(s.id); });
    return { ic:'👤', nome: pe ? pe.name : 'Usuário removido' };
  }

  function listaHTML(){
    if (!shares.length) return '<div class="doc-share-vazio">Ninguém convidado individualmente ainda.</div>';
    return '<div class="doc-share-lista">'+shares.map(function(s, idx){
      var a = nomeDoAlvo(s);
      return '<div class="doc-share-row">'+
        '<span class="doc-share-nome">'+a.ic+' '+esc(a.nome)+'</span>'+
        permSelect(s.perm, 'data-share-perm="'+idx+'"')+
        '<button type="button" class="doc-share-del" data-share-del="'+idx+'" title="Remover">×</button>'+
      '</div>';
    }).join('')+'</div>';
  }

  function addHTML(){
    var jaTem = shares.map(function(s){ return s.type+':'+s.id; });
    var optsP = pessoas.filter(function(u){ return jaTem.indexOf('user:'+u.id)===-1; })
      .map(function(u){ return '<option value="user:'+esc(u.id)+'">👤 '+esc(u.name)+'</option>'; }).join('');
    var optsU = unidades.filter(function(x){ return jaTem.indexOf('unidade:'+x.id)===-1; })
      .map(function(x){ return '<option value="unidade:'+esc(x.id)+'">🏪 '+esc(x.name)+'</option>'; }).join('');
    // v113: equipes visíveis no compartilhamento
    var equipesAptas = (typeof equipesVisiveis==='function' ? equipesVisiveis() : (ST.equipes||[])).filter(function(e){ return e.is_active!==false; });
    var optsE = equipesAptas.filter(function(e){ return jaTem.indexOf('equipe:'+e.id)===-1; })
      .map(function(e){
        var n = (e.membros||[]).length;
        return '<option value="equipe:'+esc(e.id)+'">👥 '+esc(e.name)+' ('+n+')</option>';
      }).join('');
    if (!optsP && !optsU && !optsE) return '<div class="doc-share-vazio">Todo mundo do setor já está na lista.</div>';
    return '<div class="doc-share-add">'+
      '<select id="dsAlvo"><option value="">— escolher pessoa, unidade ou equipe —</option>'+
        (optsE ? '<optgroup label="Equipes">'+optsE+'</optgroup>' : '')+
        (optsP ? '<optgroup label="Pessoas">'+optsP+'</optgroup>' : '')+
        (optsU ? '<optgroup label="Unidades">'+optsU+'</optgroup>' : '')+
      '</select>'+
      permSelect('editar','id="dsPerm"')+
      '<button type="button" class="btn btn-primary" id="dsAdd">Convidar</button>'+
    '</div>';
  }

  var corpo =
    '<div class="doc-share-doc">'+docTipoIcon(d.doc_type)+' <b>'+esc(d.title||'Sem título')+'</b></div>'+
    '<label class="modal-label">Quem tem acesso</label>'+
    '<div id="dsVisWrap">'+visHTML()+'</div>'+
    '<div id="dsPadraoWrap">'+padraoHTML()+'</div>'+
    '<label class="modal-label" style="margin-top:14px">Convidados individualmente</label>'+
    '<div id="dsListaWrap">'+listaHTML()+'</div>'+
    '<div id="dsAddWrap">'+addHTML()+'</div>';

  var m = makeModal({
    title: 'Compartilhar documento',
    width: 560,
    body: corpo,
    saveLabel: 'Salvar acesso',
    onSave: function(close){
      var payload = { visibility: vis, default_perm: padrao, shares: shares };
      if (vis==='unidade') payload.unit_id = unitId;
      sb.from('malba_docs').update(payload).eq('id', d.id).then(function(r){
        if (r.error){ toast('Não consegui salvar: '+(r.error.message||''),'error'); return; }
        d.visibility = vis; d.default_perm = padrao; d.shares = shares;
        if (vis==='unidade') d.unit_id = unitId;
        close(); toast('Acesso atualizado','success'); renderPage();
      });
    }
  });

  function redesenha(){
    var w1 = m.root.querySelector('#dsPadraoWrap'); if (w1) w1.innerHTML = padraoHTML();
    var w2 = m.root.querySelector('#dsListaWrap');  if (w2) w2.innerHTML = listaHTML();
    var w3 = m.root.querySelector('#dsAddWrap');    if (w3) w3.innerHTML = addHTML();
    ligar();
  }

  function ligar(){
    m.root.querySelectorAll('[data-vis]').forEach(function(b){
      b.addEventListener('click', function(){
        vis = this.getAttribute('data-vis');
        m.root.querySelectorAll('[data-vis]').forEach(function(x){ x.classList.toggle('on', x.getAttribute('data-vis')===vis); });
        redesenha();
      });
    });
    var sp = m.root.querySelector('#dsPadrao');
    if (sp) sp.addEventListener('change', function(){ padrao = this.value; });
    m.root.querySelectorAll('[data-share-perm]').forEach(function(sel){
      sel.addEventListener('change', function(){ shares[Number(this.getAttribute('data-share-perm'))].perm = this.value; });
    });
    m.root.querySelectorAll('[data-share-del]').forEach(function(b){
      b.addEventListener('click', function(){ shares.splice(Number(this.getAttribute('data-share-del')),1); redesenha(); });
    });
    var add = m.root.querySelector('#dsAdd');
    if (add) add.addEventListener('click', function(){
      var sel = m.root.querySelector('#dsAlvo');
      var alvo = sel ? sel.value : '';
      if (!alvo){ toast('Escolha quem vai receber o acesso','error'); return; }
      var permEl = m.root.querySelector('#dsPerm');
      var partes = alvo.split(':');
      shares.push({ type: partes[0]==='unidade' ? 'unidade' : 'user', id: partes.slice(1).join(':'), perm: permEl ? permEl.value : 'editar' });
      redesenha();
    });
  }
  ligar();
}

/* ============================================================
   v98: MÓDULO DOCUMENTOS — Fase 3
   (A) Versionamento com histórico e restauração
   (B) Pesquisa no conteúdo (full-text em português)

   Estratégia de versão: UMA por sessão de edição — guarda o
   estado ANTES das alterações. Mais o botão manual "Marcar
   versão". Evita 200 versões inúteis por causa do autosave.
   ============================================================ */

/* ---------- (B) Extrai texto puro dos blocos do EditorJS ---------- */
function docBodyParaTexto(body){
  if (!body) return '';
  var b = body;
  if (typeof b === 'string'){ try { b = JSON.parse(b); } catch(e){ return ''; } }
  var blocks = b && Array.isArray(b.blocks) ? b.blocks : [];
  var partes = [];
  function limpaTags(t){ return String(t||'').replace(/<[^>]*>/g,' ').replace(/&nbsp;/g,' '); }
  blocks.forEach(function(bl){
    var d = bl && bl.data ? bl.data : {};
    if (d.text) partes.push(limpaTags(d.text));
    if (d.caption) partes.push(limpaTags(d.caption));
    if (d.title) partes.push(limpaTags(d.title));
    if (d.message) partes.push(limpaTags(d.message));
    if (d.code) partes.push(String(d.code));
    if (Array.isArray(d.items)){
      d.items.forEach(function(it){
        if (typeof it === 'string') partes.push(limpaTags(it));
        else if (it && it.text) partes.push(limpaTags(it.text));
        else if (it && it.content) partes.push(limpaTags(it.content));
      });
    }
    if (Array.isArray(d.content)){ // tabela: matriz de linhas
      d.content.forEach(function(linha){
        if (Array.isArray(linha)) linha.forEach(function(cel){ partes.push(limpaTags(cel)); });
      });
    }
  });
  return partes.join(' ').replace(/\s+/g,' ').trim().slice(0, 100000);
}

/* ---------- (A) Grava uma versão ---------- */
function docsGravarVersao(docId, body, titulo, nota){
  if (!sb) return Promise.resolve(null);
  var eu = ST.session && ST.session.user ? ST.session.user : null;
  var payload = {
    doc_id: docId,
    sector: ST.sector,
    title: titulo || null,
    body: body || null,
    note: nota || null,
    author_id: eu ? eu.id : null,
    author_name: eu ? eu.name : null
  };
  return sb.from('malba_doc_versions').insert(payload).select().single().then(function(r){
    if (r.error){ console.warn('versão:', r.error.message); return null; }
    if (r.data){
      if (!ST.docVersions) ST.docVersions = {};
      if (!ST.docVersions[docId]) ST.docVersions[docId] = [];
      ST.docVersions[docId].unshift(r.data);
    }
    return r.data;
  });
}

/* ---------- (A) Carrega o histórico de um documento ---------- */
function docsCarregarVersoes(docId){
  if (!sb) return Promise.resolve([]);
  return sb.from('malba_doc_versions')
    .select('id, doc_id, title, note, author_id, author_name, created_at')
    .eq('doc_id', docId).order('created_at', { ascending:false }).limit(50)
    .then(function(r){
      if (r.error){ console.warn('histórico:', r.error.message); return []; }
      if (!ST.docVersions) ST.docVersions = {};
      ST.docVersions[docId] = r.data || [];
      return ST.docVersions[docId];
    });
}

/* ---------- (A) Painel de histórico ---------- */
function docsAbrirHistorico(docId){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  if (!d){ toast('Documento não encontrado','error'); return; }
  if (!docPodeVer(d)){ toast('Você não tem acesso a este documento.','error'); return; }
  var podeRestaurar = docPodeEditar(d);

  var m = makeModal({
    title: 'Histórico de versões',
    width: 560,
    body: '<div class="doc-hist-doc">'+docTipoIcon(d.doc_type)+' <b>'+esc(d.title||'Sem título')+'</b></div>'+
          (podeRestaurar ? '<button type="button" class="btn btn-secondary doc-hist-marcar" id="dhMarcar">📌 Marcar versão agora</button>' : '')+
          '<div id="dhLista"><div class="doc-hist-load">Carregando histórico…</div></div>',
    hideFoot: true
  });

  function desenhar(versoes){
    var wrap = m.root.querySelector('#dhLista');
    if (!wrap) return;
    if (!versoes.length){
      wrap.innerHTML = '<div class="doc-hist-vazio">Nenhuma versão guardada ainda.<br><span>Uma versão é criada automaticamente sempre que alguém começa a editar o documento — guardando como ele estava antes.</span></div>';
      return;
    }
    wrap.innerHTML = '<div class="doc-hist-lista">'+versoes.map(function(v){
      var quando = v.created_at ? tempoRelativo(v.created_at) : '';
      var dataCompleta = v.created_at ? (fmtDate(String(v.created_at).slice(0,10))+' '+String(v.created_at).slice(11,16)) : '';
      var nota = v.note ? '<span class="doc-hist-nota">'+esc(v.note)+'</span>' : '';
      var btn = podeRestaurar ? '<button type="button" class="doc-hist-restaurar" data-restaurar="'+esc(v.id)+'">Restaurar</button>' : '';
      return '<div class="doc-hist-item">'+
        '<div class="doc-hist-info">'+
          '<div class="doc-hist-tit">'+esc(v.title || '(sem título)')+' '+nota+'</div>'+
          '<div class="doc-hist-meta">'+esc(v.author_name||'alguém')+' · '+esc(quando)+' <span>'+esc(dataCompleta)+'</span></div>'+
        '</div>'+btn+
      '</div>';
    }).join('')+'</div>';
    wrap.querySelectorAll('[data-restaurar]').forEach(function(b){
      b.addEventListener('click', function(){ docsRestaurarVersao(docId, this.getAttribute('data-restaurar'), m); });
    });
  }

  docsCarregarVersoes(docId).then(desenhar);

  var marcar = m.root.querySelector('#dhMarcar');
  if (marcar) marcar.addEventListener('click', function(){
    var b = marcar; setBusy(b, true);
    function terminou(){ setBusy(b, false); docsCarregarVersoes(docId).then(desenhar); }
    // se o editor está aberto, pega o estado atual dele; senão busca do banco
    if (_docEditorAtual && _docEditorAtual.id===docId && _docEditorAtual.editor){
      _docEditorAtual.editor.save().then(function(data){
        docsGravarVersao(docId, data, d.title, 'marcada manualmente').then(terminou);
      }).catch(terminou);
    } else {
      sb.from('malba_docs').select('body').eq('id', docId).single().then(function(r){
        docsGravarVersao(docId, r.data ? r.data.body : null, d.title, 'marcada manualmente').then(terminou);
      }, terminou);
    }
  });
}

/* ---------- (A) Restaurar uma versão ---------- */
function docsRestaurarVersao(docId, versaoId, modalHist){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  if (!d || !docPodeEditar(d)){ toast('Você não tem acesso de edição neste documento.','error'); return; }
  confirmDialog({
    title:'Restaurar esta versão?',
    message:'O conteúdo atual vai ser guardado como uma nova versão antes — então dá pra voltar atrás se você se arrepender.',
    confirmLabel:'Sim, restaurar',
    onConfirm: function(){
      // 1) busca o corpo da versão escolhida
      sb.from('malba_doc_versions').select('body, title, created_at').eq('id', versaoId).single().then(function(rv){
        if (rv.error || !rv.data){ toast('Não consegui ler a versão','error'); return; }
        var corpoAntigo = rv.data.body;
        // 2) guarda o estado atual antes de sobrescrever
        function aplicar(corpoAtual){
          docsGravarVersao(docId, corpoAtual, d.title, 'antes de restaurar').then(function(){
            var texto = docBodyParaTexto(corpoAntigo);
            sb.from('malba_docs').update({ body: corpoAntigo, plain_text: texto }).eq('id', docId).then(function(r){
              if (r.error){ toast('Não consegui restaurar: '+(r.error.message||''),'error'); return; }
              d.body = corpoAntigo;
              toast('Versão restaurada','success');
              if (modalHist && modalHist.close) modalHist.close();
              // reabre o editor com o conteúdo restaurado
              if (ST.docOpen===docId){ _docEditorAtual = null; openDocEditor(d); }
              else renderPage();
            });
          });
        }
        if (_docEditorAtual && _docEditorAtual.id===docId && _docEditorAtual.editor){
          _docEditorAtual.editor.save().then(aplicar).catch(function(){ aplicar(d.body); });
        } else {
          sb.from('malba_docs').select('body').eq('id', docId).single().then(function(rb){
            aplicar(rb.data ? rb.data.body : d.body);
          }, function(){ aplicar(d.body); });
        }
      });
    }
  });
}

/* ---------- (B) Pesquisa no conteúdo (servidor) ---------- */
var _buscaConteudoTimer = null;
function docsBuscarNoConteudo(termo){
  if (!sb || !termo || termo.length < 3){ ST.docHits = null; renderPage(); return; }
  ST.docBuscando = true; renderPage();
  sb.from('malba_docs')
    .select('id, plain_text')
    .eq('sector', ST.sector)
    .ilike('plain_text', '%'+termo+'%')
    .limit(100)
    .then(function(r){
      ST.docBuscando = false;
      if (r.error){ console.warn('busca conteúdo:', r.error.message); ST.docHits = null; renderPage(); return; }
      var hits = {};
      (r.data||[]).forEach(function(row){
        hits[row.id] = docTrechoDoTermo(row.plain_text, termo);
      });
      ST.docHits = hits;
      renderPage();
    }, function(){ ST.docBuscando = false; ST.docHits = null; renderPage(); });
}

/* ---------- (B) Recorta um trecho ao redor do termo encontrado ---------- */
function docTrechoDoTermo(texto, termo){
  if (!texto) return '';
  var t = String(texto);
  var i = t.toLowerCase().indexOf(String(termo).toLowerCase());
  if (i < 0) return t.slice(0, 120);
  var ini = Math.max(0, i - 45);
  var fim = Math.min(t.length, i + termo.length + 75);
  return (ini>0?'…':'') + t.slice(ini, fim) + (fim<t.length?'…':'');
}

/* ---------- (B) Destaca o termo dentro do trecho (já escapado) ---------- */
function docDestacar(trecho, termo){
  if (!trecho) return '';
  var safe = esc(trecho);
  if (!termo) return safe;
  var alvo = esc(termo);
  var re = new RegExp('(' + alvo.replace(/[.*+?^${}()|[\]\\]/g,'\\$&') + ')', 'ig');
  return safe.replace(re, '<mark>$1</mark>');
}

/* ============================================================
   v99: MÓDULO DOCUMENTOS — Fase 4
   (A) Comentários com respostas, menções e resolução
       Ancorados por BLOCO (não por trecho de texto) — bloco tem
       id próprio e sobrevive às edições ao redor.
   (B) Ata: "Transformar pendências em tarefas"
   ============================================================ */

/* ---------- (A) Carregar comentários de um documento ---------- */
function docsCarregarComentarios(docId){
  if (!sb) return Promise.resolve([]);
  return sb.from('malba_doc_comments').select('*').eq('doc_id', docId).order('created_at', { ascending:true })
    .then(function(r){
      if (r.error){ console.warn('comentários:', r.error.message); return []; }
      if (!ST.docComments) ST.docComments = {};
      ST.docComments[docId] = r.data || [];
      return ST.docComments[docId];
    });
}

function docComentariosDe(docId){ return (ST.docComments && ST.docComments[docId]) || []; }

/* ---------- (A) Contagem de comentários abertos (aparece na lista) ---------- */
function docComentariosAbertos(docId){
  return docComentariosDe(docId).filter(function(c){ return !c.resolved && !c.parent_id; }).length;
}

/* ---------- (A) Gravar comentário ou resposta ---------- */
function docsComentar(docId, texto, blockId, blockPreview, parentId){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  if (!d || !docPodeComentar(d)){ toast('Você precisa de acesso de comentário neste documento.','error'); return Promise.resolve(null); }
  var eu = ST.session && ST.session.user ? ST.session.user : null;
  var payload = {
    doc_id: docId,
    sector: ST.sector,
    block_id: blockId || null,
    block_preview: blockPreview || null,
    parent_id: parentId || null,
    text: texto,
    mentions: docExtrairMencoes(texto),
    author_id: eu ? eu.id : null,
    author_name: eu ? eu.name : null,
    resolved: false
  };
  return sb.from('malba_doc_comments').insert(payload).select().single().then(function(r){
    if (r.error){ toast('Não consegui comentar: '+(r.error.message||''),'error'); return null; }
    if (r.data){
      if (!ST.docComments) ST.docComments = {};
      if (!ST.docComments[docId]) ST.docComments[docId] = [];
      ST.docComments[docId].push(r.data);
    }
    return r.data;
  });
}

/* ---------- (A) Extrai @mencoes e devolve os ids das pessoas ---------- */
function docExtrairMencoes(texto){
  if (!texto) return [];
  var achados = [];
  var pessoas = (ST.allUsers||ST.users||[]).filter(function(u){ return String(u.sector||'')===String(ST.sector); });
  pessoas.forEach(function(u){
    var primeiro = String(u.name||'').split(' ')[0];
    if (!primeiro) return;
    var re = new RegExp('@'+primeiro.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'i');
    if (re.test(texto) && achados.indexOf(u.id)===-1) achados.push(u.id);
  });
  return achados;
}

/* ---------- (A) Marca as menções no texto exibido ---------- */
function docRenderMencoes(texto){
  var safe = esc(texto||'');
  var pessoas = (ST.allUsers||ST.users||[]).filter(function(u){ return String(u.sector||'')===String(ST.sector); });
  pessoas.forEach(function(u){
    var primeiro = String(u.name||'').split(' ')[0];
    if (!primeiro) return;
    var re = new RegExp('(@'+esc(primeiro).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')', 'ig');
    safe = safe.replace(re, '<span class="doc-mencao">$1</span>');
  });
  return safe;
}

/* ---------- (A) Resolver / reabrir ---------- */
function docsResolverComentario(docId, comentarioId, resolver){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  if (!d || !docPodeComentar(d)){ toast('Sem acesso para resolver.','error'); return; }
  var eu = ST.session && ST.session.user ? ST.session.user : null;
  var novo = resolver !== false;
  var patch = novo
    ? { resolved:true, resolved_by: eu?eu.id:null, resolved_at: new Date().toISOString() }
    : { resolved:false, resolved_by:null, resolved_at:null };
  sb.from('malba_doc_comments').update(patch).eq('id', comentarioId).then(function(r){
    if (r.error){ toast('Não consegui salvar','error'); return; }
    var c = docComentariosDe(docId).find(function(x){ return String(x.id)===String(comentarioId); });
    if (c) Object.assign(c, patch);
    toast(novo ? 'Comentário resolvido' : 'Comentário reaberto','success');
    docsPainelComentariosRender(docId);
    renderPage();
  });
}

/* ---------- (A) Excluir comentário (autor ou admin do doc) ---------- */
function docsExcluirComentario(docId, comentarioId){
  var c = docComentariosDe(docId).find(function(x){ return String(x.id)===String(comentarioId); });
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';
  if (!c || !d) return;
  if (String(c.author_id||'')!==eu && !docPodeAdmin(d)){ toast('Só quem escreveu (ou um admin do documento) pode apagar.','error'); return; }
  sb.from('malba_doc_comments').delete().eq('id', comentarioId).then(function(r){
    if (r.error){ toast('Não consegui apagar','error'); return; }
    // apaga também as respostas dele
    ST.docComments[docId] = docComentariosDe(docId).filter(function(x){
      return String(x.id)!==String(comentarioId) && String(x.parent_id||'')!==String(comentarioId);
    });
    docsPainelComentariosRender(docId);
    renderPage();
  });
}

/* ---------- (A) Painel lateral de comentários ---------- */
function docsPainelComentariosHTML(docId){
  var aberto = !!ST.docPainelComentarios;
  if (!aberto) return '';
  return '<aside class="doc-coment-painel" id="docComentPainel">'+
    '<div class="doc-coment-head">'+
      '<b>Comentários</b>'+
      '<label class="doc-coment-toggle"><input type="checkbox" id="dcMostrarResolvidos"'+(ST.docMostrarResolvidos?' checked':'')+'> mostrar resolvidos</label>'+
      '<button class="doc-coment-fechar" id="dcFechar" title="Fechar">×</button>'+
    '</div>'+
    '<div id="dcCorpo" class="doc-coment-corpo"><div class="doc-coment-load">Carregando…</div></div>'+
  '</aside>';
}

function docsPainelComentariosRender(docId){
  var corpo = document.getElementById('dcCorpo');
  if (!corpo) return;
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  var podeComentar = d && docPodeComentar(d);
  var todos = docComentariosDe(docId);
  var raizes = todos.filter(function(c){ return !c.parent_id; });
  if (!ST.docMostrarResolvidos) raizes = raizes.filter(function(c){ return !c.resolved; });
  raizes.sort(function(a,b){ return (b.created_at||'').localeCompare(a.created_at||''); });

  var novo = podeComentar
    ? '<div class="doc-coment-novo">'+
        '<textarea id="dcNovoTxt" rows="2" placeholder="Comentar no documento… use @ para mencionar"></textarea>'+
        '<button class="btn btn-primary" id="dcNovoSend">Comentar</button>'+
      '</div>'
    : '<div class="doc-coment-vazio">Você tem acesso de leitura — não dá pra comentar aqui.</div>';

  var lista;
  if (!raizes.length){
    lista = '<div class="doc-coment-vazio">'+(ST.docMostrarResolvidos?'Nenhum comentário ainda.':'Nenhum comentário em aberto.')+'</div>';
  } else {
    lista = raizes.map(function(c){
      var respostas = todos.filter(function(x){ return String(x.parent_id||'')===String(c.id); })
                           .sort(function(a,b){ return (a.created_at||'').localeCompare(b.created_at||''); });
      return docComentarioItemHTML(c, respostas, podeComentar, d);
    }).join('');
  }
  corpo.innerHTML = novo + '<div class="doc-coment-lista">'+lista+'</div>';
  docsPainelComentariosBind(docId);
}

function docComentarioItemHTML(c, respostas, podeComentar, d){
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';
  var podeApagar = String(c.author_id||'')===eu || (d && docPodeAdmin(d));
  var ancora = c.block_preview
    ? '<div class="doc-coment-ancora" title="Trecho comentado">“'+esc(String(c.block_preview).slice(0,80))+(String(c.block_preview).length>80?'…':'')+'”</div>'
    : '';
  var acoes = '';
  if (podeComentar) acoes += '<button class="doc-coment-acao" data-resolver="'+esc(c.id)+'" data-estado="'+(c.resolved?'1':'0')+'">'+(c.resolved?'↩︎ reabrir':'✓ resolver')+'</button>';
  if (podeComentar) acoes += '<button class="doc-coment-acao" data-responder="'+esc(c.id)+'">↳ responder</button>';
  if (podeApagar)   acoes += '<button class="doc-coment-acao del" data-apagar="'+esc(c.id)+'">apagar</button>';

  var resps = respostas.map(function(r){
    var podeApagarR = String(r.author_id||'')===eu || (d && docPodeAdmin(d));
    return '<div class="doc-coment-resp">'+
      '<div class="doc-coment-meta"><b>'+esc(r.author_name||'alguém')+'</b><span>'+esc(tempoRelativo(r.created_at))+'</span>'+
        (podeApagarR?'<button class="doc-coment-acao del mini" data-apagar="'+esc(r.id)+'">×</button>':'')+
      '</div>'+
      '<div class="doc-coment-txt">'+docRenderMencoes(r.text)+'</div>'+
    '</div>';
  }).join('');

  return '<div class="doc-coment-item'+(c.resolved?' resolvido':'')+'" data-coment-id="'+esc(c.id)+'">'+
    ancora+
    '<div class="doc-coment-meta"><b>'+esc(c.author_name||'alguém')+'</b><span>'+esc(tempoRelativo(c.created_at))+'</span>'+
      (c.resolved?'<span class="doc-coment-selo">resolvido</span>':'')+
    '</div>'+
    '<div class="doc-coment-txt">'+docRenderMencoes(c.text)+'</div>'+
    (resps ? '<div class="doc-coment-resps">'+resps+'</div>' : '')+
    '<div class="doc-coment-acoes">'+acoes+'</div>'+
    '<div class="doc-coment-respbox" id="rb-'+esc(c.id)+'" style="display:none">'+
      '<textarea rows="2" placeholder="Responder…"></textarea>'+
      '<button class="btn btn-primary" data-enviar-resp="'+esc(c.id)+'">Enviar</button>'+
    '</div>'+
  '</div>';
}

function docsPainelComentariosBind(docId){
  var corpo = document.getElementById('dcCorpo');
  if (!corpo) return;

  var send = corpo.querySelector('#dcNovoSend');
  if (send) send.addEventListener('click', function(){
    var ta = corpo.querySelector('#dcNovoTxt');
    var v = (ta.value||'').trim();
    if (!v){ toast('Escreva algo antes de enviar','error'); return; }
    setBusy(send, true);
    // se tem um bloco selecionado no editor, ancora nele
    var alvo = ST.docBlocoSelecionado || {};
    docsComentar(docId, v, alvo.id||null, alvo.preview||null, null).then(function(){
      setBusy(send, false);
      ta.value='';
      ST.docBlocoSelecionado = null;
      docsPainelComentariosRender(docId);
    });
  });
  var ta = corpo.querySelector('#dcNovoTxt');
  if (ta) ta.addEventListener('keydown', function(e){
    if ((e.ctrlKey||e.metaKey) && e.key==='Enter'){ e.preventDefault(); if (send) send.click(); }
  });

  corpo.querySelectorAll('[data-resolver]').forEach(function(b){
    b.addEventListener('click', function(){
      docsResolverComentario(docId, this.getAttribute('data-resolver'), this.getAttribute('data-estado')!=='1');
    });
  });
  corpo.querySelectorAll('[data-apagar]').forEach(function(b){
    b.addEventListener('click', function(){ docsExcluirComentario(docId, this.getAttribute('data-apagar')); });
  });
  corpo.querySelectorAll('[data-responder]').forEach(function(b){
    b.addEventListener('click', function(){
      var box = corpo.querySelector('#rb-'+this.getAttribute('data-responder'));
      if (box){ box.style.display = box.style.display==='none' ? 'flex' : 'none'; var t=box.querySelector('textarea'); if(t) t.focus(); }
    });
  });
  corpo.querySelectorAll('[data-enviar-resp]').forEach(function(b){
    b.addEventListener('click', function(){
      var pid = this.getAttribute('data-enviar-resp');
      var box = corpo.querySelector('#rb-'+pid);
      var t = box ? box.querySelector('textarea') : null;
      var v = t ? (t.value||'').trim() : '';
      if (!v){ toast('Escreva a resposta','error'); return; }
      setBusy(b, true);
      docsComentar(docId, v, null, null, pid).then(function(){
        setBusy(b, false);
        docsPainelComentariosRender(docId);
      });
    });
  });

  var chk = document.getElementById('dcMostrarResolvidos');
  if (chk) chk.addEventListener('change', function(){ ST.docMostrarResolvidos = this.checked; docsPainelComentariosRender(docId); });
  var fechar = document.getElementById('dcFechar');
  if (fechar) fechar.addEventListener('click', function(){ ST.docPainelComentarios = false; renderPage(); });
}

/* ---------- (A) Captura qual bloco está selecionado no editor ---------- */
function docsCapturarBlocoAtual(){
  var ctx = _docEditorAtual;
  if (!ctx || !ctx.editor || !ctx.editor.blocks) return null;
  try {
    var idx = ctx.editor.blocks.getCurrentBlockIndex();
    if (idx < 0) return null;
    var bl = ctx.editor.blocks.getBlockByIndex(idx);
    if (!bl) return null;
    var texto = '';
    if (bl.holder) texto = String(bl.holder.textContent||'').trim();
    return { id: bl.id || ('idx-'+idx), preview: texto.slice(0,120) };
  } catch(e){ return null; }
}

/* ============================================================
   (B) ATA — Transformar pendências em tarefas
   ============================================================ */

/* ---------- Varre o corpo procurando itens de checklist/lista pendentes ---------- */
function docPendenciasDoCorpo(body){
  var b = body;
  if (typeof b === 'string'){ try { b = JSON.parse(b); } catch(e){ return []; } }
  var blocks = (b && Array.isArray(b.blocks)) ? b.blocks : [];
  function limpa(t){ return String(t||'').replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').trim(); }
  var achados = [];
  var secaoRelevante = false;
  blocks.forEach(function(bl){
    var d = bl && bl.data ? bl.data : {};
    if (bl.type==='header'){
      var h = limpa(d.text).toLowerCase();
      // seções que costumam virar tarefa
      secaoRelevante = /pend|próxim|proxim|ação|acao|ações|acoes|to.?do|tarefa/.test(h);
      return;
    }
    if (bl.type==='checklist' && Array.isArray(d.items)){
      d.items.forEach(function(it){
        var t = limpa(it && it.text);
        if (t && !(it && it.checked)) achados.push(t); // só o que NÃO foi marcado
      });
      return;
    }
    if (secaoRelevante && bl.type==='list' && Array.isArray(d.items)){
      d.items.forEach(function(it){
        var t = limpa(typeof it==='string' ? it : (it && (it.content||it.text)));
        if (t) achados.push(t);
      });
    }
  });
  // remove duplicados e placeholders de template
  var vistos = {};
  return achados.filter(function(t){
    if (!t || t.length < 3) return false;
    if (/^\(.*\)$/.test(t)) return false;           // "(cada item vira uma tarefa...)"
    if (vistos[t.toLowerCase()]) return false;
    vistos[t.toLowerCase()] = true;
    return true;
  });
}

/* ---------- Modal: escolher quais pendências viram tarefa ---------- */
function docsPendenciasEmTarefas(docId){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  if (!d){ toast('Documento não encontrado','error'); return; }
  if (!docPodeVer(d)){ toast('Sem acesso a este documento.','error'); return; }

  function abrirCom(body){
    var itens = docPendenciasDoCorpo(body);
    if (!itens.length){
      makeModal({
        title:'Transformar pendências em tarefas', width:480, hideFoot:true,
        body:'<div class="doc-pend-vazio">Não encontrei pendências neste documento.<br><span>Procuro por itens de checklist não marcados, e por listas embaixo de títulos como “Pendências” ou “Próximas ações”.</span></div>'
      });
      return;
    }
    var respOpts = '<option value="">— sem responsável —</option>' + (ST.allUsers||ST.users||[]).filter(function(u){
      return String(u.sector||'')===String(ST.sector);
    }).map(function(u){ return '<option value="'+esc(u.id)+'">'+esc(u.name)+'</option>'; }).join('');

    var linhas = itens.map(function(t, i){
      return '<div class="doc-pend-row">'+
        '<label class="doc-pend-lb"><input type="checkbox" data-pend="'+i+'" checked><span>'+esc(t)+'</span></label>'+
        '<select data-pend-resp="'+i+'">'+respOpts+'</select>'+
        '<input type="date" data-pend-due="'+i+'">'+
      '</div>';
    }).join('');

    makeModal({
      title:'Transformar pendências em tarefas',
      width:640,
      body:'<div class="doc-pend-doc">'+docTipoIcon(d.doc_type)+' <b>'+esc(d.title||'Sem título')+'</b></div>'+
           '<p class="modal-note">Achei '+itens.length+' pendência'+(itens.length>1?'s':'')+'. Desmarque o que não vira tarefa e escolha responsável e prazo.</p>'+
           '<div class="doc-pend-lista">'+linhas+'</div>',
      saveLabel:'Criar tarefas',
      onSave: function(close, root){
        var novas = [];
        itens.forEach(function(t, i){
          var chk = root.querySelector('[data-pend="'+i+'"]');
          if (!chk || !chk.checked) return;
          var resp = root.querySelector('[data-pend-resp="'+i+'"]');
          var due  = root.querySelector('[data-pend-due="'+i+'"]');
          novas.push({
            sector: ST.sector,
            title: t,
            status: 'todo',
            priority: 'media',
            due_date: (due && due.value) || null,
            assignee_id: (resp && resp.value) || null,
            store_unit_id: ST.store ? ST.store.id : null
          });
        });
        if (!novas.length){ toast('Marque pelo menos uma pendência','error'); return; }
        var criadas = 0, erros = 0;
        novas.forEach(function(t){
          sb.from('malba_vl_tasks').insert(t).select().single().then(function(r){
            if (r.error){ erros++; console.error('pendência->tarefa:', r.error); }
            else if (r.data){ if(!ST.tasks) ST.tasks=[]; ST.tasks.push(r.data); }
            criadas++;
            if (criadas===novas.length){
              close();
              if (erros) toast(erros+' não deram certo — o resto foi criado','error');
              else toast(novas.length+' tarefa'+(novas.length>1?'s':'')+' criada'+(novas.length>1?'s':'')+' em Trabalho','success');
              renderPage();
            }
          });
        });
      }
    });
  }

  // usa o conteúdo do editor se estiver aberto; senão busca do banco
  if (_docEditorAtual && _docEditorAtual.id===docId && _docEditorAtual.editor){
    _docEditorAtual.editor.save().then(abrirCom).catch(function(){ abrirCom(d.body); });
  } else {
    sb.from('malba_docs').select('body').eq('id', docId).single().then(function(r){
      abrirCom(r.data ? r.data.body : d.body);
    }, function(){ abrirCom(d.body); });
  }
}

/* ============================================================
   v100: MÓDULO DOCUMENTOS — Fase 5 (última)
   (A) Vínculos: documento ligado a Projeto / Tarefa / Cliente /
       Ideia / Objetivo. Guardado em links JSONB no próprio doc.
   (B) Dashboard de indicadores do módulo.
   ============================================================ */

/* ---------- (A) Tipos de entidade que aceitam vínculo ---------- */
var DOC_LINK_TIPOS = {
  projeto:  { label:'Projeto',   ic:'🚀', lista:function(){ return (ST.projects||[]).map(function(p){ return { id:p.id, nome:p.name }; }); } },
  tarefa:   { label:'Tarefa',    ic:'✅', lista:function(){ return (ST.tasks||[]).filter(function(t){ return String(t.sector||'')===String(ST.sector); }).map(function(t){ return { id:t.id, nome:t.title }; }); } },
  cliente:  { label:'Cliente',   ic:'🤝', lista:function(){ return (ST.clients||[]).map(function(c){ return { id:c.id, nome:c.name || c.nome }; }); } },
  ideia:    { label:'Ideia',     ic:'💡', lista:function(){ return (ST.ideias||[]).map(function(i){ return { id:i.id, nome:i.title }; }); } },
  objetivo: { label:'Objetivo',  ic:'🎯', lista:function(){ return (ST.objetivos||[]).map(function(o){ return { id:o.id, nome:o.title }; }); } }
};
var DOC_LINK_ORDER = ['projeto','tarefa','cliente','ideia','objetivo'];

/* ---------- (A) Resolve o nome atual da entidade (com fallback) ---------- */
function docLinkNome(link){
  if (!link) return '';
  var tipo = DOC_LINK_TIPOS[link.type];
  if (tipo){
    var achado = tipo.lista().find(function(e){ return String(e.id)===String(link.id); });
    if (achado && achado.nome) return achado.nome;
  }
  // entidade sumiu — usa o nome guardado no momento do vínculo
  return link.label || '(item removido)';
}

function docLinksDe(d){ return Array.isArray(d && d.links) ? d.links : []; }

/* ---------- (A) Documentos ligados a uma entidade (usado na volta) ---------- */
function docsDaEntidade(tipo, entidadeId){
  return (ST.docs||[]).filter(function(d){
    if (d.is_archived || !docPodeVer(d)) return false;
    return docLinksDe(d).some(function(l){ return l.type===tipo && String(l.id)===String(entidadeId); });
  });
}

/* ---------- (A) Chip de vínculo ---------- */
function docLinkChipHTML(link, comRemover){
  var t = DOC_LINK_TIPOS[link.type] || { ic:'🔗', label:'Vínculo' };
  var rm = comRemover ? '<button type="button" class="doc-link-del" data-link-del="'+esc(link.type+':'+link.id)+'" title="Desvincular">×</button>' : '';
  return '<span class="doc-link-chip" title="'+esc(t.label)+'">'+t.ic+' '+esc(docLinkNome(link))+rm+'</span>';
}

/* ---------- (A) Modal de vínculos ---------- */
function docsVincular(docId){
  var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(docId); });
  if (!d){ toast('Documento não encontrado','error'); return; }
  if (!docPodeEditar(d)){ toast('Você precisa de acesso de edição para vincular.','error'); return; }

  var links = docLinksDe(d).map(function(l){ return { type:l.type, id:String(l.id), label:l.label||'' }; });

  function listaHTML(){
    if (!links.length) return '<div class="doc-link-vazio">Nenhum vínculo ainda. Ligue este documento a um projeto, tarefa, cliente, ideia ou objetivo.</div>';
    return '<div class="doc-link-lista">'+links.map(function(l){ return docLinkChipHTML(l, true); }).join('')+'</div>';
  }

  function addHTML(){
    var tipoSel = ST.docLinkTipo || 'projeto';
    var tipos = DOC_LINK_ORDER.map(function(k){
      return '<option value="'+k+'"'+(tipoSel===k?' selected':'')+'>'+DOC_LINK_TIPOS[k].ic+' '+DOC_LINK_TIPOS[k].label+'</option>';
    }).join('');
    var jaTem = links.map(function(l){ return l.type+':'+l.id; });
    var itens = DOC_LINK_TIPOS[tipoSel].lista().filter(function(e){
      return e.nome && jaTem.indexOf(tipoSel+':'+e.id)===-1;
    });
    var opts = itens.length
      ? itens.map(function(e){ return '<option value="'+esc(e.id)+'">'+esc(e.nome)+'</option>'; }).join('')
      : '';
    var selAlvo = itens.length
      ? '<select id="dlAlvo"><option value="">— escolher —</option>'+opts+'</select>'
      : '<select id="dlAlvo" disabled><option>nenhum disponível</option></select>';
    return '<div class="doc-link-add">'+
      '<select id="dlTipo">'+tipos+'</select>'+
      selAlvo+
      '<button type="button" class="btn btn-primary" id="dlAdd">Vincular</button>'+
    '</div>';
  }

  var m = makeModal({
    title:'Vínculos do documento', width:540,
    body:'<div class="doc-link-doc">'+docTipoIcon(d.doc_type)+' <b>'+esc(d.title||'Sem título')+'</b></div>'+
         '<label class="modal-label">Ligado a</label>'+
         '<div id="dlListaWrap">'+listaHTML()+'</div>'+
         '<div id="dlAddWrap">'+addHTML()+'</div>'+
         '<p class="modal-note">O documento aparece dentro do projeto, tarefa ou cliente vinculado — e você pode filtrar por vínculo na barra lateral.</p>',
    saveLabel:'Salvar vínculos',
    onSave: function(close){
      sb.from('malba_docs').update({ links: links }).eq('id', d.id).then(function(r){
        if (r.error){ toast('Não consegui salvar: '+(r.error.message||''),'error'); return; }
        d.links = links;
        close(); toast('Vínculos salvos','success'); renderPage();
      });
    }
  });

  function redesenha(){
    var a = m.root.querySelector('#dlListaWrap'); if (a) a.innerHTML = listaHTML();
    var b = m.root.querySelector('#dlAddWrap');   if (b) b.innerHTML = addHTML();
    ligar();
  }
  function ligar(){
    var tp = m.root.querySelector('#dlTipo');
    if (tp) tp.addEventListener('change', function(){ ST.docLinkTipo = this.value; redesenha(); });
    var add = m.root.querySelector('#dlAdd');
    if (add) add.addEventListener('click', function(){
      var sel = m.root.querySelector('#dlAlvo');
      var id = sel ? sel.value : '';
      if (!id){ toast('Escolha o item','error'); return; }
      var tipo = ST.docLinkTipo || 'projeto';
      var achado = DOC_LINK_TIPOS[tipo].lista().find(function(e){ return String(e.id)===String(id); });
      links.push({ type:tipo, id:String(id), label: achado ? achado.nome : '' });
      redesenha();
    });
    m.root.querySelectorAll('[data-link-del]').forEach(function(b){
      b.addEventListener('click', function(){
        var chave = this.getAttribute('data-link-del');
        links = links.filter(function(l){ return (l.type+':'+l.id)!==chave; });
        redesenha();
      });
    });
  }
  ligar();
}

/* ---------- (A) Bloco "Documentos vinculados" para reusar em outros modais ---------- */
function docsVinculadosBlocoHTML(tipo, entidadeId){
  var lista = docsDaEntidade(tipo, entidadeId);
  if (!lista.length) return '';
  return '<div class="doc-vinc-bloco">'+
    '<label class="modal-label">📄 Documentos vinculados ('+lista.length+')</label>'+
    '<div class="doc-vinc-lista">'+lista.map(function(d){
      return '<button type="button" class="doc-vinc-item" data-abrir-doc="'+esc(d.id)+'">'+
        docTipoIcon(d.doc_type)+' <span>'+esc(d.title||'Sem título')+'</span>'+
      '</button>';
    }).join('')+'</div>'+
  '</div>';
}

function bindDocsVinculados(root){
  (root||document).querySelectorAll('[data-abrir-doc]').forEach(function(b){
    b.addEventListener('click', function(){
      var id = this.getAttribute('data-abrir-doc');
      var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(id); });
      if (!d) return;
      document.querySelectorAll('.modal-bg').forEach(function(m){ m.remove(); });
      ST.page = 'docs';
      openDocEditor(d);
    });
  });
}

/* ============================================================
   (B) DASHBOARD DO MÓDULO
   ============================================================ */
function docsDashboardHTML(){
  var todos = (ST.docs||[]).filter(docPodeVer);
  var ativos = todos.filter(function(d){ return !d.is_archived; });
  var eu = ST.session && ST.session.user ? String(ST.session.user.id) : '';

  var arquivados = todos.filter(function(d){ return d.is_archived; }).length;
  var favoritos  = ativos.filter(function(d){ return Array.isArray(d.is_favorite_by) && d.is_favorite_by.indexOf(eu)!==-1; }).length;
  var seteDias   = new Date(Date.now()-7*24*3600*1000).toISOString();
  var recentes   = ativos.filter(function(d){ return (d.updated_at||'')>=seteDias; }).length;
  var compartilhados = ativos.filter(function(d){
    var vis = d.visibility||'setor';
    return vis!=='privado' || (Array.isArray(d.shares) && d.shares.length>0);
  }).length;
  var noventa = new Date(Date.now()-90*24*3600*1000).toISOString();
  var parados = ativos.filter(function(d){ return (d.updated_at||'') < noventa; });
  var comentariosAbertos = Object.keys(ST.docCommentCount||{}).reduce(function(acc,k){
    var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(k); });
    return acc + ((d && docPodeVer(d)) ? (ST.docCommentCount[k]||0) : 0);
  }, 0);
  var vinculados = ativos.filter(function(d){ return docLinksDe(d).length>0; }).length;

  function kpi(label, valor, cor, sub){
    return '<div class="estr-kpi"><div class="estr-kpi-v" style="color:'+(cor||'var(--u-text)')+'">'+valor+'</div><div class="estr-kpi-l">'+esc(label)+'</div>'+(sub?'<div class="estr-kpi-s">'+esc(sub)+'</div>':'')+'</div>';
  }

  var kpis = '<div class="estr-kpis">'+
    kpi('Documentos', ativos.length, '#0EA5E9', arquivados+' arquivado'+(arquivados===1?'':'s'))+
    kpi('Compartilhados', compartilhados, '#3B6FF7', 'visíveis para outras pessoas')+
    kpi('Meus favoritos', favoritos, '#F59E0B', 'marcados por você')+
    kpi('Editados na semana', recentes, '#16A34A', 'últimos 7 dias')+
    kpi('Comentários abertos', comentariosAbertos, comentariosAbertos?'#EF4444':'#16A34A', 'esperando resposta')+
    kpi('Vinculados', vinculados, '#8B5CF6', 'ligados a projeto, tarefa ou cliente')+
  '</div>';

  // distribuição por tipo
  var porTipo = {};
  ativos.forEach(function(d){ var t = d.doc_type||'geral'; porTipo[t] = (porTipo[t]||0)+1; });
  var nomes = { geral:'Documento', ata:'Ata de reunião', pop:'POP', manual:'Manual', wiki:'Wiki', planejamento:'Planejamento', estrategia:'Estratégia' };
  var chaves = Object.keys(porTipo).sort(function(a,b){ return porTipo[b]-porTipo[a]; });
  var maxT = chaves.length ? porTipo[chaves[0]] : 1;
  var tiposHTML = chaves.length
    ? chaves.map(function(k){
        var pct = Math.round(porTipo[k]/maxT*100);
        return '<div class="estr-funil-row"><span class="estr-funil-lb">'+docTipoIcon(k)+' '+esc(nomes[k]||k)+'</span><div class="estr-funil-bar"><span style="width:'+pct+'%;background:#3B6FF7"></span></div><span class="estr-funil-c">'+porTipo[k]+'</span></div>';
      }).join('')
    : '<div class="estr-rec-empty">Nenhum documento ainda.</div>';
  var boxTipos = '<div class="estr-funil"><h4>Por tipo</h4>'+tiposHTML+'</div>';

  // documentos parados
  var paradosOrd = parados.slice().sort(function(a,b){ return (a.updated_at||'').localeCompare(b.updated_at||''); }).slice(0,6);
  var paradosHTML = paradosOrd.length
    ? paradosOrd.map(function(d){
        return '<div class="estr-rec-row" data-dash-doc="'+esc(d.id)+'"><span class="estr-rec-status" style="background:#F59E0B"></span><b>'+esc(d.title||'Sem título')+'</b><span class="estr-rec-cat">'+esc(tempoRelativo(d.updated_at))+'</span></div>';
      }).join('')
    : '<div class="estr-rec-empty">Nenhum documento parado há mais de 90 dias. 👏</div>';
  var boxParados = '<div class="estr-box"><h4>Sem atualização há 90+ dias'+(parados.length>6?' (6 de '+parados.length+')':'')+'</h4><div class="estr-rec">'+paradosHTML+'</div></div>';

  return '<div class="estr-dash">'+kpis+'<div class="estr-dash-2col">'+boxTipos+boxParados+'</div></div>';
}

function bindDocsDashboard(){
  document.querySelectorAll('[data-dash-doc]').forEach(function(el){
    el.addEventListener('click', function(){
      var d = (ST.docs||[]).find(function(x){ return String(x.id)===String(el.getAttribute('data-dash-doc')); });
      if (d) openDocEditor(d);
    });
  });
}

/* ============================================================
   v103: CENTRAL DE CADASTROS (Fase 1)
   Árvore Empresa → Lojas → Colaboradores → Acessos.
   Nenhum termo técnico na tela. Nenhuma mudança de banco.
   ============================================================ */

/* ---------- Quem pode entrar ---------- */
function centralPodeAcessar(){ return isAdmin(ST.session); } // Admin ou Gestor
function centralGestorRestrito(){ return isAdmin(ST.session) && !isSuper(ST.session); } // Gestor vê só o próprio setor

/* ---------- Estado inicial ---------- */
function centralEstadoIni(){
  if (!ST.central) ST.central = { nav:'empresa', lojaId:null, colabId:null, q:'', colabAba:'dados', filtro:'todos' };
  return ST.central;
}

/* ---------- Contagens usadas na árvore ---------- */
function centralColabsDaLoja(lojaId){
  return (ST.members||[]).filter(function(m){ return String(m.store_unit_id||'')===String(lojaId); });
}
function centralColabsDoSetor(){
  var todos = (ST.members||[]);
  if (centralGestorRestrito()){
    // Gestor: só colaboradores das lojas que estão no setor dele
    return todos; // Lojas é setor 'lojas'; simplificamos: se admin de setor, vê os membros que ele já enxerga
  }
  return todos;
}
function centralUnidadesVisiveis(){
  var todas = (ST.storeUnits||[]).slice();
  // Ordena por número da loja
  todas.sort(function(a,b){ return (a.store_number||0) - (b.store_number||0); });
  return todas;
}
function centralUserDoColab(m){ return userDoMembro(m); } // reusa a existente

/* ---------- HTML principal ---------- */
function centralHTML(){
  if (!centralPodeAcessar()){
    return '<div class="empty-page"><div class="ep-ico">'+icon('gear')+'</div><h3>Acesso restrito</h3><p>Só Administrador e Gestor entram na Central de Cadastros.</p></div>';
  }
  centralEstadoIni();
  var head = '<div class="tasks-head"><div><h2>Central de Cadastros</h2><div class="sub">Estrutura da empresa em um lugar só</div></div></div>';
  var busca = '<div class="cad-search">'+icon('search')+
    '<input id="cadQ" placeholder="Buscar colaborador, loja, cargo…" value="'+esc(ST.central.q||'')+'">'+
  '</div>';
  return head + busca + '<div class="cad-wrap">'+centralArvoreHTML()+'<div class="cad-main">'+centralConteudoHTML()+'</div></div>';
}

/* ---------- Árvore lateral ---------- */
function centralArvoreHTML(){
  var c = ST.central;
  var lojas = centralUnidadesVisiveis();
  var colabs = centralColabsDoSetor();
  var ativos = colabs.filter(function(m){ return m.is_active!==false; });
  var comAcesso = ativos.filter(centralUserDoColab).length;
  var semAcesso = ativos.length - comAcesso;

  function item(nav, ic, label, contagem, extra, ativo){
    var on = ativo ? ' on' : '';
    var badge = (contagem!==undefined && contagem!==null) ? '<span class="cad-count">'+contagem+'</span>' : '';
    return '<button class="cad-item'+on+'" data-cad-nav="'+esc(nav)+'"'+(extra||'')+'>'+
      '<span class="cad-item-ic">'+ic+'</span>'+
      '<span class="cad-item-lb">'+esc(label)+'</span>'+badge+
    '</button>';
  }

  var lojasAbertas = c.nav==='lojas' || c.nav==='loja';
  var lojasFilhos = lojasAbertas ? lojas.map(function(l){
    var n = centralColabsDaLoja(l.id).filter(function(m){ return m.is_active!==false; }).length;
    var atv = c.nav==='loja' && String(c.lojaId)===String(l.id);
    return '<button class="cad-item cad-sub'+(atv?' on':'')+'" data-cad-nav="loja" data-cad-loja="'+esc(l.id)+'">'+
      '<span class="cad-item-lb">'+esc(l.name || ('Loja '+l.store_number))+'</span>'+
      '<span class="cad-count">'+n+'</span>'+
    '</button>';
  }).join('') : '';

  var colabsAbertos = c.nav==='colabs' || c.nav==='colab';
  var filtroAtual = c.filtro || 'todos';
  var colabsFilhos = colabsAbertos ? [
    '<button class="cad-item cad-sub'+(filtroAtual==='todos'?' on':'')+'" data-cad-nav="colabs" data-cad-filtro="todos"><span class="cad-item-lb">Todos ativos</span><span class="cad-count">'+ativos.length+'</span></button>',
    '<button class="cad-item cad-sub'+(filtroAtual==='comacesso'?' on':'')+'" data-cad-nav="colabs" data-cad-filtro="comacesso"><span class="cad-item-lb">Com acesso ao sistema</span><span class="cad-count">'+comAcesso+'</span></button>',
    '<button class="cad-item cad-sub'+(filtroAtual==='semacesso'?' on':'')+'" data-cad-nav="colabs" data-cad-filtro="semacesso"><span class="cad-item-lb">Sem acesso ao sistema</span><span class="cad-count">'+semAcesso+'</span></button>',
    '<button class="cad-item cad-sub'+(filtroAtual==='inativos'?' on':'')+'" data-cad-nav="colabs" data-cad-filtro="inativos"><span class="cad-item-lb">Inativos</span><span class="cad-count">'+(colabs.length-ativos.length)+'</span></button>'
  ].join('') : '';

  return '<aside class="cad-side">'+
    item('empresa', '🏢', 'Empresa', null, '', c.nav==='empresa')+
    item('lojas',   '🏪', 'Lojas', lojas.length, '', lojasAbertas)+
    lojasFilhos+
    item('colabs',  '👥', 'Colaboradores', ativos.length, '', colabsAbertos)+
    colabsFilhos+
    item('acessos', '🔑', 'Acessos e Permissões', comAcesso, '', c.nav==='acessos')+
    item('cargos',  '💼', 'Cargos', (ST.cargos||[]).length, '', c.nav==='cargos')+
    item('equipes', '👥', 'Equipes', equipesVisiveis().length, '', c.nav==='equipes' || c.nav==='equipe-detalhe')+
    (isSuper(ST.session) ? item('departamentos', '🏢', 'Departamentos', (ST.departamentos||[]).length, '', c.nav==='departamentos') : '')+
    (isSuper(ST.session) ? item('perfis', '🎭', 'Perfis de Permissão', (5 + ((ST.perfis||[]).length)), '', c.nav==='perfis') : '')+
    item('organograma', '🗺️', 'Organograma', (ST.departamentos||[]).length, '', c.nav==='organograma')+
  '</aside>';
}

/* ---------- Conteúdo principal (roteador) ---------- */
function centralConteudoHTML(){
  var c = ST.central;
  var q = (c.q||'').trim();
  if (q) return centralPesquisaHTML(q);
  if (c.nav==='colab' && c.colabId) return centralColabHTML(c.colabId);
  if (c.nav==='loja' && c.lojaId)   return centralLojaHTML(c.lojaId);
  if (c.nav==='colabs')  return centralListaColabsHTML();
  if (c.nav==='lojas')   return centralListaLojasHTML();
  if (c.nav==='acessos') return centralAcessosHTML();
  if (c.nav==='cargos')  return centralCargosHTML();
  if (c.nav==='departamentos' && isSuper(ST.session)) return centralDepartamentosHTML();
  if (c.nav==='perfis' && isSuper(ST.session)) return centralPerfisHTML();
  if (c.nav==='organograma') return centralOrganogramaHTML();
  if (c.nav==='equipe' && c.equipeId) return centralEquipeDetalheHTML(c.equipeId);
  if (c.nav==='equipes')  return centralEquipesHTML();
  return centralVisaoEmpresaHTML();
}

/* ---------- Empresa (visão geral) ---------- */
function centralVisaoEmpresaHTML(){
  var lojas = centralUnidadesVisiveis();
  var colabs = centralColabsDoSetor().filter(function(m){ return m.is_active!==false; });
  var comAcesso = colabs.filter(centralUserDoColab).length;
  var gestores = (ST.allUsers||[]).filter(function(u){
    var nv = nivelDe(u);
    return nv==='gestor' || nv==='admin';
  }).length;
  function box(n, l, cor){
    return '<div class="cad-kpi"><div class="cad-kpi-v" style="color:'+cor+'">'+n+'</div><div class="cad-kpi-l">'+esc(l)+'</div></div>';
  }
  var kpis = '<div class="cad-kpis">'+
    box(lojas.length, 'Lojas', '#3B6FF7')+
    box(colabs.length, 'Colaboradores ativos', '#16A34A')+
    box(comAcesso, 'Com acesso ao sistema', '#8B5CF6')+
    box(gestores, 'Gestores', '#F59E0B')+
  '</div>';

  // Grade das lojas com resumo
  var cards = lojas.length ? lojas.map(function(l){
    var totalM = centralColabsDaLoja(l.id).filter(function(m){ return m.is_active!==false; }).length;
    var gestor = l.user_id ? (ST.allUsers||[]).find(function(u){ return String(u.id)===String(l.user_id); }) : null;
    return '<button class="cad-loja-card" data-cad-nav="loja" data-cad-loja="'+esc(l.id)+'">'+
      '<div class="cad-loja-h">🏪 <b>'+esc(l.name || ('Loja '+l.store_number))+'</b></div>'+
      '<div class="cad-loja-info">'+totalM+' pessoa'+(totalM===1?'':'s')+(gestor?' · Gestor: '+esc(gestor.name):'')+'</div>'+
    '</button>';
  }).join('') : '<div class="cad-vazio">Nenhuma loja cadastrada ainda.</div>';

  return '<div class="cad-titulo"><h3>Visão da empresa</h3><span class="cad-sub">Panorama da estrutura MALBA</span></div>'+
    kpis +
    '<div class="cad-titulo"><h3>Lojas</h3></div>'+
    '<div class="cad-loja-grid">'+cards+'</div>';
}

/* ---------- Lista de lojas ---------- */
function centralListaLojasHTML(){
  var lojas = centralUnidadesVisiveis();
  var podeCriar = isSuper(ST.session); // só Admin cria loja
  var btn = podeCriar ? '<button class="btn-new" id="cadNovaLoja">'+icon('plus')+'Nova loja</button>' : '';
  var linhas = lojas.length ? lojas.map(function(l){
    var totalM = centralColabsDaLoja(l.id).filter(function(m){ return m.is_active!==false; }).length;
    var gestor = l.user_id ? (ST.allUsers||[]).find(function(u){ return String(u.id)===String(l.user_id); }) : null;
    return '<button class="cad-linha" data-cad-nav="loja" data-cad-loja="'+esc(l.id)+'">'+
      '<span class="cad-linha-ic">🏪</span>'+
      '<span class="cad-linha-main"><b>'+esc(l.name || ('Loja '+l.store_number))+'</b>'+
        '<span class="cad-linha-sub">'+totalM+' pessoa'+(totalM===1?'':'s')+(gestor?' · Gestor: '+esc(gestor.name):'')+'</span>'+
      '</span>'+
      '<span class="cad-linha-seta">›</span>'+
    '</button>';
  }).join('') : '<div class="cad-vazio">Nenhuma loja cadastrada.</div>';
  return '<div class="cad-titulo"><h3>Lojas</h3><span class="cad-sub">'+lojas.length+' unidade(s)</span>'+btn+'</div>'+
    '<div class="cad-lista">'+linhas+'</div>';
}

/* ---------- Detalhe da loja ---------- */
function centralLojaHTML(lojaId){
  var l = (ST.storeUnits||[]).find(function(x){ return String(x.id)===String(lojaId); });
  if (!l) return '<div class="cad-vazio">Loja não encontrada.</div>';
  var pessoas = centralColabsDaLoja(l.id);
  var ativos = pessoas.filter(function(m){ return m.is_active!==false; });
  var gestor = l.user_id ? (ST.allUsers||[]).find(function(u){ return String(u.id)===String(l.user_id); }) : null;
  var podeEditar = isSuper(ST.session);

  var infoLinhas = [
    ['Nome', l.name || ('Loja '+l.store_number)],
    ['Número', l.store_number || '—'],
    ['Endereço', l.address || '—'],
    ['Gestor responsável', gestor ? gestor.name : '— não definido —']
  ].map(function(li){ return '<div class="cad-info-row"><span>'+esc(li[0])+'</span><b>'+esc(String(li[1]))+'</b></div>'; }).join('');

  var equipe = ativos.length ? '<div class="cad-eq-lista">'+ativos.map(function(m){
    var u = centralUserDoColab(m);
    var chip = u ? '<span class="cad-eq-chip">🔑 tem acesso</span>' : '';
    return '<button class="cad-eq-item" data-cad-nav="colab" data-cad-colab="'+esc(m.id)+'">'+
      '<span class="cad-eq-av" style="background:'+esc(m.color||'#3B6FF7')+'">'+esc(iniciais(m.name))+'</span>'+
      '<span class="cad-eq-main"><b>'+esc(m.name)+'</b><span class="cad-eq-sub">'+esc(m.role||'sem cargo')+'</span></span>'+
      chip+
    '</button>';
  }).join('')+'</div>' : '<div class="cad-vazio">Nenhum colaborador vinculado a esta loja.</div>';

  var acoes = podeEditar ? '<button class="btn btn-secondary" id="cadLojaEditar">Editar loja</button>' : '';

  return '<div class="cad-titulo"><button class="cad-voltar" data-cad-nav="lojas">← Lojas</button><h3>🏪 '+esc(l.name || ('Loja '+l.store_number))+'</h3>'+acoes+'</div>'+
    '<div class="cad-2col">'+
      '<div class="cad-bloco"><h4>Informações</h4>'+infoLinhas+'</div>'+
      '<div class="cad-bloco"><h4>Indicadores</h4>'+
        '<div class="cad-info-row"><span>Colaboradores ativos</span><b>'+ativos.length+'</b></div>'+
        '<div class="cad-info-row"><span>Com acesso ao sistema</span><b>'+ativos.filter(centralUserDoColab).length+'</b></div>'+
        '<div class="cad-info-row"><span>Sem acesso</span><b>'+ativos.filter(function(m){ return !centralUserDoColab(m); }).length+'</b></div>'+
      '</div>'+
    '</div>'+
    '<div class="cad-titulo"><h3>Equipe</h3><span class="cad-sub">'+ativos.length+' pessoa(s)</span></div>'+
    equipe;
}

/* ---------- Lista de colaboradores ---------- */
function centralListaColabsHTML(){
  var filtro = ST.central.filtro || 'todos';
  var todos = centralColabsDoSetor();
  var list = todos.filter(function(m){
    if (filtro==='todos')     return m.is_active!==false;
    if (filtro==='inativos')  return m.is_active===false;
    if (filtro==='comacesso') return m.is_active!==false && !!centralUserDoColab(m);
    if (filtro==='semacesso') return m.is_active!==false && !centralUserDoColab(m);
    return true;
  });
  list.sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); });
  var btn = isAdmin(ST.session) ? '<button class="btn-new" id="cadNovoColab">'+icon('plus')+'Novo colaborador</button>' : '';
  var linhas = list.length ? list.map(function(m){
    var u = centralUserDoColab(m);
    var loja = (ST.storeUnits||[]).find(function(x){ return String(x.id)===String(m.store_unit_id); });
    var lojaLb = loja ? (loja.name || ('Loja '+loja.store_number)) : 'sem loja';
    var acesso = u ? '<span class="cad-eq-chip">🔑 '+esc((NIVEIS[nivelDe(u)]||NIVEIS.colaborador).label)+'</span>' : '<span class="cad-eq-chip cinza">sem acesso</span>';
    var inat = m.is_active===false ? ' inativo' : '';
    return '<button class="cad-linha'+inat+'" data-cad-nav="colab" data-cad-colab="'+esc(m.id)+'">'+
      '<span class="cad-eq-av" style="background:'+esc(m.color||'#3B6FF7')+'">'+esc(iniciais(m.name))+'</span>'+
      '<span class="cad-linha-main"><b>'+esc(m.name)+'</b>'+
        '<span class="cad-linha-sub">'+esc(m.role||'sem cargo')+' · '+esc(lojaLb)+'</span>'+
      '</span>'+
      acesso+
      '<span class="cad-linha-seta">›</span>'+
    '</button>';
  }).join('') : '<div class="cad-vazio">Nenhum colaborador nesta lista.</div>';
  var titulos = { todos:'Todos os colaboradores ativos', comacesso:'Com acesso ao sistema', semacesso:'Sem acesso ao sistema', inativos:'Inativos' };
  return '<div class="cad-titulo"><h3>👥 '+esc(titulos[filtro])+'</h3><span class="cad-sub">'+list.length+' pessoa(s)</span>'+btn+'</div>'+
    '<div class="cad-lista">'+linhas+'</div>';
}

/* ---------- Detalhe do colaborador ---------- */
function centralColabHTML(colabId){
  var m = (ST.members||[]).find(function(x){ return String(x.id)===String(colabId); });
  if (!m) return '<div class="cad-vazio">Colaborador não encontrado.</div>';
  var aba = ST.central.colabAba || 'dados';
  var abas = ['dados','acesso','vinculos','historico'].map(function(k){
    var lbs = { dados:'Dados', acesso:'Acesso ao Sistema', vinculos:'Vínculos', historico:'Histórico' };
    return '<button class="cad-aba'+(aba===k?' on':'')+'" data-cad-aba="'+k+'">'+esc(lbs[k])+'</button>';
  }).join('');
  var u = centralUserDoColab(m);
  var loja = (ST.storeUnits||[]).find(function(x){ return String(x.id)===String(m.store_unit_id); });
  var lojaLb = loja ? (loja.name || ('Loja '+loja.store_number)) : '— sem loja —';

  var conteudo = '';
  if (aba==='dados'){
    conteudo = '<div class="cad-bloco"><h4>Dados pessoais</h4>'+
      '<div class="cad-info-row"><span>Nome</span><b>'+esc(m.name)+'</b></div>'+
      '<div class="cad-info-row"><span>Cargo</span><b>'+esc(m.role||'sem cargo')+'</b></div>'+
      '<div class="cad-info-row"><span>Loja</span><b>'+esc(lojaLb)+'</b></div>'+
      '<div class="cad-info-row"><span>Situação</span><b>'+(m.is_active===false?'Inativo':'Ativo')+'</b></div>'+
      (m.email ? '<div class="cad-info-row"><span>Contato</span><b>'+esc(m.email)+'</b></div>' : '')+
      (isAdmin(ST.session) ? '<button class="btn btn-secondary cad-btn-editar" id="cadEditarColab">Editar dados</button>' : '')+
    '</div>';
  } else if (aba==='acesso'){
    conteudo = centralColabAcessoHTML(m, u);
  } else if (aba==='vinculos'){
    conteudo = centralColabVinculosHTML(m, u);
  } else if (aba==='historico'){
    conteudo = '<div class="cad-bloco"><h4>Histórico</h4><div class="cad-vazio">Histórico de alterações e ações desta pessoa aparecerá aqui em breve.</div></div>';
  }

  return '<div class="cad-titulo"><button class="cad-voltar" data-cad-nav="colabs">← Colaboradores</button>'+
    '<h3><span class="cad-eq-av grande" style="background:'+esc(m.color||'#3B6FF7')+'">'+esc(iniciais(m.name))+'</span> '+esc(m.name)+'</h3>'+
    '<span class="cad-sub">'+esc(m.role||'sem cargo')+' · '+esc(lojaLb)+'</span></div>'+
    '<div class="cad-abas">'+abas+'</div>'+
    conteudo;
}

/* ---------- Aba: Acesso ao Sistema ---------- */
function centralColabAcessoHTML(m, u){
  if (!u){
    var podeCriar = isAdmin(ST.session);
    return '<div class="cad-bloco"><h4>🔑 Acesso ao Sistema</h4>'+
      '<p class="cad-explica">Esta pessoa <b>não tem acesso</b> ao sistema. Ela existe como colaboradora, aparece em ponto e ranking, mas não faz login.</p>'+
      (podeCriar ? '<div class="cad-acao-grid">'+
        '<button class="btn btn-primary" id="cadCriarAcesso">Criar acesso agora</button>'+
        '<button class="btn btn-secondary" id="cadVincularAcesso">Vincular a um login que já existe</button>'+
      '</div>' : '<p class="cad-explica">Peça a um administrador para criar o acesso.</p>')+
    '</div>';
  }
  var nv = nivelDe(u);
  var info = NIVEIS[nv] || NIVEIS.colaborador;
  var podeMexer = isAdmin(ST.session) && String(u.id)!==String(ST.session.user.id); // não mexe no próprio
  return '<div class="cad-bloco"><h4>🔑 Acesso ao Sistema</h4>'+
    '<div class="cad-info-row"><span>E-mail de login</span><b>'+esc(u.email||'—')+'</b></div>'+
    '<div class="cad-info-row"><span>Nível de acesso</span><b style="color:'+info.color+'">'+esc((typeof perfilLabelDe==='function' ? perfilLabelDe(u) : info.label))+'</b></div>'+
    '<div class="cad-explica">'+esc(info.desc)+'</div>'+
    (podeMexer ? '<div class="cad-acao-grid">'+
      '<button class="btn btn-secondary" id="cadAcessoEditar">Alterar nível e permissões</button>'+
      '<button class="btn btn-secondary" id="cadAcessoSenha">Redefinir senha</button>'+
      '<button class="btn btn-ghost cad-btn-danger" id="cadAcessoRemover">Remover acesso</button>'+
    '</div>' : '')+
  '</div>';
}

/* ---------- Aba: Vínculos ---------- */
function centralColabVinculosHTML(m, u){
  var uid = u ? String(u.id) : null;
  var tarefas = uid ? (ST.tasks||[]).filter(function(t){ return String(t.assignee_id||'')===uid; }) : [];
  var projetos = uid ? (ST.projects||[]).filter(function(p){ return (p.members||[]).map(String).indexOf(uid)!==-1; }) : [];
  var docs = uid ? (ST.docs||[]).filter(function(d){ return String(d.author_id||'')===uid; }) : [];
  function bloco(titulo, itens){
    if (!itens.length) return '<div class="cad-bloco"><h4>'+esc(titulo)+'</h4><div class="cad-vazio">Nenhum item.</div></div>';
    return '<div class="cad-bloco"><h4>'+esc(titulo)+' ('+itens.length+')</h4>'+
      '<ul class="cad-vinc-lista">'+itens.slice(0,10).map(function(x){ return '<li>'+esc(x.title || x.name || 'sem título')+'</li>'; }).join('')+'</ul>'+
      (itens.length>10 ? '<div class="cad-sub">e mais '+(itens.length-10)+'…</div>' : '')+
    '</div>';
  }
  if (!u) return '<div class="cad-bloco"><h4>Vínculos</h4><div class="cad-vazio">Esta pessoa não tem acesso ao sistema — não há tarefas, projetos ou documentos vinculados.</div></div>';
  return '<div class="cad-2col">'+bloco('Tarefas', tarefas)+bloco('Projetos', projetos)+'</div>'+bloco('Documentos', docs);
}

/* ---------- Acessos e Permissões (visão geral) ---------- */
function centralAcessosHTML(){
  var users = (ST.allUsers||[]);
  if (centralGestorRestrito()) users = users.filter(function(u){ return String(u.sector||'')===String(ST.sector); });
  users.sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); });
  var podeCriar = isAdmin(ST.session);
  var btn = podeCriar ? '<button class="btn-new" id="cadNovoUsuario">'+icon('plus')+'Novo acesso</button>' : '';
  var linhas = users.length ? users.map(function(u){
    var nv = nivelDe(u); var info = NIVEIS[nv] || NIVEIS.colaborador;
    return '<button class="cad-linha" data-cad-usuario="'+esc(u.id)+'">'+
      '<span class="cad-eq-av" style="background:'+esc(u.color||'#3B6FF7')+'">'+esc(iniciais(u.name))+'</span>'+
      '<span class="cad-linha-main"><b>'+esc(u.name)+'</b>'+
        '<span class="cad-linha-sub">'+esc(u.email||'')+'</span>'+
      '</span>'+
      '<span class="cad-eq-chip" style="color:'+info.color+';background:'+info.color+'18">'+esc((typeof perfilLabelDe==='function' ? perfilLabelDe(u) : info.label))+'</span>'+
      '<span class="cad-linha-seta">›</span>'+
    '</button>';
  }).join('') : '<div class="cad-vazio">Nenhum acesso cadastrado.</div>';
  return '<div class="cad-titulo"><h3>🔑 Acessos e Permissões</h3><span class="cad-sub">'+users.length+' pessoa(s) com login</span>'+btn+'</div>'+
    '<p class="cad-explica">Cada linha é uma pessoa que faz login. O nível define o que ela pode fazer.</p>'+
    '<div class="cad-lista">'+linhas+'</div>';
}

/* ---------- Pesquisa global ---------- */
function centralPesquisaHTML(termo){
  var t = termo.toLowerCase();
  var lojas = centralUnidadesVisiveis().filter(function(l){ return (l.name||('Loja '+l.store_number)).toLowerCase().indexOf(t)!==-1; });
  var colabs = centralColabsDoSetor().filter(function(m){
    return (m.name||'').toLowerCase().indexOf(t)!==-1 || (m.role||'').toLowerCase().indexOf(t)!==-1;
  });
  var users = (centralGestorRestrito() ? (ST.allUsers||[]).filter(function(u){ return String(u.sector||'')===String(ST.sector); }) : (ST.allUsers||[])).filter(function(u){
    return (u.name||'').toLowerCase().indexOf(t)!==-1 || (u.email||'').toLowerCase().indexOf(t)!==-1;
  });
  function bloco(titulo, itens, tipo){
    if (!itens.length) return '';
    return '<div class="cad-bloco"><h4>'+esc(titulo)+' ('+itens.length+')</h4><div class="cad-lista">'+itens.slice(0,20).map(function(x){
      if (tipo==='loja') return '<button class="cad-linha" data-cad-nav="loja" data-cad-loja="'+esc(x.id)+'"><span class="cad-linha-ic">🏪</span><span class="cad-linha-main"><b>'+esc(x.name||('Loja '+x.store_number))+'</b></span></button>';
      if (tipo==='colab') return '<button class="cad-linha" data-cad-nav="colab" data-cad-colab="'+esc(x.id)+'"><span class="cad-eq-av" style="background:'+esc(x.color||'#3B6FF7')+'">'+esc(iniciais(x.name))+'</span><span class="cad-linha-main"><b>'+esc(x.name)+'</b><span class="cad-linha-sub">'+esc(x.role||'sem cargo')+'</span></span></button>';
      return '<button class="cad-linha" data-cad-usuario="'+esc(x.id)+'"><span class="cad-eq-av" style="background:'+esc(x.color||'#3B6FF7')+'">'+esc(iniciais(x.name))+'</span><span class="cad-linha-main"><b>'+esc(x.name)+'</b><span class="cad-linha-sub">'+esc(x.email||'')+'</span></span></button>';
    }).join('')+'</div></div>';
  }
  var total = lojas.length + colabs.length + users.length;
  if (!total) return '<div class="cad-vazio">Nada encontrado para "'+esc(termo)+'".</div>';
  return '<div class="cad-titulo"><h3>Resultado da pesquisa</h3><span class="cad-sub">'+total+' resultado(s) para "'+esc(termo)+'"</span></div>'+
    bloco('Lojas', lojas, 'loja')+
    bloco('Colaboradores', colabs, 'colab')+
    bloco('Acessos ao sistema', users, 'user');
}

/* ---------- Binds ---------- */
function bindCentral(){
  if (!centralPodeAcessar()) return;
  if (ST.central && ST.central.nav==='cargos') bindCentralCargos();
  if (ST.central && ST.central.nav==='departamentos') bindCentralDepartamentos();
  if (ST.central && ST.central.nav==='perfis') bindCentralPerfis();
  if (ST.central && ST.central.nav==='organograma') bindCentralOrganograma();
  if (ST.central && ST.central.nav==='equipes') bindCentralEquipes();
  if (ST.central && ST.central.nav==='equipe') bindCentralEquipeDetalhe();
  var q = document.getElementById('cadQ');
  if (q){
    var t=null;
    q.addEventListener('input', function(){
      var v=this.value; clearTimeout(t);
      t=setTimeout(function(){ ST.central.q=v; renderPage(); }, 180);
    });
  }
  document.querySelectorAll('[data-cad-nav]').forEach(function(b){
    b.addEventListener('click', function(e){
      e.stopPropagation();
      var nav = this.getAttribute('data-cad-nav');
      var loja = this.getAttribute('data-cad-loja');
      var colab = this.getAttribute('data-cad-colab');
      var filtro = this.getAttribute('data-cad-filtro');
      ST.central.nav = nav;
      if (loja) ST.central.lojaId = loja;
      if (colab){ ST.central.colabId = colab; ST.central.colabAba = 'dados'; }
      if (filtro) ST.central.filtro = filtro;
      ST.central.q = ''; // pesquisa não sobrevive a clique
      renderPage();
    });
  });
  document.querySelectorAll('[data-cad-aba]').forEach(function(b){
    b.addEventListener('click', function(){ ST.central.colabAba = this.getAttribute('data-cad-aba'); renderPage(); });
  });
  document.querySelectorAll('[data-cad-usuario]').forEach(function(b){
    b.addEventListener('click', function(){
      var uid = this.getAttribute('data-cad-usuario');
      var u = (ST.allUsers||[]).find(function(x){ return String(x.id)===String(uid); });
      if (u) openUserModal(u);
    });
  });
  // ações do detalhe
  var novoColab = document.getElementById('cadNovoColab');
  if (novoColab) novoColab.addEventListener('click', function(){ openMemberModal({ store_unit_id: ST.central.lojaId || (ST.store?ST.store.id:null) }); });
  var editarColab = document.getElementById('cadEditarColab');
  if (editarColab) editarColab.addEventListener('click', function(){
    var m = (ST.members||[]).find(function(x){ return String(x.id)===String(ST.central.colabId); });
    if (m) openMemberModal(m);
  });
  var novaLoja = document.getElementById('cadNovaLoja');
  if (novaLoja) novaLoja.addEventListener('click', function(){ openStoreModal({}); });
  var editLoja = document.getElementById('cadLojaEditar');
  if (editLoja) editLoja.addEventListener('click', function(){
    var l = (ST.storeUnits||[]).find(function(x){ return String(x.id)===String(ST.central.lojaId); });
    if (l) openStoreModal(l);
  });
  var novoUser = document.getElementById('cadNovoUsuario');
  if (novoUser) novoUser.addEventListener('click', function(){ openUserModal({}); });
  // ações da aba Acesso
  var criarAc = document.getElementById('cadCriarAcesso');
  if (criarAc) criarAc.addEventListener('click', function(){
    var m = (ST.members||[]).find(function(x){ return String(x.id)===String(ST.central.colabId); });
    if (!m) return;
    // abre o modal de novo usuário já com nome e setor pré-preenchidos
    openUserModal({ name:m.name, sector: ST.sector, color: m.color, _origem_member_id: m.id });
  });
  var vincAc = document.getElementById('cadVincularAcesso');
  if (vincAc) vincAc.addEventListener('click', function(){
    // por enquanto: abre a lista de acessos pra pessoa escolher
    ST.central.nav = 'acessos'; renderPage();
    toast('Encontre o acesso na lista e edite para trocar o setor da pessoa','info');
  });
  var acEd = document.getElementById('cadAcessoEditar');
  if (acEd) acEd.addEventListener('click', function(){
    var m = (ST.members||[]).find(function(x){ return String(x.id)===String(ST.central.colabId); });
    var u = m ? centralUserDoColab(m) : null;
    if (u) openUserModal(u);
  });
}

/* ============================================================
   v104: CADASTROS — Fase 2 (Cargos)
   Cargos deixam de ser lista fixa e viram cadastro editável,
   consumido pelo modal de funcionário e reutilizável nos
   próximos módulos (equipes, avaliações, comissões).
   ============================================================ */

/* ---------- Semeia lista se o banco estiver vazio ---------- */
var CARGOS_SEED = [
  { name:'Vendedor',    sector:null },
  { name:'Caixa',       sector:'lojas' },
  { name:'Estoquista',  sector:'lojas' },
  { name:'Gerente',     sector:null },
  { name:'Atendente',   sector:'lojas' },
  { name:'Repositor',   sector:'lojas' },
  { name:'Auxiliar',    sector:null }
];

/* ---------- Carrega cargos do banco ---------- */
function cargosCarregar(cb){
  if (!sb){ cb && cb(); return; }
  sb.from('malba_cargos').select('*').order('name').then(function(r){
    if (r.error){
      var m = (r.error.message||'').toLowerCase();
      if (m.indexOf('does not exist')!==-1 || m.indexOf('relation')!==-1){
        // tabela ainda não criada — usa a lista antiga
        ST.cargos = CARGOS_SEED.map(function(c,i){ return { id:'seed-'+i, name:c.name, sector:c.sector, is_active:true }; });
      } else {
        console.warn('cargos:', r.error.message);
        ST.cargos = [];
      }
    } else {
      ST.cargos = r.data || [];
    }
    if (cb) cb();
  }, function(){ ST.cargos = []; if (cb) cb(); });
}

/* ---------- Cargos visíveis pra um setor ---------- */
function cargosVisiveis(setor){
  var s = setor || ST.sector;
  return (ST.cargos||[]).filter(function(c){
    if (c.is_active===false) return false;
    if (!c.sector) return true;              // compartilhado
    return String(c.sector)===String(s);
  }).sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); });
}

/* ---------- Chip do cargo (usado na descrição do colab) ---------- */
function cargoLabel(nomeOuId){
  if (!nomeOuId) return '';
  var c = (ST.cargos||[]).find(function(x){ return String(x.id)===String(nomeOuId) || String(x.name)===String(nomeOuId); });
  return c ? c.name : String(nomeOuId);
}

/* ---------- CRUD do cargo ---------- */
function cargoSalvar(cargo, cb){
  var payload = { name: (cargo.name||'').trim(), sector: cargo.sector||null, is_active: cargo.is_active!==false };
  if (!payload.name){ toast('Digite um nome para o cargo','error'); return; }
  // duplicado?
  var jaTem = (ST.cargos||[]).find(function(c){
    return String(c.id)!==String(cargo.id||'') &&
           (c.name||'').toLowerCase()===payload.name.toLowerCase() &&
           String(c.sector||'')===String(payload.sector||'');
  });
  if (jaTem){ toast('Já existe um cargo com esse nome nesse escopo','error'); return; }
  if (cargo.id && !String(cargo.id).startsWith('seed-')){
    sb.from('malba_cargos').update(payload).eq('id', cargo.id).then(function(r){
      if (r.error){ toast('Não consegui salvar: '+(r.error.message||''),'error'); return; }
      var i = (ST.cargos||[]).findIndex(function(x){ return String(x.id)===String(cargo.id); });
      if (i>=0) ST.cargos[i] = Object.assign(ST.cargos[i], payload);
      if (cb) cb(); toast('Cargo salvo','success'); renderPage();
    });
  } else {
    sb.from('malba_cargos').insert(payload).select().single().then(function(r){
      if (r.error){
        var m = (r.error.message||'').toLowerCase();
        if (m.indexOf('does not exist')!==-1) toast('Rode o SQL-cadastros-fase2.sql no Supabase para habilitar cargos.','error');
        else toast('Não consegui criar: '+(r.error.message||''),'error');
        return;
      }
      ST.cargos = ST.cargos || [];
      ST.cargos.push(r.data);
      if (cb) cb(); toast('Cargo criado','success'); renderPage();
    });
  }
}

function cargoRemover(id){
  var c = (ST.cargos||[]).find(function(x){ return String(x.id)===String(id); });
  if (!c) return;
  // conta quantos funcionários usam esse cargo
  var emUso = (ST.members||[]).filter(function(m){ return (m.role||'')===c.name; }).length;
  var msg = emUso
    ? 'Este cargo está em uso por '+emUso+' funcionário'+(emUso===1?'':'s')+'. Se remover, eles continuam com o cargo antigo como texto — mas some da lista de opções. Remover mesmo assim?'
    : 'Remover o cargo "'+c.name+'"?';
  confirmDialog({
    title:'Remover cargo', message:msg, confirmLabel:'Remover',
    onConfirm: function(){
      if (String(id).startsWith('seed-')){
        ST.cargos = (ST.cargos||[]).filter(function(x){ return String(x.id)!==String(id); });
        toast('Cargo removido','success'); renderPage(); return;
      }
      sb.from('malba_cargos').delete().eq('id', id).then(function(r){
        if (r.error){ toast('Não consegui remover: '+(r.error.message||''),'error'); return; }
        ST.cargos = (ST.cargos||[]).filter(function(x){ return String(x.id)!==String(id); });
        toast('Cargo removido','success'); renderPage();
      });
    }
  });
}

/* ---------- Modal editar/criar cargo ---------- */
function openCargoModal(cargo){
  var isNew = !cargo || !cargo.id;
  var c = Object.assign({ name:'', sector:null, is_active:true }, cargo||{});
  var setorOpts = '<option value="">Todos os setores (compartilhado)</option>' +
    Object.keys(SECTORS).map(function(k){
      return '<option value="'+k+'"'+(String(c.sector||'')===k?' selected':'')+'>'+esc(SECTORS[k].label)+'</option>';
    }).join('');
  var contagem = c.id ? (ST.members||[]).filter(function(m){ return (m.role||'')===c.name; }).length : 0;
  var infoUso = c.id ? '<div class="cad-explica">Em uso por <b>'+contagem+'</b> funcionário'+(contagem===1?'':'s')+'.</div>' : '';
  var m = makeModal({
    title: isNew ? 'Novo cargo' : 'Editar cargo',
    width: 460,
    body: '<div class="modal-row"><label class="modal-label">Nome do cargo</label>'+
            '<input type="text" id="cgNome" value="'+esc(c.name)+'" placeholder="Ex: Vendedor, Caixa, Gerente" autofocus></div>'+
          '<div class="modal-row"><label class="modal-label">Setor</label>'+
            '<select id="cgSetor">'+setorOpts+'</select>'+
            '<div class="cad-explica">Deixe "compartilhado" quando o cargo faz sentido em vários setores (ex: Gerente).</div></div>'+
          infoUso,
    saveLabel: isNew ? 'Criar cargo' : 'Salvar',
    onSave: function(close, root){
      var nome = (root.querySelector('#cgNome').value||'').trim();
      var setor = root.querySelector('#cgSetor').value || null;
      if (!nome){ toast('Digite o nome','error'); return; }
      cargoSalvar({ id:c.id, name:nome, sector:setor, is_active:true }, function(){ close(); });
    }
  });
}

/* ---------- Tela da aba Cargos dentro de Cadastros ---------- */
function centralCargosHTML(){
  var todos = (ST.cargos||[]).slice().sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); });
  var podeMexer = isSuper(ST.session); // só Admin gerencia cargos
  var btn = podeMexer ? '<button class="btn-new" id="cadNovoCargo">'+icon('plus')+'Novo cargo</button>' : '';
  var linhas = todos.length ? todos.map(function(c){
    var setLb = c.sector ? (SECTORS[c.sector]||{label:c.sector}).label : 'Todos os setores';
    var emUso = (ST.members||[]).filter(function(m){ return (m.role||'')===c.name; }).length;
    var acao = podeMexer
      ? '<span class="cad-linha-acoes">'+
          '<button class="cad-linha-btn" data-cargo-edit="'+esc(c.id)+'">✎</button>'+
          '<button class="cad-linha-btn danger" data-cargo-del="'+esc(c.id)+'">×</button>'+
        '</span>'
      : '';
    return '<div class="cad-linha">'+
      '<span class="cad-linha-ic">💼</span>'+
      '<span class="cad-linha-main"><b>'+esc(c.name)+'</b>'+
        '<span class="cad-linha-sub">'+esc(setLb)+' · '+emUso+' funcionário'+(emUso===1?'':'s')+'</span>'+
      '</span>'+
      acao+
    '</div>';
  }).join('') : '<div class="cad-vazio">Nenhum cargo cadastrado ainda.</div>';
  var info = todos.some(function(c){ return String(c.id||'').indexOf('seed-')===0; })
    ? '<p class="cad-explica">⚠️ Os cargos mostrados são os padrões antigos. Rode o SQL da Fase 2 no Supabase para começar a editar.</p>'
    : '';
  return '<div class="cad-titulo"><h3>💼 Cargos</h3><span class="cad-sub">'+todos.length+' cargo(s)</span>'+btn+'</div>'+
    '<p class="cad-explica">Cargos padronizam o que aparece na lista quando você cadastra um funcionário. Um cargo "compartilhado" aparece em todos os setores.</p>'+
    info +
    '<div class="cad-lista">'+linhas+'</div>';
}

function bindCentralCargos(){
  var novo = document.getElementById('cadNovoCargo');
  if (novo) novo.addEventListener('click', function(){ openCargoModal({}); });
  document.querySelectorAll('[data-cargo-edit]').forEach(function(b){
    b.addEventListener('click', function(){
      var c = (ST.cargos||[]).find(function(x){ return String(x.id)===String(this.getAttribute('data-cargo-edit')); }.bind(this));
      if (c) openCargoModal(c);
    });
  });
  document.querySelectorAll('[data-cargo-del]').forEach(function(b){
    b.addEventListener('click', function(){ cargoRemover(this.getAttribute('data-cargo-del')); });
  });
}

/* ============================================================
   v105: CADASTROS — Fase 3a (Departamentos: banco + fundação)

   Setor deixa de ser hardcoded e passa a vir do banco. Os 4
   originais ficam como registros "protegidos" no banco (não
   podem ser apagados). Registros novos herdam o menu de um
   existente e podem definir suas próprias flags.

   Nada muda visualmente nesta fase — a tela de login e o
   gerenciamento vêm em F3b e F3c.
   ============================================================ */

/* ---------- Departamentos padrão (fallback se a tabela ainda não existir) ---------- */
var DEPS_PADRAO = [
  { key:'marketing',  label:'Marketing',  sub:'Campanhas & Conteúdo', icon:'megaphone', color:'#8B5CF6', tem_crm:true,  tem_rotinas:false, tem_equipe:false, ordem:1, is_protegido:true, is_active:true },
  { key:'vendas',     label:'Vendas',     sub:'CRM & Metas',          icon:'trend',     color:'#16A34A', tem_crm:true,  tem_rotinas:false, tem_equipe:false, ordem:2, is_protegido:true, is_active:true },
  { key:'lojas',      label:'Lojas',      sub:'Operação Diária',      icon:'store',     color:'#3B6FF7', tem_crm:true,  tem_rotinas:true,  tem_equipe:true,  ordem:3, is_protegido:true, is_active:true },
  { key:'financeiro', label:'Financeiro', sub:'Rotinas & Controle',   icon:'dollar',    color:'#F59E0B', tem_crm:false, tem_rotinas:false, tem_equipe:false, ordem:4, is_protegido:true, is_active:true }
];

/* ---------- Menu padrão de cada setor original (a fonte é o próprio PAGES original) ---------- */
/* Guardado como page IDs simples (sem posição/grupo) — usado para clonar em depto novo */
var MENU_PADRAO_POR_DEPTO = {
  lojas:      ['inicio','tarefas','calendario','projetos','equipe','crm','estrategia','docs','gestao','chat','config','ponto','metas','relatorio'],
  vendas:     ['inicio','tarefas','calendario','projetos','crm','estrategia','docs','gestao','chat','config','metas','ranking'],
  financeiro: ['inicio','tarefas','calendario','projetos','estrategia','docs','chat','config'],
  marketing:  ['inicio','tarefas','calendario','projetos','crm','campanhas','conteudo','biblioteca','estrategia','docs','gestao','chat','config','metas','relatorio','orcamento']
};

/* ---------- Estado ---------- */
ST.departamentos = null;   // preenchido no boot; null = ainda não carregou

/* ---------- Carrega departamentos do banco ---------- */
function departamentosCarregar(cb){
  if (!sb){ ST.departamentos = DEPS_PADRAO.slice(); refazSECTORS(); if (cb) cb(); return; }
  sb.from('malba_departamentos').select('*').order('ordem').then(function(r){
    if (r.error){
      var msg = (r.error.message||'').toLowerCase();
      if (msg.indexOf('does not exist')!==-1 || msg.indexOf('relation')!==-1){
        // tabela ainda não criada — usa os 4 padrão
        ST.departamentos = DEPS_PADRAO.slice();
      } else {
        console.warn('departamentos:', r.error.message);
        ST.departamentos = DEPS_PADRAO.slice();
      }
    } else {
      var lista = r.data || [];
      if (!lista.length){
        // banco vazio — usa os padrão (SQL seed deve popular, mas por segurança)
        ST.departamentos = DEPS_PADRAO.slice();
      } else {
        ST.departamentos = lista;
      }
    }
    refazSECTORS();
    if (cb) cb();
  }, function(){ ST.departamentos = DEPS_PADRAO.slice(); refazSECTORS(); if (cb) cb(); });
}

/* ---------- Reconstrói SECTORS e PAGES a partir de ST.departamentos ----------
   SECTORS mantém a MESMA forma que tinha antes (chave = key do depto).
   PAGES ganha um entry pra cada depto novo (menu clonado do template).
   Os 4 originais NÃO são recriados aqui: eles já existem em PAGES.
*/
function refazSECTORS(){
  var deps = ST.departamentos || [];
  deps.forEach(function(d){
    if (!d.key) return;
    // SECTORS: sempre reflete o cadastro (label/sub/ícone podem ter mudado)
    SECTORS[d.key] = { label: d.label, sub: d.sub||'', icon: d.icon||'grid', color: d.color||'#64748B' };
    // PAGES: novos deptos ganham menu clonado a partir do modelo
    if (!PAGES[d.key]){
      var modelo = d.menu_modelo || 'marketing';
      var ids = MENU_PADRAO_POR_DEPTO[modelo] || MENU_PADRAO_POR_DEPTO['marketing'];
      // pega o PAGES do modelo pra copiar posições/grupos/hidden — não só os ids
      var modeloPages = PAGES[modelo] || PAGES['marketing'];
      var novoMenu = [];
      modeloPages.forEach(function(pg){
        // filtros: remove CRM se o depto não tem CRM; remove equipe/ponto se não tem equipe
        if (pg.id==='crm' && !d.tem_crm) return;
        if ((pg.id==='equipe' || pg.id==='ponto') && !d.tem_equipe) return;
        // rotina/pop não é uma página por si — é uma capacidade dentro de Tarefas
        novoMenu.push(Object.assign({}, pg));
      });
      PAGES[d.key] = novoMenu;
    }
  });
  // remove departamentos inativos da lista efetiva
  Object.keys(SECTORS).forEach(function(k){
    var d = deps.find(function(x){ return x.key===k; });
    if (d && d.is_active===false){
      // marca visualmente pra tela de login pular, mas mantém o registro
      SECTORS[k]._inativo = true;
    } else if (SECTORS[k]) {
      delete SECTORS[k]._inativo;
    }
  });
}

/* ---------- Lookup por key ---------- */
function departamentoDe(key){
  if (!ST.departamentos) return null;
  return ST.departamentos.find(function(d){ return d.key===key; }) || null;
}

/* ---------- Perguntas sobre capacidades — usadas pelo resto do sistema ---------- */
function deptoTemRotinas(key){
  var d = departamentoDe(key || ST.sector);
  if (!d) return (key||ST.sector)==='lojas'; // fallback ao comportamento antigo
  return !!d.tem_rotinas;
}
function deptoTemCRM(key){
  var d = departamentoDe(key || ST.sector);
  if (!d) return ['marketing','vendas','lojas'].indexOf(key||ST.sector)!==-1;
  return !!d.tem_crm;
}
function deptoTemEquipe(key){
  var d = departamentoDe(key || ST.sector);
  if (!d) return (key||ST.sector)==='lojas';
  return !!d.tem_equipe;
}

/* ---------- v106b: "esta pessoa se comporta como qual dos 4 modelos originais?"
   Usado nos hardcodes que dependem de comportamento específico (Metas do Marketing,
   KPIs do Vendas etc). Depto novo herda o comportamento do modelo escolhido no cadastro.
*/
function deptoModelo(key){
  var k = key || ST.sector;
  var d = departamentoDe(k);
  if (!d) return k; // sem cadastro: comporta-se como o próprio nome
  if (d.is_protegido) return k; // é um dos 4 originais: comporta-se como ele mesmo
  return d.menu_modelo || 'marketing';
}
function deptoComoModelo(modelo, key){
  return deptoModelo(key||ST.sector) === modelo;
}

/* ---------- Departamentos visíveis pra escolha na tela de login ---------- */
function departamentosParaLogin(){
  var deps = (ST.departamentos || DEPS_PADRAO).slice();
  return deps.filter(function(d){ return d.is_active!==false; })
             .sort(function(a,b){ return (a.ordem||0)-(b.ordem||0); });
}

/* ============================================================
   v108: CADASTROS — Fase 3c (Gerenciar Departamentos)

   Interface para criar, editar, reordenar e desativar
   departamentos sem tocar em SQL.
   ============================================================ */

/* ---------- Ícones e cores oferecidas no modal ---------- */
var DEPTO_ICONES = ['megaphone','trend','store','dollar','grid','users','target','folder','tasks','dashboard','cal','image','archive','gear','chat','bell','check','clock','edit','copy'];
var DEPTO_CORES  = ['#3B6FF7','#8B5CF6','#16A34A','#F59E0B','#EF4444','#0EA5E9','#EC4899','#14B8A6','#F97316','#64748B'];

/* ---------- Aba "Departamentos" na Central ---------- */
function centralDepartamentosHTML(){
  var deps = (ST.departamentos || []).slice().sort(function(a,b){ return (a.ordem||0)-(b.ordem||0); });
  var podeMexer = isSuper(ST.session); // só Admin
  var btn = podeMexer ? '<button class="btn-new" id="cadNovoDepto">'+icon('plus')+'Novo departamento</button>' : '';

  var linhas = deps.length ? deps.map(function(d, idx){
    var cor = d.color || '#64748B';
    var status = d.is_active===false ? '<span class="cad-eq-chip cinza">desativado</span>' : '';
    var prot = d.is_protegido ? '<span class="cad-eq-chip" title="Departamento protegido — não pode ser apagado">🛡 padrão</span>' : '';
    var caps = [];
    if (d.tem_crm)     caps.push('CRM');
    if (d.tem_rotinas) caps.push('Rotinas');
    if (d.tem_equipe)  caps.push('Equipe');
    var capsTxt = caps.length ? caps.join(' · ') : 'menu básico';
    var acoes = podeMexer ? '<span class="cad-linha-acoes">'+
      (idx>0 ? '<button class="cad-linha-btn" data-depto-cima="'+esc(d.id||d.key)+'" title="Subir">↑</button>' : '<span class="cad-linha-btn placeholder"></span>')+
      (idx<deps.length-1 ? '<button class="cad-linha-btn" data-depto-baixo="'+esc(d.id||d.key)+'" title="Descer">↓</button>' : '<span class="cad-linha-btn placeholder"></span>')+
      '<button class="cad-linha-btn" data-depto-edit="'+esc(d.id||d.key)+'" title="Editar">✎</button>'+
      (d.is_protegido
        ? '<button class="cad-linha-btn" data-depto-toggle="'+esc(d.id||d.key)+'" title="'+(d.is_active===false?'Ativar':'Desativar')+'">'+(d.is_active===false?'✓':'⏸')+'</button>'
        : '<button class="cad-linha-btn danger" data-depto-del="'+esc(d.id||d.key)+'" title="Remover">×</button>')+
    '</span>' : '';
    return '<div class="cad-linha'+(d.is_active===false?' inativo':'')+'">'+
      '<span class="cad-linha-ic" style="background:'+cor+'18;color:'+cor+'">'+icon(d.icon||'grid')+'</span>'+
      '<span class="cad-linha-main">'+
        '<b>'+esc(d.label||d.key)+'</b> '+prot+' '+status+
        '<span class="cad-linha-sub">'+esc(d.sub||'sem descrição')+' · '+esc(capsTxt)+'</span>'+
      '</span>'+
      acoes+
    '</div>';
  }).join('') : '<div class="cad-vazio">Nenhum departamento cadastrado.</div>';

  return '<div class="cad-titulo"><h3>🏢 Departamentos</h3><span class="cad-sub">'+deps.length+' no total</span>'+btn+'</div>'+
    '<p class="cad-explica">Cada departamento é um portal com seu próprio menu. Novos departamentos aparecem na tela "Quem está acessando?" e podem clonar o menu de qualquer um existente.</p>'+
    '<div class="cad-lista">'+linhas+'</div>';
}

function bindCentralDepartamentos(){
  var novo = document.getElementById('cadNovoDepto');
  if (novo) novo.addEventListener('click', function(){ openDepartamentoModal({}); });
  document.querySelectorAll('[data-depto-edit]').forEach(function(b){
    b.addEventListener('click', function(){
      var chave = this.getAttribute('data-depto-edit');
      var d = (ST.departamentos||[]).find(function(x){ return String(x.id||x.key)===String(chave); });
      if (d) openDepartamentoModal(d);
    });
  });
  document.querySelectorAll('[data-depto-del]').forEach(function(b){
    b.addEventListener('click', function(){ departamentoRemover(this.getAttribute('data-depto-del')); });
  });
  document.querySelectorAll('[data-depto-toggle]').forEach(function(b){
    b.addEventListener('click', function(){ departamentoToggleAtivo(this.getAttribute('data-depto-toggle')); });
  });
  document.querySelectorAll('[data-depto-cima]').forEach(function(b){
    b.addEventListener('click', function(){ departamentoMover(this.getAttribute('data-depto-cima'), -1); });
  });
  document.querySelectorAll('[data-depto-baixo]').forEach(function(b){
    b.addEventListener('click', function(){ departamentoMover(this.getAttribute('data-depto-baixo'), +1); });
  });
}

/* ---------- Modal ---------- */
function openDepartamentoModal(d){
  var isNew = !d || !d.id;
  var ed = Object.assign({
    key:'', label:'', sub:'', icon:'grid', color:'#3B6FF7',
    tem_crm:false, tem_rotinas:false, tem_equipe:false,
    menu_modelo:'marketing', ordem: 100, is_active: true
  }, d || {});

  // slug gerado do label — só editável em novos, os antigos travam a key
  function slugify(t){
    return String(t||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,32);
  }

  var iconesHTML = DEPTO_ICONES.map(function(k){
    return '<button type="button" class="dp-ico-opt'+(ed.icon===k?' on':'')+'" data-dp-ico="'+k+'" style="--c:'+ed.color+'">'+icon(k)+'</button>';
  }).join('');
  var coresHTML = DEPTO_CORES.map(function(c){
    return '<button type="button" class="dp-cor-opt'+(ed.color===c?' on':'')+'" data-dp-cor="'+c+'" style="background:'+c+'"></button>';
  }).join('');

  // opções de "menu clonado de"
  var modelosHTML = (ST.departamentos||[])
    .filter(function(x){ return !ed.id || String(x.id||x.key)!==String(ed.id); })
    .map(function(x){ return '<option value="'+esc(x.key)+'"'+(ed.menu_modelo===x.key?' selected':'')+'>'+esc(x.label)+'</option>'; })
    .join('');

  var travadoKey = !isNew || ed.is_protegido;
  var travadoProt = ed.is_protegido;

  var protInfo = travadoProt
    ? '<p class="cad-explica" style="color:#F59E0B">🛡 Este é um departamento padrão. Você pode editar aparência e capacidades, mas não pode remover nem trocar o identificador — o sistema depende dele para os dados existentes.</p>'
    : '';

  var m = makeModal({
    title: isNew ? 'Novo departamento' : 'Editar '+ed.label,
    width: 640,
    body:
      protInfo +
      '<div class="dp-2col">'+
        '<div class="modal-row"><label class="modal-label">Nome</label>'+
          '<input type="text" id="dpNome" value="'+esc(ed.label)+'" placeholder="Ex: Tecnologia" autofocus></div>'+
        '<div class="modal-row"><label class="modal-label">Subtítulo <span class="cad-sub">(opcional)</span></label>'+
          '<input type="text" id="dpSub" value="'+esc(ed.sub||'')+'" placeholder="Ex: Sistemas & Infra"></div>'+
      '</div>'+
      '<div class="modal-row"><label class="modal-label">Identificador interno</label>'+
        '<input type="text" id="dpKey" value="'+esc(ed.key)+'" placeholder="gerado do nome"'+(travadoKey?' readonly':'')+'>'+
        '<div class="cad-explica">'+(travadoKey?'Não pode ser alterado depois de criado — dados já usam este identificador.':'Gerado do nome. Só letras, números e underscore.')+'</div>'+
      '</div>'+
      '<div class="modal-row"><label class="modal-label">Ícone</label>'+
        '<div class="dp-ico-grid" id="dpIcoGrid">'+iconesHTML+'</div></div>'+
      '<div class="modal-row"><label class="modal-label">Cor</label>'+
        '<div class="dp-cor-grid" id="dpCorGrid">'+coresHTML+'</div></div>'+
      '<div class="modal-row"><label class="modal-label">Menu — clonar de qual departamento?</label>'+
        '<select id="dpModelo"'+(travadoProt?' disabled':'')+'>'+modelosHTML+'</select>'+
        '<div class="cad-explica">'+(travadoProt?'Departamentos padrão têm seu próprio menu.':'O novo departamento começa com o mesmo menu deste, e você ajusta as capacidades abaixo.')+'</div>'+
      '</div>'+
      '<div class="modal-row"><label class="modal-label">Capacidades do portal</label>'+
        '<div class="dp-cap">'+
          '<label class="dp-cap-item"><input type="checkbox" id="dpCrm"'+(ed.tem_crm?' checked':'')+'><b>CRM</b><span>Gestão de clientes e funil</span></label>'+
          '<label class="dp-cap-item"><input type="checkbox" id="dpRot"'+(ed.tem_rotinas?' checked':'')+'><b>Rotinas do Dia</b><span>POPs que viram checklist diário</span></label>'+
          '<label class="dp-cap-item"><input type="checkbox" id="dpEqp"'+(ed.tem_equipe?' checked':'')+'><b>Equipe e Ponto</b><span>Gestão de funcionários e batida de ponto</span></label>'+
        '</div>'+
      '</div>',
    saveLabel: isNew ? 'Criar departamento' : 'Salvar',
    onSave: function(close, root){
      var payload = {
        label: (root.querySelector('#dpNome').value||'').trim(),
        sub:   (root.querySelector('#dpSub').value||'').trim(),
        icon:  ed.icon,
        color: ed.color,
        tem_crm:     !!root.querySelector('#dpCrm').checked,
        tem_rotinas: !!root.querySelector('#dpRot').checked,
        tem_equipe:  !!root.querySelector('#dpEqp').checked
      };
      if (!payload.label){ toast('Digite o nome','error'); return; }
      // key: só define em criação
      if (isNew){
        var keyInput = (root.querySelector('#dpKey').value||'').trim();
        payload.key = keyInput || slugify(payload.label);
        if (!/^[a-z0-9_]+$/.test(payload.key)){ toast('Identificador só aceita letras, números e underscore','error'); return; }
        if ((ST.departamentos||[]).some(function(x){ return x.key===payload.key; })){ toast('Já existe um departamento com este identificador','error'); return; }
        payload.menu_modelo = root.querySelector('#dpModelo').value || 'marketing';
        payload.ordem = ((ST.departamentos||[]).reduce(function(mx,x){ return Math.max(mx, x.ordem||0); }, 0)) + 1;
      }
      departamentoSalvar(Object.assign({}, ed, payload), close);
    }
  });

  // preview em tempo real
  var nomeIn = m.root.querySelector('#dpNome');
  var keyIn = m.root.querySelector('#dpKey');
  if (nomeIn && keyIn && isNew) nomeIn.addEventListener('input', function(){ keyIn.value = slugify(this.value); });

  // seletores de ícone e cor
  function refazIco(){
    var grid = m.root.querySelector('#dpIcoGrid');
    if (!grid) return;
    grid.innerHTML = DEPTO_ICONES.map(function(k){
      return '<button type="button" class="dp-ico-opt'+(ed.icon===k?' on':'')+'" data-dp-ico="'+k+'" style="--c:'+ed.color+'">'+icon(k)+'</button>';
    }).join('');
    grid.querySelectorAll('[data-dp-ico]').forEach(function(b){
      b.addEventListener('click', function(){ ed.icon = this.getAttribute('data-dp-ico'); refazIco(); });
    });
  }
  function refazCor(){
    var grid = m.root.querySelector('#dpCorGrid');
    if (!grid) return;
    grid.innerHTML = DEPTO_CORES.map(function(c){
      return '<button type="button" class="dp-cor-opt'+(ed.color===c?' on':'')+'" data-dp-cor="'+c+'" style="background:'+c+'"></button>';
    }).join('');
    grid.querySelectorAll('[data-dp-cor]').forEach(function(b){
      b.addEventListener('click', function(){ ed.color = this.getAttribute('data-dp-cor'); refazIco(); refazCor(); });
    });
  }
  refazIco(); refazCor();
}

/* ---------- Salvar ---------- */
function departamentoSalvar(dep, cb){
  var isNew = !dep.id;
  var payload = {
    key:         dep.key,
    label:       dep.label,
    sub:         dep.sub || null,
    icon:        dep.icon || 'grid',
    color:       dep.color || '#64748B',
    tem_crm:     !!dep.tem_crm,
    tem_rotinas: !!dep.tem_rotinas,
    tem_equipe:  !!dep.tem_equipe,
    menu_modelo: dep.menu_modelo || null,
    ordem:       dep.ordem || 100,
    is_active:   dep.is_active!==false
  };
  if (isNew){
    sb.from('malba_departamentos').insert(payload).select().single().then(function(r){
      if (r.error){
        var m = (r.error.message||'').toLowerCase();
        if (m.indexOf('does not exist')!==-1) toast('Rode o SQL-cadastros-fase3a.sql no Supabase para habilitar departamentos.','error');
        else toast('Não consegui criar: '+(r.error.message||''),'error');
        return;
      }
      ST.departamentos = ST.departamentos || [];
      ST.departamentos.push(r.data);
      refazSECTORS();
      if (cb) cb();
      toast('Departamento criado','success'); renderPage();
    });
  } else {
    // protegidos não podem trocar key
    var patch = Object.assign({}, payload);
    delete patch.key; // proteção extra
    sb.from('malba_departamentos').update(patch).eq('id', dep.id).then(function(r){
      if (r.error){ toast('Não consegui salvar: '+(r.error.message||''),'error'); return; }
      var i = (ST.departamentos||[]).findIndex(function(x){ return String(x.id)===String(dep.id); });
      if (i>=0) ST.departamentos[i] = Object.assign(ST.departamentos[i], patch);
      refazSECTORS();
      if (cb) cb();
      toast('Departamento salvo','success'); renderPage();
    });
  }
}

/* ---------- Ativar/Desativar (usado nos protegidos) ---------- */
function departamentoToggleAtivo(chave){
  var d = (ST.departamentos||[]).find(function(x){ return String(x.id||x.key)===String(chave); });
  if (!d) return;
  var novo = d.is_active===false;
  if (novo===false){
    // não deixa desativar o último ativo — protegido ou não
    var ativos = (ST.departamentos||[]).filter(function(x){ return x.is_active!==false; }).length;
    if (ativos<=1){ toast('Não posso desativar — precisa ter pelo menos um departamento ativo','error'); return; }
  }
  sb.from('malba_departamentos').update({ is_active:novo }).eq('id', d.id).then(function(r){
    if (r.error){ toast('Não consegui salvar','error'); return; }
    d.is_active = novo;
    refazSECTORS();
    toast(novo?'Ativado':'Desativado','success'); renderPage();
  });
}

/* ---------- Remover ---------- */
function departamentoRemover(chave){
  var d = (ST.departamentos||[]).find(function(x){ return String(x.id||x.key)===String(chave); });
  if (!d) return;
  if (d.is_protegido){ toast('Este é um departamento padrão — só dá pra desativar, não remover','error'); return; }
  var usuarios = (ST.allUsers||[]).filter(function(u){ return String(u.sector||'')===String(d.key); }).length;
  var msg = usuarios
    ? 'Este departamento tem '+usuarios+' pessoa'+(usuarios===1?'':'s')+' vinculada'+(usuarios===1?'':'s')+'. Elas ficarão órfãs — precisarão ser movidas para outro departamento. Remover mesmo assim?'
    : 'Remover o departamento "'+d.label+'"? Todos os dados vinculados a ele (tarefas, documentos, etc) continuam existindo mas ficam sem portal para serem acessados.';
  confirmDialog({
    title:'Remover departamento', message:msg, confirmLabel:'Remover',
    onConfirm: function(){
      sb.from('malba_departamentos').delete().eq('id', d.id).then(function(r){
        if (r.error){ toast('Não consegui remover: '+(r.error.message||''),'error'); return; }
        ST.departamentos = (ST.departamentos||[]).filter(function(x){ return String(x.id)!==String(d.id); });
        delete SECTORS[d.key]; delete PAGES[d.key];
        toast('Departamento removido','success'); renderPage();
      });
    }
  });
}

/* ---------- Reordenar (subir/descer) ---------- */
function departamentoMover(chave, dir){
  var lista = (ST.departamentos||[]).slice().sort(function(a,b){ return (a.ordem||0)-(b.ordem||0); });
  var idx = lista.findIndex(function(x){ return String(x.id||x.key)===String(chave); });
  if (idx<0) return;
  var alvo = idx + dir;
  if (alvo<0 || alvo>=lista.length) return;
  var a = lista[idx], b = lista[alvo];
  var oa = a.ordem||0, ob = b.ordem||0;
  // se as ordens forem iguais, força +/-1
  if (oa===ob){ if (dir<0){ oa=ob-1; } else { oa=ob+1; } }
  Promise.all([
    sb.from('malba_departamentos').update({ ordem:ob }).eq('id', a.id).then(function(r){ return r; }),
    sb.from('malba_departamentos').update({ ordem:oa }).eq('id', b.id).then(function(r){ return r; })
  ]).then(function(res){
    if (res.some(function(x){ return x.error; })){ toast('Falha ao reordenar','error'); return; }
    a.ordem = ob; b.ordem = oa;
    renderPage();
  });
}

/* ============================================================
   v109: CADASTROS — Fase 4 (Equipes)

   Equipes são agrupamentos de pessoas — podem ser de um só
   departamento ou cross-departamento (ex: "Força-tarefa BF").
   Uma pessoa participa de várias.
   ============================================================ */

/* ---------- Carrega equipes + membros ---------- */
/* ============================================================
   v109: CADASTROS — Fase 4 (Equipes)

   Equipe = grupo nomeado de pessoas.
   - N pra N (pessoa em várias, equipe com várias)
   - Pode ser de um departamento (só admite pessoas dele) OU
     cruzada (aceita qualquer pessoa)
   - Sem líder (por decisão do usuário)

   Estado em ST.equipes  = [{id,name,description,sector,color,is_active,membros:[user_id...]}]
   ============================================================ */

/* ---------- Carregar ---------- */
function equipesCarregar(cb){
  if (!sb){ ST.equipes = []; if (cb) cb(); return; }
  // busca equipes + membros em paralelo
  Promise.all([
    sb.from('malba_equipes').select('*').order('name').then(function(r){ return r; }),
    sb.from('malba_equipe_membros').select('*').then(function(r){ return r; })
  ]).then(function(res){
    var e = res[0], m = res[1];
    if (e.error){
      var msg = (e.error.message||'').toLowerCase();
      if (msg.indexOf('does not exist')!==-1 || msg.indexOf('relation')!==-1){
        ST.equipes = [];
      } else {
        console.warn('equipes:', e.error.message);
        ST.equipes = [];
      }
      if (cb) cb(); return;
    }
    var eqs = (e.data||[]).map(function(x){ return Object.assign({}, x, { membros: [] }); });
    var byId = {}; eqs.forEach(function(x){ byId[String(x.id)] = x; });
    var membros = (m && !m.error && m.data) ? m.data : [];
    membros.forEach(function(mm){
      var q = byId[String(mm.equipe_id)];
      if (q) q.membros.push(String(mm.user_id));
    });
    ST.equipes = eqs;
    if (cb) cb();
  });
}

/* ---------- Lookups ---------- */
function equipesDoUsuario(userId){
  return (ST.equipes||[]).filter(function(e){
    return (e.membros||[]).map(String).indexOf(String(userId))!==-1;
  });
}
function usuariosDaEquipe(equipeId){
  var e = (ST.equipes||[]).find(function(x){ return String(x.id)===String(equipeId); });
  if (!e) return [];
  return (e.membros||[]).map(function(uid){
    return (ST.allUsers||[]).find(function(u){ return String(u.id)===String(uid); });
  }).filter(Boolean);
}
function equipesVisiveis(){
  // Admin vê tudo. Gestor vê equipes do próprio setor + cruzadas.
  var lista = (ST.equipes||[]).slice();
  if (!isSuper(ST.session) && isAdmin(ST.session)){
    lista = lista.filter(function(e){ return !e.sector || String(e.sector)===String(ST.sector); });
  }
  return lista.sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); });
}

/* ---------- Tela: aba Equipes na Central ---------- */
function centralEquipesHTML(){
  var lista = equipesVisiveis();
  var podeMexer = isAdmin(ST.session); // Admin ou Gestor (Gestor no próprio setor)
  var btn = podeMexer ? '<button class="btn-new" id="cadNovaEquipe">'+icon('plus')+'Nova equipe</button>' : '';

  var linhas = lista.length ? lista.map(function(e){
    var cor = e.color || '#3B6FF7';
    var qtd = (e.membros||[]).length;
    var escopo = e.sector ? (SECTORS[e.sector]||{label:e.sector}).label : 'Cruzada';
    var status = e.is_active===false ? '<span class="cad-eq-chip cinza">desativada</span>' : '';
    var chipEsc = e.sector ? '<span class="cad-eq-chip">'+esc(escopo)+'</span>' : '<span class="cad-eq-chip" style="color:#8B5CF6;background:#8B5CF618">🔗 cruzada</span>';
    var avatares = (e.membros||[]).slice(0,4).map(function(uid){
      var u = (ST.allUsers||[]).find(function(x){ return String(x.id)===String(uid); });
      if (!u) return '';
      return '<span class="cad-eq-mini" style="background:'+esc(u.color||'#64748B')+'" title="'+esc(u.name||'')+'">'+esc(iniciais(u.name||''))+'</span>';
    }).join('');
    var maisN = qtd>4 ? '<span class="cad-eq-mini extra">+'+(qtd-4)+'</span>' : '';
    return '<button class="cad-linha'+(e.is_active===false?' inativo':'')+'" data-eq-open="'+esc(e.id)+'">'+
      '<span class="cad-linha-ic" style="background:'+cor+'18;color:'+cor+'">'+icon('users')+'</span>'+
      '<span class="cad-linha-main">'+
        '<b>'+esc(e.name)+'</b> '+chipEsc+' '+status+
        '<span class="cad-linha-sub">'+esc(e.description || 'sem descrição')+' · '+qtd+' pessoa'+(qtd===1?'':'s')+'</span>'+
      '</span>'+
      '<span class="cad-eq-avs">'+avatares+maisN+'</span>'+
      '<span class="cad-linha-seta">›</span>'+
    '</button>';
  }).join('') : '<div class="cad-vazio">Nenhuma equipe cadastrada ainda.</div>';

  return '<div class="cad-titulo"><h3>👥 Equipes</h3><span class="cad-sub">'+lista.length+' equipe(s)</span>'+btn+'</div>'+
    '<p class="cad-explica">Equipes agrupam pessoas para compartilhar documentos, receber tarefas em conjunto ou aparecer em relatórios. Uma equipe pode ser de um departamento ou <b>cruzada</b> (aceita qualquer pessoa).</p>'+
    '<div class="cad-lista">'+linhas+'</div>';
}

/* ---------- Detalhe de uma equipe ---------- */
function centralEquipeDetalheHTML(equipeId){
  var e = (ST.equipes||[]).find(function(x){ return String(x.id)===String(equipeId); });
  if (!e) return '<div class="cad-vazio">Equipe não encontrada.</div>';
  var cor = e.color || '#3B6FF7';
  var podeMexer = isAdmin(ST.session);
  var escopo = e.sector ? (SECTORS[e.sector]||{label:e.sector}).label : 'Cruzada (qualquer departamento)';

  var membros = usuariosDaEquipe(e.id);
  var listaMembros = membros.length ? membros.map(function(u){
    var setLb = u.sector ? ' · '+((SECTORS[u.sector]||{label:u.sector}).label) : '';
    var acao = podeMexer ? '<button class="cad-linha-btn danger" data-eq-rem="'+esc(u.id)+'" title="Tirar da equipe">×</button>' : '';
    return '<div class="cad-linha">'+
      '<span class="cad-eq-av" style="background:'+esc(u.color||'#64748B')+'">'+esc(iniciais(u.name||''))+'</span>'+
      '<span class="cad-linha-main">'+
        '<b>'+esc(u.name||'')+'</b>'+
        '<span class="cad-linha-sub">'+esc(u.email||'sem e-mail')+esc(setLb)+'</span>'+
      '</span>'+
      acao+
    '</div>';
  }).join('') : '<div class="cad-vazio">Nenhum membro ainda. Clique em "Adicionar pessoa" para começar.</div>';

  var acoesTopo = podeMexer ? '<button class="btn btn-secondary" id="eqEditar">Editar</button>' +
    '<button class="btn btn-secondary" id="eqAddMembro">'+icon('plus')+'Adicionar pessoa</button>' : '';

  return '<div class="cad-titulo"><button class="cad-voltar" data-cad-nav="equipes">← Equipes</button>'+
    '<h3><span class="cad-eq-av grande" style="background:'+cor+'">'+icon('users')+'</span> '+esc(e.name)+'</h3>'+
    '<span class="cad-sub">'+esc(escopo)+' · '+membros.length+' pessoa(s)</span>'+
    acoesTopo+
  '</div>'+
    '<div class="cad-2col">'+
      '<div class="cad-bloco"><h4>Informações</h4>'+
        '<div class="cad-info-row"><span>Descrição</span><b>'+esc(e.description||'—')+'</b></div>'+
        '<div class="cad-info-row"><span>Escopo</span><b>'+esc(escopo)+'</b></div>'+
        '<div class="cad-info-row"><span>Situação</span><b>'+(e.is_active===false?'Desativada':'Ativa')+'</b></div>'+
      '</div>'+
      '<div class="cad-bloco"><h4>Indicadores</h4>'+
        '<div class="cad-info-row"><span>Membros</span><b>'+membros.length+'</b></div>'+
        '<div class="cad-info-row"><span>Com acesso ao sistema</span><b>'+membros.length+'</b></div>'+
      '</div>'+
    '</div>'+
    '<div class="cad-titulo"><h3>Membros</h3></div>'+
    '<div class="cad-lista">'+listaMembros+'</div>';
}

/* ---------- Modal criar/editar equipe ---------- */
function openEquipeModal(equipe){
  var isNew = !equipe || !equipe.id;
  var ed = Object.assign({ name:'', description:'', sector:'', color:'#3B6FF7', is_active:true }, equipe || {});
  // opções de escopo: cruzada + todos os departamentos ativos
  var setorOpts = '<option value="">Cruzada (qualquer departamento)</option>' +
    (ST.departamentos||[]).filter(function(d){ return d.is_active!==false; })
      .map(function(d){ return '<option value="'+esc(d.key)+'"'+(String(ed.sector||'')===d.key?' selected':'')+'>'+esc(d.label)+'</option>'; })
      .join('');
  var cores = ['#3B6FF7','#8B5CF6','#16A34A','#F59E0B','#EF4444','#0EA5E9','#EC4899','#14B8A6'];
  var coresHTML = cores.map(function(c){ return '<button type="button" class="dp-cor-opt'+(ed.color===c?' on':'')+'" data-eq-cor="'+c+'" style="background:'+c+'"></button>'; }).join('');

  var contMembros = isNew ? '' : '<div class="cad-explica">Esta equipe tem <b>'+((equipe.membros||[]).length)+'</b> membro(s). Para gerenciar membros, feche este modal e use "Adicionar pessoa" na tela da equipe.</div>';

  var m = makeModal({
    title: isNew ? 'Nova equipe' : 'Editar equipe',
    width: 520,
    body:
      '<div class="modal-row"><label class="modal-label">Nome</label>'+
        '<input type="text" id="eqNome" value="'+esc(ed.name)+'" placeholder="Ex: Força-tarefa Black Friday" autofocus></div>'+
      '<div class="modal-row"><label class="modal-label">Descrição <span class="cad-sub">(opcional)</span></label>'+
        '<input type="text" id="eqDesc" value="'+esc(ed.description||'')+'" placeholder="Para que serve esta equipe?"></div>'+
      '<div class="modal-row"><label class="modal-label">Escopo</label>'+
        '<select id="eqSetor">'+setorOpts+'</select>'+
        '<div class="cad-explica">Um escopo de departamento limita a equipe a pessoas daquele setor. "Cruzada" aceita qualquer pessoa.</div>'+
      '</div>'+
      '<div class="modal-row"><label class="modal-label">Cor</label>'+
        '<div class="dp-cor-grid" id="eqCorGrid">'+coresHTML+'</div>'+
      '</div>'+
      contMembros,
    saveLabel: isNew ? 'Criar equipe' : 'Salvar',
    onSave: function(close, root){
      var payload = {
        name: (root.querySelector('#eqNome').value||'').trim(),
        description: (root.querySelector('#eqDesc').value||'').trim(),
        sector: root.querySelector('#eqSetor').value || null,
        color: ed.color,
        is_active: ed.is_active!==false
      };
      if (!payload.name){ toast('Digite o nome','error'); return; }
      var duplo = (ST.equipes||[]).find(function(x){
        return (!ed.id || String(x.id)!==String(ed.id)) &&
               (x.name||'').toLowerCase()===payload.name.toLowerCase();
      });
      if (duplo){ toast('Já existe uma equipe com esse nome','error'); return; }
      equipeSalvar(Object.assign({}, ed, payload), close);
    }
  });

  // bind cores
  m.root.querySelectorAll('[data-eq-cor]').forEach(function(b){
    b.addEventListener('click', function(){
      ed.color = this.getAttribute('data-eq-cor');
      m.root.querySelectorAll('[data-eq-cor]').forEach(function(x){ x.classList.toggle('on', x.getAttribute('data-eq-cor')===ed.color); });
    });
  });
}

/* ---------- Salvar ---------- */
function equipeSalvar(eq, cb){
  var isNew = !eq.id;
  var payload = {
    name: eq.name, description: eq.description || null,
    sector: eq.sector || null, color: eq.color || '#3B6FF7',
    is_active: eq.is_active!==false
  };
  if (isNew){
    sb.from('malba_equipes').insert(payload).select().single().then(function(r){
      if (r.error){
        var m = (r.error.message||'').toLowerCase();
        if (m.indexOf('does not exist')!==-1) toast('Rode o SQL-cadastros-fase4.sql no Supabase.','error');
        else toast('Não consegui criar: '+(r.error.message||''),'error');
        return;
      }
      var novo = Object.assign({}, r.data, { membros: [] });
      ST.equipes = (ST.equipes||[]).concat([novo]);
      if (cb) cb();
      toast('Equipe criada','success'); renderPage();
    });
  } else {
    sb.from('malba_equipes').update(payload).eq('id', eq.id).then(function(r){
      if (r.error){ toast('Não consegui salvar: '+(r.error.message||''),'error'); return; }
      var i = (ST.equipes||[]).findIndex(function(x){ return String(x.id)===String(eq.id); });
      if (i>=0) ST.equipes[i] = Object.assign(ST.equipes[i], payload);
      if (cb) cb();
      toast('Equipe salva','success'); renderPage();
    });
  }
}

/* ---------- Adicionar membro ---------- */
function openAddMembroEquipe(equipeId){
  var eq = (ST.equipes||[]).find(function(x){ return String(x.id)===String(equipeId); });
  if (!eq) return;
  // candidatos: quem ainda não é membro E respeita o escopo da equipe
  var jaSao = new Set((eq.membros||[]).map(String));
  var candidatos = (ST.allUsers||[]).filter(function(u){
    if (jaSao.has(String(u.id))) return false;
    if (eq.sector && String(u.sector||'')!==String(eq.sector)) return false;
    return true;
  }).sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); });

  if (!candidatos.length){
    var msg = eq.sector
      ? 'Todos do departamento "'+((SECTORS[eq.sector]||{label:eq.sector}).label)+'" já estão nesta equipe, ou não há mais pessoas neste departamento.'
      : 'Todas as pessoas com acesso ao sistema já estão nesta equipe.';
    toast(msg, 'info'); return;
  }

  var linhas = candidatos.map(function(u){
    var setLb = u.sector ? ((SECTORS[u.sector]||{label:u.sector}).label) : '—';
    return '<label class="cad-eq-pick"><input type="checkbox" data-add-uid="'+esc(u.id)+'">'+
      '<span class="cad-eq-av" style="background:'+esc(u.color||'#64748B')+'">'+esc(iniciais(u.name||''))+'</span>'+
      '<span class="cad-eq-pick-main"><b>'+esc(u.name||'')+'</b><span>'+esc(setLb)+'</span></span>'+
    '</label>';
  }).join('');

  makeModal({
    title: 'Adicionar pessoas a '+eq.name,
    width: 520,
    body:
      '<p class="cad-explica">'+(eq.sector ? 'Só pessoas do departamento "'+esc((SECTORS[eq.sector]||{label:eq.sector}).label)+'" aparecem aqui.' : 'Equipe cruzada — qualquer pessoa pode entrar.')+'</p>'+
      '<div class="cad-eq-picks">'+linhas+'</div>',
    saveLabel: 'Adicionar selecionadas',
    onSave: function(close, root){
      var ids = [...root.querySelectorAll('[data-add-uid]:checked')].map(function(c){ return c.getAttribute('data-add-uid'); });
      if (!ids.length){ toast('Selecione ao menos uma pessoa','error'); return; }
      var payloads = ids.map(function(uid){ return { equipe_id: eq.id, user_id: uid }; });
      sb.from('malba_equipe_membros').insert(payloads).select().then(function(r){
        if (r.error){ toast('Não consegui adicionar: '+(r.error.message||''),'error'); return; }
        eq.membros = (eq.membros||[]).concat(ids.map(String));
        close();
        toast(ids.length+' pessoa'+(ids.length===1?'':'s')+' adicionada'+(ids.length===1?'':'s'),'success');
        renderPage();
      });
    }
  });
}

/* ---------- Remover membro ---------- */
function equipeRemoverMembro(equipeId, userId){
  var eq = (ST.equipes||[]).find(function(x){ return String(x.id)===String(equipeId); });
  if (!eq) return;
  sb.from('malba_equipe_membros').delete().eq('equipe_id', equipeId).eq('user_id', userId).then(function(r){
    if (r.error){ toast('Não consegui remover: '+(r.error.message||''),'error'); return; }
    eq.membros = (eq.membros||[]).filter(function(x){ return String(x)!==String(userId); });
    toast('Pessoa removida da equipe','success'); renderPage();
  });
}

/* ---------- Remover equipe ---------- */
function equipeRemover(id){
  var eq = (ST.equipes||[]).find(function(x){ return String(x.id)===String(id); });
  if (!eq) return;
  var qtd = (eq.membros||[]).length;
  var msg = qtd
    ? 'Esta equipe tem '+qtd+' pessoa'+(qtd===1?'':'s')+'. Elas continuam existindo (só saem desta equipe). Remover mesmo assim?'
    : 'Remover a equipe "'+eq.name+'"?';
  confirmDialog({
    title:'Remover equipe', message:msg, confirmLabel:'Remover',
    onConfirm: function(){
      // remove membros primeiro, depois a equipe
      sb.from('malba_equipe_membros').delete().eq('equipe_id', id).then(function(){
        sb.from('malba_equipes').delete().eq('id', id).then(function(r){
          if (r.error){ toast('Não consegui remover','error'); return; }
          ST.equipes = (ST.equipes||[]).filter(function(x){ return String(x.id)!==String(id); });
          toast('Equipe removida','success');
          if (ST.central && ST.central.equipeId===id) ST.central.nav='equipes';
          renderPage();
        });
      });
    }
  });
}

/* ---------- Bind ---------- */
function bindCentralEquipes(){
  var nova = document.getElementById('cadNovaEquipe');
  if (nova) nova.addEventListener('click', function(){ openEquipeModal({}); });
  document.querySelectorAll('[data-eq-open]').forEach(function(b){
    b.addEventListener('click', function(){
      ST.central.equipeId = this.getAttribute('data-eq-open');
      ST.central.nav = 'equipe';
      renderPage();
    });
  });
}
function bindCentralEquipeDetalhe(){
  var edit = document.getElementById('eqEditar');
  if (edit) edit.addEventListener('click', function(){
    var eq = (ST.equipes||[]).find(function(x){ return String(x.id)===String(ST.central.equipeId); });
    if (eq) openEquipeModal(eq);
  });
  var add = document.getElementById('eqAddMembro');
  if (add) add.addEventListener('click', function(){ openAddMembroEquipe(ST.central.equipeId); });
  document.querySelectorAll('[data-eq-rem]').forEach(function(b){
    b.addEventListener('click', function(){ equipeRemoverMembro(ST.central.equipeId, this.getAttribute('data-eq-rem')); });
  });
}

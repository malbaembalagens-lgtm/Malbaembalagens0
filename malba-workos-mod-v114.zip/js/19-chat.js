/* ========== [10l] CHAT EFÊMERO (Realtime broadcast — nada é salvo) ========== */
var chatChannel=null, chatMsgs=[];
function chatTeardown(){ if (chatChannel) { try{ sb.removeChannel(chatChannel); }catch(e){} chatChannel=null; } }
function chatStartOfDayISO(){ var d=new Date(); d.setHours(0,0,0,0); return d.toISOString(); }
function chatTime(ts){ try{ var d=new Date(ts); return pad(d.getHours())+':'+pad(d.getMinutes()); }catch(e){ return ''; } }
function chatHTML() {
  var setorLabel = SECTORS[ST.sector] ? SECTORS[ST.sector].label : '';
  return '<div class="chat-wrap">'+
    '<div class="chat-head"><div><h2>Chat da equipe</h2><div class="sub">Setor '+esc(setorLabel)+' · mensagens de hoje</div></div><div class="chat-online" id="chatOnline"><span class="chat-on-dot"></span>conectando…</div></div>'+
    '<div class="chat-note">As mensagens ficam guardadas só durante o dia e são limpas automaticamente à meia-noite, para não pesar o sistema.</div>'+
    '<div class="chat-msgs" id="chatMsgs"><div class="chat-empty">Carregando…</div></div>'+
    '<div class="chat-input">'+
      '<input type="file" id="chatFile" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt" style="display:none">'+
      '<button class="chat-attach" id="chatAttach" title="Anexar imagem ou arquivo">'+icon('folder')+'</button>'+
      '<input type="text" id="chatInput" placeholder="Escreva uma mensagem…" autocomplete="off" maxlength="500">'+
      '<button class="btn btn-primary" id="chatSend">'+icon('chat')+'Enviar</button>'+
    '</div>'+
  '</div>';
}
function bindChat() {
  var u=ST.session.user;
  var sector=ST.sector;
  var storeId=ST.store?ST.store.id:(scopeStore()||null);
  chatMsgs=[]; var seen={};
  var msgsEl=document.getElementById('chatMsgs');
  var input=document.getElementById('chatInput');
  var sendBtn=document.getElementById('chatSend');
  var attachBtn=document.getElementById('chatAttach');
  var fileEl=document.getElementById('chatFile');
  var onlineEl=document.getElementById('chatOnline');

  function bubbleContent(m){
    if (m.kind==='image' && m.file_url) return '<a href="'+esc(m.file_url)+'" target="_blank" rel="noopener"><img class="chat-img" src="'+esc(m.file_url)+'" alt="imagem"></a>';
    if (m.kind==='file' && m.file_url) return '<a class="chat-file" href="'+esc(m.file_url)+'" target="_blank" rel="noopener" download>'+icon('folder')+'<span>'+esc(m.file_name||'arquivo')+'</span></a>';
    return '<span class="chat-text">'+esc(m.body||'')+'</span>';
  }
  function renderMsgs(){
    if (chatMsgs.length===0){ msgsEl.innerHTML='<div class="chat-empty">Comece a conversa com a equipe.</div>'; return; }
    msgsEl.innerHTML=chatMsgs.map(function(m){
      var mine=String(m.user_id)===String(u.id);
      var av = mine?'':'<span class="chat-av" style="background:'+(m.user_color||'#3B6FF7')+'">'+esc(iniciais(m.user_name||'?'))+'</span>';
      return '<div class="chat-msg'+(mine?' mine':'')+'">'+av+'<div class="chat-bubble">'+(mine?'':'<span class="chat-name">'+esc(m.user_name||'')+'</span>')+bubbleContent(m)+'<span class="chat-time">'+chatTime(m.created_at)+'</span></div></div>';
    }).join('');
    msgsEl.scrollTop=msgsEl.scrollHeight;
  }
  function addMsg(m){ if(!m||!m.id||seen[m.id]) return; seen[m.id]=1; chatMsgs.push(m); if(chatMsgs.length>300) chatMsgs.shift(); renderMsgs(); }

  // 1) carrega as mensagens de HOJE
  sb.from('malba_chat_messages').select('*').eq('sector',sector).gte('created_at',chatStartOfDayISO()).order('created_at',{ascending:true}).limit(400).then(function(r){
    if (r.error){ msgsEl.innerHTML='<div class="chat-empty">Não foi possível carregar o chat.</div>'; console.error(r.error); return; }
    (r.data||[]).forEach(addMsg);
    if (chatMsgs.length===0) renderMsgs();
  });

  // 2) tempo real via broadcast (entrega imediata) + presença (online)
  chatTeardown();
  var ch = sb.channel('chat-'+sector, { config:{ broadcast:{ self:false }, presence:{ key:u.id } } });
  ch.on('broadcast', { event:'msg' }, function(p){ if(p && p.payload) addMsg(p.payload); });
  ch.on('presence', { event:'sync' }, function(){ if(onlineEl){ var st=ch.presenceState(); onlineEl.innerHTML='<span class="chat-on-dot"></span>'+Object.keys(st).length+' online'; } });
  ch.subscribe(function(status){
    if (status==='SUBSCRIBED') ch.track({ name:u.name, at:Date.now() });
    else if (status==='CHANNEL_ERROR' || status==='TIMED_OUT') { if(onlineEl) onlineEl.innerHTML='<span class="chat-on-dot off"></span>sem conexão'; }
  });
  chatChannel=ch;

  function persistAndBroadcast(row){
    sb.from('malba_chat_messages').insert(row).select().single().then(function(r){
      if (r.error || !r.data){ toast('Erro ao enviar','error'); console.error(r.error); return; }
      addMsg(r.data);
      try{ ch.send({ type:'broadcast', event:'msg', payload:r.data }); }catch(e){}
    });
  }
  function sendText(){
    var txt=(input.value||'').trim(); if(!txt) return;
    input.value=''; input.focus();
    persistAndBroadcast({ sector:sector, store_unit_id:storeId, user_id:u.id, user_name:u.name, user_color:u.color||'#3B6FF7', kind:'text', body:txt });
  }
  sendBtn.addEventListener('click', sendText);
  input.addEventListener('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); sendText(); } });

  // 3) anexos (imagem / arquivo)
  attachBtn.addEventListener('click', function(){ fileEl.click(); });
  fileEl.addEventListener('change', function(){
    var file=fileEl.files && fileEl.files[0]; if(!file) return;
    if (file.size > 10*1024*1024){ toast('Arquivo muito grande (máx. 10MB)','error'); fileEl.value=''; return; }
    attachBtn.disabled=true; var oldOnline=onlineEl?onlineEl.innerHTML:''; if(onlineEl) onlineEl.innerHTML='<span class="chat-on-dot"></span>enviando anexo…';
    var clean=(file.name||'arquivo').replace(/[^\w.\-]+/g,'_').slice(-60);
    var path=sector+'/'+u.id+'-'+Date.now()+'-'+clean;
    sb.storage.from('chat-anexos').upload(path, file, { cacheControl:'3600', upsert:false }).then(function(up){
      attachBtn.disabled=false; if(onlineEl) onlineEl.innerHTML=oldOnline;
      if (up.error){ toast('Falha no upload','error'); console.error(up.error); fileEl.value=''; return; }
      var pub=sb.storage.from('chat-anexos').getPublicUrl(path);
      var url=pub && pub.data ? pub.data.publicUrl : null;
      var isImg=/^image\//.test(file.type);
      persistAndBroadcast({ sector:sector, store_unit_id:storeId, user_id:u.id, user_name:u.name, user_color:u.color||'#3B6FF7', kind:isImg?'image':'file', body:null, file_url:url, file_name:file.name, file_type:file.type });
      fileEl.value='';
    });
  });

  input.focus();
}
